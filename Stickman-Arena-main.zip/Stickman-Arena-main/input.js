(function (root) {
  "use strict";

  var CONTROL_PRESETS = Object.freeze({
    hybrid: "hybrid",
    keyboard: "keyboard"
  });

  function clamp(value, low, high) {
    return Math.max(low, Math.min(high, value));
  }

  function normalizeAim(x, y, fallback) {
    x = Number(x);
    y = Number(y);
    if (!Number.isFinite(x)) x = 0;
    if (!Number.isFinite(y)) y = 0;
    var magnitude = Math.sqrt(x * x + y * y);
    if (!magnitude) return { x: fallback < 0 ? -1 : 1, y: 0 };
    return { x: x / magnitude, y: clamp(y / magnitude, -1, 1) };
  }

  function createPointerController() {
    var position = { x: 0, y: 0, inside: false };
    var attackPointerId = null;
    var pickupPointerId = null;
    var attackHeld = false;
    var attackPulse = false;
    var pickupPulse = false;

    function setPosition(x, y, inside) {
      if (Number.isFinite(x)) position.x = x;
      if (Number.isFinite(y)) position.y = y;
      if (inside != null) position.inside = !!inside;
    }

    function setInside(value) {
      position.inside = !!value;
      if (!position.inside) attackHeld = false;
    }

    function press(button, pointerId) {
      if (button === 0) {
        if (attackPointerId != null || attackPulse) return false;
        attackPointerId = pointerId;
        attackHeld = true;
        attackPulse = true;
        return true;
      }
      if (button === 2) {
        if (pickupPointerId != null || pickupPulse) return false;
        pickupPointerId = pointerId;
        pickupPulse = true;
        return true;
      }
      return false;
    }

    function releasePointer(pointerId, button) {
      var released = false;
      if ((button == null || button === 0) && attackPointerId === pointerId) {
        attackPointerId = null;
        attackHeld = false;
        released = true;
      }
      if ((button == null || button === 2) && pickupPointerId === pointerId) {
        pickupPointerId = null;
        released = true;
      }
      return released;
    }

    function cancelPointer(pointerId) {
      var canceled = false;
      if (attackPointerId === pointerId) {
        attackPointerId = null;
        attackHeld = false;
        attackPulse = false;
        canceled = true;
      }
      if (pickupPointerId === pointerId) {
        pickupPointerId = null;
        pickupPulse = false;
        canceled = true;
      }
      return canceled;
    }

    function clear() {
      attackPointerId = null;
      pickupPointerId = null;
      attackHeld = false;
      attackPulse = false;
      pickupPulse = false;
    }

    function read() {
      var value = {
        x: position.x,
        y: position.y,
        inside: position.inside,
        attack: attackHeld || attackPulse,
        pickup: pickupPulse
      };
      attackPulse = false;
      pickupPulse = false;
      return value;
    }

    function visual() {
      return {
        x: position.x,
        y: position.y,
        inside: position.inside,
        attackHeld: attackHeld,
        attackPointerId: attackPointerId,
        pickupPointerId: pickupPointerId
      };
    }

    return {
      setPosition: setPosition,
      setInside: setInside,
      press: press,
      releasePointer: releasePointer,
      cancelPointer: cancelPointer,
      clear: clear,
      read: read,
      visual: visual
    };
  }

  function mapActor(options) {
    options = options || {};
    var fighter = options.fighter || {};
    var keys = options.keys || {};
    var pointer = options.pointer || {};
    var touch = options.touch || {};
    var touchButtons = touch.buttons || {};
    var preset = options.preset === CONTROL_PRESETS.keyboard ? CONTROL_PRESETS.keyboard : CONTROL_PRESETS.hybrid;
    var facing = fighter.facing < 0 ? -1 : 1;
    var moveX = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
    var moveFacing = Math.abs(moveX) > 0.12 ? (moveX < 0 ? -1 : 1) : facing;
    var aim = { x: moveFacing, y: 0 };

    if (preset === CONTROL_PRESETS.hybrid && pointer.inside) {
      aim = normalizeAim(pointer.aimX, pointer.aimY, moveFacing);
    } else if (preset === CONTROL_PRESETS.keyboard) {
      var keyboardDirection = (keys.ArrowDown ? 1 : 0) - (keys.ArrowUp ? 1 : 0);
      aim = keyboardDirection
        ? { x: moveFacing * 0.8660254037844387, y: keyboardDirection * 0.5 }
        : { x: moveFacing, y: 0 };
    }

    var frame = {
      id: fighter.id == null ? 0 : fighter.id,
      moveX: clamp(moveX, -1, 1),
      moveY: 0,
      aimX: aim.x,
      aimY: aim.y,
      weaponSlot: keys.KeyQ ? 1 : null,
      buttons: {
        jump: !!(keys.KeyW || keys.Space),
        attack: !!(keys.KeyF || (preset === CONTROL_PRESETS.hybrid && pointer.attack)),
        pickup: !!(keys.KeyE || (preset === CONTROL_PRESETS.hybrid && pointer.pickup)),
        reload: !!keys.KeyR,
        drop: !!keys.KeyS,
        rematch: false
      }
    };

    if (touch.moveActive) {
      frame.moveX = clamp(Number(touch.moveX) || 0, -1, 1);
      frame.moveY = clamp(Number(touch.moveY) || 0, -1, 1);
      if (Math.abs(frame.moveX) > 0.12) {
        frame.aimX = frame.moveX < 0 ? -1 : 1;
        frame.aimY = 0;
      }
    }
    if (touch.aimActive) {
      var touchAim = normalizeAim(touch.aimX, touch.aimY, frame.aimX);
      frame.aimX = touchAim.x;
      frame.aimY = touchAim.y;
    }
    frame.buttons.jump = frame.buttons.jump || !!touchButtons.jump;
    frame.buttons.attack = frame.buttons.attack || !!touchButtons.attack;
    frame.buttons.pickup = frame.buttons.pickup || !!touchButtons.pickup;
    frame.buttons.reload = frame.buttons.reload || !!touchButtons.reload;
    frame.buttons.drop = frame.buttons.drop || !!touchButtons.drop;
    if (touchButtons.unarmed) frame.weaponSlot = 1;
    return frame;
  }

  root.StickInput = Object.freeze({
    CONTROL_PRESETS: CONTROL_PRESETS,
    createPointerController: createPointerController,
    mapActor: mapActor
  });
}(typeof window !== "undefined" ? window : globalThis));
