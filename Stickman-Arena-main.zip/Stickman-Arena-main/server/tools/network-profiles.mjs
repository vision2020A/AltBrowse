import { AuthoritativeMatch } from "../src/authoritative-match.mjs";
import { Netcode, Sim } from "../src/shared-runtime.mjs";

const MAX_INPUT_QUEUE = 120;
const MAX_SNAPSHOT_QUEUE = 256;
const MAX_DELIVERIES_PER_TICK = 4;
const MAX_OUTBOUND_BYTES = 256 * 1024;
const PROFILE_TICKS = 900;

const PROFILES = Object.freeze([
  Object.freeze({
    name: "latency",
    inputDelay: () => 9,
    snapshotDelay: () => 9,
    drop: () => false,
  }),
  Object.freeze({
    name: "jitter",
    inputDelay: (tick, actor) => [2, 8, 4, 13, 3, 6][(tick + actor) % 6],
    snapshotDelay: (tick) => [3, 11, 5, 14, 4][tick % 5],
    drop: () => false,
  }),
  Object.freeze({
    name: "burst-reorder",
    inputDelay: (tick, actor) => (tick + actor) % 12 === 0 ? 18 : (tick % 3),
    snapshotDelay: (tick) => tick % 15 < 5 ? 20 - (tick % 15) : 2,
    drop: () => false,
  }),
  Object.freeze({
    name: "loss",
    inputDelay: (tick, actor) => (tick + actor) % 5,
    snapshotDelay: (tick) => tick % 7,
    drop: (tick, channel, actor = 0) =>
      (tick * 17 + actor * 7 + (channel === "snapshot" ? 5 : 0)) % 29 === 0,
  }),
]);

function buttons(attack) {
  return {
    jump: false,
    attack,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
  };
}

function command(generation, sequence, clientTick, actor) {
  return {
    generation,
    sequence,
    clientTick,
    moveX: sequence % 80 < 40 ? 0.8 : -0.8,
    moveY: 0,
    aimX: actor === 0 ? 1 : -1,
    aimY: 0,
    weaponSlot: null,
    buttons: buttons(sequence % 12 === 0),
  };
}

function enqueue(queue, item, limit, label) {
  queue.push(item);
  if (queue.length > limit) throw new Error(`${label} queue exceeded ${limit}`);
}

function deliverDue(queue, tick, callback) {
  const due = queue
    .filter((entry) => entry.deliverAt <= tick)
    .sort((left, right) => left.deliverAt - right.deliverAt || right.order - left.order)
    .slice(0, MAX_DELIVERIES_PER_TICK);
  for (const entry of due) {
    queue.splice(queue.indexOf(entry), 1);
    callback(entry);
  }
  return due.length;
}

function createModel(generation) {
  return Netcode.createClientModel({
    actorId: 0,
    generation,
    fixedUpdate: Sim.fixedUpdate,
  });
}

function runProfile(profile) {
  const match = new AuthoritativeMatch({ seed: 0x79c20001 });
  match.bind("actor-0", 0, 1);
  match.bind("actor-1", 1, 1);
  let model = createModel(1);
  const sessions = ["actor-0", "actor-1"];
  const sequences = [0, 0];
  const inputQueue = [];
  const snapshotQueue = [];
  let queuedSnapshotBytes = 0;
  let maxInputQueue = 0;
  let maxSnapshotQueue = 0;
  let maxDeliveredPerTick = 0;
  let droppedInputs = 0;
  let droppedSnapshots = 0;
  let staleSnapshotsRejected = 0;
  let wrongGenerationRejected = 0;
  let staleCallbackDrops = 0;
  let disconnectedInputDrops = 0;
  let acceptedInputs = 0;
  let rejectedInputs = 0;
  let maxPendingInputs = 0;
  let replayedInputs = 0;
  let acknowledgedInputsPruned = 0;
  let maxAcknowledgedSequence = -1;
  let reconnects = 0;
  let generationRestarts = 0;
  let order = 0;
  let callbackEpoch = 1;
  let staleGenerationSnapshot = null;
  const acceptedByGenerationAndActor = new Map();

  function recordAccepted(generation, actor) {
    const key = `${generation}:${actor}`;
    acceptedByGenerationAndActor.set(key, (acceptedByGenerationAndActor.get(key) || 0) + 1);
  }

  function ingestSnapshot(entry) {
    queuedSnapshotBytes -= entry.bytes;
    if (entry.callbackEpoch !== callbackEpoch) {
      staleCallbackDrops += 1;
      return;
    }
    const pendingBefore = model.getStatus().pendingInputCount;
    const result = model.ingestSnapshot(entry.snapshot);
    const status = model.getStatus();
    acknowledgedInputsPruned += Math.max(0, pendingBefore - status.pendingInputCount);
    replayedInputs += result.replayed || 0;
    maxAcknowledgedSequence = Math.max(maxAcknowledgedSequence, status.latestAckSequence);
    if (!result.accepted && result.reason === "stale") staleSnapshotsRejected += 1;
    if (!result.accepted && /generation/.test(result.reason)) wrongGenerationRejected += 1;
  }

  for (let harnessTick = 0; harnessTick < PROFILE_TICKS; harnessTick += 1) {
    if (harnessTick === 300) {
      const reservation = match.disconnect("actor-0");
      if (!reservation.accepted) throw new Error("disconnect profile could not reserve actor");
      sessions[0] = null;
      callbackEpoch += 1;
      for (let index = snapshotQueue.length - 1; index >= 0; index -= 1) {
        const entry = snapshotQueue[index];
        queuedSnapshotBytes -= entry.bytes;
        snapshotQueue.splice(index, 1);
        staleCallbackDrops += 1;
      }
      for (let index = inputQueue.length - 1; index >= 0; index -= 1) {
        if (inputQueue[index].actor !== 0) continue;
        inputQueue.splice(index, 1);
        disconnectedInputDrops += 1;
      }
    }
    if (harnessTick === 330) {
      const rebound = match.bind("actor-0-reconnected", 0, 2, []);
      if (!rebound.accepted) throw new Error("reconnect profile could not rebind actor");
      sessions[0] = "actor-0-reconnected";
      model = createModel(match.generation);
      reconnects += 1;
    }

    for (let actor = 0; actor < 2; actor += 1) {
      if (!sessions[actor]) continue;
      const payload = actor === 0
        ? model.createInputMessage(
          command(match.generation, 0, match.state.tick, actor),
          match.state.tick,
        )
        : command(match.generation, sequences[actor]++, match.state.tick, actor);
      maxPendingInputs = Math.max(
        maxPendingInputs,
        model.getStatus().pendingInputCount,
      );
      if (profile.drop(harnessTick, "input", actor)) {
        droppedInputs += 1;
        continue;
      }
      enqueue(inputQueue, {
        actor,
        deliverAt: harnessTick + profile.inputDelay(harnessTick, actor),
        order: order++,
        session: sessions[actor],
        payload,
      }, MAX_INPUT_QUEUE, "input");
    }

    maxDeliveredPerTick = Math.max(maxDeliveredPerTick, deliverDue(
      inputQueue,
      harnessTick,
      ({ actor, session, payload }) => {
        if (!match.actorBySession.has(session)) {
          disconnectedInputDrops += 1;
          return;
        }
        const result = match.accept(session, payload, harnessTick * 1000 / 60);
        if (result.accepted) {
          acceptedInputs += 1;
          recordAccepted(payload.generation, actor);
        } else if ([
          "stale-sequence",
          "stale-generation",
          "future-generation",
          "stale-tick",
        ].includes(result.reason)) {
          rejectedInputs += 1;
        } else {
          throw new Error(`unexpected input rejection: ${result.reason}`);
        }
      },
    ));
    match.step();

    if (sessions[0] && match.state.tick % 3 === 0) {
      const events = match.drainEvents();
      const snapshot = match.snapshot(sessions[0], events);
      if (profile.drop(harnessTick, "snapshot")) {
        droppedSnapshots += 1;
      } else {
        const bytes = Buffer.byteLength(JSON.stringify(snapshot));
        queuedSnapshotBytes += bytes;
        if (queuedSnapshotBytes > MAX_OUTBOUND_BYTES) {
          throw new Error("snapshot backpressure exceeded the runtime byte ceiling");
        }
        enqueue(snapshotQueue, {
          bytes,
          callbackEpoch,
          deliverAt: harnessTick + profile.snapshotDelay(harnessTick),
          order: order++,
          snapshot,
        }, MAX_SNAPSHOT_QUEUE, "snapshot");
      }
    }

    maxDeliveredPerTick = Math.max(maxDeliveredPerTick, deliverDue(
      snapshotQueue,
      harnessTick,
      ingestSnapshot,
    ));

    if (harnessTick === 600) {
      staleGenerationSnapshot = match.snapshot(sessions[0], []);
      match.state.match.phase = "finished";
      const restarted = match.restartGeneration();
      if (!restarted.accepted || restarted.generation !== 2) {
        throw new Error("network generation restart failed");
      }
      model = createModel(restarted.generation);
      sequences[0] = 0;
      sequences[1] = 0;
      const before = model.getStatus();
      const stale = model.ingestSnapshot(staleGenerationSnapshot);
      if (stale.accepted || stale.reason !== "stale-generation") {
        throw new Error("stale generation mutated the restarted client");
      }
      if (model.getStatus().latestSnapshotTick !== before.latestSnapshotTick) {
        throw new Error("stale generation changed client history");
      }
      wrongGenerationRejected += 1;
      generationRestarts += 1;
    }

    maxInputQueue = Math.max(maxInputQueue, inputQueue.length);
    maxSnapshotQueue = Math.max(maxSnapshotQueue, snapshotQueue.length);
    const status = model.getStatus();
    maxPendingInputs = Math.max(maxPendingInputs, status.pendingInputCount);
    if (status.pendingInputCount > Netcode.MAX_HISTORY_LIMIT
        || status.pendingEventCount > Netcode.MAX_PENDING_EVENTS
        || status.eventIdentityCount > Netcode.MAX_EVENT_IDENTITY_HISTORY) {
      throw new Error("client history exceeded its runtime bound");
    }
  }

  for (let flushTick = PROFILE_TICKS;
    flushTick < PROFILE_TICKS + MAX_SNAPSHOT_QUEUE && snapshotQueue.length;
    flushTick += 1) {
    maxDeliveredPerTick = Math.max(maxDeliveredPerTick, deliverDue(
      snapshotQueue,
      flushTick,
      ingestSnapshot,
    ));
  }
  if (snapshotQueue.length || queuedSnapshotBytes !== 0) {
    throw new Error("bounded snapshot catch-up did not drain");
  }
  if (maxDeliveredPerTick > MAX_DELIVERIES_PER_TICK) {
    throw new Error("snapshot catch-up exceeded its per-tick delivery bound");
  }

  const beforeProcessRestart = model.getStatus();
  const freshProcessModel = createModel(1);
  const future = freshProcessModel.ingestSnapshot(match.snapshot(sessions[0], []));
  if (future.accepted || future.reason !== "future-generation") {
    throw new Error("pre-restart generation entered a fresh process model");
  }
  if (freshProcessModel.getStatus().latestSnapshotTick !== -1
      || beforeProcessRestart.generation !== 2) {
    throw new Error("process restart did not isolate client history");
  }
  wrongGenerationRejected += 1;
  for (const generation of [1, 2]) {
    for (const actor of [0, 1]) {
      if (!acceptedByGenerationAndActor.get(`${generation}:${actor}`)) {
        throw new Error(`generation ${generation} actor ${actor} accepted no input`);
      }
    }
  }
  if (maxPendingInputs === 0 || replayedInputs === 0 || acknowledgedInputsPruned === 0
      || maxAcknowledgedSequence < 0) {
    throw new Error("prediction and acknowledgement paths were not exercised");
  }

  return {
    profile: profile.name,
    simulatedTicks: PROFILE_TICKS,
    latencyModel: "deterministic application-level queue at 60 Hz",
    maxInputQueue,
    maxSnapshotQueue,
    maxDeliveredPerTick,
    droppedInputs,
    droppedSnapshots,
    disconnectedInputDrops,
    staleSnapshotsRejected,
    wrongGenerationRejected,
    staleCallbackDrops,
    acceptedInputs,
    rejectedInputs,
    maxPendingInputs,
    replayedInputs,
    acknowledgedInputsPruned,
    maxAcknowledgedSequence,
    reconnects,
    generationRestarts,
    finalGeneration: match.generation,
    finalTick: match.state.tick,
    accepted: true,
  };
}

function exerciseBackpressure() {
  const match = new AuthoritativeMatch({ seed: 0x79c20002 });
  match.bind("actor-0", 0, 1);
  match.bind("actor-1", 1, 1);
  const snapshot = match.snapshot("actor-0", []);
  const bytes = Buffer.byteLength(JSON.stringify(snapshot));
  let queuedBytes = 0;
  let acceptedSnapshots = 0;
  while (queuedBytes + bytes <= MAX_OUTBOUND_BYTES) {
    queuedBytes += bytes;
    acceptedSnapshots += 1;
  }
  const rejectedAtBytes = queuedBytes + bytes;
  if (rejectedAtBytes <= MAX_OUTBOUND_BYTES || queuedBytes > MAX_OUTBOUND_BYTES) {
    throw new Error("backpressure model did not stop at the runtime ceiling");
  }
  return {
    snapshotApplicationBytes: bytes,
    acceptedSnapshots,
    queuedBytes,
    rejectedAtBytes,
    ceilingBytes: MAX_OUTBOUND_BYTES,
    expectedTerminalClose: true,
  };
}

try {
  const profiles = PROFILES.map(runProfile);
  const report = {
    schema: 1,
    label: "deterministic synthetic network evidence; not packet, browser, or public-network evidence",
    units: {
      tick: "one 1/60 second harness step",
      queue: "decoded application messages, not wire packets",
    },
    limits: {
      maxInputQueue: MAX_INPUT_QUEUE,
      maxSnapshotQueue: MAX_SNAPSHOT_QUEUE,
      maxDeliveriesPerTick: MAX_DELIVERIES_PER_TICK,
      maxOutboundApplicationBytes: MAX_OUTBOUND_BYTES,
    },
    exercised: [
      "latency",
      "jitter",
      "burst",
      "reorder",
      "loss",
      "disconnect-reconnect",
      "generation-restart",
      "process-restart-isolation",
      "backpressure",
    ],
    profiles,
    backpressure: exerciseBackpressure(),
    accepted: profiles.every((profile) => profile.accepted),
  };
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} catch (error) {
  process.stderr.write(`network profiles failed: ${error.message}\n`);
  process.exitCode = 1;
}
