import os from "node:os";
import { spawn } from "node:child_process";
import { monitorEventLoopDelay, performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";
import { Client } from "@colyseus/sdk";
import { CloseCode, matchMaker } from "@colyseus/core";

import { createApplication } from "../src/app.config.mjs";
import { roomRegistry } from "../src/room-registry.mjs";
import { Netcode } from "../src/shared-runtime.mjs";
import { createOperationsLogger } from "../src/operations.mjs";
import { createRuntimeConfig } from "../src/runtime-config.mjs";

const PROFILES = Object.freeze({
  short: Object.freeze({
    rooms: 2,
    warmupMs: 1_000,
    measureMs: 2_000,
    sampleMs: 100,
    reconnectCycles: 1,
    floodRooms: 2,
  }),
  soak: Object.freeze({
    rooms: 8,
    warmupMs: 60_000,
    measureMs: 30 * 60_000,
    sampleMs: 1_000,
    reconnectCycles: 4,
    floodRooms: 4,
  }),
});

const CATCH_UP_STEP_LIMIT = 12;
const SNAPSHOT_TICK_DELTA_LIMIT = 30;
const EVENT_LOOP_DELAY_LIMIT_MS = 250;
const DEFAULT_PORT = 2579;
const INDEX_PATH = fileURLToPath(new URL("../src/index.mjs", import.meta.url));

function selectedProfile() {
  const argument = process.argv.find((value) => value.startsWith("--profile="));
  const positionalIndex = process.argv.indexOf("--profile");
  const name = argument?.slice("--profile=".length)
    || (positionalIndex >= 0 ? process.argv[positionalIndex + 1] : "short");
  if (!Object.hasOwn(PROFILES, name)) {
    throw new Error("profile must be short or soak");
  }
  return { name, ...PROFILES[name] };
}

function selectedPort() {
  const value = process.env.LOAD_PORT;
  if (value === undefined) return DEFAULT_PORT;
  if (!/^[1-9][0-9]{0,4}$/.test(value)) throw new Error("LOAD_PORT is invalid");
  const port = Number(value);
  if (port > 65535) throw new Error("LOAD_PORT is invalid");
  return port;
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function waitForCondition(predicate, message, timeoutMs = 5_000) {
  const deadline = performance.now() + timeoutMs;
  while (performance.now() < deadline) {
    if (predicate()) return;
    await delay(10);
  }
  throw new Error(message);
}

function withTimeout(promise, message, timeoutMs = 8_000) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error(message)), timeoutMs);
    }),
  ]).finally(() => clearTimeout(timer));
}

function onceMessage(room, type, timeoutMs = 5_000) {
  return new Promise((resolve, reject) => {
    let unsubscribe = () => {};
    const timer = setTimeout(() => {
      unsubscribe();
      reject(new Error(`${type} message exceeded its deadline`));
    }, timeoutMs);
    unsubscribe = room.onMessage(type, (message) => {
      clearTimeout(timer);
      unsubscribe();
      resolve(message);
    });
  });
}

function onceSignal(signal, label, timeoutMs = 8_000) {
  return new Promise((resolve, reject) => {
    const callback = (...values) => {
      clearTimeout(timer);
      signal.remove(callback);
      resolve(values);
    };
    const timer = setTimeout(() => {
      signal.remove(callback);
      reject(new Error(`${label} exceeded its deadline`));
    }, timeoutMs);
    signal(callback);
  });
}

async function onceReconnect(room) {
  await onceSignal(room.onReconnect, "reconnect");
}

function onceLeave(room) {
  return onceSignal(room.onLeave, "leave").then(([code]) => code);
}

function compatibilityOptions(operation) {
  const options = {
    compatibility: Netcode.createCompatibilityOffer(),
    operation,
  };
  if (operation !== "join-code") {
    options.modeId = "free-for-all";
    options.mapId = "original-arena";
  }
  return options;
}

function neutralButtons(attack = false) {
  return {
    jump: false,
    attack,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
  };
}

async function bootstrap(room) {
  room.onMessage("lifecycle", () => {});
  room.onMessage("match-start", () => {});
  room.onMessage("control-rejected", () => {});
  room.onMessage("input-rejected", () => {});
  const helloPromise = onceMessage(room, "server-hello");
  room.send("protocol-request", {});
  const hello = await helloPromise;
  if (!Netcode.validateCurrentServerHello(hello).accepted) {
    throw new Error("server hello was incompatible");
  }
  const assignmentPromise = onceMessage(room, "assignment");
  room.send("hello-ack", hello);
  const assignment = await assignmentPromise;
  const snapshotPromise = onceMessage(room, "snapshot");
  room.send("ready", { generation: assignment.generation });
  await snapshotPromise;
  return assignment;
}

function resourceCounts() {
  const counts = {};
  for (const type of process.getActiveResourcesInfo()) {
    counts[type] = (counts[type] || 0) + 1;
  }
  return Object.fromEntries(Object.entries(counts).sort(([left], [right]) =>
    left.localeCompare(right)));
}

function registryCounts() {
  const { liveRooms, codeRooms } = roomRegistry.snapshot();
  return { liveRooms, codeRooms };
}

function backendResourcesCleared(backend) {
  return backend.lifecycle === "disposed"
    && backend.handshakeTimers.size === 0
    && backend.rematchVotes.size === 0
    && backend.controlRateWindows.size === 0
    && backend.reservations.size === 0
    && backend.admittedSessions.size === 0
    && backend.readySessions.size === 0
    && backend.negotiatingSessions.size === 0
    && backend.helloSentSessions.size === 0
    && backend.initialWaitingTimer === null
    && backend.resultsTimer === null
    && backend.generationReadyTimer === null
    && backend.match.actorBySession.size === 0;
}

function collectBounded(stream, maximumBytes = 64 * 1024) {
  let output = "";
  stream.setEncoding("utf8");
  stream.on("data", (chunk) => {
    if (output.length < maximumBytes) output += chunk.slice(0, maximumBytes - output.length);
  });
  return () => output;
}

function waitForChildExit(child, timeoutMs = 8_000) {
  if (child.exitCode !== null || child.signalCode !== null) {
    return Promise.resolve({ code: child.exitCode, signal: child.signalCode });
  }
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      child.removeListener("exit", onExit);
      reject(new Error("recovery process exit exceeded its deadline"));
    }, timeoutMs);
    const onExit = (code, signal) => {
      clearTimeout(timer);
      resolve({ code, signal });
    };
    child.once("exit", onExit);
  });
}

async function waitForProbe(origin, path, child, timeoutMs = 5_000) {
  const deadline = performance.now() + timeoutMs;
  while (performance.now() < deadline) {
    if (child.exitCode !== null) throw new Error("recovery process exited before probes");
    try {
      const remainingMs = Math.max(1, Math.ceil(deadline - performance.now()));
      const response = await fetch(`${origin}${path}`, {
        signal: AbortSignal.timeout(Math.min(500, remainingMs)),
      });
      if (response.status === 200) return true;
    } catch {
      // The fresh listener may not be bound yet.
    }
    await delay(25);
  }
  throw new Error(`${path} recovery probe exceeded its deadline`);
}

async function exerciseFreshProcessRecovery(port) {
  const child = spawn(process.execPath, [INDEX_PATH], {
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      PORT: String(port),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const stdout = collectBounded(child.stdout);
  const stderr = collectBounded(child.stderr);
  try {
    const origin = `http://127.0.0.1:${port}`;
    await waitForProbe(origin, "/livez", child);
    await waitForProbe(origin, "/readyz", child);
    if (!child.kill("SIGTERM")) throw new Error("recovery process did not accept SIGTERM");
    const exit = await waitForChildExit(child);
    if (exit.code !== 0 || exit.signal !== null || stderr() !== "") {
      throw new Error("recovery process did not drain cleanly");
    }
    const records = stdout().trim().split("\n").filter(Boolean).map(JSON.parse);
    if (records.at(-1)?.reason !== "stopped") {
      throw new Error("recovery process omitted its stopped record");
    }
    return {
      live: true,
      ready: true,
      exitCode: exit.code,
      stopped: true,
    };
  } finally {
    if (child.exitCode === null) child.kill("SIGKILL");
  }
}

function memorySample() {
  const memory = process.memoryUsage();
  return {
    rssBytes: memory.rss,
    heapUsedBytes: memory.heapUsed,
    externalBytes: memory.external,
    arrayBuffersBytes: memory.arrayBuffers,
  };
}

function updatePeak(peak, sample) {
  for (const key of Object.keys(sample)) peak[key] = Math.max(peak[key] || 0, sample[key]);
}

function createMetrics() {
  return {
    active: false,
    snapshotCount: 0,
    snapshotBytes: 0,
    eventCount: 0,
    eventBytes: 0,
    staleGenerationEffects: 0,
    maxSnapshotTickDelta: 0,
    latestByRoom: new WeakMap(),
    maxAckByRoom: new WeakMap(),
    inputRejections: 0,
    fixedSteps: 0,
    maxFixedStepGapMs: 0,
    maxCatchUpSteps: 0,
    stepSeries: new WeakMap(),
    peakRooms: 0,
  };
}

function observeClientRoom(room, metrics) {
  room.onMessage("input-rejected", () => {
    metrics.inputRejections += 1;
  });
  room.onMessage("snapshot", (snapshot) => {
    const previous = metrics.latestByRoom.get(room);
    if (previous) {
      if (snapshot.generation < previous.generation
          || (snapshot.generation === previous.generation && snapshot.tick <= previous.tick)) {
        metrics.staleGenerationEffects += 1;
      } else if (snapshot.generation === previous.generation) {
        metrics.maxSnapshotTickDelta = Math.max(
          metrics.maxSnapshotTickDelta,
          snapshot.tick - previous.tick,
        );
      }
    }
    metrics.latestByRoom.set(room, {
      generation: snapshot.generation,
      tick: snapshot.tick,
    });
    if (Number.isSafeInteger(snapshot.ackSequence)) {
      metrics.maxAckByRoom.set(
        room,
        Math.max(metrics.maxAckByRoom.get(room) ?? -1, snapshot.ackSequence),
      );
    }
    if (!metrics.active) return;
    metrics.snapshotCount += 1;
    metrics.snapshotBytes += Buffer.byteLength(JSON.stringify(snapshot));
    const events = Array.isArray(snapshot.events) ? snapshot.events : [];
    metrics.eventCount += events.length;
    metrics.eventBytes += Buffer.byteLength(JSON.stringify(events));
  });
}

function observeBackend(backend, metrics) {
  const original = backend.fixedStep.bind(backend);
  backend.fixedStep = (context) => {
    const now = performance.now();
    const prior = metrics.stepSeries.get(backend) || {
      lastAt: null,
      catchUpSteps: 0,
    };
    if (prior.lastAt !== null) {
      const gap = now - prior.lastAt;
      metrics.maxFixedStepGapMs = Math.max(metrics.maxFixedStepGapMs, gap);
      prior.catchUpSteps = gap < 1 ? prior.catchUpSteps + 1 : 1;
      metrics.maxCatchUpSteps = Math.max(metrics.maxCatchUpSteps, prior.catchUpSteps);
    }
    prior.lastAt = now;
    metrics.stepSeries.set(backend, prior);
    if (metrics.active) metrics.fixedSteps += 1;
    return original(context);
  };
}

function updatePeakRooms(metrics) {
  metrics.peakRooms = Math.max(metrics.peakRooms, roomRegistry.snapshot().liveRooms);
}

async function createQuickRooms(origin, count, metrics, allRooms) {
  const entries = [];
  for (let index = 0; index < count; index += 1) {
    const first = await withTimeout(
      new Client(origin).joinOrCreate(
        "arena",
        compatibilityOptions("quick-match"),
      ),
      "first quick-match request exceeded its deadline",
    );
    const second = await withTimeout(
      new Client(origin).joinOrCreate(
        "arena",
        compatibilityOptions("quick-match"),
      ),
      "second quick-match request exceeded its deadline",
    );
    allRooms.add(first);
    allRooms.add(second);
    observeClientRoom(first, metrics);
    observeClientRoom(second, metrics);
    const backend = matchMaker.getLocalRoomById(first.roomId);
    if (!backend || first.roomId !== second.roomId) throw new Error("Room pairing failed");
    observeBackend(backend, metrics);
    await Promise.all([bootstrap(first), bootstrap(second)]);
    entries.push({
      backend,
      rooms: [first, second],
      generation: backend.match.generation,
      sequences: [0, 0],
      rematches: 0,
      rematchPromise: null,
      rematchError: null,
    });
    updatePeakRooms(metrics);
  }
  return entries;
}

function startValidTraffic(entries, { autoRematch = false } = {}) {
  return setInterval(() => {
    for (const entry of entries) {
      if (autoRematch && entry.backend.lifecycle === "finished" && !entry.rematchPromise) {
        entry.rematchPromise = restartEntry(entry)
          .catch((error) => {
            entry.rematchError = error;
          })
          .finally(() => {
            entry.rematchPromise = null;
          });
      }
      entry.generation = entry.backend.match.generation;
      entry.rooms.forEach((room, actorIndex) => {
        const sequence = entry.sequences[actorIndex]++;
        const tick = entry.backend.match.state.tick;
        try {
          room.send("input", {
            generation: entry.generation,
            sequence,
            clientTick: tick,
            moveX: sequence % 80 < 40 ? 0.75 : -0.75,
            moveY: 0,
            aimX: actorIndex === 0 ? 1 : -1,
            aimY: 0,
            weaponSlot: null,
            buttons: neutralButtons(sequence % 12 === 0),
          });
        } catch {
          // Shutdown may close the transport between interval iterations.
        }
      });
    }
  }, 50);
}

async function restartEntry(entry) {
  const assignmentPromises = entry.rooms.map((room) => onceMessage(room, "assignment"));
  for (const room of entry.rooms) {
    room.send("rematch-vote", { generation: entry.backend.match.generation, vote: true });
  }
  const assignments = await Promise.all(assignmentPromises);
  entry.generation = assignments[0].generation;
  entry.sequences = [0, 0];
  const snapshots = entry.rooms.map((room) => onceMessage(room, "snapshot"));
  entry.rooms.forEach((room) => room.send("ready", { generation: entry.generation }));
  await Promise.all(snapshots);
  await waitForCondition(
    () => entry.backend.lifecycle === "playing",
    "rematch did not pass the fresh ready barrier",
  );
  entry.rematches += 1;
}

async function settleBackgroundRematches(entries) {
  await Promise.all(entries.map((entry) => entry.rematchPromise).filter(Boolean));
  const failed = entries.find((entry) => entry.rematchError);
  if (failed) throw failed.rematchError;
}

async function exerciseRematches(entries) {
  await settleBackgroundRematches(entries);
  for (const entry of entries) entry.backend.match.state.match.ticksRemaining = 1;
  await Promise.all(entries.map((entry) => waitForCondition(
    () => entry.backend.lifecycle === "finished",
    "Room did not reach compact results",
  )));
  await Promise.all(entries.map(restartEntry));
}

async function exerciseReconnects(entries, cycles) {
  const originalInfo = console.info;
  console.info = () => {};
  try {
    for (let cycle = 0; cycle < cycles; cycle += 1) {
      await Promise.all(entries.map(async (entry) => {
      const roomIndex = cycle % entry.rooms.length;
      const room = entry.rooms[roomIndex];
        room.reconnection.minUptime = 0;
        room.reconnection.maxRetries = 9;
        room.reconnection.maxEnqueuedMessages = 0;
        const reconnected = onceReconnect(room);
        void room.leave(false);
        await withTimeout(reconnected, "simultaneous reconnect wave did not reconnect");
        const assignment = await bootstrap(room);
        entry.sequences[roomIndex] = 0;
        if (assignment.generation !== entry.backend.match.generation) {
          throw new Error("reconnect crossed match generation");
        }
      }));
    }
  } finally {
    console.info = originalInfo;
  }
}

async function exerciseCreateJoinFlood(origin, count, metrics, allRooms, retainedRoomCount) {
  const creators = await Promise.all(Array.from({ length: count }, async () => {
    const room = await withTimeout(
      new Client(origin).create("arena", compatibilityOptions("create-match")),
      "create-match request exceeded its deadline",
    );
    allRooms.add(room);
    observeClientRoom(room, metrics);
    const backend = matchMaker.getLocalRoomById(room.roomId);
    if (!backend) throw new Error("created Room backend was unavailable");
    observeBackend(backend, metrics);
    return room;
  }));
  updatePeakRooms(metrics);
  const joiners = await Promise.all(creators.map(async (creator) => {
    const room = await withTimeout(
      new Client(origin).joinById(
        creator.roomId,
        compatibilityOptions("join-code"),
      ),
      "join-code request exceeded its deadline",
    );
    allRooms.add(room);
    observeClientRoom(room, metrics);
    return room;
  }));
  await Promise.all(creators.flatMap((creator, index) => [
    bootstrap(creator),
    bootstrap(joiners[index]),
  ]));
  await Promise.all([...creators, ...joiners].map((room) => room.leave(true)));
  await waitForCondition(
    () => roomRegistry.snapshot().liveRooms === retainedRoomCount,
    "create/join flood Rooms did not recover",
  );
}

async function exerciseControlAbuse(origin, metrics, allRooms, retainedRoomCount) {
  const room = await withTimeout(
    new Client(origin).joinOrCreate(
      "arena",
      compatibilityOptions("quick-match"),
    ),
    "control-abuse matchmaking exceeded its deadline",
  );
  allRooms.add(room);
  observeClientRoom(room, metrics);
  const backend = matchMaker.getLocalRoomById(room.roomId);
  if (!backend) throw new Error("control-abuse Room backend was unavailable");
  observeBackend(backend, metrics);
  await bootstrap(room);
  room.onMessage("server-hello", () => {});
  const left = onceLeave(room);
  for (let attempt = 0; attempt < 4; attempt += 1) room.send("protocol-request", {});
  const code = await withTimeout(left, "control abuse did not terminate the sender");
  if (code !== CloseCode.WITH_ERROR) {
    throw new Error("control abuse used an unexpected close code");
  }
  await waitForCondition(
    () => roomRegistry.snapshot().liveRooms === retainedRoomCount,
    "control-abuse Room did not recover",
  );
}

async function exerciseBackpressure(origin, metrics, allRooms, retainedRoomCount) {
  const first = await withTimeout(
    new Client(origin).joinOrCreate(
      "arena",
      compatibilityOptions("quick-match"),
    ),
    "backpressure first matchmaking exceeded its deadline",
  );
  const second = await withTimeout(
    new Client(origin).joinOrCreate(
      "arena",
      compatibilityOptions("quick-match"),
    ),
    "backpressure second matchmaking exceeded its deadline",
  );
  allRooms.add(first);
  allRooms.add(second);
  observeClientRoom(first, metrics);
  observeClientRoom(second, metrics);
  const backend = matchMaker.getLocalRoomById(first.roomId);
  if (!backend) throw new Error("backpressure Room backend was unavailable");
  observeBackend(backend, metrics);
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  const original = backend.clientBufferedAmount.bind(backend);
  backend.clientBufferedAmount = (client) => client === serverClient ? 256 * 1024 : original(client);
  const left = onceLeave(first);
  backend.sendSnapshot(serverClient);
  await withTimeout(left, "backpressure injection did not terminate the slow client");
  await second.leave(true);
  await waitForCondition(
    () => roomRegistry.snapshot().liveRooms === retainedRoomCount,
    "backpressure Room did not recover",
  );
}

async function main() {
  const profile = selectedProfile();
  const port = selectedPort();
  const origin = `http://127.0.0.1:${port}`;
  const conditions = {
    profile: profile.name,
    node: process.version,
    platform: `${os.platform()} ${os.release()}`,
    cpuModel: os.cpus()[0]?.model || "unknown",
    logicalCpuCount: os.cpus().length,
    hostMemoryBytes: os.totalmem(),
    port,
    topology: "one process; two humans plus two server bots per Room",
  };
  const metrics = createMetrics();
  const operationLines = [];
  const application = createApplication(createRuntimeConfig({ PORT: String(port) }), {
    operationsLogger: createOperationsLogger({
      buildId: Netcode.SERVER_BUILD_ID,
      write: (line) => operationLines.push(line),
    }),
  });
  const allRooms = new Set();
  const beforeStart = {
    memory: memorySample(),
    resources: resourceCounts(),
  };
  let traffic = null;
  let memoryTimer = null;
  let eventLoop;
  try {
    await application.listen();
    application.markReady();
    const entries = await createQuickRooms(origin, profile.rooms, metrics, allRooms);
    traffic = startValidTraffic(entries, { autoRematch: profile.name === "soak" });
    await delay(profile.warmupMs);
    const afterWarmup = memorySample();
    const peakMemory = { ...afterWarmup };
    const cpuStart = process.cpuUsage();
    const measureStartedAt = performance.now();
    eventLoop = monitorEventLoopDelay({ resolution: 10 });
    eventLoop.enable();
    eventLoop.reset();
    metrics.active = true;
    memoryTimer = setInterval(() => updatePeak(peakMemory, memorySample()), profile.sampleMs);
    await delay(profile.measureMs);
    clearInterval(traffic);
    traffic = null;
    await settleBackgroundRematches(entries);

    await exerciseRematches(entries);
    await exerciseReconnects(entries, profile.reconnectCycles);
    await exerciseCreateJoinFlood(
      origin,
      profile.floodRooms,
      metrics,
      allRooms,
      profile.rooms,
    );
    await exerciseControlAbuse(origin, metrics, allRooms, profile.rooms);
    await exerciseBackpressure(origin, metrics, allRooms, profile.rooms);
    const validTrafficExpectedClients = entries.length * 2;
    const validTrafficAcknowledgedClients = entries
      .flatMap((entry) => entry.rooms)
      .filter((room) => (metrics.maxAckByRoom.get(room) ?? -1) >= 0)
      .length;
    const validTrafficInputRejections = metrics.inputRejections;
    updatePeak(peakMemory, memorySample());
    metrics.active = false;
    clearInterval(memoryTimer);
    memoryTimer = null;
    const measuredMs = performance.now() - measureStartedAt;
    const cpu = process.cpuUsage(cpuStart);
    eventLoop.disable();

    const beforeShutdown = {
      memory: memorySample(),
      resources: resourceCounts(),
      registry: registryCounts(),
    };
    const shutdownLeaves = entries.flatMap((entry) => entry.rooms.map(onceLeave));
    traffic = startValidTraffic(entries);
    await delay(250);
    const shutdownStartedAt = performance.now();
    const shutdown = await application.shutdown();
    const shutdownMs = performance.now() - shutdownStartedAt;
    clearInterval(traffic);
    traffic = null;
    const closeCodes = await withTimeout(
      Promise.all(shutdownLeaves),
      "clients did not observe graceful shutdown",
    );
    await delay(1_000);
    const afterShutdown = {
      memory: memorySample(),
      resources: resourceCounts(),
      registry: registryCounts(),
    };
    const backendRecovery = entries.every((entry) => backendResourcesCleared(entry.backend));
    const stoppedPhase = application.serviceState.snapshot().phase === "stopped";
    const forbiddenResources = ["TCPServerWrap", "TCPSocketWrap", "Timeout"]
      .filter((type) => afterShutdown.resources[type]);
    const freshProcess = await exerciseFreshProcessRecovery(port);
    await delay(100);
    const afterRecoveryResources = resourceCounts();
    const cpuMicros = cpu.user + cpu.system;
    const failures = [];
    if (metrics.staleGenerationEffects !== 0) failures.push("stale-generation-effect");
    if (metrics.maxCatchUpSteps > CATCH_UP_STEP_LIMIT) failures.push("simulation-catch-up");
    if (metrics.maxSnapshotTickDelta > SNAPSHOT_TICK_DELTA_LIMIT) {
      failures.push("snapshot-tick-gap");
    }
    if (validTrafficAcknowledgedClients !== validTrafficExpectedClients
        || validTrafficInputRejections !== 0) failures.push("valid-input-traffic");
    const eventLoopMaxMs = eventLoop.max / 1e6;
    if (eventLoopMaxMs > EVENT_LOOP_DELAY_LIMIT_MS) failures.push("event-loop-delay");
    if (!shutdown.accepted || !stoppedPhase || !backendRecovery
        || afterShutdown.registry.liveRooms !== 0 || afterShutdown.registry.codeRooms !== 0
        || forbiddenResources.length !== 0 || !freshProcess.ready || !freshProcess.stopped) {
      failures.push("resource-recovery");
    }
    if (closeCodes.some((code) => code !== 4001)) failures.push("shutdown-close-code");
    const report = {
      schema: 1,
      label: "local sample; not a production capacity claim",
      conditions,
      configuration: {
        rooms: profile.rooms,
        humanClients: profile.rooms * 2,
        serverBots: profile.rooms * 2,
        warmupMs: profile.warmupMs,
        steadyMeasureMs: profile.measureMs,
        steadyAndScenarioMeasuredMs: Math.round(measuredMs),
        simultaneousReconnectWaves: profile.reconnectCycles,
        createJoinFloodRooms: profile.floodRooms,
        completedRematches: entries.reduce((total, entry) => total + entry.rematches, 0),
        controlAbuse: "one terminal sender",
        backpressure: "one injected slow sender",
      },
      measurements: {
        cpuOneCorePercent: Number((cpuMicros / (measuredMs * 10)).toFixed(2)),
        cpuUserMicros: cpu.user,
        cpuSystemMicros: cpu.system,
        memoryAfterWarmup: afterWarmup,
        peakMemory,
        snapshotCount: metrics.snapshotCount,
        snapshotApplicationBytes: metrics.snapshotBytes,
        snapshotApplicationBytesPerSecond: Math.round(
          metrics.snapshotBytes / (measuredMs / 1_000),
        ),
        eventCount: metrics.eventCount,
        eventApplicationBytes: metrics.eventBytes,
        validTraffic: {
          expectedClients: validTrafficExpectedClients,
          acknowledgedClients: validTrafficAcknowledgedClients,
          inputRejections: validTrafficInputRejections,
        },
        eventLoopDelayMs: {
          p50: Number((eventLoop.percentile(50) / 1e6).toFixed(3)),
          p99: Number((eventLoop.percentile(99) / 1e6).toFixed(3)),
          max: Number(eventLoopMaxMs.toFixed(3)),
        },
        simulation: {
          fixedSteps: metrics.fixedSteps,
          maxFixedStepGapMs: Number(metrics.maxFixedStepGapMs.toFixed(3)),
          maxCatchUpStepsWithoutOneMillisecondYield: metrics.maxCatchUpSteps,
          maxSnapshotTickDelta: metrics.maxSnapshotTickDelta,
          staleGenerationEffects: metrics.staleGenerationEffects,
        },
        peakConcurrentRooms: metrics.peakRooms,
        shutdownMs: Number(shutdownMs.toFixed(3)),
        shutdownCloseCodes: closeCodes,
        operationsRecords: operationLines.length,
      },
      recovery: {
        beforeStart,
        beforeShutdown,
        afterShutdown,
        backendResourcesCleared: backendRecovery,
        stoppedPhase,
        forbiddenResources,
        freshProcess,
        afterRecoveryResources,
        rssDeltaFromWarmupBytes: afterShutdown.memory.rssBytes - afterWarmup.rssBytes,
        heapDeltaFromWarmupBytes: afterShutdown.memory.heapUsedBytes - afterWarmup.heapUsedBytes,
      },
      thresholds: {
        maxCatchUpStepsWithoutOneMillisecondYield: CATCH_UP_STEP_LIMIT,
        maxSnapshotTickDelta: SNAPSHOT_TICK_DELTA_LIMIT,
        maxEventLoopDelayMs: EVENT_LOOP_DELAY_LIMIT_MS,
      },
      scenarios: [
        "valid-input-traffic",
        "concurrent-rooms",
        "compact-rematch",
        "simultaneous-reconnect-wave",
        "create-join-flood",
        "control-abuse",
        "backpressure",
        "graceful-shutdown-under-load",
      ],
      failures,
      accepted: failures.length === 0,
    };
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
    if (failures.length) process.exitCode = 1;
  } finally {
    metrics.active = false;
    if (memoryTimer) clearInterval(memoryTimer);
    if (traffic) clearInterval(traffic);
    eventLoop?.disable();
    if (application.serviceState.snapshot().phase !== "stopped") {
      await application.shutdown().catch(() => {});
    }
    for (const room of allRooms) {
      try {
        void room.leave(true).catch(() => {});
      } catch {
        // The terminal scenario or application shutdown may already own close.
      }
    }
  }
}

try {
  await main();
} catch (error) {
  process.stderr.write(`load/soak failed: ${error.message}\n`);
  process.exitCode = 1;
}
