module.exports = {
  apps: [{
    name: "stickman-arena",
    script: "src/index.mjs",
    instances: 1,
    exec_mode: "fork",
    watch: false,
    wait_ready: true,
    listen_timeout: 12_000,
    kill_timeout: 7_000,
  }],
};
