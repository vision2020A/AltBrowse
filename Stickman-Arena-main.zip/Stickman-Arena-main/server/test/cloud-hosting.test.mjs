import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const require = createRequire(import.meta.url);
const ecosystem = require("../ecosystem.config.cjs");
const packageManifest = require("../package.json");
const indexPath = fileURLToPath(new URL("../src/index.mjs", import.meta.url));
const sdkUrl = new URL("../node_modules/@colyseus/sdk/build/index.mjs", import.meta.url).href;
const toolsRolloutSource = readFileSync(
  resolve(dirname(require.resolve("@colyseus/tools")), "../pm2/rollout.cjs"),
  "utf8",
);
const toolsListenSource = readFileSync(
  resolve(dirname(require.resolve("@colyseus/tools")), "index.mjs"),
  "utf8",
);

test("Colyseus Cloud entrypoint stays one-process and uses the existing server owner", () => {
  assert.deepEqual(ecosystem, {
    apps: [{
      name: "stickman-arena",
      script: "src/index.mjs",
      instances: 1,
      exec_mode: "fork",
      watch: false,
      wait_ready: true,
      listen_timeout: 12_000,
      kill_timeout: 7_000,
    }],
  });
  assert.equal(packageManifest.scripts.build, "node --check src/index.mjs");
  assert.equal(packageManifest.scripts.start, "node src/index.mjs");
  assert.equal(Object.hasOwn(ecosystem.apps[0], "env"), false);
  assert.match(toolsRolloutSource, /const BASE_PORT = 2567;/);
  assert.match(
    toolsRolloutSource,
    /function socketPort\(nodeAppInstance\) \{\s*return BASE_PORT \+ Number\(nodeAppInstance\);\s*\}/,
  );
  assert.match(
    toolsListenSource,
    /const socketPath = `\/run\/colyseus\/\$\{port\}\.sock`;/,
  );
  assert.match(
    toolsListenSource,
    /await server\.listen\(\s*socketPath,\s*0/,
  );
});

test("Cloud listen binds the pinned tools Unix socket and sends PM2 ready", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const listenDir = mkdtempSync(join(tmpdir(), "stickman-cloud-listen-"));
  const listenPath = join(listenDir, "2567.sock");
  const source = `
    const { connect } = await import("node:net");
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const sent = [];
    process.send = (message) => {
      if (message === "ready") sent.push(message);
      return true;
    };
    const application = createApplication(Object.freeze({
      ...createRuntimeConfig({
        PORT: "25975",
        NODE_ENV: "production",
        COLYSEUS_CLOUD: "provider-marker",
        NODE_APP_INSTANCE: "0",
        STICKMAN_SERVER_MODE: "public",
        STICKMAN_BIND_HOST: "0.0.0.0",
        STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
        STICKMAN_ALLOWED_ORIGINS:
          "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      }),
      listenPath: ${JSON.stringify(listenPath)},
    }), {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    await application.listen();
    application.markReady();
    const address = application.httpServer.address();
    const socket = connect(${JSON.stringify(listenPath)});
    const livez = await new Promise((resolve, reject) => {
      let response = "";
      socket.setTimeout(2000, () => reject(new Error("unix /livez timed out")));
      socket.on("error", reject);
      socket.on("data", (chunk) => {
        response += chunk.toString("latin1");
        if (response.includes("\\r\\n\\r\\n")) resolve(response);
      });
      socket.on("connect", () => socket.write([
        "GET /livez HTTP/1.1",
        "Host: de-fra-1131bd95.colyseus.cloud",
        "Origin: https://xenovoyage.github.io",
        "Connection: close",
        "",
        "",
      ].join("\\r\\n")));
    });
    socket.destroy();
    await application.shutdown();
    process.stdout.write(JSON.stringify({
      sent,
      address,
      livez: livez.split("\\r\\n", 1)[0],
      livezBody: livez.includes('{"status":"live"}'),
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 10_000,
  });
  rmSync(listenDir, { recursive: true, force: true });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  const result = JSON.parse(child.stdout);
  assert.deepEqual(result.sent, ["ready"]);
  assert.equal(result.address, listenPath);
  assert.equal(result.livez, "HTTP/1.1 200 OK");
  assert.equal(result.livezBody, true);
});

test("Cloud environment preload stays quiet and validation still fails closed", () => {
  const child = spawnSync(process.execPath, [indexPath], {
    encoding: "utf8",
    env: {
      PATH: process.env.PATH,
      NODE_ENV: "production",
      COLYSEUS_CLOUD: "provider-marker",
      STICKMAN_SERVER_MODE: "public",
      STICKMAN_BIND_HOST: "0.0.0.0",
      STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
      STICKMAN_ALLOWED_ORIGINS:
        "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
    },
    timeout: 5_000,
  });
  assert.equal(child.status, 1, child.stderr || child.stdout);
  assert.equal(child.stdout, "");
  const records = child.stderr.trim().split("\n").map(JSON.parse);
  assert.equal(records.length, 1);
  assert.deepEqual(
    Object.fromEntries(Object.entries(records[0])
      .filter(([key]) => key !== "timestamp")),
    {
      level: "error",
      event: "service.configuration",
      buildId: "pass12b4b-shutdown",
      reason: "configuration-invalid",
    },
  );
});

test("Cloud APP_ROOT_PATH environment overrides are loaded before validation", () => {
  const root = mkdtempSync(join(tmpdir(), "stickman-cloud-env-"));
  try {
    writeFileSync(join(root, ".env.cloud"), "NODE_APP_INSTANCE=2\n", {
      encoding: "utf8",
      mode: 0o600,
    });
    const child = spawnSync(process.execPath, [indexPath], {
      encoding: "utf8",
      env: {
        PATH: process.env.PATH,
        NODE_ENV: "production",
        APP_ROOT_PATH: root,
        COLYSEUS_CLOUD: "provider-marker",
        NODE_APP_INSTANCE: "0",
        STICKMAN_SERVER_MODE: "public",
        STICKMAN_BIND_HOST: "0.0.0.0",
        STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
        STICKMAN_ALLOWED_ORIGINS:
          "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      },
      timeout: 5_000,
    });
    assert.equal(child.error, undefined, child.error?.message);
    assert.equal(child.status, 1, child.stderr || child.stdout);
    assert.equal(child.stdout, "");
    const records = child.stderr.trim().split("\n").map(JSON.parse);
    assert.equal(records.length, 1);
    assert.deepEqual(
      Object.fromEntries(Object.entries(records[0])
        .filter(([key]) => key !== "timestamp")),
      {
        level: "error",
        event: "service.configuration",
        buildId: "pass12b4b-shutdown",
        reason: "configuration-invalid",
      },
    );
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("Cloud drain closes zero-byte pre-request sockets before framework shutdown", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const listenDir = mkdtempSync(join(tmpdir(), "stickman-cloud-drain-"));
  const listenPath = join(listenDir, "2568.sock");
  const source = `
    const { connect } = await import("node:net");
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const runtimeConfig = Object.freeze({
      ...createRuntimeConfig({
        PORT: "25979",
        NODE_ENV: "production",
        COLYSEUS_CLOUD: "provider-marker",
        NODE_APP_INSTANCE: "1",
        STICKMAN_SERVER_MODE: "public",
        STICKMAN_BIND_HOST: "0.0.0.0",
        STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
        STICKMAN_ALLOWED_ORIGINS:
          "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      }),
      listenPath: ${JSON.stringify(listenPath)},
    });
    const application = createApplication(runtimeConfig, {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    let closeIdleCalls = 0;
    const closeIdleConnections = application.httpServer.closeIdleConnections
      .bind(application.httpServer);
    application.httpServer.closeIdleConnections = () => {
      closeIdleCalls += 1;
      return closeIdleConnections();
    };
    await application.listen();
    application.markReady();
    const socket = connect(${JSON.stringify(listenPath)});
    await new Promise((resolve, reject) => {
      socket.once("connect", resolve);
      socket.once("error", reject);
    });
    const preRequestClosed = new Promise((resolve) => socket.once("close", () => resolve(true)));
    const result = await application.shutdown();
    await preRequestClosed;
    process.stdout.write(JSON.stringify({
      closeIdleCalls,
      preRequestClosed: socket.destroyed,
      result,
      phase: application.serviceState.snapshot().phase,
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 10_000,
  });
  rmSync(listenDir, { recursive: true, force: true });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  const output = JSON.parse(child.stdout);
  assert.ok(output.closeIdleCalls >= 1);
  assert.deepEqual({
    preRequestClosed: output.preRequestClosed,
    result: output.result,
    phase: output.phase,
  }, {
    preRequestClosed: true,
    result: { accepted: true, timedOut: false },
    phase: "stopped",
  });
});

test("public Cloud nginx forwarding headers do not produce the fixed bad-request edge", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const sharedRuntimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const listenDir = mkdtempSync(join(tmpdir(), "stickman-cloud-headers-"));
  const listenPath = join(listenDir, "2567.sock");
  const source = `
    const { connect } = await import("node:net");
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { Netcode } = await import(${JSON.stringify(sharedRuntimeUrl)});
    const application = createApplication(Object.freeze({
      ...createRuntimeConfig({
        PORT: "25981",
        NODE_ENV: "production",
        COLYSEUS_CLOUD: "provider-marker",
        NODE_APP_INSTANCE: "0",
        STICKMAN_SERVER_MODE: "public",
        STICKMAN_BIND_HOST: "0.0.0.0",
        STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
        STICKMAN_ALLOWED_ORIGINS:
          "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      }),
      listenPath: ${JSON.stringify(listenPath)},
    }), {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    await application.listen();
    application.markReady();
    const nginxHeaders = [
      "Host: de-fra-1131bd95.colyseus.cloud",
      "Origin: https://xenovoyage.github.io",
      "Forwarded: for=203.0.113.10;proto=https;host=de-fra-1131bd95.colyseus.cloud",
      "X-Forwarded-For: 203.0.113.10",
      "X-Forwarded-Proto: https",
      "X-Forwarded-Host: de-fra-1131bd95.colyseus.cloud",
      "X-Real-IP: 203.0.113.10",
      "Connection: close",
    ];
    const exchange = (requestLines) => new Promise((resolve, reject) => {
      const socket = connect(${JSON.stringify(listenPath)});
      let response = "";
      let settled = false;
      const finish = (error, value) => {
        if (settled) return;
        settled = true;
        socket.setTimeout(0);
        socket.destroy();
        if (error) reject(error);
        else resolve(value);
      };
      socket.setTimeout(2000, () => finish(new Error("proxy-header request timed out")));
      socket.on("error", (error) => finish(error));
      socket.on("data", (chunk) => {
        response += chunk.toString("latin1");
        if (response.includes("\\r\\n\\r\\n")) finish(null, response);
      });
      socket.on("end", () => finish(null, response));
      socket.on("connect", () => socket.write(requestLines.join("\\r\\n")));
    });
    const livez = await exchange(["GET /livez HTTP/1.1", ...nginxHeaders, "", ""]);
    const readyz = await exchange(["GET /readyz HTTP/1.1", ...nginxHeaders, "", ""]);
    const root = await exchange(["GET / HTTP/1.1", ...nginxHeaders, "", ""]);
    const body = JSON.stringify({
      compatibility: Netcode.createCompatibilityOffer(),
      operation: "quick-match",
      modeId: "free-for-all",
      mapId: "original-arena",
    });
    const matchmake = await exchange([
      "POST /matchmake/joinOrCreate/arena HTTP/1.1",
      ...nginxHeaders,
      "Content-Type: application/json",
      "Content-Length: " + Buffer.byteLength(body),
      "",
      body,
    ]);
    await application.shutdown();
    process.stdout.write(JSON.stringify({
      livez: livez.split("\\r\\n", 1)[0],
      readyz: readyz.split("\\r\\n", 1)[0],
      root: root.split("\\r\\n", 1)[0],
      matchmake: matchmake.split("\\r\\n", 1)[0],
      livezBadRequest: livez.includes('{"error":"bad request"}'),
      matchmakeBadRequest: matchmake.includes('{"error":"bad request"}'),
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 10_000,
  });
  rmSync(listenDir, { recursive: true, force: true });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  const result = JSON.parse(child.stdout);
  assert.equal(result.livez, "HTTP/1.1 200 OK");
  assert.equal(result.readyz, "HTTP/1.1 200 OK");
  assert.equal(result.root, "HTTP/1.1 200 OK");
  assert.equal(result.livezBadRequest, false);
  assert.equal(result.matchmakeBadRequest, false);
  assert.match(result.matchmake, /^HTTP\/1\.1 2\d\d /);
});

test("Cloud drain preserves an in-flight matchmaking request until it quiesces", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const sharedRuntimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const listenDir = mkdtempSync(join(tmpdir(), "stickman-cloud-inflight-"));
  const listenPath = join(listenDir, "2568.sock");
  const source = `
    const { connect } = await import("node:net");
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { Netcode } = await import(${JSON.stringify(sharedRuntimeUrl)});
    const application = createApplication(Object.freeze({
      ...createRuntimeConfig({
        PORT: "25978",
        NODE_ENV: "production",
        COLYSEUS_CLOUD: "provider-marker",
        NODE_APP_INSTANCE: "1",
        STICKMAN_SERVER_MODE: "public",
        STICKMAN_BIND_HOST: "0.0.0.0",
        STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
        STICKMAN_ALLOWED_ORIGINS:
          "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      }),
      listenPath: ${JSON.stringify(listenPath)},
    }), {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    await application.listen();
    application.markReady();
    const body = JSON.stringify({
      compatibility: Netcode.createCompatibilityOffer(),
      operation: "quick-match",
      modeId: "free-for-all",
      mapId: "original-arena",
    });
    const socket = connect(${JSON.stringify(listenPath)});
    socket.on("data", () => {});
    await new Promise((resolve, reject) => {
      socket.once("connect", resolve);
      socket.once("error", reject);
    });
    socket.write([
      "POST /matchmake/joinOrCreate/arena HTTP/1.1",
      "Host: de-fra-1131bd95.colyseus.cloud",
      "Origin: https://xenovoyage.github.io",
      "Content-Type: application/json",
      "Content-Length: " + Buffer.byteLength(body),
      "Connection: close",
      "",
      "",
    ].join("\\r\\n"));
    const deadline = Date.now() + 2000;
    while (application.admissionTracker.snapshot().active !== 1) {
      if (Date.now() >= deadline) throw new Error("matchmaking request was not tracked");
      await new Promise((resolve) => setTimeout(resolve, 5));
    }
    const shutdown = application.shutdown();
    await new Promise((resolve) => setTimeout(resolve, 25));
    const preservedBeforeBody = !socket.destroyed;
    socket.end(body);
    const result = await shutdown;
    process.stdout.write(JSON.stringify({
      preservedBeforeBody,
      result,
      phase: application.serviceState.snapshot().phase,
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 10_000,
  });
  rmSync(listenDir, { recursive: true, force: true });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  assert.deepEqual(JSON.parse(child.stdout), {
    preservedBeforeBody: true,
    result: { accepted: true, timedOut: false },
    phase: "stopped",
  });
});

test("Cloud drain preserves upgraded Room sockets for close code 4001", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const sharedRuntimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const source = `
    const { Client } = await import(${JSON.stringify(sdkUrl)});
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { Netcode } = await import(${JSON.stringify(sharedRuntimeUrl)});
    const local = createRuntimeConfig({ PORT: "25977" });
    const application = createApplication(Object.freeze({ ...local, cloudProxy: true }), {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    await application.listen();
    application.markReady();
    const client = new Client("http://127.0.0.1:25977");
    const options = {
      compatibility: Netcode.createCompatibilityOffer(),
      operation: "quick-match",
      modeId: "free-for-all",
      mapId: "original-arena",
    };
    const rooms = [
      await client.joinOrCreate("arena", options),
      await client.joinOrCreate("arena", options),
    ];
    const onceMessage = (room, type) => new Promise((resolve) => {
      const unsubscribe = room.onMessage(type, (message) => {
        unsubscribe();
        resolve(message);
      });
    });
    const bootstrap = async (room) => {
      room.onMessage("lifecycle", () => {});
      room.onMessage("match-start", () => {});
      const hello = onceMessage(room, "server-hello");
      room.send("protocol-request", {});
      const compatibility = await hello;
      const assignment = onceMessage(room, "assignment");
      room.send("hello-ack", compatibility);
      const assigned = await assignment;
      const snapshot = onceMessage(room, "snapshot");
      room.send("ready", { generation: assigned.generation });
      await snapshot;
    };
    await Promise.all(rooms.map(bootstrap));
    const leaves = rooms.map((room) => new Promise((resolve) => room.onLeave(resolve)));
    const result = await application.shutdown();
    const closeCodes = await Promise.all(leaves);
    process.stdout.write(JSON.stringify({
      closeCodes,
      result,
      phase: application.serviceState.snapshot().phase,
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 15_000,
  });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  assert.deepEqual(JSON.parse(child.stdout), {
    closeCodes: [4001, 4001],
    result: { accepted: true, timedOut: false },
    phase: "stopped",
  });
});
