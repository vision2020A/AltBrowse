import assert from "node:assert/strict";
import test from "node:test";

import {
  DEFAULT_MAX_FUTURE_TICKS,
  DEFAULT_MAX_HELD_INPUT_TICKS,
  DEFAULT_MAX_MESSAGES_PER_SECOND,
  DEFAULT_MAX_PAST_TICKS,
  DEFAULT_MAX_SEQUENCE_ADVANCE,
  EDGE_BUTTON_KEYS,
  HELD_BUTTON_KEYS,
  INPUT_BUTTON_KEYS,
  INPUT_ROOT_KEYS,
  MultiHumanInputAggregator,
} from "../src/input-aggregator.mjs";

function command(overrides = {}) {
  const base = {
    generation: 1,
    sequence: 0,
    clientTick: 0,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: {
      jump: false,
      attack: false,
      pickup: false,
      reload: false,
      drop: false,
      rematch: false,
    },
  };
  const result = { ...base, ...overrides };
  result.buttons = { ...base.buttons, ...(overrides.buttons || {}) };
  return result;
}

function neutralBot(_state, fighter) {
  return {
    id: fighter.id,
    moveX: 0,
    moveY: 0,
    aimX: fighter.facing,
    aimY: 0,
    weaponSlot: null,
    buttons: {
      jump: false,
      attack: false,
      pickup: false,
      reload: false,
      drop: false,
      rematch: false,
    },
  };
}

function state(...fighters) {
  return { fighters: fighters.map(([id, facing = 1]) => ({ id, facing })) };
}

function aggregator(options = {}) {
  return new MultiHumanInputAggregator({
    actorIds: [0],
    botActorIds: [],
    makeBotInput: neutralBot,
    ...options,
  });
}

test("exports the canonical input contract and bounded defaults", () => {
  assert.deepEqual(INPUT_ROOT_KEYS, [
    "generation", "sequence", "clientTick", "moveX", "moveY", "aimX", "aimY", "weaponSlot", "buttons",
  ]);
  assert.deepEqual(INPUT_BUTTON_KEYS, ["jump", "attack", "pickup", "reload", "drop", "rematch"]);
  assert.deepEqual(HELD_BUTTON_KEYS, ["attack"]);
  assert.deepEqual(EDGE_BUTTON_KEYS, ["jump", "pickup", "reload", "drop"]);
  assert.equal(DEFAULT_MAX_FUTURE_TICKS, 120);
  assert.equal(DEFAULT_MAX_PAST_TICKS, 30);
  assert.equal(DEFAULT_MAX_MESSAGES_PER_SECOND, 120);
  assert.equal(DEFAULT_MAX_SEQUENCE_ADVANCE, 120);
  assert.equal(DEFAULT_MAX_HELD_INPUT_TICKS, 60);
  assert.equal(Object.isFrozen(INPUT_ROOT_KEYS), true);
  assert.equal(Object.isFrozen(INPUT_BUTTON_KEYS), true);
});

test("constructor validates actors, bot ownership, callback, and bounds", () => {
  assert.throws(() => new MultiHumanInputAggregator(), /actorIds/);
  assert.throws(() => aggregator({ actorIds: [0, 0] }), /unique/);
  assert.throws(() => aggregator({ actorIds: [-1] }), /nonnegative/);
  assert.throws(() => aggregator({ botActorIds: [1] }), /botActorIds/);
  assert.throws(() => aggregator({ makeBotInput: null }), /makeBotInput/);
  assert.throws(() => aggregator({ maxFutureTicks: -1 }), /maxFutureTicks/);
  assert.throws(() => aggregator({ maxPastTicks: 0.5 }), /maxPastTicks/);
  assert.throws(() => aggregator({ maxMessagesPerSecond: 0 }), /maxMessagesPerSecond/);
  assert.throws(() => aggregator({ maxSequenceAdvance: 0 }), /maxSequenceAdvance/);
  assert.throws(() => aggregator({ maxHeldInputTicks: 0 }), /maxHeldInputTicks/);
  assert.throws(() => aggregator({ generation: 0 }), /generation/);
});

test("accept requires an exact prototype-safe payload with finite bounded fields", () => {
  const inputs = aggregator();
  assert.equal(inputs.bind("player", 0).accepted, true);

  const invalid = [];
  for (const [field, value] of Object.entries({
    actorId: 0,
    targetId: 1,
    position: { x: 50, y: 40 },
    velocity: { x: 1, y: 1 },
    health: 100,
    damage: 99,
    hit: true,
    pickupId: 101,
    inventory: ["rifle"],
    score: 9,
    seed: 123,
    modeId: "forged-mode",
    mapId: "forged-map",
    winnerId: 0,
    result: "win",
  })) invalid.push({ ...command(), [field]: value });
  const missing = command();
  delete missing.aimY;
  invalid.push(missing);
  invalid.push(Object.assign(Object.create({ inherited: true }), command()));
  invalid.push({ ...command(), buttons: { ...command().buttons, damage: true } });
  invalid.push({ ...command(), buttons: { ...command().buttons, attack: 1 } });
  invalid.push(command({ sequence: -1 }));
  invalid.push(command({ generation: 0 }));
  invalid.push(command({ generation: -1 }));
  invalid.push(command({ generation: 1.5 }));
  invalid.push(command({ generation: Number.MAX_SAFE_INTEGER + 1 }));
  invalid.push(command({ sequence: Number.MAX_SAFE_INTEGER + 1 }));
  invalid.push(command({ clientTick: -1 }));
  invalid.push(command({ moveX: Number.NaN }));
  invalid.push(command({ moveY: Infinity }));
  invalid.push(command({ aimX: 1.001 }));
  invalid.push(command({ aimY: -1.001 }));
  invalid.push(command({ weaponSlot: 0 }));
  invalid.push(command({ weaponSlot: 7 }));
  invalid.push(command({ weaponSlot: 1.5 }));
  invalid.push(command({ buttons: { rematch: true } }));

  let getterCalls = 0;
  const accessor = command();
  Object.defineProperty(accessor, "moveX", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return 0;
    },
  });
  invalid.push(accessor);

  for (const payload of invalid) {
    assert.deepEqual(inputs.accept("player", payload, 0, 0), {
      accepted: false,
      reason: "invalid-payload",
    });
  }
  assert.equal(getterCalls, 0, "validation invoked an input accessor");
  assert.equal(inputs.ackFor("player"), null);

  const nullPrototype = Object.assign(Object.create(null), command());
  nullPrototype.buttons = Object.assign(Object.create(null), command().buttons);
  assert.equal(inputs.accept("player", nullPrototype, 0, 0).accepted, true);
});

test("generation mismatch is rejected before sequence, tick, ack, or held state changes", () => {
  const inputs = aggregator({ generation: 2 });
  inputs.bind("player", 0);
  assert.equal(inputs.accept("player", command({ generation: 1, sequence: 90 }), 0, 0).reason,
    "stale-generation");
  assert.equal(inputs.accept("player", command({ generation: 3, sequence: 91 }), 0, 1).reason,
    "future-generation");
  assert.equal(inputs.ackFor("player"), null);
  assert.equal(inputs.accept("player", command({ generation: 2, sequence: 0, moveX: 0.5 }), 0, 2).accepted,
    true);
  assert.deepEqual(inputs.ackFor("player"), {
    sequence: 0,
    clientTick: 0,
    authoritativeTick: 0,
  });
  assert.equal(inputs.frame(state([0]), 0).actors[0].moveX, 0.5);
});

test("ownership, sequence, and client tick windows reject without advancing acknowledgements", () => {
  const inputs = aggregator({
    actorIds: [0, 1],
    botActorIds: [1],
    maxFutureTicks: 2,
    maxPastTicks: 1,
  });
  assert.deepEqual(inputs.bind("bot-thief", 1), { accepted: false, reason: "bot-owned" });
  assert.deepEqual(inputs.bind("unknown", 9), { accepted: false, reason: "unknown-actor" });
  assert.equal(inputs.bind("owner", 0, 4).accepted, true);
  assert.deepEqual(inputs.bind("other", 0), { accepted: false, reason: "actor-owned" });
  assert.equal(inputs.actorFor("owner"), 0);
  assert.equal(inputs.actorFor("missing"), null);

  assert.deepEqual(inputs.accept("missing", command(), 10, 0), {
    accepted: false,
    reason: "unbound-session",
  });
  assert.equal(inputs.accept("owner", command({ sequence: 7, clientTick: 9 }), 10, 0).accepted, true);
  assert.deepEqual(inputs.ackFor("owner"), { sequence: 7, clientTick: 9, authoritativeTick: 10 });

  assert.equal(inputs.accept("owner", command({ sequence: 7, clientTick: 10 }), 10, 1).reason, "stale-sequence");
  assert.equal(inputs.accept("owner", command({ sequence: 8, clientTick: 13 }), 10, 1).reason, "future-tick");
  assert.deepEqual(inputs.ackFor("owner"), { sequence: 7, clientTick: 9, authoritativeTick: 10 });

  assert.equal(inputs.accept("owner", command({ sequence: 8, clientTick: 8 }), 10, 1).reason, "past-tick");
  assert.deepEqual(inputs.ackFor("owner"), { sequence: 7, clientTick: 9, authoritativeTick: 10 });
  assert.equal(inputs.accept("owner", command({ sequence: 8, clientTick: 12 }), 10, 1).accepted, true);
  assert.deepEqual(inputs.ackFor("owner"), { sequence: 8, clientTick: 12, authoritativeTick: 10 });
});

test("future sequence gaps are bounded without pinning the acknowledgement window", () => {
  const inputs = aggregator({ maxSequenceAdvance: 2 });
  assert.equal(inputs.bind("player", 0).accepted, true);
  assert.equal(inputs.accept("player", command({ sequence: 1 }), 0, 0).accepted, true);
  assert.equal(inputs.accept("player", command({ sequence: 3 }), 0, 1).accepted, true);
  assert.equal(inputs.ackFor("player").sequence, 3);
  assert.equal(inputs.accept("player", command({ sequence: 6 }), 0, 2).reason, "future-sequence");
  assert.equal(inputs.ackFor("player").sequence, 3);
  assert.equal(inputs.accept("player", command({ sequence: 4 }), 0, 3).accepted, true);
  assert.equal(inputs.ackFor("player").sequence, 4);
});

test("a connected session's held controls neutralize after the fixed authoritative idle bound", () => {
  const inputs = aggregator({ maxHeldInputTicks: 3 });
  assert.equal(inputs.bind("player", 0).accepted, true);
  assert.equal(inputs.accept("player", command({
    sequence: 0,
    moveX: 1,
    buttons: { attack: true },
  }), 0, 0).accepted, true);
  assert.equal(inputs.frame(state([0]), 0).actors[0].moveX, 1);
  assert.equal(inputs.frame(state([0]), 2).actors[0].buttons.attack, true);
  const neutral = inputs.frame(state([0, -1]), 3).actors[0];
  assert.equal(neutral.moveX, 0);
  assert.equal(neutral.aimX, -1);
  assert.ok(Object.values(neutral.buttons).every((pressed) => pressed === false));
  assert.equal(inputs.ackFor("player").sequence, 0, "neutralization preserves acknowledgement");
  assert.equal(inputs.accept("player", command({ sequence: 1, moveX: -1 }), 3, 3).accepted, true);
  assert.equal(inputs.frame(state([0]), 3).actors[0].moveX, -1);
});

test("held input persists while edge buttons and weapon selection pulse once", () => {
  const inputs = aggregator();
  inputs.bind("player", 0);
  assert.equal(inputs.accept("player", command({
    sequence: 1,
    moveX: -0.75,
    moveY: 0.25,
    aimX: -0.6,
    aimY: 0.8,
    weaponSlot: 4,
    buttons: {
      jump: true,
      attack: true,
      pickup: true,
      reload: true,
      drop: true,
    },
  }), 0, 0).accepted, true);

  const first = inputs.frame(state([0, -1]), 0).actors[0];
  assert.equal(first.id, 0);
  assert.equal(first.moveX, -0.75);
  assert.equal(first.moveY, 0.25);
  assert.equal(first.aimX, -0.6);
  assert.equal(first.aimY, 0.8);
  assert.equal(first.weaponSlot, 4);
  assert.deepEqual(first.buttons, {
    jump: true,
    attack: true,
    pickup: true,
    reload: true,
    drop: true,
    rematch: false,
  });

  const second = inputs.frame(state([0, -1]), 1).actors[0];
  assert.equal(second.moveX, -0.75);
  assert.equal(second.moveY, 0.25);
  assert.equal(second.aimX, -0.6);
  assert.equal(second.aimY, 0.8);
  assert.equal(second.weaponSlot, null);
  assert.deepEqual(second.buttons, {
    jump: false,
    attack: true,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
  });

  assert.equal(inputs.accept("player", command({
    sequence: 2,
    clientTick: 1,
    buttons: { attack: false },
  }), 1, 1).accepted, true);
  assert.equal(inputs.frame(state([0, -1]), 2).actors[0].buttons.attack, false);
});

test("edge latches survive later false messages before the next authoritative frame", () => {
  const inputs = aggregator();
  inputs.bind("player", 0);
  inputs.accept("player", command({
    sequence: 1,
    buttons: { jump: true, attack: true, pickup: true },
  }), 0, 0);
  inputs.accept("player", command({ sequence: 2, weaponSlot: 3 }), 0, 1);
  inputs.accept("player", command({ sequence: 3 }), 0, 2);

  const actor = inputs.frame(state([0]), 0).actors[0];
  assert.equal(actor.buttons.jump, true);
  assert.equal(actor.buttons.attack, true);
  assert.equal(actor.buttons.pickup, true);
  assert.equal(actor.weaponSlot, 3);
  const cleared = inputs.frame(state([0]), 1).actors[0];
  assert.equal(cleared.buttons.jump, false);
  assert.equal(cleared.buttons.attack, false);
  assert.equal(cleared.buttons.pickup, false);
  assert.equal(cleared.weaponSlot, null);
});

test("unbind clears held input, pending edges, acknowledgement, and ownership", () => {
  const inputs = aggregator();
  inputs.bind("old", 0);
  inputs.accept("old", command({
    sequence: 4,
    moveX: 1,
    buttons: { attack: true, jump: true },
  }), 0, 0);
  assert.equal(inputs.unbind("old").accepted, true);
  assert.equal(inputs.actorFor("old"), null);
  assert.equal(inputs.ackFor("old"), null);
  assert.equal(inputs.bind("new", 0).accepted, true);

  const neutral = inputs.frame(state([0, -1]), 0).actors[0];
  assert.equal(neutral.moveX, 0);
  assert.equal(neutral.aimX, -1);
  assert.ok(Object.values(neutral.buttons).every((pressed) => pressed === false));
});

test("rolling rate limit rejects without consuming sequence or changing accepted input", () => {
  const inputs = aggregator({ maxMessagesPerSecond: 2 });
  inputs.bind("player", 0);
  assert.equal(inputs.accept("player", command({ sequence: 1, moveX: -1 }), 0, 0).accepted, true);
  assert.equal(inputs.accept("player", command({ sequence: 2, moveX: 0.5 }), 0, 999).accepted, true);
  assert.deepEqual(inputs.accept("player", command({ sequence: 3, moveX: 1 }), 0, 999), {
    accepted: false,
    reason: "rate-limit",
  });
  assert.deepEqual(inputs.ackFor("player"), { sequence: 2, clientTick: 0, authoritativeTick: 0 });
  assert.equal(inputs.frame(state([0]), 0).actors[0].moveX, 0.5);

  assert.equal(inputs.accept("player", command({ sequence: 3, moveX: 1 }), 0, 1000).accepted, true);
  assert.deepEqual(inputs.ackFor("player"), { sequence: 3, clientTick: 0, authoritativeTick: 0 });
  assert.equal(inputs.frame(state([0]), 1).actors[0].moveX, 1);
});

test("reconnect transfers one actor to a fresh neutral epoch and rejects stale sessions", () => {
  const inputs = aggregator();
  inputs.bind("old", 0, 5);
  inputs.accept("old", command({ sequence: 12, buttons: { attack: true, drop: true } }), 0, 0);

  assert.deepEqual(inputs.reconnect("old", "new", 5), { accepted: false, reason: "stale-epoch" });
  assert.equal(inputs.reconnect("old", "new", 6).accepted, true);
  assert.equal(inputs.actorFor("old"), null);
  assert.equal(inputs.actorFor("new"), 0);
  assert.equal(inputs.ackFor("new"), null);
  assert.equal(inputs.accept("old", command({ sequence: 13 }), 0, 1).reason, "unbound-session");

  const neutral = inputs.frame(state([0]), 0).actors[0];
  assert.ok(Object.values(neutral.buttons).every((pressed) => pressed === false));
  assert.equal(inputs.accept("new", command({ sequence: 0 }), 0, 1).accepted, true);
  assert.deepEqual(inputs.ackFor("new"), { sequence: 0, clientTick: 0, authoritativeTick: 0 });
});

test("bots run through makeBotInput exactly once each and every actor is sorted", () => {
  const calls = [];
  const inputs = new MultiHumanInputAggregator({
    actorIds: [2, 0, 1],
    botActorIds: [2, 1],
    makeBotInput(currentState, fighter) {
      calls.push({ currentState, fighter });
      return command({
        moveX: fighter.id / 2,
        aimX: fighter.facing,
        buttons: { attack: fighter.id === 2 },
      });
    },
  });
  inputs.bind("human", 0);
  inputs.accept("human", command({ sequence: 1, moveX: -0.5 }), 7, 0);
  const currentState = state([2, -1], [0, 1], [1, 1]);
  const frame = inputs.frame(currentState, 7);

  assert.deepEqual(frame.actors.map((actor) => actor.id), [0, 1, 2]);
  assert.deepEqual(calls.map(({ fighter }) => fighter.id), [1, 2]);
  assert.equal(calls.length, 2);
  assert.ok(calls.every(({ currentState: seen }) => seen === currentState));
  assert.equal(frame.actors[0].moveX, -0.5);
  assert.equal(frame.actors[1].moveX, 0.5);
  assert.equal(frame.actors[2].moveX, 1);
  assert.equal(frame.actors[2].buttons.attack, true);
});

test("stats are deterministic copies and account for accepted and rejected messages", () => {
  const inputs = aggregator();
  inputs.bind("player", 0);
  inputs.accept("player", command({ sequence: 1 }), 0, 0);
  inputs.accept("player", command({ sequence: 1 }), 0, 1);
  inputs.accept("missing", command(), 0, 1);

  const stats = inputs.stats();
  assert.deepEqual({ ...stats, rejections: { ...stats.rejections } }, {
    accepted: 1,
    rejected: 2,
    sessions: 1,
    actors: 1,
    botActors: 0,
    rejections: { "stale-sequence": 1, "unbound-session": 1 },
  });
  stats.rejections["stale-sequence"] = 99;
  assert.equal(inputs.stats().rejections["stale-sequence"], 1);
});
