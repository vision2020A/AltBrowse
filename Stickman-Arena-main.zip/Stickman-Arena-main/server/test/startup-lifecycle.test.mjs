import assert from "node:assert/strict";
import { EventEmitter } from "node:events";
import test from "node:test";

import {
  createShutdownController,
  startConfiguredApplication,
} from "../src/startup.mjs";

const runtimeConfig = Object.freeze({ bindHost: "127.0.0.1", port: 2567 });

function applicationFactory(overrides = {}) {
  const calls = [];
  const application = {
    async listen() {
      calls.push(["listen"]);
    },
    markReady() {
      calls.push(["markReady"]);
    },
    async abortStartup() {
      calls.push(["abortStartup"]);
    },
    ...overrides,
  };
  return { application, calls };
}

test("startup returns only the ready application after ordered listen and readiness", async () => {
  const { application, calls } = applicationFactory();
  const result = await startConfiguredApplication(runtimeConfig, async () => ({
    createApplication: () => application,
  }));
  assert.equal(result.accepted, true);
  assert.equal(result.application, application);
  assert.deepEqual(calls, [
    ["listen"],
    ["markReady"],
  ]);
});

test("post-bind startup failure always invokes contained cleanup and returns no error detail", async () => {
  const canary = "POST_BIND_STARTUP_CANARY_12B4A";
  const { application, calls } = applicationFactory({
    markReady() {
      calls.push(["markReady"]);
      throw new Error(canary);
    },
  });
  const result = await startConfiguredApplication(runtimeConfig, async () => ({
    createApplication: () => application,
  }));
  assert.deepEqual(result, { accepted: false, application });
  assert.equal(JSON.stringify(result).includes(canary), false);
  assert.deepEqual(calls, [
    ["listen"],
    ["markReady"],
    ["abortStartup"],
  ]);
});

test("startup stays redacted when factory loading or cleanup fails", async () => {
  const loadFailure = await startConfiguredApplication(runtimeConfig, async () => {
    throw new Error("LOAD_CANARY_12B4A");
  });
  assert.deepEqual(loadFailure, { accepted: false, application: null });

  const { application, calls } = applicationFactory({
    async abortStartup() {
      calls.push(["abortStartup"]);
      throw new Error("CLEANUP_CANARY_12B4A");
    },
    async listen() {
      calls.push(["listen"]);
      throw new Error("LISTEN_CANARY_12B4A");
    },
  });
  const cleanupFailure = await startConfiguredApplication(runtimeConfig, async () => ({
    createApplication: () => application,
  }));
  assert.deepEqual(cleanupFailure, { accepted: false, application });
  assert.deepEqual(calls, [["listen"], ["abortStartup"]]);
  assert.equal(JSON.stringify(cleanupFailure).includes("CANARY"), false);
});

test("a signal before application creation skips listen and shares one shutdown", async () => {
  const signalTarget = new EventEmitter();
  const completions = [];
  const controller = createShutdownController({
    signalTarget,
    onComplete: (result, context) => completions.push({ result, context }),
  });
  assert.equal(controller.install(), true);
  assert.equal(controller.install(), false);
  signalTarget.emit("SIGTERM");
  signalTarget.emit("SIGINT");

  const { application, calls } = applicationFactory({
    async shutdown(reason) {
      calls.push(["shutdown", reason]);
      return { accepted: true, timedOut: false, detail: "must-not-escape" };
    },
  });
  const result = await startConfiguredApplication(
    runtimeConfig,
    async () => ({ createApplication: () => application }),
    { shutdownController: controller },
  );

  assert.deepEqual(result, { accepted: false, interrupted: true, application });
  assert.deepEqual(calls, [["shutdown", "shutdown-signal"]]);
  assert.deepEqual(completions, [{
    result: { accepted: true, timedOut: false },
    context: { fatal: false },
  }]);
  assert.equal(signalTarget.listenerCount("SIGTERM"), 1);
  assert.equal(signalTarget.listenerCount("SIGINT"), 1);
  assert.equal(signalTarget.listenerCount("uncaughtException"), 1);
  assert.equal(signalTarget.listenerCount("unhandledRejection"), 1);
  assert.equal(controller.dispose(), true);
  assert.equal(signalTarget.listenerCount("SIGTERM"), 0);
  assert.equal(signalTarget.listenerCount("SIGINT"), 0);
  assert.equal(signalTarget.listenerCount("uncaughtException"), 0);
  assert.equal(signalTarget.listenerCount("unhandledRejection"), 0);
});

test("the process-style fatal capture bypasses later event reporters and is restored on dispose", () => {
  class CaptureTarget extends EventEmitter {
    capture = null;

    hasUncaughtExceptionCaptureCallback() {
      return this.capture !== null;
    }

    setUncaughtExceptionCaptureCallback(callback) {
      this.capture = callback;
    }
  }
  const signalTarget = new CaptureTarget();
  const controller = createShutdownController({ signalTarget });
  assert.equal(controller.install(), true);
  assert.equal(typeof signalTarget.capture, "function");
  assert.equal(signalTarget.listenerCount("uncaughtException"), 0);
  assert.equal(signalTarget.listenerCount("unhandledRejection"), 1);
  assert.equal(controller.dispose(), true);
  assert.equal(signalTarget.capture, null);
  assert.equal(signalTarget.listenerCount("unhandledRejection"), 0);
});

test("process-style installation rejects pre-owned fatal capture without partial handlers", () => {
  class CaptureTarget extends EventEmitter {
    capture = () => {};

    hasUncaughtExceptionCaptureCallback() {
      return this.capture !== null;
    }

    setUncaughtExceptionCaptureCallback(callback) {
      this.capture = callback;
    }
  }
  const signalTarget = new CaptureTarget();
  const originalCapture = signalTarget.capture;
  const controller = createShutdownController({ signalTarget });

  assert.throws(() => controller.install(), /^Error: shutdown capture unavailable$/);
  assert.equal(signalTarget.capture, originalCapture);
  assert.equal(signalTarget.listenerCount("SIGTERM"), 0);
  assert.equal(signalTarget.listenerCount("SIGINT"), 0);
  assert.equal(signalTarget.listenerCount("uncaughtException"), 0);
  assert.equal(signalTarget.listenerCount("unhandledRejection"), 0);
  assert.equal(controller.dispose(), false);
});

test("a signal during listen prevents readiness and repeated signals coalesce", async () => {
  const signalTarget = new EventEmitter();
  const controller = createShutdownController({ signalTarget });
  controller.install();
  let finishListen;
  const listenPending = new Promise((resolve) => {
    finishListen = resolve;
  });
  const { application, calls } = applicationFactory({
    async listen() {
      calls.push(["listen"]);
      await listenPending;
      throw new Error("listener closed by shutdown");
    },
    async shutdown(reason) {
      calls.push(["shutdown", reason]);
      finishListen();
      return { accepted: true, timedOut: false };
    },
  });

  const starting = startConfiguredApplication(
    runtimeConfig,
    async () => ({ createApplication: () => application }),
    { shutdownController: controller },
  );
  await new Promise((resolve) => setImmediate(resolve));
  signalTarget.emit("SIGINT");
  signalTarget.emit("SIGTERM");
  const result = await starting;

  assert.equal(result.interrupted, true);
  assert.deepEqual(calls, [
    ["listen"],
    ["shutdown", "shutdown-signal"],
  ]);
});

test("the redacted fatal path drains once and reports a non-signal outcome", async () => {
  const signalTarget = new EventEmitter();
  const completions = [];
  const controller = createShutdownController({
    signalTarget,
    onComplete: (result, context) => completions.push({ result, context }),
  });
  controller.install();
  const { application, calls } = applicationFactory({
    async shutdown(reason) {
      calls.push(["shutdown", reason]);
      return { accepted: true, timedOut: false };
    },
  });
  controller.attach(application);
  signalTarget.emit("uncaughtException", new Error("FATAL_DETAIL_CANARY_12B4B"));
  signalTarget.emit("SIGTERM");
  const result = await controller.wait();

  assert.deepEqual(result, { accepted: false, timedOut: false });
  assert.deepEqual(calls, [["shutdown", "failed"]]);
  assert.deepEqual(completions, [{
    result: { accepted: false, timedOut: false },
    context: { fatal: true },
  }]);
  assert.equal(JSON.stringify(completions).includes("CANARY"), false);
});

test("a fatal event escalates an in-flight signal drain without starting a second drain", async () => {
  const signalTarget = new EventEmitter();
  const controller = createShutdownController({ signalTarget });
  controller.install();
  let finishShutdown;
  const pending = new Promise((resolve) => {
    finishShutdown = resolve;
  });
  const { application, calls } = applicationFactory({
    shutdown(reason) {
      calls.push(["shutdown", reason]);
      return pending;
    },
  });
  controller.attach(application);
  signalTarget.emit("SIGTERM");
  signalTarget.emit("uncaughtException", new Error("ESCALATION_CANARY_12B4B"));
  finishShutdown({ accepted: true, timedOut: false });

  assert.deepEqual(await controller.wait(), { accepted: false, timedOut: false });
  assert.deepEqual(calls, [
    ["shutdown", "shutdown-signal"],
    ["shutdown", "failed"],
  ]);
});

test("a fatal event after completion raises the scheduled outcome without restarting cleanup", async () => {
  const signalTarget = new EventEmitter();
  const completions = [];
  const controller = createShutdownController({
    signalTarget,
    onComplete: (result, context) => completions.push({ result, context }),
  });
  controller.install();
  const { application, calls } = applicationFactory({
    shutdown(reason) {
      calls.push(["shutdown", reason]);
      return Promise.resolve({ accepted: true, timedOut: false });
    },
  });
  controller.attach(application);
  signalTarget.emit("SIGTERM");
  assert.deepEqual(await controller.wait(), { accepted: true, timedOut: false });
  signalTarget.emit("uncaughtException", new Error("LATE_FATAL_CANARY_12B4B"));

  assert.deepEqual(calls, [
    ["shutdown", "shutdown-signal"],
    ["shutdown", "failed"],
  ]);
  assert.deepEqual(completions, [
    {
      result: { accepted: true, timedOut: false },
      context: { fatal: false },
    },
    {
      result: { accepted: false, timedOut: false },
      context: { fatal: true },
    },
  ]);
});
