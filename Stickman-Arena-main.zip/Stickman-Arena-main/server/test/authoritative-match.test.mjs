import assert from "node:assert/strict";
import crypto from "node:crypto";
import test from "node:test";

import {
  AuthoritativeMatch,
  SnapshotLimitError,
  snapshotJsonBytes,
  stateHash,
} from "../src/authoritative-match.mjs";
import { Netcode, Sim } from "../src/shared-runtime.mjs";

function buttons(overrides = {}) {
  return {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
    ...overrides,
  };
}

function command(sequence, clientTick, overrides = {}) {
  return {
    generation: 1,
    sequence,
    clientTick,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: buttons(),
    ...overrides,
    buttons: buttons(overrides.buttons),
  };
}

function scriptedCommand(actorId, tick) {
  const phase = (tick + actorId * 7) % 240;
  return command(tick, tick, {
    moveX: phase < 70 ? 1 : phase < 140 ? -1 : 0,
    moveY: phase % 90 < 8 ? -1 : 0,
    aimX: actorId === 0 ? 1 : -1,
    aimY: ((tick + actorId * 11) % 35 - 17) / 21,
    weaponSlot: tick === 180 + actorId * 30 ? 3 : null,
    buttons: {
      jump: tick % (137 + actorId * 13) === 0,
      attack: tick % (47 + actorId * 5) === 0,
      pickup: tick % (211 + actorId * 17) === 0,
      reload: tick % (401 + actorId * 19) === 0,
      drop: tick % (313 + actorId * 23) === 0,
    },
  });
}

function bindTwo(match) {
  assert.deepEqual(match.bind("session-a"), { accepted: true, actorId: 0, epoch: 1 });
  assert.deepEqual(match.bind("session-b"), { accepted: true, actorId: 1, epoch: 1 });
}

test("session bindings allocate stable numeric actors outside simulation state", () => {
  const match = new AuthoritativeMatch({ seed: 0x12345678 });
  bindTwo(match);
  assert.equal(match.actorBySession.get("session-a"), 0);
  assert.equal(match.actorBySession.get("session-b"), 1);
  assert.deepEqual(match.botActorIds, [2, 3]);
  assert.equal(Sim.serialize(match.state).includes("session-a"), false);
  assert.equal(Sim.serialize(match.state).includes("session-b"), false);
  assert.equal(match.bind("session-c").reason, "seat-unavailable");
});

test("two humans control only their actors and bots share the canonical frame", () => {
  const match = new AuthoritativeMatch({ seed: 0x20260826 });
  bindTwo(match);
  match.accept("session-a", command(0, 0, { moveX: 1 }), 0);
  match.accept("session-b", command(0, 0, { moveX: -1 }), 0);
  match.step();
  const frame = match.replayLedger()[0];
  assert.deepEqual(frame.actors.map((actor) => actor.id), [0, 1, 2, 3]);
  assert.equal(frame.actors[0].moveX, 1);
  assert.equal(frame.actors[1].moveX, -1);
  assert.ok(frame.actors.slice(2).every((actor) => actor.id >= 2));
  assert.equal(match.state.tick, 1);
});

test("malformed and unowned commands cannot mutate authority or acknowledgements", () => {
  const match = new AuthoritativeMatch({ seed: 0x55aa });
  match.bind("owner");
  const before = Sim.serialize(match.state);
  assert.equal(match.accept("stranger", command(0, 0), 0).reason, "unbound-session");
  assert.equal(match.accept("owner", { ...command(0, 0), damage: 100 }, 0).reason, "invalid-payload");
  assert.equal(match.accept("owner", command(0, 0, { moveX: Number.NaN }), 0).reason, "invalid-payload");
  assert.equal(match.accept("owner", command(0, 999), 0).reason, "future-tick");
  assert.equal(Sim.serialize(match.state), before);
  assert.equal(match.inputs.ackFor("owner"), null);
});

test("authority accepts only the exact 1/60 simulation step", () => {
  const match = new AuthoritativeMatch({ seed: 1 });
  assert.throws(() => match.step(1 / 30), /1\/60/);
  assert.equal(match.state.tick, 0);
  match.step(1 / 60);
  assert.equal(match.state.tick, 1);
});

test("disconnect neutralizes held and edge inputs before the next step and reconnect keeps actor ID", () => {
  const match = new AuthoritativeMatch({ seed: 2 });
  match.bind("old");
  match.accept("old", command(7, 0, {
    moveX: 1,
    buttons: { jump: true, attack: true, pickup: true },
  }), 0);
  const released = match.disconnect("old");
  assert.deepEqual(released, { accepted: true, actorId: 0, epoch: 2 });
  match.step();
  const actor = match.replayLedger()[0].actors[0];
  assert.equal(actor.moveX, 0);
  assert.ok(Object.values(actor.buttons).every((pressed) => pressed === false));
  assert.deepEqual(match.bind("new", released.actorId, released.epoch), {
    accepted: true, actorId: 0, epoch: 2,
  });
  assert.equal(match.accept("old", command(8, 1), 1).reason, "unbound-session");
  assert.equal(match.accept("new", command(0, 1), 1).accepted, true);
});

test("a reconnect reservation cannot be stolen by a new pre-start session", () => {
  const match = new AuthoritativeMatch({ seed: 22 });
  const first = match.bind("first");
  assert.equal(first.actorId, 0);
  const reservation = match.disconnect("first");
  assert.equal(reservation.actorId, 0);

  const newcomer = match.bind("newcomer", undefined, 1, [reservation.actorId]);
  assert.deepEqual(newcomer, { accepted: true, actorId: 1, epoch: 1 });
  assert.equal(match.bind("third", undefined, 1, [reservation.actorId]).reason, "seat-unavailable");
  assert.deepEqual(match.bind("first", reservation.actorId, reservation.epoch), {
    accepted: true, actorId: 0, epoch: 2,
  });
});

test("full regulation server ledger replays byte-identically through headless fixedUpdate", () => {
  const seed = 0x12345678;
  const match = new AuthoritativeMatch({ seed });
  bindTwo(match);
  const direct = Sim.createState({ seed, humanCount: 2, botCount: 2 });
  const rolling = crypto.createHash("sha256");
  const checkpoints = new Map();

  for (let tick = 0; tick < 10800; tick += 1) {
    assert.equal(match.accept("session-a", scriptedCommand(0, tick), tick * (1000 / 60)).accepted, true);
    assert.equal(match.accept("session-b", scriptedCommand(1, tick), tick * (1000 / 60)).accepted, true);
    match.step();
    const serialized = Sim.serialize(match.state);
    rolling.update(serialized);
    rolling.update("\n");
    if (tick === 0 || tick === 1799 || tick === 10799) {
      checkpoints.set(tick + 1, serialized);
    }
  }

  const ledger = match.replayLedger();
  assert.equal(ledger.length, 10800);
  assert.deepEqual(match.replayLedgerStats(), {
    entries: 10800,
    capacity: 10800,
    maxEntries: 10800,
    retainedBytes: 1_512_000,
    maxRetainedBytes: 1_512_000,
  });
  for (let tick = 0; tick < ledger.length; tick += 1) {
    Sim.fixedUpdate(direct, ledger[tick], Sim.STEP);
    if (checkpoints.has(tick + 1)) {
      assert.equal(Sim.serialize(direct), checkpoints.get(tick + 1), `replay diverged at tick ${tick + 1}`);
    }
  }

  assert.equal(Sim.serialize(direct), Sim.serialize(match.state));
  assert.equal(match.state.tick, 10800);
  assert.equal(match.state.match.phase, "finished");
  const frozen = Sim.serialize(match.state);
  for (let index = 0; index < 120; index += 1) match.step();
  assert.equal(match.replayLedger().length, 10800, "finished rooms must not grow replay history");
  assert.equal(Sim.serialize(match.state), frozen, "finished authority remains frozen until Pass 12 lifecycle");
  assert.match(rolling.digest("hex"), /^[0-9a-f]{64}$/);
});

test("snapshot projection is a pure JSON copy with monotonic ack, hash, and ordered events", () => {
  const match = new AuthoritativeMatch({ seed: 3 });
  match.bind("player");
  match.accept("player", command(4, 0, { buttons: { jump: true } }), 0);
  match.step();
  const events = match.drainEvents();
  const before = Sim.serialize(match.state);
  const snapshot = match.snapshot("player", events);
  assert.equal(snapshot.tick, 1);
  assert.equal(snapshot.actorId, 0);
  assert.equal(snapshot.ackSequence, 4);
  assert.equal(snapshot.stateHash, stateHash(match.state));
  assert.deepEqual(snapshot.events, events);
  assert.ok(snapshot.events.every((event, index, list) => index === 0
    || event.tick > list[index - 1].tick
    || (event.tick === list[index - 1].tick && event.id !== list[index - 1].id)));
  snapshot.state.fighters[0].x = -99999;
  snapshot.events.push({ id: 999, tick: 1, type: "forged" });
  assert.equal(Sim.serialize(match.state), before);
  assert.ok(snapshotJsonBytes(snapshot) < Netcode.MAX_SNAPSHOT_JSON_BYTES);
});

test("snapshot bytes and server event queues fail closed at explicit transport budgets", () => {
  const match = new AuthoritativeMatch({ seed: 31 });
  match.bind("player");
  const events = Array.from({ length: Netcode.MAX_SNAPSHOT_EVENTS + 1 }, (_, index) => ({
    id: index,
    tick: 0,
    type: "bounded",
  }));
  assert.equal(
    match.snapshot("player", events.slice(0, Netcode.MAX_SNAPSHOT_EVENTS)).events.length,
    Netcode.MAX_SNAPSHOT_EVENTS,
  );
  assert.throws(() => match.snapshot("player", events), SnapshotLimitError);

  match.captureEvents(events);
  assert.equal(match.pendingEvents.length, Netcode.MAX_SNAPSHOT_EVENTS);
  assert.throws(() => match.drainEvents(), SnapshotLimitError);
  assert.deepEqual(match.drainEvents(), []);

  match.state.snapshotLimitCanary = "";
  const emptyCanaryBytes = snapshotJsonBytes(match.snapshot("player"));
  match.state.snapshotLimitCanary = "x".repeat(
    Netcode.MAX_SNAPSHOT_JSON_BYTES - emptyCanaryBytes,
  );
  assert.equal(
    snapshotJsonBytes(match.snapshot("player")),
    Netcode.MAX_SNAPSHOT_JSON_BYTES,
  );
  match.state.snapshotLimitCanary += "x";
  assert.throws(() => match.snapshot("player"), SnapshotLimitError);
  delete match.state.snapshotLimitCanary;
  assert.ok(snapshotJsonBytes(match.snapshot("player")) < Netcode.MAX_SNAPSHOT_JSON_BYTES);
});

test("a server-owned generation restart clears every generation-local buffer and preserves seats", () => {
  const seeds = [0x2468ace0];
  const match = new AuthoritativeMatch({
    seed: 0x13579bdf,
    seedSource: () => seeds.shift(),
  });
  bindTwo(match);
  assert.equal(match.accept("session-a", command(8, 0, {
    buttons: { attack: true, jump: true },
  }), 0).accepted, true);
  match.step();
  match.pendingEvents.push({ id: 999, tick: 1, type: "old" });
  match.state.match.phase = "finished";

  const restarted = match.restartGeneration();
  assert.deepEqual(restarted, {
    accepted: true,
    generation: 2,
    seed: 0x2468ace0,
  });
  assert.equal(match.generation, 2);
  assert.equal(match.state.tick, 0);
  assert.equal(match.state.seed, 0x2468ace0);
  assert.equal(match.state.match.phase, "playing");
  assert.deepEqual(match.replayLedger(), []);
  assert.deepEqual(match.replayLedgerStats(), {
    entries: 0,
    capacity: 256,
    maxEntries: 10800,
    retainedBytes: 35_840,
    maxRetainedBytes: 1_512_000,
  });
  assert.deepEqual(match.drainEvents(), []);
  assert.equal(match.actorBySession.get("session-a"), 0);
  assert.equal(match.actorBySession.get("session-b"), 1);
  assert.equal(match.inputs.ackFor("session-a"), null);
  assert.equal(match.accept("session-a", command(9, 0), 0).reason, "stale-generation");
  assert.equal(match.accept("session-a", command(9, 0, { generation: 3 }), 0).reason, "future-generation");
  assert.equal(match.accept("session-a", command(0, 0, { generation: 2 }), 0).accepted, true);
  match.step();
  const actor = match.replayLedger()[0].actors[0];
  assert.equal(actor.buttons.attack, false, "old held input crossed the generation boundary");
  assert.equal(actor.buttons.jump, false, "old edge input crossed the generation boundary");
});

test("repeated rematches keep generations monotonic, seeds distinct, and histories bounded", () => {
  let nextSeed = 100;
  const match = new AuthoritativeMatch({ seed: 99, seedSource: () => nextSeed++ });
  bindTwo(match);
  for (let expectedGeneration = 2; expectedGeneration <= 26; expectedGeneration += 1) {
    match.state.match.phase = "finished";
    const priorSeed = match.state.seed;
    const restarted = match.restartGeneration();
    assert.equal(restarted.accepted, true);
    assert.equal(restarted.generation, expectedGeneration);
    assert.notEqual(match.state.seed, priorSeed);
    assert.equal(restarted.seed, match.state.seed);
    assert.equal(match.state.tick, 0);
    assert.deepEqual(match.replayLedger(), []);
    assert.deepEqual(match.drainEvents(), []);
    assert.equal(match.inputs.ackFor("session-a"), null);
  }
});

test("same-seed fallback is nonzero, canonical, and distinct across uint32 wrap", () => {
  const repeated = 0x61c88647;
  const match = new AuthoritativeMatch({ seed: repeated, seedSource: () => repeated });
  match.state.match.phase = "finished";
  const restarted = match.restartGeneration();
  assert.equal(restarted.seed, 0x6d2b79f5);
  assert.equal(restarted.seed, match.state.seed);
  assert.notEqual(restarted.seed, repeated);
});

function runDelayedProfile(delays) {
  const seed = 0x44cc88aa;
  const match = new AuthoritativeMatch({ seed });
  bindTwo(match);
  const queues = [[], []];
  for (let tick = 0; tick < 900; tick += 1) {
    for (let actorId = 0; actorId < 2; actorId += 1) {
      const delay = delays[(tick + actorId) % delays.length];
      // Application-level suppression models loss without claiming that a live
      // WebSocket reorders or drops transport packets.
      if ((tick + actorId * 17) % 113 !== 0) {
        queues[actorId].push({ deliverAt: tick + delay, payload: scriptedCommand(actorId, tick) });
      }
      while (queues[actorId].length && queues[actorId][0].deliverAt <= tick) {
        const next = queues[actorId].shift();
        match.accept(actorId === 0 ? "session-a" : "session-b", next.payload, tick * 20);
      }
    }
    match.step();
  }
  const replay = Sim.createState({ seed, humanCount: 2, botCount: 2 });
  for (const frame of match.replayLedger()) Sim.fixedUpdate(replay, frame, Sim.STEP);
  assert.equal(Sim.serialize(replay), Sim.serialize(match.state));
  return stateHash(match.state);
}

test("synthetic delay, jitter, burst, and send suppression preserve authoritative replay", () => {
  const hashes = [
    runDelayedProfile([0]),
    runDelayedProfile([3]),
    runDelayedProfile([0, 2, 1, 5, 3, 1]),
    runDelayedProfile([0, 0, 0, 9, 8, 7]),
  ];
  assert.ok(hashes.every((hash) => /^[0-9a-f]{64}$/.test(hash)));
  assert.equal(runDelayedProfile([0, 2, 1, 5, 3, 1]), hashes[2]);
});
