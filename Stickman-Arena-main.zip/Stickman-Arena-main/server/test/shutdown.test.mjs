import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { createServer } from "node:http";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { Client } from "@colyseus/sdk";

import { Netcode } from "../src/shared-runtime.mjs";

const indexPath = fileURLToPath(new URL("../src/index.mjs", import.meta.url));

function reservePort() {
  const server = createServer();
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}

function collect(stream) {
  let output = "";
  stream.setEncoding("utf8");
  stream.on("data", (chunk) => {
    output += chunk;
  });
  return () => output;
}

async function waitForReady(port, child) {
  const deadline = Date.now() + 5_000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error("service exited before readiness");
    try {
      const response = await fetch(`http://127.0.0.1:${port}/readyz`);
      if (response.status === 200) {
        assert.deepEqual(await response.json(), { status: "ready" });
        return;
      }
    } catch {
      // Listener startup is asynchronous; retry only within the fixed test bound.
    }
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  throw new Error("service did not become ready");
}

function waitForExit(child) {
  if (child.exitCode !== null || child.signalCode !== null) {
    return Promise.resolve({ code: child.exitCode, signal: child.signalCode });
  }
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(
      () => reject(new Error("service shutdown exceeded test deadline")),
      8_000,
    );
    child.once("exit", (code, signal) => {
      clearTimeout(timeout);
      resolve({ code, signal });
    });
  });
}

function onceMessage(room, type) {
  return new Promise((resolve) => {
    const unsubscribe = room.onMessage(type, (message) => {
      unsubscribe();
      resolve(message);
    });
  });
}

async function bootstrap(room) {
  room.onMessage("lifecycle", () => {});
  room.onMessage("match-start", () => {});
  const hello = onceMessage(room, "server-hello");
  room.send("protocol-request", {});
  const compatibility = await hello;
  assert.equal(Netcode.validateCurrentServerHello(compatibility).accepted, true);
  const assignment = onceMessage(room, "assignment");
  room.send("hello-ack", compatibility);
  const assigned = await assignment;
  const snapshot = onceMessage(room, "snapshot");
  room.send("ready", { generation: assigned.generation });
  await snapshot;
  return assigned;
}

async function runSignalCycle(port, signal) {
  const child = spawn(process.execPath, [indexPath], {
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      PORT: String(port),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const stdout = collect(child.stdout);
  const stderr = collect(child.stderr);
  try {
    await waitForReady(port, child);
    const live = await fetch(`http://127.0.0.1:${port}/livez`);
    assert.equal(live.status, 200);
    assert.equal(child.kill(signal), true);
    const exited = await waitForExit(child);
    assert.deepEqual(exited, { code: 0, signal: null });
  } finally {
    if (child.exitCode === null) child.kill("SIGKILL");
  }
  assert.equal(stderr(), "");
  const records = stdout().trim().split("\n").map(JSON.parse);
  assert.deepEqual(records.map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "starting", reason: "startup" },
    { level: "info", event: "service.lifecycle", phase: "ready", reason: "listening" },
    {
      level: "info",
      event: "service.lifecycle",
      phase: "draining",
      reason: "shutdown-signal",
    },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "info", event: "service.drain", phase: "stopped", reason: "drain-complete" },
    { level: "info", event: "service.lifecycle", phase: "stopped", reason: "stopped" },
  ]);
  assert.equal(records.every((record) => record.buildId === "pass12b4b-shutdown"), true);
  assert.equal(JSON.stringify(records).includes(signal), false);
}

test("SIGTERM and SIGINT drain cleanly and a fresh process reuses the same port", { timeout: 15000 }, async () => {
  const port = await reservePort();
  await runSignalCycle(port, "SIGTERM");
  await runSignalCycle(port, "SIGINT");
});

test("a real signal before application creation drains without opening a listener", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
  const source = `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { createShutdownController } = await import(${JSON.stringify(startupUrl)});
    const logger = createOperationsLogger({
      buildId: "pass12b4b-shutdown",
      clock: () => 0,
      write: (line) => process.stdout.write(line),
    });
    const controller = createShutdownController({
      signalTarget: process,
      onComplete(result, context) {
        const exitCode = result.accepted && !context.fatal ? 0 : 1;
        process.exitCode = exitCode;
        setImmediate(() => process.exit(exitCode));
      },
    });
    controller.install();
    process.kill(process.pid, "SIGTERM");
    await new Promise((resolve) => setImmediate(resolve));
    const application = createApplication(createRuntimeConfig({ PORT: "25674" }), {
      operationsLogger: logger,
    });
    controller.attach(application);
    await controller.wait();
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 3_000,
  });
  assert.equal(child.status, 0, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.signal, null);
  assert.equal(child.stderr, "");
  const records = child.stdout.trim().split("\n").map(JSON.parse);
  assert.deepEqual(records.map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "starting", reason: "startup" },
    {
      level: "info",
      event: "service.lifecycle",
      phase: "draining",
      reason: "shutdown-signal",
    },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "info", event: "service.drain", phase: "stopped", reason: "drain-complete" },
    { level: "info", event: "service.lifecycle", phase: "stopped", reason: "stopped" },
  ]);
});

test("SIGTERM closes a playing Room non-reconnectably and releases the process", { timeout: 15000 }, async () => {
  const port = await reservePort();
  const child = spawn(process.execPath, [indexPath], {
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      PORT: String(port),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const stdout = collect(child.stdout);
  const stderr = collect(child.stderr);
  const rooms = [];
  try {
    await waitForReady(port, child);
    const client = new Client(`http://127.0.0.1:${port}`);
    const options = {
      compatibility: Netcode.createCompatibilityOffer(),
      operation: "quick-match",
      modeId: "free-for-all",
      mapId: "original-arena",
    };
    const first = await client.joinOrCreate("arena", options);
    const second = await client.joinOrCreate("arena", options);
    rooms.push(first, second);
    await Promise.all([bootstrap(first), bootstrap(second)]);
    const left = rooms.map((room) => new Promise((resolve) => {
      room.onLeave((code) => resolve(code));
    }));
    assert.equal(child.kill("SIGTERM"), true);
    assert.deepEqual(await Promise.all(left), [
      4001,
      4001,
    ]);
    assert.deepEqual(await waitForExit(child), { code: 0, signal: null });
  } finally {
    for (const room of rooms) {
      try {
        room.leave();
      } catch {
        // The process-owned 4001 close is expected to win this race.
      }
    }
    if (child.exitCode === null) child.kill("SIGKILL");
  }
  assert.equal(stderr(), "");
  const records = stdout().trim().split("\n").map(JSON.parse);
  assert.equal(records.some((record) => record.event === "room.lifecycle"
    && record.roomPhase === "closing"), true);
  assert.equal(records.some((record) => record.event === "room.lifecycle"
    && record.roomPhase === "disposed"), true);
  assert.equal(records.at(-1).event, "service.lifecycle");
  assert.equal(records.at(-1).reason, "stopped");
  assert.equal(records.every((record) => !Object.hasOwn(record, "roomId")
    && !Object.hasOwn(record, "sessionId")), true);
});

test("a hung framework drain reaches the fixed fallback and failed terminal state", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const source = `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const lines = [];
    const application = createApplication(createRuntimeConfig({ PORT: "25679" }), {
      drainTimeoutMs: 25,
      forceCleanupTimeoutMs: 25,
      operationsLogger: createOperationsLogger({
        buildId: "pass12b4b-shutdown",
        clock: () => 0,
        write: (line) => lines.push(JSON.parse(line)),
      }),
    });
    application.server.gracefullyShutdown = () => new Promise(() => {});
    const result = await application.shutdown();
    process.stdout.write(JSON.stringify({ result, state: application.serviceState.snapshot(), lines }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 2_000,
  });
  assert.equal(child.status, 0, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  const output = JSON.parse(child.stdout);
  assert.deepEqual(output.result, { accepted: false, timedOut: true });
  assert.deepEqual(output.state, {
    phase: "failed",
    ready: false,
    listenerAvailable: false,
    dependenciesAvailable: false,
  });
  assert.deepEqual(output.lines.map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "starting", reason: "startup" },
    {
      level: "info",
      event: "service.lifecycle",
      phase: "draining",
      reason: "shutdown-signal",
    },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "error", event: "service.drain", phase: "failed", reason: "drain-timeout" },
  ]);
});

test("a fatal shutdown drains resources but records only a failed terminal outcome", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const source = `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const lines = [];
    const application = createApplication(createRuntimeConfig({ PORT: "25678" }), {
      operationsLogger: createOperationsLogger({
        buildId: "pass12b4b-shutdown",
        clock: () => 0,
        write: (line) => lines.push(JSON.parse(line)),
      }),
    });
    await application.listen();
    application.markReady();
    const result = await application.shutdown("failed");
    process.stdout.write(JSON.stringify({ result, state: application.serviceState.snapshot(), lines }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 3_000,
  });
  assert.equal(child.status, 0, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  const output = JSON.parse(child.stdout);
  assert.deepEqual(output.result, { accepted: false, timedOut: false });
  assert.equal(output.state.phase, "failed");
  assert.equal(output.lines.some((record) => record.phase === "stopped"
    || record.reason === "stopped" || record.reason === "drain-complete"), false);
  assert.deepEqual(output.lines.slice(-3).map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "draining", reason: "failed" },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "error", event: "service.drain", phase: "failed", reason: "failed" },
  ]);
});

test("a real uncaught exception drains, redacts the error, and exits one", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
  const source = `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { createShutdownController } = await import(${JSON.stringify(startupUrl)});
    const logger = createOperationsLogger({
      buildId: "pass12b4b-shutdown",
      clock: () => 0,
      write: (line) => process.stdout.write(line),
    });
    const controller = createShutdownController({
      signalTarget: process,
      onComplete(result, context) {
        const exitCode = result.accepted && !context.fatal ? 0 : 1;
        process.exitCode = exitCode;
        setImmediate(() => process.exit(exitCode));
      },
    });
    controller.install();
    const application = createApplication(createRuntimeConfig({ PORT: "25677" }), {
      operationsLogger: logger,
    });
    controller.attach(application);
    await application.listen();
    application.markReady();
    setImmediate(() => { throw new Error("UNCAUGHT_DETAIL_CANARY_12B4B"); });
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 4_000,
  });
  assert.equal(child.status, 1, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.signal, null);
  assert.equal(child.stderr, "");
  assert.equal(child.stdout.includes("UNCAUGHT_DETAIL_CANARY_12B4B"), false);
  const records = child.stdout.trim().split("\n").map(JSON.parse);
  assert.deepEqual(records.slice(-3).map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "draining", reason: "failed" },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "error", event: "service.drain", phase: "failed", reason: "failed" },
  ]);
});

test("a real unhandled rejection bypasses framework reporters and exits one", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
  const source = `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { createShutdownController } = await import(${JSON.stringify(startupUrl)});
    const logger = createOperationsLogger({
      buildId: "pass12b4b-shutdown",
      clock: () => 0,
      write: (line) => process.stdout.write(line),
    });
    const controller = createShutdownController({
      signalTarget: process,
      onComplete(result, context) {
        const exitCode = result.accepted && !context.fatal ? 0 : 1;
        process.exitCode = exitCode;
        setImmediate(() => process.exit(exitCode));
      },
    });
    controller.install();
    const application = createApplication(createRuntimeConfig({ PORT: "25675" }), {
      operationsLogger: logger,
    });
    controller.attach(application);
    await application.listen();
    application.markReady();
    Promise.reject(new Error("UNHANDLED_DETAIL_CANARY_12B4B"));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 4_000,
  });
  assert.equal(child.status, 1, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.signal, null);
  assert.equal(child.stderr, "");
  assert.equal(child.stdout.includes("UNHANDLED_DETAIL_CANARY_12B4B"), false);
  const records = child.stdout.trim().split("\n").map(JSON.parse);
  assert.deepEqual(records.slice(-3).map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    { level: "info", event: "service.lifecycle", phase: "draining", reason: "failed" },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    { level: "error", event: "service.drain", phase: "failed", reason: "failed" },
  ]);
});

test("a fatal rejection in the completion-to-exit turn latches exit one", () => {
  const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
  const source = `
    const { createShutdownController } = await import(${JSON.stringify(startupUrl)});
    let exitScheduled = false;
    const controller = createShutdownController({
      signalTarget: process,
      onComplete(result, context) {
        const exitCode = result.accepted && !context.fatal ? 0 : 1;
        process.exitCode = process.exitCode === 1 || exitCode === 1 ? 1 : 0;
        process.stdout.write(JSON.stringify({ result, context, exitCode: process.exitCode }) + "\\n");
        if (exitScheduled) return;
        exitScheduled = true;
        setImmediate(() => process.exit(process.exitCode === 0 ? 0 : 1));
      },
    });
    controller.install();
    controller.attach({ shutdown: () => Promise.resolve({ accepted: true, timedOut: false }) });
    controller.request("SIGTERM").then(() => {
      queueMicrotask(() => Promise.reject(new Error("LATE_FATAL_PRIVATE_CANARY_12B4B")));
    });
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 2_000,
  });
  assert.equal(child.status, 1, child.error?.message || child.stderr || child.stdout);
  assert.equal(child.signal, null);
  assert.equal(child.stderr, "");
  assert.equal(child.stdout.includes("LATE_FATAL_PRIVATE_CANARY_12B4B"), false);
  assert.deepEqual(child.stdout.trim().split("\n").map(JSON.parse), [
    {
      result: { accepted: true, timedOut: false },
      context: { fatal: false },
      exitCode: 0,
    },
    {
      result: { accepted: false, timedOut: false },
      context: { fatal: true },
      exitCode: 1,
    },
  ]);
});
