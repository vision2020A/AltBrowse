import assert from "node:assert/strict";
import { after, before, beforeEach, test } from "node:test";
import { CloseCode } from "@colyseus/core";
import { boot } from "@colyseus/testing";

import { createApplication } from "../src/app.config.mjs";
import {
  PASS12B1_UNSUPPORTED_MESSAGE_REASON,
  PASS12B3B2_MAX_INBOUND_MESSAGES,
  PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES,
} from "../src/arena-room.mjs";
import { roomRegistry } from "../src/room-registry.mjs";
import { Netcode } from "../src/shared-runtime.mjs";
import { createOperationsLogger } from "../src/operations.mjs";
import { createRuntimeConfig } from "../src/runtime-config.mjs";
import {
  CREATE_MATCH_OPERATION,
  JOIN_CODE_OPERATION,
  QUICK_MATCH_OPERATION,
} from "../src/protocol-boundary.mjs";

let colyseus;
const matchStartHandlers = new WeakSet();
const operationsLines = [];
const application = createApplication(createRuntimeConfig({ PORT: "2568" }), {
  operationsLogger: createOperationsLogger({
    buildId: Netcode.SERVER_BUILD_ID,
    write: (line) => operationsLines.push(line),
  }),
});
const appConfig = application.server;

before(async () => {
  colyseus = await boot(appConfig);
  application.markReady();
});

after(async () => {
  if (colyseus) await colyseus.shutdown();
});

beforeEach(async () => {
  await colyseus.cleanup();
  operationsLines.length = 0;
});

function buttons(overrides = {}) {
  return {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
    ...overrides,
  };
}

function command(sequence, clientTick, overrides = {}) {
  return {
    generation: 1,
    sequence,
    clientTick,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: buttons(),
    ...overrides,
    buttons: buttons(overrides.buttons),
  };
}

function admissionOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return {
    compatibility,
    operation: QUICK_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function createMatchOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return {
    compatibility,
    operation: CREATE_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function joinCodeOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return { compatibility, operation: JOIN_CODE_OPERATION };
}

async function requestServerHello(client) {
  const serverHello = client.waitForMessage("server-hello");
  client.send("protocol-request", {});
  return serverHello;
}

async function bootstrap(client) {
  if (!matchStartHandlers.has(client)) {
    client.onMessage("match-start", () => {});
    client.onMessage("lifecycle", () => {});
    client.onMessage("control-rejected", () => {});
    matchStartHandlers.add(client);
  }
  const hello = await requestServerHello(client);
  assert.equal(Netcode.validateCurrentServerHello(hello).accepted, true);
  const assignment = client.waitForMessage("assignment");
  client.send("hello-ack", hello);
  const assigned = await assignment;
  const snapshot = client.waitForMessage("snapshot");
  client.send("ready", { generation: assigned.generation });
  return [assigned, await snapshot, hello];
}

async function waitForCondition(predicate, message, timeoutMs = 1000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(message);
}

async function finishCurrentGeneration(backend, clients) {
  const finalSnapshots = clients.map((client) => client.waitForMessage("snapshot"));
  backend.match.state.match.ticksRemaining = 1;
  await backend.waitForNextSimulationTick();
  const snapshots = await Promise.all(finalSnapshots);
  await waitForCondition(
    () => backend.lifecycle === "finished" && backend.rematchOpen,
    "authoritative results window did not open",
  );
  return snapshots;
}

function assertApplicationResourcesCleared(backend, label) {
  assert.equal(backend.handshakeTimers.size, 0, `${label}: handshake timers`);
  assert.equal(backend.rematchVotes.size, 0, `${label}: rematch votes`);
  assert.equal(backend.controlRateWindows.size, 0, `${label}: rate windows`);
  assert.equal(backend.reservations.size, 0, `${label}: reservations`);
  assert.equal(backend.admittedSessions.size, 0, `${label}: admitted`);
  assert.equal(backend.readySessions.size, 0, `${label}: ready`);
  assert.equal(backend.negotiatingSessions.size, 0, `${label}: negotiating`);
  assert.equal(backend.helloSentSessions.size, 0, `${label}: hello`);
  assert.equal(backend.terminalSessions.size, 0, `${label}: terminal`);
  assert.equal(backend.initialWaitingTimer, null, `${label}: waiting timer`);
  assert.equal(backend.resultsTimer, null, `${label}: results timer`);
  assert.equal(backend.generationReadyTimer, null, `${label}: ready timer`);
}

async function waitForDisposed(backend, roomId, message) {
  await waitForCondition(
    () => backend.lifecycle === "disposed" && !roomRegistry.snapshot().roomIds.includes(roomId),
    message,
    3000,
  );
  assertApplicationResourcesCleared(backend, message);
}

test("Pass 12C1 resource constants stay at the frozen B3B2/B4B contract", () => {
  assert.equal(Netcode.SERVER_BUILD_ID, "pass12b4b-shutdown");
  assert.equal(PASS12B3B2_MAX_INBOUND_MESSAGES, 120);
  assert.equal(PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES, 262144);
  assert.equal(roomRegistry.snapshot().liveRooms, 0);
});

test("repeated Room create and dispose leave no registry, timers, queues, or replay owners", {
  timeout: 20000,
}, async () => {
  const cycles = 4;
  for (let cycle = 0; cycle < cycles; cycle += 1) {
    const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const backend = colyseus.getRoomById(first.roomId);
    const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const roomId = first.roomId;
    await Promise.all([bootstrap(first), bootstrap(second)]);
    assert.equal(backend.lifecycle, "playing");
    assert.equal(roomRegistry.snapshot().liveRooms, 1);
    const received = backend.waitForNextMessage();
    first.send("input", command(cycle + 1, backend.match.state.tick, {
      generation: backend.match.generation,
      moveX: 1,
    }));
    await received;
    await backend.waitForNextSimulationTick();
    assert.ok(backend.match.replayLedger().length >= 1);
    assert.ok(backend.match.replayLedgerStats().retainedBytes <= 1_512_000);

    await first.leave(true);
    await second.leave(true);
    await waitForDisposed(
      backend,
      roomId,
      `cycle ${cycle} did not dispose and clear application resources`,
    );
    assert.deepEqual(roomRegistry.snapshot(), { liveRooms: 0, codeRooms: 0, roomIds: [] });
  }
});

test("compact regulation rematch resets generation-local history then disposes", {
  timeout: 15000,
}, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const roomId = first.roomId;
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const received = backend.waitForNextMessage();
  first.send("input", command(1, backend.match.state.tick, {
    generation: 1,
    moveX: 1,
    buttons: { attack: true },
  }));
  await received;
  await backend.waitForNextSimulationTick();
  assert.ok(backend.match.replayLedger().length >= 1);

  await finishCurrentGeneration(backend, [first, second]);
  assert.equal(backend.lifecycle, "finished");
  assert.ok(backend.resultsTimer);
  const firstAssignment = first.waitForMessage("assignment");
  const secondAssignment = second.waitForMessage("assignment");
  first.send("rematch-vote", { generation: 1, vote: true });
  second.send("rematch-vote", { generation: 1, vote: true });
  await Promise.all([firstAssignment, secondAssignment]);

  assert.equal(backend.match.generation, 2);
  assert.deepEqual(backend.match.replayLedger(), []);
  assert.deepEqual(backend.match.drainEvents(), []);
  assert.deepEqual(backend.match.replayLedgerStats(), {
    entries: 0,
    capacity: 256,
    maxEntries: 10800,
    retainedBytes: 35_840,
    maxRetainedBytes: 1_512_000,
  });
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(backend.resultsTimer, null);
  assert.ok(backend.generationReadyTimer);
  assert.equal(backend.readySessions.size, 0);

  const firstSnapshot = first.waitForMessage("snapshot");
  const secondSnapshot = second.waitForMessage("snapshot");
  first.send("ready", { generation: 2 });
  second.send("ready", { generation: 2 });
  await Promise.all([firstSnapshot, secondSnapshot]);
  await waitForCondition(() => backend.lifecycle === "playing", "generation two did not start");
  assert.equal(backend.generationReadyTimer, null);

  backend.onBeforeShutdown();
  await waitForDisposed(backend, roomId, "rematch Room did not clear shutdown resources");
});

test("abandoned reconnect expiry cannot mutate a replacement Room", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const abandoned = colyseus.getRoomById(first.roomId);
  await bootstrap(first);
  const abandonedId = first.roomId;
  const abandonedSession = first.sessionId;
  const waitingTimer = abandoned.initialWaitingTimer;
  abandoned.reconnectWindowSeconds = () => 0.5;
  first.reconnection.minUptime = 0;
  first.reconnection.maxRetries = 0;
  first.reconnection.maxEnqueuedMessages = 0;

  await first.leave(false);
  await waitForCondition(
    () => abandoned.reservations.has(abandonedSession),
    "abandoned drop did not reserve a seat",
  );
  assert.equal(abandoned.lifecycle, "waiting");

  // Create Match always allocates a distinct Room. Quick Match would join the
  // still-waiting abandoned Room and collapse the expiry race.
  const replacementFirst = await colyseus.sdk.create("arena", createMatchOptions());
  const replacement = colyseus.getRoomById(replacementFirst.roomId);
  const replacementSecond = await colyseus.sdk.joinById(
    replacementFirst.roomId,
    joinCodeOptions(),
  );
  await Promise.all([bootstrap(replacementFirst), bootstrap(replacementSecond)]);
  assert.notEqual(replacementFirst.roomId, abandonedId);
  assert.equal(replacement.lifecycle, "playing");

  await waitForDisposed(
    abandoned,
    abandonedId,
    "abandoned Room did not expire its reconnect reservation",
  );
  const replacementTick = replacement.match.state.tick;
  waitingTimer.execute();
  assert.equal(replacement.lifecycle, "playing", "stale abandoned timer closed the replacement");
  assert.equal(replacement.match.state.tick, replacementTick);
  assert.equal(roomRegistry.snapshot().liveRooms, 1);

  await replacementFirst.leave(true);
  await replacementSecond.leave(true);
  await waitForDisposed(
    replacement,
    replacementFirst.roomId,
    "replacement Room did not dispose after the expiry race",
  );
});

test("malformed, oversized, rate-limit, and slow-client closes leave no reservation residue", {
  timeout: 15000,
}, async () => {
  const malformed = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const malformedBackend = colyseus.getRoomById(malformed.roomId);
  const malformedLeft = new Promise((resolve) => malformed.onLeave((code, reason) => {
    resolve({ code, reason });
  }));
  malformed.send("STRING_TYPE_CANARY_12C1", {});
  assert.deepEqual(await malformedLeft, {
    code: CloseCode.WITH_ERROR,
    reason: PASS12B1_UNSUPPORTED_MESSAGE_REASON,
  });
  await waitForDisposed(
    malformedBackend,
    malformed.roomId,
    "malformed close left a live Room or maps",
  );

  const oversized = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const oversizedBackend = colyseus.getRoomById(oversized.roomId);
  const oversizedLeft = new Promise((resolve) => oversized.onLeave((code) => resolve(code)));
  oversized.connection.send(new Uint8Array(4097));
  assert.equal(await oversizedLeft, 1009);
  await waitForDisposed(
    oversizedBackend,
    oversized.roomId,
    "oversized close left a live Room or maps",
  );

  const rate = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const rateBackend = colyseus.getRoomById(rate.roomId);
  const rateServer = [...rateBackend.clients].find((client) => client.sessionId === rate.sessionId);
  rateBackend.monotonicNow = () => 4_000;
  for (let count = 0; count < PASS12B3B2_MAX_INBOUND_MESSAGES; count += 1) {
    assert.equal(rateBackend.consumeInboundFrame(rateServer, new Uint8Array([1])), true);
  }
  const rateLeft = new Promise((resolve) => rate.onLeave(resolve));
  assert.equal(rateBackend.consumeInboundFrame(rateServer, new Uint8Array([1])), false);
  await rateLeft;
  assert.equal(rateBackend.reservations.has(rate.sessionId), false);
  await waitForDisposed(rateBackend, rate.roomId, "rate-limit close left a live Room or maps");

  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const slowBackend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const slowServer = [...slowBackend.clients].find((client) => client.sessionId === first.sessionId);
  const peerServer = [...slowBackend.clients].find((client) => client.sessionId === second.sessionId);
  const originalBufferedAmount = slowBackend.clientBufferedAmount.bind(slowBackend);
  slowBackend.clientBufferedAmount = (client) => client === slowServer
    ? PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES
    : originalBufferedAmount(client);
  const slowLeft = new Promise((resolve) => first.onLeave((code, reason) => resolve({ code, reason })));
  assert.equal(slowBackend.sendSnapshot(slowServer), false);
  assert.deepEqual(await slowLeft, {
    code: CloseCode.WITH_ERROR,
    reason: "connection output limit exceeded",
  });
  assert.equal(slowBackend.reservations.has(first.sessionId), false);
  assert.equal(slowBackend.match.actorBySession.has(second.sessionId), true);
  assert.equal(slowBackend.sendSnapshot(peerServer), true);

  await second.leave(true);
  await waitForDisposed(
    slowBackend,
    first.roomId,
    "slow-client survivor Room did not dispose",
  );
});

test("shutdown clears waiting, playing, and results handles before registry release", {
  timeout: 15000,
}, async () => {
  const waiting = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const waitingBackend = colyseus.getRoomById(waiting.roomId);
  await bootstrap(waiting);
  assert.ok(waitingBackend.initialWaitingTimer);
  const waitingId = waiting.roomId;
  assert.equal(waitingBackend.onBeforeShutdown(), true);
  await waitForDisposed(waitingBackend, waitingId, "waiting shutdown left handles");

  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const playing = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const received = playing.waitForNextMessage();
  first.send("input", command(2, playing.match.state.tick, {
    generation: 1,
    moveX: 1,
    buttons: { attack: true },
  }));
  await received;
  await finishCurrentGeneration(playing, [first, second]);
  assert.ok(playing.resultsTimer);
  first.send("rematch-vote", { generation: 1, vote: true });
  await waitForCondition(() => playing.rematchVotes.size === 1, "vote was not recorded");
  const playingTick = playing.match.state.tick;

  assert.equal(playing.onBeforeShutdown(), true);
  assert.equal(playing.lifecycle, "closing");
  assert.equal(playing.match.actorBySession.size, 0);
  assert.equal(playing.rematchVotes.size, 0);
  assert.equal(playing.resultsTimer, null);
  playing.fixedStep({ dt: 1 / 60 });
  assert.equal(playing.match.state.tick, playingTick, "shutdown advanced finished authority");
  await waitForDisposed(playing, first.roomId, "results shutdown left handles");
  assert.deepEqual(roomRegistry.snapshot(), { liveRooms: 0, codeRooms: 0, roomIds: [] });
});
