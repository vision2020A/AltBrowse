import assert from "node:assert/strict";
import test from "node:test";

await import("../../multiplayer.js");

const Multiplayer = globalThis.StickMultiplayer;

function buttons(overrides = {}) {
  return {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
    ...overrides
  };
}

function stateAt(tick, localX = 0, remoteX = 100) {
  return {
    tick,
    version: 6,
    fighters: [
      { id: 0, x: localX, y: 10, prevX: localX - 2, prevY: 9, vx: 0, vy: 0, prevVx: -1, prevVy: 0, facing: 1, dead: false, respawn: 0 },
      { id: 1, x: remoteX, y: 20, prevX: remoteX - 2, prevY: 19, vx: 0, vy: 0, prevVx: -1, prevVy: 0, facing: -1, dead: false, respawn: 0 }
    ],
    events: []
  };
}

function movementUpdate(state, frame, step) {
  assert.equal(step, 1 / 60);
  assert.equal(frame.actors.length, state.fighters.length);
  for (const fighter of state.fighters) {
    const input = frame.actors.find((candidate) => candidate.id === fighter.id);
    fighter.x += input.moveX;
  }
  state.tick += 1;
  return state;
}

test("classic module binds a frozen Node-safe API", () => {
  assert.ok(Multiplayer);
  assert.ok(Object.isFrozen(Multiplayer));
  assert.equal(typeof Multiplayer.createClientModel, "function");
  assert.equal(Multiplayer.MAX_HISTORY_LIMIT, 180);
  assert.equal(Multiplayer.MAX_SNAPSHOT_EVENTS, 64);
  assert.equal(Multiplayer.MAX_PENDING_EVENTS, 256);
  assert.equal(Multiplayer.MAX_EVENT_IDENTITY_HISTORY, 512);
  assert.equal(Multiplayer.MAX_SNAPSHOT_JSON_BYTES, 32 * 1024);
});

test("outgoing input has only the exact canonical wire keys", () => {
  const model = Multiplayer.createClientModel({ actorId: 0 });
  const message = model.createInputMessage({
    sequence: 900,
    clientTick: 900,
    id: 1,
    moveX: 7,
    moveY: -7,
    aimX: Number.NaN,
    aimY: 0.5,
    weaponSlot: 3,
    damage: 999,
    hit: true,
    score: 20,
    position: { x: 999, y: 999 },
    buttons: { attack: 1, jump: 0, outcome: true }
  }, 12);

  assert.deepEqual(Object.keys(message), Multiplayer.WIRE_KEYS);
  assert.deepEqual(Object.keys(message.buttons), Multiplayer.BUTTON_KEYS);
  assert.deepEqual(message, {
    generation: 1,
    sequence: 0,
    clientTick: 12,
    moveX: 1,
    moveY: -1,
    aimX: 1,
    aimY: 0.5,
    weaponSlot: 3,
    buttons: buttons({ attack: true })
  });
  assert.equal("id" in message, false);
  assert.equal("damage" in message, false);
  assert.equal("hit" in message, false);
  assert.equal("score" in message, false);
  assert.equal("position" in message, false);
});

test("prediction converges with delayed and immediate acknowledgements", () => {
  const model = Multiplayer.createClientModel({ actorId: 0, fixedUpdate: movementUpdate });
  const firstSnapshot = { generation: 1, tick: 0, state: stateAt(0), ackSequence: -1, events: [] };
  const untouched = structuredClone(firstSnapshot);
  model.ingestSnapshot(firstSnapshot);
  model.createInputMessage({ moveX: 1 }, 1);
  model.createInputMessage({ moveX: 1 }, 2);
  model.createInputMessage({ moveX: 1 }, 3);

  assert.equal(model.getPredictedState().fighters[0].x, 3);
  assert.equal(model.getPredictedState().fighters[1].x, 100, "remote actors replay neutral input");
  assert.deepEqual(firstSnapshot, untouched, "authoritative payload is never mutated");

  const delayed = model.ingestSnapshot({
    generation: 1,
    tick: 1,
    state: stateAt(1, 1),
    ackSequence: 0,
    events: []
  });
  assert.equal(delayed.replayed, 2);
  assert.equal(model.getPredictedState().fighters[0].x, 3);
  assert.deepEqual(model.getPendingInputs().map((input) => input.sequence), [1, 2]);

  const authoritative = stateAt(3, 3);
  const immediate = model.ingestSnapshot({
    generation: 1,
    tick: 3,
    state: authoritative,
    ackSequence: 2,
    events: []
  });
  assert.equal(immediate.replayed, 0);
  assert.deepEqual(model.getPredictedState(), authoritative);
  assert.deepEqual(model.getPendingInputs(), []);
});

test("stale and duplicate snapshots are ignored in full", () => {
  const model = Multiplayer.createClientModel({ actorId: 0 });
  assert.equal(model.ingestSnapshot({ generation: 1, tick: 5, state: stateAt(5, 5), ackSequence: -1, events: [] }).accepted, true);
  assert.deepEqual(model.drainEvents(), []);

  const stale = model.ingestSnapshot({
    generation: 1,
    tick: 4,
    state: stateAt(4, 999),
    ackSequence: 99,
    events: [{ id: -1, tick: 4, type: "stale" }]
  });
  const duplicate = model.ingestSnapshot({
    generation: 1,
    tick: 5,
    state: stateAt(5, 888),
    ackSequence: 99,
    events: [{ id: -2, tick: 5, type: "duplicate" }]
  });
  assert.deepEqual(stale, { accepted: false, reason: "stale", tick: 5 });
  assert.deepEqual(duplicate, { accepted: false, reason: "stale", tick: 5 });
  assert.equal(model.getAuthoritativeState().fighters[0].x, 5);
  assert.equal(model.getStatus().latestAckSequence, -1);
  assert.deepEqual(model.drainEvents(), []);
});

test("input history is bounded and needsResync clears only after the lost sequence is acknowledged", () => {
  const model = Multiplayer.createClientModel({ actorId: 0, historyLimit: 2 });
  model.ingestSnapshot({ generation: 1, tick: 0, state: stateAt(0), ackSequence: -1, events: [] });
  model.createInputMessage({ moveX: 1 }, 1);
  model.createInputMessage({ moveX: 1 }, 2);
  model.createInputMessage({ moveX: 1 }, 3);

  assert.deepEqual(model.getPendingInputs().map((input) => input.sequence), [1, 2]);
  assert.equal(model.getStatus().needsResync, true);

  model.ingestSnapshot({ generation: 1, tick: 1, state: stateAt(1), ackSequence: -1, events: [] });
  assert.equal(model.getStatus().needsResync, true);
  model.ingestSnapshot({ generation: 1, tick: 2, state: stateAt(2), ackSequence: 0, events: [] });
  assert.equal(model.getStatus().needsResync, false);
});

test("prediction configuration cannot raise the production history ceiling", () => {
  const model = Multiplayer.createClientModel({ actorId: 0, historyLimit: 10_000 });
  for (let sequence = 0; sequence < Multiplayer.MAX_HISTORY_LIMIT + 5; sequence += 1) {
    model.createInputMessage({ moveX: 1 }, sequence);
  }
  assert.equal(model.getStatus().historyLimit, Multiplayer.MAX_HISTORY_LIMIT);
  assert.equal(model.getStatus().pendingInputCount, Multiplayer.MAX_HISTORY_LIMIT);
});

test("events use generation:tick:id identity, retain negative IDs, sort, and drain exactly once", () => {
  const model = Multiplayer.createClientModel({ actorId: 0 });
  model.ingestSnapshot({
    generation: 1,
    tick: 10,
    state: stateAt(10),
    ackSequence: -1,
    events: [
      { id: 3, tick: 10, type: "third" },
      { id: -1, tick: 9, type: "first" },
      { id: -2, tick: 10, type: "second" },
      { id: -2, tick: 10, type: "duplicate-second" }
    ]
  });
  assert.deepEqual(model.drainEvents().map((event) => event.type), ["first", "second", "third"]);
  assert.deepEqual(model.drainEvents(), []);

  model.ingestSnapshot({
    generation: 1,
    tick: 11,
    state: stateAt(11),
    ackSequence: -1,
    events: [
      { id: -2, tick: 10, type: "repeat-second" },
      { id: -1, tick: 11, type: "new-negative-id" }
    ]
  });
  assert.deepEqual(model.drainEvents().map((event) => event.type), ["new-negative-id"]);
});

test("snapshot event batches, pending presentation events, and dedup identities stay bounded", () => {
  const model = Multiplayer.createClientModel({ actorId: 0 });
  const tooMany = Array.from({ length: Multiplayer.MAX_SNAPSHOT_EVENTS + 1 }, (_, index) => ({
    id: index,
    tick: 1,
    type: "bounded",
  }));
  const exactModel = Multiplayer.createClientModel({ actorId: 0 });
  assert.equal(exactModel.ingestSnapshot({
    generation: 1,
    tick: 1,
    state: stateAt(1),
    ackSequence: -1,
    events: tooMany.slice(0, Multiplayer.MAX_SNAPSHOT_EVENTS),
  }).accepted, true);
  assert.equal(exactModel.getStatus().pendingEventCount, Multiplayer.MAX_SNAPSHOT_EVENTS);
  assert.throws(() => model.ingestSnapshot({
    generation: 1,
    tick: 1,
    state: stateAt(1),
    ackSequence: -1,
    events: tooMany,
  }), /bounded contract/);
  assert.equal(model.getStatus().latestSnapshotTick, -1);

  for (let tick = 1; tick <= Multiplayer.MAX_EVENT_IDENTITY_HISTORY + 80; tick += 1) {
    model.ingestSnapshot({
      generation: 1,
      tick,
      state: stateAt(tick),
      ackSequence: -1,
      events: [{ id: tick, tick, type: `event-${tick}` }],
    });
  }
  const status = model.getStatus();
  assert.equal(status.pendingEventCount, Multiplayer.MAX_PENDING_EVENTS);
  assert.equal(status.eventIdentityCount, Multiplayer.MAX_EVENT_IDENTITY_HISTORY);
  const events = model.drainEvents();
  assert.equal(events.length, Multiplayer.MAX_PENDING_EVENTS);
  assert.equal(events[0].tick, 337);
  assert.equal(events.at(-1).tick, 592);
  assert.equal(model.getStatus().pendingEventCount, 0);
  assert.equal(model.getStatus().eventIdentityCount, Multiplayer.MAX_EVENT_IDENTITY_HISTORY);
});

test("remote interpolation is pure, finite, and reaches continuous endpoints", () => {
  const model = Multiplayer.createClientModel({ actorId: 0, teleportDistance: 200 });
  const older = stateAt(20, 40, 0);
  older.fighters[1].y = 20;
  older.fighters[1].vx = 10;
  const newer = stateAt(21, 80, 100);
  newer.fighters[1].y = 60;
  newer.fighters[1].vx = 30;
  const olderPayload = { generation: 1, tick: 20, state: older, ackSequence: -1, events: [] };
  const newerPayload = { generation: 1, tick: 21, state: newer, ackSequence: -1, events: [] };
  const olderUntouched = structuredClone(olderPayload);
  const newerUntouched = structuredClone(newerPayload);
  model.ingestSnapshot(olderPayload);
  model.ingestSnapshot(newerPayload);

  const start = model.sampleRemoteState(0);
  const middle = model.sampleRemoteState(0.5);
  const end = model.sampleRemoteState(1);
  assert.equal(start.fighters[1].x, 0);
  assert.equal(start.fighters[1].y, 20);
  assert.equal(middle.fighters[1].x, 50);
  assert.equal(middle.fighters[1].y, 40);
  assert.equal(middle.fighters[1].vx, 20);
  assert.equal(middle.fighters[1].prevX, 50, "remote sample is ready for the renderer without a second lerp");
  assert.equal(middle.fighters[1].prevY, 40);
  assert.equal(middle.fighters[1].prevVx, 20);
  assert.equal(end.fighters[1].x, 100);
  assert.equal(end.fighters[1].y, 60);
  assert.equal(start.fighters[0].x, 80, "the assigned actor is not remotely interpolated");
  assert.equal(model.sampleRemoteState(Number.NaN).fighters[1].x, 100);

  middle.fighters[1].x = -500;
  assert.equal(model.sampleRemoteState(0.5).fighters[1].x, 50);
  assert.deepEqual(olderPayload, olderUntouched);
  assert.deepEqual(newerPayload, newerUntouched);
});

test("remote interpolation snaps on teleport, death, and respawn discontinuities", () => {
  function sampledRemoteX(olderFighterPatch, newerFighterPatch, distance = 200) {
    const model = Multiplayer.createClientModel({ actorId: 0, teleportDistance: distance });
    const older = stateAt(30, 0, 0);
    const newer = stateAt(31, 0, 10);
    Object.assign(older.fighters[1], olderFighterPatch);
    Object.assign(newer.fighters[1], newerFighterPatch);
    model.ingestSnapshot({ generation: 1, tick: 30, state: older, ackSequence: -1, events: [] });
    model.ingestSnapshot({ generation: 1, tick: 31, state: newer, ackSequence: -1, events: [] });
    return model.sampleRemoteState(0.25).fighters[1].x;
  }

  assert.equal(sampledRemoteX({}, { x: 500 }), 500, "large teleport snaps to newest");
  assert.equal(sampledRemoteX({}, { x: 10, dead: true }), 10, "death snaps to newest");
  assert.equal(sampledRemoteX({ dead: true, respawn: 1 }, { x: 90, dead: false, respawn: 0 }), 90,
    "respawn snaps to newest");
});

test("wrong-generation snapshots are inert and a fresh model resets every client window", () => {
  const first = Multiplayer.createClientModel({ actorId: 0, generation: 4, fixedUpdate: movementUpdate });
  first.ingestSnapshot({ generation: 4, tick: 8, state: stateAt(8, 8), ackSequence: -1, events: [
    { id: 7, tick: 8, type: "generation-four" },
  ] });
  first.createInputMessage({ moveX: 1, generation: 999 }, 9);
  const before = {
    status: first.getStatus(),
    state: first.getAuthoritativeState(),
    pending: first.getPendingInputs(),
  };
  assert.deepEqual(first.ingestSnapshot({
    generation: 3,
    tick: 999,
    state: stateAt(999, 999),
    ackSequence: 999,
    events: [{ id: 8, tick: 999, type: "stale-generation" }],
  }), { accepted: false, reason: "stale-generation", generation: 4 });
  assert.deepEqual(first.ingestSnapshot({
    generation: 5,
    tick: 0,
    state: stateAt(0, 500),
    ackSequence: 999,
    events: [{ id: 9, tick: 0, type: "future-generation" }],
  }), { accepted: false, reason: "future-generation", generation: 4 });
  assert.deepEqual(first.getStatus(), before.status);
  assert.deepEqual(first.getAuthoritativeState(), before.state);
  assert.deepEqual(first.getPendingInputs(), before.pending);
  assert.deepEqual(first.drainEvents().map((event) => event.type), ["generation-four"]);

  const next = Multiplayer.createClientModel({ actorId: 0, generation: 5, fixedUpdate: movementUpdate });
  assert.deepEqual(next.getStatus(), {
    actorId: 0,
    generation: 5,
    latestSnapshotTick: -1,
    latestAckSequence: -1,
    nextSequence: 0,
    pendingInputCount: 0,
    historyLimit: 180,
    pendingEventCount: 0,
    eventIdentityCount: 0,
    needsResync: false,
  });
  next.ingestSnapshot({ generation: 5, tick: 0, state: stateAt(0), ackSequence: -1, events: [
    { id: 7, tick: 0, type: "generation-five" },
  ] });
  assert.deepEqual(next.drainEvents().map((event) => event.type), ["generation-five"]);
  const message = next.createInputMessage({ moveX: -1, generation: 12345 }, 1);
  assert.equal(message.generation, 5, "raw input cannot spoof the model-owned generation");
  assert.equal(message.sequence, 0);
});
