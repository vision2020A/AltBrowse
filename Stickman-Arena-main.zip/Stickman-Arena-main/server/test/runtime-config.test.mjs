import assert from "node:assert/strict";
import test from "node:test";

import {
  COLYSEUS_CLOUD_ENVIRONMENT_KEY,
  COLYSEUS_CLOUD_INSTANCE_KEY,
  COLYSEUS_CLOUD_ROLLOUT_INSTANCES,
  COLYSEUS_CLOUD_SOCKET_DIRECTORY,
  DEFAULT_SERVER_PORT,
  FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS,
  MAX_ALLOWED_ORIGINS,
  RuntimeConfigError,
  colyseusCloudUnixSocketPath,
  createRuntimeConfig,
  isRequestAuthorityAllowed,
  isRequestOriginAllowed,
  isRequestPolicyAllowed,
} from "../src/runtime-config.mjs";

const PUBLIC_ENV = Object.freeze({
  STICKMAN_SERVER_MODE: "public",
  NODE_ENV: "production",
  STICKMAN_BIND_HOST: "0.0.0.0",
  STICKMAN_PUBLIC_ORIGIN: "https://arena.example",
  STICKMAN_ALLOWED_ORIGINS: "https://arena.example",
});

function expectConfigError(environment, key, reason, forbiddenValue) {
  assert.throws(() => createRuntimeConfig(environment), (error) => {
    assert.ok(error instanceof RuntimeConfigError);
    assert.equal(error.name, "RuntimeConfigError");
    assert.equal(error.key, key);
    assert.equal(error.reason, reason);
    assert.equal(error.message, `Invalid runtime configuration: ${key} (${reason})`);
    if (forbiddenValue) assert.equal(error.message.includes(forbiddenValue), false);
    return true;
  });
}

test("local runtime configuration is exact, deeply frozen, and loopback-only by default", () => {
  const config = createRuntimeConfig({});
  assert.deepEqual(config, {
    serverMode: "local",
    bindHost: "127.0.0.1",
    port: DEFAULT_SERVER_PORT,
    publicOrigin: null,
    allowedOrigins: [
      "http://127.0.0.1:2567",
      "http://localhost:2567",
    ],
    allowedAuthorities: ["127.0.0.1:2567", "localhost:2567"],
    allowMissingOrigin: true,
    cloudProxy: false,
    listenPath: null,
  });
  assert.deepEqual(Object.keys(config), [
    "serverMode",
    "bindHost",
    "port",
    "publicOrigin",
    "allowedOrigins",
    "allowedAuthorities",
    "allowMissingOrigin",
    "cloudProxy",
    "listenPath",
  ]);
  assert.equal(Object.isFrozen(config), true);
  assert.equal(Object.isFrozen(config.allowedOrigins), true);
  assert.equal(Object.isFrozen(config.allowedAuthorities), true);
});

test("PORT is a canonical decimal integer and drives local origins and authorities", () => {
  const config = createRuntimeConfig({ PORT: "4321" });
  assert.equal(config.port, 4321);
  assert.deepEqual(config.allowedOrigins, [
    "http://127.0.0.1:4321",
    "http://localhost:4321",
  ]);
  assert.deepEqual(config.allowedAuthorities, ["127.0.0.1:4321", "localhost:4321"]);

  assert.equal(createRuntimeConfig({ PORT: "1" }).port, 1);
  assert.equal(createRuntimeConfig({ PORT: "65535" }).port, 65535);
  for (const value of ["", "0", "65536", "02567", "+1", "1.0", " 1", "1 ", "NaN"]) {
    expectConfigError({ PORT: value }, "PORT", "invalid-port", value || undefined);
  }
  expectConfigError({ PORT: 2567 }, "PORT", "invalid-value");
});

test("server mode is explicit and local mode rejects every public-only variable even when empty", () => {
  assert.equal(createRuntimeConfig({ STICKMAN_SERVER_MODE: "local" }).serverMode, "local");
  for (const value of ["", "LOCAL", "production", " public", "public "]) {
    expectConfigError(
      { STICKMAN_SERVER_MODE: value },
      "STICKMAN_SERVER_MODE",
      "invalid-mode",
      value || undefined,
    );
  }
  for (const key of [
    "STICKMAN_BIND_HOST",
    "STICKMAN_PUBLIC_ORIGIN",
    "STICKMAN_ALLOWED_ORIGINS",
  ]) {
    expectConfigError({ [key]: "" }, key, "not-allowed-in-local-mode");
  }
});

test("unsupported topology overrides and unknown STICKMAN variables fail closed without values", () => {
  assert.equal(Object.isFrozen(FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS), true);
  for (const key of FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS) {
    expectConfigError({ [key]: "" }, key, "unsupported-topology-override");
    expectConfigError(
      { [key]: "do-not-disclose-this-value" },
      key,
      "unsupported-topology-override",
      "do-not-disclose-this-value",
    );
  }
  expectConfigError(
    { STICKMAN_PRIVATE_TOKEN_DO_NOT_DISCLOSE: "secret-value-do-not-disclose" },
    "STICKMAN_*",
    "unknown-variable",
    "secret-value-do-not-disclose",
  );
});

test("Colyseus Cloud accepts only the two one-process rolling deployment slots", () => {
  assert.deepEqual(COLYSEUS_CLOUD_ROLLOUT_INSTANCES, ["0", "1"]);
  assert.equal(Object.isFrozen(COLYSEUS_CLOUD_ROLLOUT_INSTANCES), true);
  const cloud = createRuntimeConfig({
    ...PUBLIC_ENV,
    STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
    STICKMAN_ALLOWED_ORIGINS:
      "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
    [COLYSEUS_CLOUD_ENVIRONMENT_KEY]: "injected-by-provider",
    [COLYSEUS_CLOUD_INSTANCE_KEY]: "0",
  });
  assert.equal(cloud.cloudProxy, true);
  assert.equal(COLYSEUS_CLOUD_SOCKET_DIRECTORY, "/run/colyseus");
  assert.equal(colyseusCloudUnixSocketPath("0"), "/run/colyseus/2567.sock");
  assert.equal(colyseusCloudUnixSocketPath("1"), "/run/colyseus/2568.sock");
  assert.equal(cloud.listenPath, "/run/colyseus/2567.sock");
  const slotOne = createRuntimeConfig({
    ...PUBLIC_ENV,
    [COLYSEUS_CLOUD_ENVIRONMENT_KEY]: "provider",
    [COLYSEUS_CLOUD_INSTANCE_KEY]: "1",
  });
  assert.equal(slotOne.cloudProxy, true);
  assert.equal(slotOne.listenPath, "/run/colyseus/2568.sock");
  assert.equal(cloud.publicOrigin, "https://de-fra-1131bd95.colyseus.cloud");
  assert.deepEqual(cloud.allowedOrigins, [
    "https://de-fra-1131bd95.colyseus.cloud",
    "https://xenovoyage.github.io",
  ]);

  for (const environment of [
    { [COLYSEUS_CLOUD_ENVIRONMENT_KEY]: "provider" },
    { [COLYSEUS_CLOUD_INSTANCE_KEY]: "0" },
  ]) {
    const key = Object.keys(environment)[0];
    expectConfigError(environment, key, "not-allowed-in-local-mode");
  }
  expectConfigError(
    { ...PUBLIC_ENV, [COLYSEUS_CLOUD_INSTANCE_KEY]: "0" },
    COLYSEUS_CLOUD_ENVIRONMENT_KEY,
    "unsupported-topology-override",
  );
  expectConfigError(
    { ...PUBLIC_ENV, [COLYSEUS_CLOUD_ENVIRONMENT_KEY]: "provider" },
    COLYSEUS_CLOUD_INSTANCE_KEY,
    "unsupported-topology-override",
  );
  for (const instance of ["", "2", "01", "-1", "worker"]) {
    expectConfigError(
      {
        ...PUBLIC_ENV,
        [COLYSEUS_CLOUD_ENVIRONMENT_KEY]: "provider",
        [COLYSEUS_CLOUD_INSTANCE_KEY]: instance,
      },
      COLYSEUS_CLOUD_INSTANCE_KEY,
      "unsupported-topology-override",
      instance || undefined,
    );
  }
});

test("environment records are read as own data properties without invoking accessors", () => {
  const inherited = Object.create({ STICKMAN_UNKNOWN_INHERITED: "ignored" });
  assert.equal(createRuntimeConfig(inherited).serverMode, "local");

  let calls = 0;
  const accessor = {};
  Object.defineProperty(accessor, "PORT", {
    enumerable: true,
    get() {
      calls += 1;
      return "2567";
    },
  });
  expectConfigError(accessor, "PORT", "invalid-value");
  assert.equal(calls, 0);
  expectConfigError(null, "environment", "invalid-record");
  expectConfigError([], "environment", "invalid-record");
});

test("public mode requires production and an exact public bind host", () => {
  for (const nodeEnvironment of [undefined, "", "development", "Production"]) {
    const environment = { ...PUBLIC_ENV };
    if (nodeEnvironment === undefined) delete environment.NODE_ENV;
    else environment.NODE_ENV = nodeEnvironment;
    expectConfigError(environment, "NODE_ENV", "required-production", nodeEnvironment || undefined);
  }
  for (const bindHost of ["", "127.0.0.1", "localhost", "*", "0.0.0.0 ", "[::]"]) {
    expectConfigError(
      { ...PUBLIC_ENV, STICKMAN_BIND_HOST: bindHost },
      "STICKMAN_BIND_HOST",
      "invalid-bind-host",
      bindHost || undefined,
    );
  }
  assert.equal(createRuntimeConfig(PUBLIC_ENV).bindHost, "0.0.0.0");
  assert.equal(createRuntimeConfig({ ...PUBLIC_ENV, STICKMAN_BIND_HOST: "::" }).bindHost, "::");
});

test("public mode fails closed when any required public variable is absent", () => {
  for (const [key, reason] of [
    ["STICKMAN_BIND_HOST", "invalid-bind-host"],
    ["STICKMAN_PUBLIC_ORIGIN", "invalid-origin"],
    ["STICKMAN_ALLOWED_ORIGINS", "invalid-list"],
  ]) {
    const environment = { ...PUBLIC_ENV };
    delete environment[key];
    expectConfigError(environment, key, reason);
  }
});

test("public origins are canonical HTTPS origins and the public origin is allowlisted", () => {
  const config = createRuntimeConfig({
    ...PUBLIC_ENV,
    PORT: "8443",
    STICKMAN_PUBLIC_ORIGIN: "https://arena.example:8443",
    STICKMAN_ALLOWED_ORIGINS: "https://pages.example,https://arena.example:8443",
  });
  assert.deepEqual(config, {
    serverMode: "public",
    bindHost: "0.0.0.0",
    port: 8443,
    publicOrigin: "https://arena.example:8443",
    allowedOrigins: ["https://pages.example", "https://arena.example:8443"],
    allowedAuthorities: ["arena.example:8443"],
    allowMissingOrigin: false,
    cloudProxy: false,
    listenPath: null,
  });
  assert.equal(Object.isFrozen(config), true);
  assert.equal(Object.isFrozen(config.allowedOrigins), true);
  assert.equal(Object.isFrozen(config.allowedAuthorities), true);

  for (const origin of [
    "", "http://arena.example", "https://arena.example/", "https://arena.example/path",
    "https://arena.example?query=1", "https://arena.example#fragment",
    "https://user@arena.example", "https://Example.com", "https://arena.example:443",
    " https://arena.example", "https://arena.example ", "not-an-origin",
  ]) {
    expectConfigError(
      {
        ...PUBLIC_ENV,
        STICKMAN_PUBLIC_ORIGIN: origin,
        STICKMAN_ALLOWED_ORIGINS: origin,
      },
      "STICKMAN_PUBLIC_ORIGIN",
      "invalid-origin",
      origin || undefined,
    );
  }
});

test("public allowed-origin lists reject noncanonical, duplicate, missing, empty, and oversized entries", () => {
  for (const [value, reason] of [
    ["https://arena.example,https://arena.example", "duplicate-origin"],
    ["https://pages.example", "missing-public-origin"],
    ["https://arena.example,", "invalid-origin"],
    [",https://arena.example", "invalid-origin"],
    ["https://arena.example, https://pages.example", "invalid-origin"],
    ["https://arena.example,http://pages.example", "invalid-origin"],
  ]) {
    expectConfigError(
      { ...PUBLIC_ENV, STICKMAN_ALLOWED_ORIGINS: value },
      "STICKMAN_ALLOWED_ORIGINS",
      reason,
      value,
    );
  }
  const origins = Array.from(
    { length: MAX_ALLOWED_ORIGINS + 1 },
    (_, index) => `https://origin-${index}.example`,
  );
  origins[0] = PUBLIC_ENV.STICKMAN_PUBLIC_ORIGIN;
  expectConfigError(
    { ...PUBLIC_ENV, STICKMAN_ALLOWED_ORIGINS: origins.join(",") },
    "STICKMAN_ALLOWED_ORIGINS",
    "invalid-list",
  );
});

test("request policy uses exact dynamically configured origins and authorities", () => {
  const local = createRuntimeConfig({ PORT: "4321" });
  assert.equal(isRequestOriginAllowed(local, null), true);
  assert.equal(isRequestOriginAllowed(local, undefined), true);
  assert.equal(isRequestOriginAllowed(local, ""), false);
  assert.equal(isRequestOriginAllowed(local, "http://127.0.0.1:4321"), true);
  assert.equal(isRequestOriginAllowed(local, "http://localhost:4321"), true);
  assert.equal(isRequestOriginAllowed(local, "http://127.0.0.1:2567"), false);
  assert.equal(isRequestAuthorityAllowed(local, "127.0.0.1:4321"), true);
  assert.equal(isRequestAuthorityAllowed(local, "localhost:4321"), true);
  assert.equal(isRequestAuthorityAllowed(local, "LOCALHOST:4321"), false);
  assert.equal(isRequestPolicyAllowed(local, null, "127.0.0.1:4321"), true);
  assert.equal(isRequestPolicyAllowed(local, "http://localhost:4321", "127.0.0.1:4321"), false);
  assert.equal(isRequestPolicyAllowed(local, "https://attacker.example", "127.0.0.1:4321"), false);

  const publicConfig = createRuntimeConfig({
    ...PUBLIC_ENV,
    STICKMAN_ALLOWED_ORIGINS: "https://arena.example,https://pages.example",
  });
  assert.equal(isRequestOriginAllowed(publicConfig, null), false);
  assert.equal(isRequestOriginAllowed(publicConfig, ""), false);
  assert.equal(isRequestOriginAllowed(publicConfig, "https://arena.example"), true);
  assert.equal(isRequestOriginAllowed(publicConfig, "https://pages.example"), true);
  assert.equal(isRequestOriginAllowed(publicConfig, "https://PAGES.example"), false);
  assert.equal(isRequestAuthorityAllowed(publicConfig, "arena.example"), true);
  assert.equal(isRequestAuthorityAllowed(publicConfig, "pages.example"), false);
  assert.equal(isRequestPolicyAllowed(
    publicConfig,
    "https://pages.example",
    "arena.example",
  ), true);
});
