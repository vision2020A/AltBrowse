import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { createServer } from "node:http";
import test from "node:test";
import { fileURLToPath } from "node:url";

const indexPath = fileURLToPath(new URL("../src/index.mjs", import.meta.url));

function listen(server) {
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      server.removeListener("error", reject);
      resolve(server.address().port);
    });
  });
}

function close(server) {
  return new Promise((resolve) => server.close(resolve));
}

test("invalid startup configuration fails before framework bootstrap with one redacted record", () => {
  const valueCanary = "STARTUP_VALUE_CANARY_12B4A";
  const keyCanary = "STICKMAN_STARTUP_KEY_CANARY_12B4A";
  const child = spawnSync(process.execPath, [indexPath], {
    encoding: "utf8",
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      PORT: valueCanary,
      [keyCanary]: "do-not-log",
    },
    timeout: 5_000,
  });

  assert.equal(child.status, 1, child.error?.message || child.stdout || child.stderr);
  assert.equal(child.signal, null);
  assert.equal(child.stdout, "", "framework/runtime bootstrap must not run after config rejection");
  assert.equal(child.stderr.includes(valueCanary), false);
  assert.equal(child.stderr.includes(keyCanary), false);
  assert.equal(child.stderr.includes("do-not-log"), false);
  assert.equal(child.stderr.includes("Error:"), false);
  const lines = child.stderr.trim().split("\n");
  assert.equal(lines.length, 1);
  const record = JSON.parse(lines[0]);
  assert.deepEqual(Object.keys(record), [
    "timestamp", "level", "event", "buildId", "reason",
  ]);
  assert.equal(record.level, "error");
  assert.equal(record.event, "service.configuration");
  assert.equal(record.buildId, "pass12b4b-shutdown");
  assert.equal(record.reason, "configuration-invalid");
  assert.equal(Number.isNaN(Date.parse(record.timestamp)), false);
});

test("pre-owned exception capture fails before framework bootstrap with one redacted record", () => {
  const captureCanary = "PREOWNED_CAPTURE_CANARY_12B4B";
  const source = `
    let captured = 0;
    process.setUncaughtExceptionCaptureCallback(() => { captured += 1; });
    setInterval(() => {}, 1_000);
    await import(${JSON.stringify(new URL("../src/index.mjs", import.meta.url).href)});
    process.stdout.write(JSON.stringify({
      captured,
      captureActive: process.hasUncaughtExceptionCaptureCallback(),
    }));
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      PORT: captureCanary,
    },
    timeout: 5_000,
  });

  assert.equal(child.status, 1, child.error?.message || child.stdout || child.stderr);
  assert.equal(child.signal, null);
  assert.deepEqual(JSON.parse(child.stdout), { captured: 0, captureActive: true });
  assert.equal(child.stderr.includes(captureCanary), false);
  assert.equal(child.stderr.includes("shutdown capture unavailable"), false);
  const lines = child.stderr.trim().split("\n");
  assert.equal(lines.length, 1);
  const record = JSON.parse(lines[0]);
  assert.deepEqual(Object.keys(record), [
    "timestamp", "level", "event", "buildId", "phase", "reason",
  ]);
  assert.equal(record.level, "error");
  assert.equal(record.event, "service.failure");
  assert.equal(record.buildId, "pass12b4b-shutdown");
  assert.equal(record.phase, "failed");
  assert.equal(record.reason, "failed");
});

test("a real occupied port fails promptly and clears framework startup resources", async () => {
  const blocker = createServer();
  const port = await listen(blocker);
  let child;
  try {
    child = spawnSync(process.execPath, [indexPath], {
      encoding: "utf8",
      env: { PATH: process.env.PATH, PORT: String(port) },
      timeout: 5_000,
    });
  } finally {
    await close(blocker);
  }
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 1, child.stderr || child.stdout);
  assert.equal(child.signal, null);
  assert.equal(child.stderr, "");
  const records = child.stdout.trim().split("\n").map(JSON.parse);
  assert.deepEqual(records.map(({ level, event, phase, reason }) => ({
    level, event, phase, reason,
  })), [
    {
      level: "info",
      event: "service.lifecycle",
      phase: "starting",
      reason: "startup",
    },
    {
      level: "error",
      event: "framework.error",
      phase: undefined,
      reason: "framework-error",
    },
    {
      level: "error",
      event: "service.failure",
      phase: "failed",
      reason: "failed",
    },
  ]);
  assert.equal(records.every((record) => record.buildId === "pass12b4b-shutdown"), true);
});

test("a real post-bind readiness failure exits after framework cleanup", async () => {
  const reservation = createServer();
  const port = await listen(reservation);
  await close(reservation);
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    const appModule = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { startConfiguredApplication } = await import(${JSON.stringify(startupUrl)});
    const runtimeConfig = createRuntimeConfig({ PORT: ${JSON.stringify(String(port))} });
    const result = await startConfiguredApplication(runtimeConfig, async () => ({
      createApplication(config) {
        const real = appModule.createApplication(config, {
          operationsLogger: createOperationsLogger({ write() {} }),
        });
        return Object.freeze({
          ...real,
          markReady() { throw new Error("POST_BIND_CANARY_12B4A"); },
        });
      },
    }));
    assert.equal(result.accepted, false);
    process.stdout.write("clean-exit");
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 5_000,
  });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stdout, "clean-exit");
  assert.equal(child.stderr.includes("POST_BIND_CANARY_12B4A"), false);
});

test("real Express probes and admission follow starting, ready, and draining state", async () => {
  const reservation = createServer();
  const port = await listen(reservation);
  await close(reservation);
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const sharedRuntimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { Netcode } = await import(${JSON.stringify(sharedRuntimeUrl)});
    const config = createRuntimeConfig({ PORT: ${JSON.stringify(String(port))} });
    const application = createApplication(config, {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    const origin = "http://127.0.0.1:${port}";
    const probe = async (path, status, payload) => {
      const response = await fetch(origin + path);
      assert.equal(response.status, status, path);
      assert.equal(response.headers.get("cache-control"), "no-store");
      assert.equal(response.headers.get("x-content-type-options"), "nosniff");
      assert.deepEqual(await response.json(), payload);
    };
    const rejectedOptions = async (path, status, error) => {
      const response = await fetch(origin + path, {
        method: "OPTIONS",
        headers: {
          origin,
          "access-control-request-method": "POST",
          "access-control-request-headers": "content-type",
        },
      });
      assert.equal(response.status, status, path);
      assert.equal(response.headers.get("cache-control"), "no-store");
      assert.equal(response.headers.get("x-content-type-options"), "nosniff");
      assert.deepEqual(await response.json(), { error });
    };
    await application.listen();
    await probe("/livez", 200, { status: "live" });
    await probe("/readyz", 503, { status: "unavailable" });
    application.markReady();
    await probe("/readyz", 200, { status: "ready" });
    await rejectedOptions("/livez", 405, "method not allowed");
    await rejectedOptions("/readyz", 405, "method not allowed");
    await rejectedOptions("/health", 404, "not found");
    await rejectedOptions("/__healthcheck", 404, "not found");
    await rejectedOptions("/nope", 404, "not found");
    const preflight = await fetch(origin + "/matchmake/joinOrCreate/arena", {
      method: "OPTIONS",
      headers: {
        origin,
        "access-control-request-method": "POST",
        "access-control-request-headers": "content-type",
      },
    });
    assert.equal(preflight.status, 204);
    assert.equal(preflight.headers.get("access-control-allow-origin"), origin);
    assert.equal(preflight.headers.get("access-control-allow-credentials"), "false");
    application.serviceState.transition("draining");
    await probe("/livez", 200, { status: "live" });
    await probe("/readyz", 503, { status: "unavailable" });
    const admission = await fetch(origin + "/matchmake/joinOrCreate/arena", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        compatibility: Netcode.createCompatibilityOffer(),
        operation: "quick-match",
        modeId: "free-for-all",
        mapId: "original-arena",
      }),
    });
    assert.equal(admission.status, 503);
    assert.deepEqual(await admission.json(), { error: "service unavailable" });
    await application.abortStartup();
    process.stdout.write("clean-exit");
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
    timeout: 5_000,
  });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stdout, "clean-exit");
});
