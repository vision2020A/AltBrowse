import assert from "node:assert/strict";
import test from "node:test";

import { ErrorCode, ServerError } from "@colyseus/core";

import { Netcode, Sim } from "../src/shared-runtime.mjs";
import { createSecurityRejectionTracker, createServiceState } from "../src/operations.mjs";
import * as Boundary from "../src/protocol-boundary.mjs";

const LOCAL_ORIGIN = "http://127.0.0.1:2567";
const LOCAL_MATCHMAKE = `${LOCAL_ORIGIN}/matchmake/joinOrCreate/arena`;
const LOCAL_CREATE = `${LOCAL_ORIGIN}/matchmake/create/arena`;
const LOCAL_JOIN_CODE = `${LOCAL_ORIGIN}/matchmake/joinById/ABCDEFG`;
const LOCAL_UPGRADE = `${LOCAL_ORIGIN}/room-1/process-1?sessionId=session-1`;

function offer(overrides = {}) {
  return { ...Netcode.createCompatibilityOffer(), ...overrides };
}

function hello(overrides = {}) {
  return { ...Netcode.createServerHello(), ...overrides };
}

function configuredOptions(operation, compatibility = offer()) {
  return {
    compatibility,
    operation,
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function options(compatibility = offer()) {
  return configuredOptions(Boundary.QUICK_MATCH_OPERATION, compatibility);
}

function createOptions(compatibility = offer()) {
  return configuredOptions(Boundary.CREATE_MATCH_OPERATION, compatibility);
}

function joinOptions(compatibility = offer()) {
  return { compatibility, operation: Boundary.JOIN_CODE_OPERATION };
}

function canonicalAuth(operation, compatibility = offer()) {
  return configuredOptions(operation, compatibility);
}

function context(origin = LOCAL_ORIGIN, path = "/matchmake/joinOrCreate/arena") {
  return {
    headers: new Headers({ host: "127.0.0.1:2567", ...(origin == null ? {} : { origin }) }),
    req: { method: "POST", url: `${LOCAL_ORIGIN}${path}` },
  };
}

function admissionRequest({
  url = LOCAL_MATCHMAKE,
  method = "POST",
  origin = LOCAL_ORIGIN,
  host = "127.0.0.1:2567",
  contentType = "application/json",
  contentLength,
  contentEncoding,
  authorization,
  edgeRejected = false,
  body = JSON.stringify(options()),
} = {}) {
  if (contentLength === undefined) contentLength = String(Buffer.byteLength(body));
  const headers = new Headers();
  if (origin != null) headers.set("origin", origin);
  if (host != null) headers.set("host", host);
  if (contentType != null) headers.set("content-type", contentType);
  if (contentLength != null) headers.set("content-length", contentLength);
  if (contentEncoding != null) headers.set("content-encoding", contentEncoding);
  if (authorization != null) headers.set("authorization", authorization);
  if (edgeRejected) headers.set(Boundary.PASS12B1_RAW_REJECTION_HEADER, "1");
  return new Request(url, {
    method,
    headers,
    ...(body === undefined || method === "GET" || method === "HEAD" ? {} : { body }),
  });
}

function upgradeRequest({
  url = LOCAL_UPGRADE,
  origin = LOCAL_ORIGIN,
  host = "127.0.0.1:2567",
} = {}) {
  const headers = new Headers();
  if (origin != null) headers.set("origin", origin);
  if (host != null) headers.set("host", host);
  return new Request(url, { headers });
}

async function responseJson(response) {
  assert.ok(response instanceof Response);
  return response.json();
}

function rejected(result, reason) {
  assert.equal(result.accepted, false);
  if (reason) assert.equal(result.reason, reason);
}

function assertAuthFailure(callback, message) {
  assert.throws(callback, (error) => {
    assert.ok(error instanceof ServerError);
    assert.equal(error.code, ErrorCode.AUTH_FAILED);
    assert.equal(error.message, message);
    return true;
  });
}

test("compatibility offer and server hello have separate exact contracts", () => {
  assert.equal(typeof Netcode.createCompatibilityOffer, "function");
  assert.equal(typeof Netcode.validateCompatibilityOffer, "function");
  assert.equal(typeof Netcode.createServerHello, "function");
  assert.equal(typeof Netcode.validateServerHello, "function");
  assert.equal(typeof Netcode.validateCurrentServerHello, "function");
  assert.equal(Netcode.SIMULATION_SCHEMA_VERSION, Sim.VERSION);

  const clientOffer = offer();
  assert.deepEqual(Object.keys(clientOffer), [
    "protocolVersion",
    "simulationSchemaVersion",
    "inputContractVersion",
    "clientRuntimeId",
    "supportedModeIds",
    "supportedMapIds",
  ]);
  assert.equal("serverBuildId" in clientOffer, false, "server identity is not a client claim");
  assert.deepEqual(clientOffer.supportedModeIds, ["free-for-all"]);
  assert.deepEqual(clientOffer.supportedMapIds, ["original-arena"]);
  assert.equal(Netcode.validateCompatibilityOffer(clientOffer).accepted, true);

  const serverHello = hello();
  assert.deepEqual(Object.keys(serverHello), [...Object.keys(clientOffer), "serverBuildId"]);
  assert.equal(Netcode.validateServerHello(serverHello).accepted, true);
  assert.equal(Netcode.validateCurrentServerHello(serverHello).accepted, true);

  const rollbackBuild = hello({ serverBuildId: "pass12b1-rollback.2" });
  assert.equal(
    Netcode.validateServerHello(rollbackBuild).accepted,
    true,
    "a safe build identifier is diagnostic, not a patch/rollback compatibility key",
  );
  rejected(Netcode.validateCurrentServerHello(rollbackBuild), "server-build-id");
});

test("compatibility accepts an exact null-prototype record and rejects record-shape tricks", () => {
  const nullPrototype = Object.assign(Object.create(null), offer());
  assert.equal(Netcode.validateCompatibilityOffer(nullPrototype).accepted, true);

  const missing = offer();
  delete missing.protocolVersion;
  rejected(Netcode.validateCompatibilityOffer(missing), "invalid-record");

  rejected(Netcode.validateCompatibilityOffer({ ...offer(), authority: "client" }), "invalid-record");
  rejected(Netcode.validateCompatibilityOffer({ ...offer(), serverUrl: "wss://attacker.invalid" }), "invalid-record");
  rejected(Netcode.validateCompatibilityOffer(Object.create(offer())), "invalid-record");
  rejected(Netcode.validateCompatibilityOffer([]), "invalid-record");
  rejected(Netcode.validateCompatibilityOffer(null), "invalid-record");

  const symbol = offer();
  symbol[Symbol("hidden")] = true;
  rejected(Netcode.validateCompatibilityOffer(symbol), "invalid-record");

  const nonEnumerable = offer();
  Object.defineProperty(nonEnumerable, "protocolVersion", {
    value: nonEnumerable.protocolVersion,
    enumerable: false,
  });
  rejected(Netcode.validateCompatibilityOffer(nonEnumerable), "invalid-record");
});

test("compatibility validation never invokes accessor values and catches hostile proxy traps", () => {
  let getterCalls = 0;
  const accessor = offer();
  Object.defineProperty(accessor, "protocolVersion", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return Netcode.ONLINE_PROTOCOL_VERSION;
    },
  });
  rejected(Netcode.validateCompatibilityOffer(accessor), "invalid-record");
  assert.equal(getterCalls, 0);

  const catalogAccessor = offer();
  const modes = ["free-for-all"];
  Object.defineProperty(modes, "0", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return "free-for-all";
    },
  });
  catalogAccessor.supportedModeIds = modes;
  rejected(Netcode.validateCompatibilityOffer(catalogAccessor), "supported-mode-ids");
  assert.equal(getterCalls, 0);

  for (const trap of ["getPrototypeOf", "ownKeys", "getOwnPropertyDescriptor"]) {
    const hostile = new Proxy(offer(), {
      [trap]() {
        throw new Error(`hostile ${trap}`);
      },
    });
    let result;
    assert.doesNotThrow(() => {
      result = Netcode.validateCompatibilityOffer(hostile);
    });
    rejected(result);
  }
});

test("compatibility versions and catalogs must match exactly", () => {
  for (const [key, values] of [
    ["protocolVersion", [0, 1, 2, 4, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY, "3", null]],
    ["simulationSchemaVersion", [0, 5, 7, -1, 6.5, Number.NaN, "6", null]],
    ["inputContractVersion", [0, 1, 3, -1, 1.5, Number.NaN, "2", null]],
  ]) {
    for (const value of values) {
      rejected(Netcode.validateCompatibilityOffer(offer({ [key]: value })));
    }
  }

  for (const clientRuntimeId of [
    "classic-canvas-v2",
    "",
    "CLASSIC-CANVAS-V1",
    null,
    1,
  ]) {
    rejected(
      Netcode.validateCompatibilityOffer(offer({ clientRuntimeId })),
      "client-runtime-id",
    );
  }

  for (const modes of [[], ["FREE-FOR-ALL"], ["free-for-all", "free-for-all"], ["other"]]) {
    rejected(Netcode.validateCompatibilityOffer(offer({ supportedModeIds: modes })), "supported-mode-ids");
  }
  for (const maps of [[], ["ORIGINAL-ARENA"], ["original-arena", "original-arena"], ["other"]]) {
    rejected(Netcode.validateCompatibilityOffer(offer({ supportedMapIds: maps })), "supported-map-ids");
  }

  const sparseModes = new Array(1);
  rejected(Netcode.validateCompatibilityOffer(offer({ supportedModeIds: sparseModes })), "supported-mode-ids");
  const inheritedModes = Object.create(["free-for-all"]);
  rejected(Netcode.validateCompatibilityOffer(offer({ supportedModeIds: inheritedModes })), "supported-mode-ids");
});

test("server hello permits only a bounded diagnostic build identifier", () => {
  for (const serverBuildId of [
    "",
    "UPPERCASE",
    " leading-space",
    "line\nbreak",
    "../secret",
    "x".repeat(65),
    null,
    12,
  ]) {
    rejected(Netcode.validateServerHello(hello({ serverBuildId })), "server-build-id");
  }
  rejected(Netcode.validateServerHello({ ...hello(), stack: "secret" }), "invalid-record");
  rejected(Netcode.validateServerHello(offer()), "invalid-record");
});

test("Quick, Create, Join, and canonical auth records are exact and prototype-safe", () => {
  assert.deepEqual(Boundary.validateAdmissionOptions(options()), {
    accepted: true,
    operation: Boundary.QUICK_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  });
  assert.deepEqual(Boundary.validateAdmissionOptions(createOptions()), {
    accepted: true,
    operation: Boundary.CREATE_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  });
  assert.deepEqual(Boundary.validateAdmissionOptions(joinOptions()), {
    accepted: true,
    operation: Boundary.JOIN_CODE_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  });
  for (const operation of [
    Boundary.QUICK_MATCH_OPERATION,
    Boundary.CREATE_MATCH_OPERATION,
    Boundary.JOIN_CODE_OPERATION,
  ]) {
    assert.equal(Boundary.validateAdmissionAuth(canonicalAuth(operation)), true);
  }
  assert.equal(
    Boundary.validateAdmissionAuth(joinOptions()),
    false,
    "join options omit the server-derived frozen configuration and are not canonical auth",
  );

  for (const valid of [options(), createOptions(), joinOptions()]) {
    const nullOptions = Object.assign(Object.create(null), valid);
    assert.equal(Boundary.validateAdmissionOptions(nullOptions).accepted, true);
  }
  const nullAuth = Object.assign(
    Object.create(null),
    canonicalAuth(Boundary.JOIN_CODE_OPERATION),
  );
  assert.equal(Boundary.validateAdmissionAuth(nullAuth), true);

  for (const invalid of [
    {},
    { ...options(), actorId: 0 },
    { ...options(), sessionId: "chosen-by-client" },
    { ...options(), serverUrl: "wss://attacker.invalid" },
    { ...options(), seed: 1 },
    { ...options(), operation: "unknown" },
    { ...options(), modeId: "forged-mode" },
    { ...options(), mapId: "forged-map" },
    { compatibility: offer(), operation: Boundary.QUICK_MATCH_OPERATION },
    { ...joinOptions(), modeId: "free-for-all" },
    { ...joinOptions(), mapId: "original-arena" },
    Object.create(options()),
  ]) {
    rejected(Boundary.validateAdmissionOptions(invalid), "invalid-options");
    assert.equal(Boundary.validateAdmissionAuth(invalid), false);
  }

  const symbolOptions = options();
  symbolOptions[Symbol("hidden")] = true;
  rejected(Boundary.validateAdmissionOptions(symbolOptions), "invalid-options");
  assert.equal(Boundary.validateAdmissionAuth(symbolOptions), false);

  let getterCalls = 0;
  const accessorOptions = options();
  Object.defineProperty(accessorOptions, "compatibility", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return offer();
    },
  });
  rejected(Boundary.validateAdmissionOptions(accessorOptions), "invalid-options");
  assert.equal(Boundary.validateAdmissionAuth(accessorOptions), false);
  assert.equal(getterCalls, 0);

  const hostileOptions = new Proxy(options(), {
    ownKeys() {
      throw new Error("hostile options");
    },
  });
  assert.doesNotThrow(() => Boundary.validateAdmissionOptions(hostileOptions));
  rejected(Boundary.validateAdmissionOptions(hostileOptions), "invalid-options");
  assert.equal(Boundary.validateAdmissionAuth(hostileOptions), false);
});

test("authorization regenerates canonical auth and returns fixed redacted failures", () => {
  const supplied = offer();
  const auth = Boundary.authorizeAdmission("", options(supplied), context());
  assert.deepEqual(Object.keys(auth), ["compatibility", "operation", "modeId", "mapId"]);
  assert.deepEqual(auth.compatibility, offer());
  assert.equal(auth.operation, Boundary.QUICK_MATCH_OPERATION);
  assert.equal(auth.modeId, "free-for-all");
  assert.equal(auth.mapId, "original-arena");
  assert.notEqual(auth.compatibility, supplied);
  assert.notEqual(auth.compatibility.supportedModeIds, supplied.supportedModeIds);
  assert.notEqual(auth.compatibility.supportedMapIds, supplied.supportedMapIds);
  assert.equal("sessionId" in auth, false);
  assert.equal("token" in auth, false);

  const created = Boundary.authorizeAdmission(
    "",
    createOptions(),
    context(LOCAL_ORIGIN, "/matchmake/create/arena"),
  );
  assert.deepEqual(created, canonicalAuth(Boundary.CREATE_MATCH_OPERATION));
  const joined = Boundary.authorizeAdmission(
    "",
    joinOptions(),
    context(LOCAL_ORIGIN, "/matchmake/joinById/ABCDEFG"),
  );
  assert.deepEqual(joined, canonicalAuth(Boundary.JOIN_CODE_OPERATION));

  assertAuthFailure(
    () => Boundary.authorizeAdmission("secret-do-not-reflect", options(), context()),
    Boundary.INCOMPATIBLE_CLIENT_MESSAGE,
  );
  assertAuthFailure(
    () => Boundary.authorizeAdmission("", { compatibility: { received: "secret-do-not-reflect" } }, context()),
    Boundary.INCOMPATIBLE_CLIENT_MESSAGE,
  );
  assertAuthFailure(
    () => Boundary.authorizeAdmission("", options(), context("https://attacker.invalid")),
    Boundary.ORIGIN_REJECTED_MESSAGE,
  );
  for (const [mismatched, mismatchContext] of [
    [createOptions(), context()],
    [joinOptions(), context()],
    [options(), context(LOCAL_ORIGIN, "/matchmake/create/arena")],
    [options(), context(LOCAL_ORIGIN, "/matchmake/joinById/ABCDEFG")],
  ]) {
    assertAuthFailure(
      () => Boundary.authorizeAdmission("", mismatched, mismatchContext),
      Boundary.INCOMPATIBLE_CLIENT_MESSAGE,
    );
  }
});

test("an exact incompatible envelope remains distinct from malformed matchmaking input", () => {
  const incompatible = options(offer({
    protocolVersion: Netcode.ONLINE_PROTOCOL_VERSION + 1,
  }));
  rejected(Boundary.validateAdmissionOptions(incompatible), "incompatible-client");
  rejected(
    Boundary.validateMatchmakingRequest("joinOrCreate", "arena", incompatible),
    "incompatible-client",
  );
  rejected(Boundary.validateAdmissionOptions({ compatibility: null }), "invalid-options");
});

test("matchmaking method, target, and operation are one exact contract", () => {
  for (const [method, target, admission] of [
    ["joinOrCreate", "arena", options()],
    ["create", "arena", createOptions()],
    ["joinById", "ABCDEFG", joinOptions()],
  ]) {
    assert.deepEqual(Boundary.validateMatchmakingRequest(method, target, admission), {
      accepted: true,
      operation: admission.operation,
      modeId: "free-for-all",
      mapId: "original-arena",
    });
  }

  for (const [method, target, admission] of [
    ["join", "arena", options()],
    ["joinOrCreate", "unknown", options()],
    ["joinOrCreate", "arena", createOptions()],
    ["create", "arena", options()],
    ["create", "ABCDEFG", createOptions()],
    ["joinById", "ABCDEFG", options()],
    ["joinById", "abcdefg", joinOptions()],
    ["joinById", "ABCDEF", joinOptions()],
    ["joinById", "ABCDEFGH", joinOptions()],
    ["joinById", "ABCD0FG", joinOptions()],
    ["joinById", "ABCDIFG", joinOptions()],
    ["joinById", "ABCDOFG", joinOptions()],
    ["joinById", "ABC/DEF", joinOptions()],
  ]) {
    rejected(Boundary.validateMatchmakingRequest(method, target, admission));
  }
});

test("local origins are exact and must pair with the request Host", () => {
  assert.equal(typeof Boundary.isAllowedLocalRequest, "function");
  assert.equal(typeof Boundary.isAllowedLocalHost, "function");
  for (const origin of [null, "", "http://127.0.0.1", LOCAL_ORIGIN, "http://localhost:3000"]) {
    assert.equal(Boundary.isAllowedLocalOrigin(origin), true, String(origin));
  }
  for (const origin of [
    "https://127.0.0.1:2567",
    "http://0.0.0.0:2567",
    "http://[::1]:2567",
    "http://attacker.invalid",
    "http://user@127.0.0.1:2567",
    "http://127.0.0.1:2567/path",
    "http://127.0.0.1:2567?query=1",
    "null",
    7,
  ]) {
    assert.equal(Boundary.isAllowedLocalOrigin(origin), false, String(origin));
  }

  assert.equal(Boundary.isAllowedLocalRequest(LOCAL_ORIGIN, LOCAL_MATCHMAKE), true);
  assert.equal(Boundary.isAllowedLocalRequest(null, LOCAL_MATCHMAKE), true, "headless SDK may omit Origin");
  assert.equal(
    Boundary.isAllowedLocalRequest("http://localhost:2567", LOCAL_MATCHMAKE),
    false,
    "loopback spellings do not weaken exact same-origin pairing",
  );
  assert.equal(Boundary.isAllowedLocalRequest("http://127.0.0.1:3000", LOCAL_MATCHMAKE), false);
  assert.equal(Boundary.isAllowedLocalRequest(null, "http://attacker.invalid/matchmake/joinOrCreate/arena"), false);
  assert.equal(Boundary.isAllowedLocalRequest(LOCAL_ORIGIN, "not a url"), false);
  assert.equal(Boundary.isAllowedLocalHost("127.0.0.1:2567", LOCAL_MATCHMAKE), true);
  assert.equal(Boundary.isAllowedLocalHost("localhost:2567", LOCAL_MATCHMAKE), false);
  assert.equal(Boundary.isAllowedLocalHost(null, LOCAL_MATCHMAKE), false);
  assert.equal(Boundary.isAllowedLocalHost("attacker.invalid", LOCAL_MATCHMAKE), false);
  assert.equal(Boundary.isAllowedLocalHost("2130706433:2567", LOCAL_MATCHMAKE), false);
  assert.equal(Boundary.isAllowedLocalHost("127.000.000.001:2567", LOCAL_MATCHMAKE), false);
});

test("configured request policies enforce exact local ports and allow audited public origins", () => {
  const configuredLocal = Object.freeze({
    mode: "local",
    allowMissingOrigin: true,
    allowedHosts: Object.freeze(["127.0.0.1:3456", "localhost:3456"]),
    allowedOrigins: Object.freeze(["http://127.0.0.1:3456", "http://localhost:3456"]),
  });
  assert.equal(Boundary.isAllowedRawHost("127.0.0.1:3456", configuredLocal), true);
  assert.equal(Boundary.isAllowedRawHost("127.0.0.1:2567", configuredLocal), false);
  assert.equal(Boundary.isAllowedConfiguredRequest(
    "http://127.0.0.1:3456",
    "http://127.0.0.1:3456/matchmake/joinOrCreate/arena",
    configuredLocal,
  ), true);
  assert.equal(Boundary.isAllowedConfiguredRequest(
    "http://localhost:3456",
    "http://127.0.0.1:3456/matchmake/joinOrCreate/arena",
    configuredLocal,
  ), false);
  assert.equal(Boundary.isAllowedConfiguredOrigin(null, configuredLocal), true);
  assert.equal(Boundary.isAllowedConfiguredOrigin("", configuredLocal), false);

  const configuredPublic = Object.freeze({
    mode: "public",
    allowMissingOrigin: false,
    allowedHosts: Object.freeze(["arena.example"]),
    allowedOrigins: Object.freeze(["https://arena.example", "https://pages.example"]),
  });
  assert.equal(Boundary.isAllowedConfiguredRequest(
    "https://pages.example",
    "https://arena.example/matchmake/joinOrCreate/arena",
    configuredPublic,
  ), true);
  assert.equal(Boundary.isAllowedConfiguredRequest(
    null,
    "https://arena.example/matchmake/joinOrCreate/arena",
    configuredPublic,
  ), false);
  assert.equal(Boundary.isAllowedConfiguredRequest(
    "https://attacker.invalid",
    "https://arena.example/matchmake/joinOrCreate/arena",
    configuredPublic,
  ), false);
});

test("HTTP admission accepts only the local bounded anonymous JSON contract", async () => {
  const boundary = Boundary.createProtocolBoundary();
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
  assert.equal(
    await boundary.onRequest(admissionRequest({ contentType: "application/json; charset=utf-8" })),
    undefined,
  );

  const cases = [
    [{ url: `${LOCAL_MATCHMAKE}?serverUrl=wss%3A%2F%2Fattacker.invalid` }, 404],
    [{ method: "GET" }, 405],
    [{ origin: "https://attacker.invalid" }, 403],
    [{ host: null, origin: null }, 403],
    [{ url: "http://attacker.invalid/matchmake/joinOrCreate/arena", host: "attacker.invalid", origin: null }, 403],
    [{ url: `${LOCAL_ORIGIN}/matchmake/joinOrCreate/unknown` }, 404],
    [{ url: `${LOCAL_ORIGIN}/matchmake/joinOrCreate/arena/extra` }, 404],
    [{ contentType: null }, 415],
    [{ contentType: "text/plain" }, 415],
    [{ contentLength: null }, 411],
    [{ contentLength: "0" }, 400],
    [{ contentLength: "01" }, 411],
    [{ contentLength: String(Boundary.PASS12B1_MAX_HTTP_BODY_BYTES + 1) }, 413],
    [{ contentEncoding: "gzip" }, 415],
    [{ authorization: "Bearer do-not-reflect" }, 400],
    [{ edgeRejected: true }, 400],
  ];
  for (const [requestOptions, expectedStatus] of cases) {
    const response = await boundary.onRequest(admissionRequest(requestOptions));
    assert.ok(response instanceof Response, JSON.stringify(requestOptions));
    assert.equal(response.status, expectedStatus, JSON.stringify(requestOptions));
    assert.equal(response.headers.get("cache-control"), "no-store");
    assert.equal(response.headers.get("x-content-type-options"), "nosniff");
    const payload = await responseJson(response);
    assert.deepEqual(Object.keys(payload), ["error"]);
    assert.equal(JSON.stringify(payload).includes("do-not-reflect"), false);
    assert.equal(JSON.stringify(payload).includes("attacker.invalid"), false);
  }

  const hiddenHealth = await boundary.onRequest(new Request(`${LOCAL_ORIGIN}/__healthcheck`));
  assert.equal(hiddenHealth.status, 404, "Pass 12B1 does not expose an operations endpoint early");
  assert.equal(await boundary.onRequest(new Request(`${LOCAL_ORIGIN}/online-sdk.js`)), undefined);
});

test("readiness blocks admission and upgrades before ready and throughout draining", async () => {
  const serviceState = createServiceState();
  const rejectionTracker = createSecurityRejectionTracker();
  const boundary = Boundary.createProtocolBoundary({ serviceState, rejectionTracker });

  let response = await boundary.onRequest(admissionRequest());
  assert.equal(response.status, 503);
  assert.deepEqual(await responseJson(response), { error: "service unavailable" });
  response = boundary.beforeUpgrade(upgradeRequest());
  assert.equal(response.status, 503);
  assert.equal(rejectionTracker.snapshot().counts.matchmaking, 2);

  serviceState.setListenerAvailable(true);
  serviceState.setDependenciesAvailable(true);
  serviceState.transition("ready");
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
  assert.equal(boundary.beforeUpgrade(upgradeRequest()), undefined);

  const request = admissionRequest();
  let releaseBody;
  const bodyPending = new Promise((resolve) => {
    releaseBody = resolve;
  });
  const crossing = boundary.onRequest({
    url: request.url,
    method: request.method,
    headers: request.headers,
    clone: () => ({ text: () => bodyPending }),
  });
  await new Promise((resolve) => setImmediate(resolve));
  serviceState.transition("draining");
  releaseBody(JSON.stringify(options()));
  response = await crossing;
  assert.equal(response.status, 503, "a pre-drain body crossed into matchmaking");
  assert.deepEqual(await responseJson(response), { error: "service unavailable" });
  response = await boundary.onRequest(admissionRequest());
  assert.equal(response.status, 503);
  response = boundary.beforeUpgrade(upgradeRequest());
  assert.equal(response.status, 503);
  assert.equal(rejectionTracker.snapshot().counts.matchmaking, 5);
  const rewritten = boundary.onResponse(new Response("attacker detail", { status: 503 }));
  assert.equal(rewritten.status, 503);
  assert.deepEqual(await responseJson(rewritten), { error: "service unavailable" });
});

test("HTTP exposes only exact Quick, Create, Join Code, and reconnect request shapes", async () => {
  const boundary = Boundary.createProtocolBoundary({
    quickMatchLimit: 20,
    createMatchLimit: 20,
    joinCodeLimit: 20,
    reconnectLimit: 20,
  });
  for (const [url, admission] of [
    [LOCAL_MATCHMAKE, options()],
    [LOCAL_CREATE, createOptions()],
    [LOCAL_JOIN_CODE, joinOptions()],
  ]) {
    const body = JSON.stringify(admission);
    assert.equal(await boundary.onRequest(admissionRequest({
      url,
      body,
      contentLength: String(Buffer.byteLength(body)),
    })), undefined, url);
  }

  const incompatibleBody = JSON.stringify(options(offer({
    protocolVersion: Netcode.ONLINE_PROTOCOL_VERSION + 1,
  })));
  assert.equal(await boundary.onRequest(admissionRequest({
    body: incompatibleBody,
    contentLength: String(Buffer.byteLength(incompatibleBody)),
  })), undefined, "an exact incompatible envelope must reach onAuth for the fixed 525 response");

  const legacyBody = JSON.stringify({
    compatibility: offer({ protocolVersion: Netcode.ONLINE_PROTOCOL_VERSION - 1 }),
  });
  assert.equal(await boundary.onRequest(admissionRequest({
    body: legacyBody,
    contentLength: String(Buffer.byteLength(legacyBody)),
  })), undefined, "a prior exact Quick envelope must reach onAuth for an understandable update response");

  for (const [url, admission] of [
    [`${LOCAL_ORIGIN}/matchmake/join/arena`, options()],
    [`${LOCAL_ORIGIN}/matchmake/create/ABCDEFG`, createOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/abcdefg`, joinOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/ABCDEF`, joinOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/ABCDEFGH`, joinOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/ABCD0FG`, joinOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/ABCDIFG`, joinOptions()],
    [`${LOCAL_ORIGIN}/matchmake/joinById/ABCDOFG`, joinOptions()],
  ]) {
    const body = JSON.stringify(admission);
    const response = await boundary.onRequest(admissionRequest({
      url,
      body,
      contentLength: String(Buffer.byteLength(body)),
    }));
    assert.equal(response.status, 404, url);
  }

  for (const [url, admission] of [
    [LOCAL_MATCHMAKE, createOptions()],
    [LOCAL_MATCHMAKE, joinOptions()],
    [LOCAL_CREATE, options()],
    [LOCAL_CREATE, joinOptions()],
    [LOCAL_JOIN_CODE, options()],
    [LOCAL_JOIN_CODE, createOptions()],
  ]) {
    const body = JSON.stringify(admission);
    const response = await boundary.onRequest(admissionRequest({
      url,
      body,
      contentLength: String(Buffer.byteLength(body)),
    }));
    assert.equal(response.status, 400, `${url}: ${admission.operation}`);
  }

  for (const url of [LOCAL_MATCHMAKE, LOCAL_CREATE, LOCAL_JOIN_CODE]) {
    for (const body of ["{}", "null", "[]", "{"]) {
      const response = await boundary.onRequest(admissionRequest({
        url,
        body,
        contentLength: String(Buffer.byteLength(body)),
      }));
      assert.equal(response.status, 400, `${url}: ${body}`);
    }
  }

  const reconnectUrl = `${LOCAL_ORIGIN}/matchmake/reconnect/room-1`;
  const validBody = JSON.stringify({ reconnectionToken: "reconnect-1" });
  assert.equal(await boundary.onRequest(admissionRequest({
    url: reconnectUrl,
    contentLength: String(Buffer.byteLength(validBody)),
    body: validBody,
  })), undefined);

  for (const body of [
    "{}",
    JSON.stringify({ reconnectionToken: "" }),
    JSON.stringify({ reconnectionToken: null }),
    JSON.stringify({ reconnectionToken: true }),
    JSON.stringify({ reconnectionToken: false }),
    JSON.stringify({ reconnectionToken: 123 }),
    JSON.stringify({ reconnectionToken: ["reconnect-1"] }),
    JSON.stringify({ reconnectionToken: { value: "reconnect-1" } }),
    JSON.stringify({ reconnectionToken: "reconnect-1", actorId: 0 }),
    JSON.stringify({ reconnectionToken: "r".repeat(65) }),
    "{",
  ]) {
    const response = await boundary.onRequest(admissionRequest({
      url: reconnectUrl,
      contentLength: String(Buffer.byteLength(body)),
      body,
    }));
    assert.equal(response.status, 400, body);
  }
});

test("one-process admission rejects stale Join Code and reconnect lookups before remote IPC", async () => {
  const checked = [];
  const rejectionTracker = createSecurityRejectionTracker();
  const boundary = Boundary.createProtocolBoundary({
    isLocalRoom(roomId) {
      checked.push(roomId);
      return false;
    },
    rejectionTracker,
  });
  const joinBody = JSON.stringify(joinOptions());
  let response = await boundary.onRequest(admissionRequest({
    url: LOCAL_JOIN_CODE,
    body: joinBody,
    contentLength: String(Buffer.byteLength(joinBody)),
  }));
  assert.equal(response.status, ErrorCode.MATCHMAKE_INVALID_ROOM_ID);
  assert.deepEqual(await responseJson(response), { error: Boundary.MATCH_UNAVAILABLE_MESSAGE });

  const reconnectBody = JSON.stringify({ reconnectionToken: "opaque-token-1" });
  response = await boundary.onRequest(admissionRequest({
    url: `${LOCAL_ORIGIN}/matchmake/reconnect/room-1`,
    body: reconnectBody,
    contentLength: String(Buffer.byteLength(reconnectBody)),
  }));
  assert.equal(response.status, ErrorCode.MATCHMAKE_INVALID_ROOM_ID);
  assert.deepEqual(await responseJson(response), { error: Boundary.MATCH_UNAVAILABLE_MESSAGE });
  assert.deepEqual(checked, ["ABCDEFG", "room-1"]);
  assert.equal(rejectionTracker.snapshot().counts.matchmaking, 2);

  const localBoundary = Boundary.createProtocolBoundary({ isLocalRoom: () => true });
  assert.equal(await localBoundary.onRequest(admissionRequest({
    url: LOCAL_JOIN_CODE,
    body: joinBody,
    contentLength: String(Buffer.byteLength(joinBody)),
  })), undefined);
});

test("matchmaking lookup failures are redacted after the framework responds", async () => {
  const boundary = Boundary.createProtocolBoundary();
  const canary = "ABCDEFG-do-not-reflect";
  for (const status of [
    ErrorCode.MATCHMAKE_INVALID_CRITERIA,
    ErrorCode.MATCHMAKE_INVALID_ROOM_ID,
    ErrorCode.MATCHMAKE_UNHANDLED,
    ErrorCode.MATCHMAKE_EXPIRED,
  ]) {
    const response = boundary.onResponse(new Response(JSON.stringify({
      code: status,
      error: `room ${canary} was rejected`,
    }), { status, headers: { "content-type": "application/json" } }));
    assert.equal(response.status, status);
    assert.deepEqual(await responseJson(response), { error: Boundary.MATCH_UNAVAILABLE_MESSAGE });
    assert.equal(response.headers.get("cache-control"), "no-store");
  }
  assert.equal(boundary.onResponse(new Response("ok", { status: 200 })), undefined);
  assert.equal(boundary.onResponse(new Response("incompatible", {
    status: ErrorCode.AUTH_FAILED,
  })), undefined, "the already-fixed compatibility response keeps its exact contract");
});

test("HTTP admission has a deterministic aggregate fixed-window limit", async () => {
  let now = 1_000;
  const boundary = Boundary.createProtocolBoundary({ now: () => now, httpLimit: 2 });
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
  const limited = await boundary.onRequest(admissionRequest());
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get("retry-after"), "10");
  assert.deepEqual(boundary.httpLimiter.snapshot(), {
    windowStartedAt: 1_000,
    count: 2,
    limit: 2,
    windowMs: Boundary.PASS12B1_RATE_WINDOW_MS,
  });

  boundary.reset();
  assert.deepEqual(boundary.httpLimiter.snapshot(), {
    windowStartedAt: null,
    count: 0,
    limit: 2,
    windowMs: Boundary.PASS12B1_RATE_WINDOW_MS,
  });
  assert.deepEqual(boundary.upgradeLimiter.snapshot(), {
    windowStartedAt: null,
    count: 0,
    limit: Boundary.PASS12B1_WS_UPGRADE_LIMIT,
    windowMs: Boundary.PASS12B1_RATE_WINDOW_MS,
  });
  for (const limiter of Object.values(boundary.operationLimiters)) {
    assert.equal(limiter.snapshot().windowStartedAt, null);
    assert.equal(limiter.snapshot().count, 0);
  }
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
});

test("malformed local matchmaking attempts consume the aggregate budget before body parsing", async () => {
  const boundary = Boundary.createProtocolBoundary({ httpLimit: 1 });
  const malformed = await boundary.onRequest(admissionRequest({ method: "GET" }));
  assert.equal(malformed.status, 405);
  const limited = await boundary.onRequest(admissionRequest());
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get("retry-after"), "10");

  boundary.reset();
  const foreign = await boundary.onRequest(admissionRequest({ origin: "https://attacker.invalid" }));
  assert.equal(foreign.status, 403);
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
});

test("HTTP admission has independent bounded operation windows under the aggregate cap", async () => {
  let now = 2_000;
  const boundary = Boundary.createProtocolBoundary({
    now: () => now,
    httpLimit: 20,
    quickMatchLimit: 1,
    createMatchLimit: 1,
    joinCodeLimit: 1,
    reconnectLimit: 1,
  });
  const reconnectBody = JSON.stringify({ reconnectionToken: "reconnect-1" });
  const requests = [
    [Boundary.QUICK_MATCH_OPERATION, admissionRequest()],
    [Boundary.CREATE_MATCH_OPERATION, admissionRequest({
      url: LOCAL_CREATE,
      body: JSON.stringify(createOptions()),
    })],
    [Boundary.JOIN_CODE_OPERATION, admissionRequest({
      url: LOCAL_JOIN_CODE,
      body: JSON.stringify(joinOptions()),
    })],
    ["reconnect", admissionRequest({
      url: `${LOCAL_ORIGIN}/matchmake/reconnect/room-1`,
      body: reconnectBody,
    })],
  ];

  for (const [operation, request] of requests) {
    assert.equal(await boundary.onRequest(request.clone()), undefined, operation);
    const limited = await boundary.onRequest(request.clone());
    assert.equal(limited.status, 429, operation);
    assert.equal(limited.headers.get("retry-after"), "10", operation);
    assert.deepEqual(boundary.operationLimiters[operation].snapshot(), {
      windowStartedAt: 2_000,
      count: 1,
      limit: 1,
      windowMs: Boundary.PASS12B1_RATE_WINDOW_MS,
    });
  }

  now += Boundary.PASS12B1_RATE_WINDOW_MS;
  assert.equal(await boundary.onRequest(admissionRequest()), undefined);
});

test("fixed-window limiter rejects bad configuration and handles clock rollback", () => {
  for (const limit of [0, -1, 1.5, Number.NaN, "1"]) {
    assert.throws(() => Boundary.createFixedWindowLimiter({ limit, windowMs: 10 }), /limit/);
  }
  for (const windowMs of [0, -1, 1.5, Number.NaN, "10"]) {
    assert.throws(() => Boundary.createFixedWindowLimiter({ limit: 1, windowMs }), /windowMs/);
  }
  assert.throws(
    () => Boundary.createFixedWindowLimiter({ limit: 1, windowMs: 10, now: 1 }),
    /now/,
  );

  let now = 50;
  const limiter = Boundary.createFixedWindowLimiter({ limit: 1, windowMs: 10, now: () => now });
  assert.equal(limiter.consume().accepted, true);
  assert.equal(limiter.consume().accepted, false);
  now = 40;
  assert.equal(limiter.consume().accepted, true, "clock rollback starts a fresh bounded window");
  now = Number.NaN;
  assert.throws(() => limiter.consume(), /clock must be finite/);
  limiter.reset();
  assert.deepEqual(limiter.snapshot(), {
    windowStartedAt: null,
    count: 0,
    limit: 1,
    windowMs: 10,
  });
  now = 60;
  assert.equal(limiter.consume().accepted, true, "reset starts one fresh bounded window");
});

test("CORS never reflects a foreign origin or enables credentials", () => {
  const boundary = Boundary.createProtocolBoundary();
  const allowed = boundary.getCorsHeaders(new Headers({
    host: "127.0.0.1:2567",
    origin: LOCAL_ORIGIN,
  }));
  assert.equal(allowed["Access-Control-Allow-Origin"], LOCAL_ORIGIN);
  assert.equal(allowed["Access-Control-Allow-Credentials"], "false");
  assert.equal(allowed["Access-Control-Allow-Methods"], "POST,OPTIONS");
  assert.equal(allowed["Access-Control-Allow-Headers"], "Content-Type");
  assert.equal(allowed.Vary, "Origin");

  const rejectedCors = boundary.getCorsHeaders(new Headers({
    host: "127.0.0.1:2567",
    origin: "https://attacker.invalid",
  }));
  assert.notEqual(rejectedCors["Access-Control-Allow-Origin"], "https://attacker.invalid");
  assert.equal(rejectedCors["Access-Control-Allow-Origin"], "");
  assert.equal(rejectedCors["Access-Control-Allow-Credentials"], "false");
  const formerSentinel = boundary.getCorsHeaders(new Headers({
    host: "127.0.0.1:2567",
    origin: "https://origin.invalid",
  }));
  assert.equal(formerSentinel["Access-Control-Allow-Origin"], "");
  const wrongPort = boundary.getCorsHeaders(new Headers({
    host: "127.0.0.1:2567",
    origin: "http://127.0.0.1:9999",
  }));
  assert.equal(wrongPort["Access-Control-Allow-Origin"], "");
});

test("public CORS reflects only an audited origin for the configured authority", () => {
  const boundary = Boundary.createProtocolBoundary({
    requestPolicy: Object.freeze({
      mode: "public",
      allowMissingOrigin: false,
      allowedHosts: Object.freeze(["arena.example"]),
      allowedOrigins: Object.freeze(["https://arena.example", "https://pages.example"]),
    }),
  });
  const pages = boundary.getCorsHeaders(new Headers({
    host: "arena.example",
    origin: "https://pages.example",
  }));
  assert.equal(pages["Access-Control-Allow-Origin"], "https://pages.example");
  assert.equal(pages["Access-Control-Allow-Credentials"], "false");
  for (const [host, origin] of [
    ["attacker.invalid", "https://pages.example"],
    ["arena.example", "https://attacker.invalid"],
    ["arena.example", ""],
  ]) {
    assert.equal(boundary.getCorsHeaders(new Headers({ host, origin }))[
      "Access-Control-Allow-Origin"
    ], "");
  }
});

test("WebSocket upgrade URL accepts only the exact bounded transport shape", () => {
  for (const url of [
    LOCAL_UPGRADE,
    `${LOCAL_UPGRADE}&reconnectionToken=reconnect-1`,
    `${LOCAL_UPGRADE}&reconnectionToken=reconnect-1&skipHandshake=true`,
  ]) {
    assert.equal(Boundary.isAllowedUpgradeUrl(url), true, url);
  }

  for (const url of [
    `${LOCAL_ORIGIN}/room-1/process-1`,
    `${LOCAL_UPGRADE}&unknown=value`,
    `${LOCAL_UPGRADE}&_authToken=secret`,
    `${LOCAL_UPGRADE}&sessionId=second`,
    `${LOCAL_ORIGIN}/room-1/process-1?%73essionId=session-1`,
    `${LOCAL_ORIGIN}/room-1/process-1?sessionId=session%2D1`,
    `${LOCAL_ORIGIN}/room-1/process-1?sessionId=session+1`,
    `${LOCAL_ORIGIN}/room-1/process-1?sessionId=`,
    `${LOCAL_ORIGIN}/room-1/process-1/extra?sessionId=session-1`,
    `${LOCAL_ORIGIN}/room-1/process-1?sessionId=${"s".repeat(33)}`,
    `${LOCAL_UPGRADE}&reconnectionToken=${"r".repeat(65)}`,
    `${LOCAL_UPGRADE}&skipHandshake=true`,
    `${LOCAL_UPGRADE}&skipHandshake=false&reconnectionToken=reconnect-1`,
    `${LOCAL_UPGRADE}#fragment`,
    "not a url",
  ]) {
    assert.equal(Boundary.isAllowedUpgradeUrl(url), false, url);
  }
});

test("WebSocket boundary enforces local origin/Host pairing, URL policy, and rate", () => {
  let now = 2_000;
  const boundary = Boundary.createProtocolBoundary({ now: () => now, upgradeLimit: 1 });
  assert.equal(boundary.beforeUpgrade(upgradeRequest()), undefined);

  const limited = boundary.beforeUpgrade(upgradeRequest());
  assert.ok(limited instanceof Response);
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get("retry-after"), "10");

  now += Boundary.PASS12B1_RATE_WINDOW_MS;
  assert.equal(boundary.beforeUpgrade(upgradeRequest({ origin: null })), undefined);

  const foreignOrigin = boundary.beforeUpgrade(upgradeRequest({ origin: "https://attacker.invalid" }));
  assert.equal(foreignOrigin.status, 403);
  const missingHost = boundary.beforeUpgrade(upgradeRequest({ host: null, origin: null }));
  assert.equal(missingHost.status, 403);
  const mismatchedLoopback = boundary.beforeUpgrade(upgradeRequest({ origin: "http://localhost:2567" }));
  assert.equal(mismatchedLoopback.status, 403);
  const foreignHost = boundary.beforeUpgrade(upgradeRequest({
    url: "http://attacker.invalid/room-1/process-1?sessionId=session-1",
    host: "attacker.invalid",
    origin: null,
  }));
  assert.equal(foreignHost.status, 403);
  now += Boundary.PASS12B1_RATE_WINDOW_MS;
  const badUrl = boundary.beforeUpgrade(upgradeRequest({
    url: `${LOCAL_UPGRADE}&serverUrl=wss%3A%2F%2Fattacker.invalid`,
  }));
  assert.equal(badUrl.status, 400);
  assert.equal(
    boundary.beforeUpgrade(upgradeRequest()).status,
    429,
    "a malformed local upgrade consumes the aggregate attempt budget",
  );
});
