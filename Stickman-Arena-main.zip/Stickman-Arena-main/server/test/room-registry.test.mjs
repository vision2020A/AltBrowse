import assert from "node:assert/strict";
import test from "node:test";

import {
  MAX_CODE_ROOMS,
  MAX_LIVE_ROOMS,
  ROOM_CODE_ALPHABET,
  ROOM_CODE_ATTEMPTS,
  ROOM_CODE_LENGTH,
  ROOM_CODE_PATTERN,
  ROOM_SEAT_RESERVATION_SECONDS,
  createRoomRegistry,
  isRoomCode,
} from "../src/room-registry.mjs";

test("room-code and one-process resource constants stay at the frozen B3A contract", () => {
  assert.equal(ROOM_CODE_ALPHABET, "ABCDEFGHJKLMNPQRSTUVWXYZ23456789");
  assert.equal(ROOM_CODE_LENGTH, 7);
  assert.equal(ROOM_CODE_PATTERN.source, "^[A-HJ-NP-Z2-9]{7}$");
  assert.equal(MAX_LIVE_ROOMS, 64);
  assert.equal(MAX_CODE_ROOMS, 16);
  assert.equal(ROOM_CODE_ATTEMPTS, 16);
  assert.equal(ROOM_SEAT_RESERVATION_SECONDS, 10);

  for (const code of ["ABCDEFG", "AAAAAAA", "ZZZZZZZ", "2345678", "9Z8Y7X6"]) {
    assert.equal(isRoomCode(code), true, code);
    assert.equal(ROOM_CODE_PATTERN.test(code), true, code);
  }
  for (const code of [
    "", "ABCDEF", "ABCDEFGH", "abcdefg", "ABCD3F1", "ABCD3F0", "ABCD3FI",
    "ABCD3FO", "ABC-DEF", " ABCDEF", "ABCDEF ", "ABC/DEF", "ＡＢＣＤＥＦＧ", null, 7,
  ]) {
    assert.equal(isRoomCode(code), false, String(code));
  }
});

test("room registry enforces live/code caps and identity-safe idempotent release", () => {
  const registry = createRoomRegistry({
    randomInt: () => 0,
    maxLiveRooms: 2,
    maxCodeRooms: 1,
  });
  const quickOwner = {};
  const codeOwner = {};
  const otherOwner = {};

  assert.deepEqual(registry.reserveQuick("quick-room-1", quickOwner), {
    accepted: true,
    roomId: "quick-room-1",
  });
  const code = registry.reserveCode(codeOwner);
  assert.deepEqual(code, { accepted: true, roomId: "AAAAAAA" });
  assert.equal(Object.isFrozen(code), true);
  assert.deepEqual(registry.reserveQuick("quick-room-2", {}), {
    accepted: false,
    reason: "room-capacity",
  });
  assert.deepEqual(registry.reserveCode({}), {
    accepted: false,
    reason: "room-capacity",
  });

  const snapshot = registry.snapshot();
  assert.equal(Object.isFrozen(snapshot), true);
  assert.equal(Object.isFrozen(snapshot.roomIds), true);
  assert.deepEqual(snapshot, {
    liveRooms: 2,
    codeRooms: 1,
    roomIds: ["AAAAAAA", "quick-room-1"],
  });
  assert.equal(registry.release("quick-room-1", otherOwner), false);
  assert.equal(registry.release("missing-room", quickOwner), false);
  assert.deepEqual(registry.snapshot(), snapshot);
  assert.equal(registry.release("quick-room-1", quickOwner), true);
  assert.equal(registry.release("quick-room-1", quickOwner), false);
  assert.equal(registry.release("AAAAAAA", codeOwner), true);
  assert.deepEqual(registry.snapshot(), { liveRooms: 0, codeRooms: 0, roomIds: [] });
});

test("code capacity is distinct from aggregate room capacity", () => {
  let next = 0;
  const registry = createRoomRegistry({
    randomInt: () => next++ % ROOM_CODE_ALPHABET.length,
    maxLiveRooms: 3,
    maxCodeRooms: 1,
  });
  assert.equal(registry.reserveCode({}).accepted, true);
  assert.deepEqual(registry.reserveCode({}), {
    accepted: false,
    reason: "code-capacity",
  });
  assert.equal(
    registry.reserveQuick("quick-room", {}).accepted,
    true,
    "the separate code cap must not consume remaining Quick Match capacity",
  );
});

test("code allocation retries collisions a bounded number of times", () => {
  let randomCalls = 0;
  const registry = createRoomRegistry({
    randomInt: () => {
      randomCalls += 1;
      return 0;
    },
    maxLiveRooms: 3,
    maxCodeRooms: 3,
    attempts: ROOM_CODE_ATTEMPTS,
  });
  assert.deepEqual(registry.reserveCode({}), { accepted: true, roomId: "AAAAAAA" });
  assert.deepEqual(registry.reserveCode({}), {
    accepted: false,
    reason: "code-collision",
  });
  assert.equal(
    randomCalls,
    ROOM_CODE_LENGTH * (ROOM_CODE_ATTEMPTS + 1),
    "one successful attempt plus exactly the bounded retry budget must run",
  );
  assert.deepEqual(registry.snapshot(), {
    liveRooms: 1,
    codeRooms: 1,
    roomIds: ["AAAAAAA"],
  });
});

test("room registry rejects invalid owners and Quick Match identifiers without mutation", () => {
  const registry = createRoomRegistry({ randomInt: () => 0 });
  for (const owner of [null, undefined, 0, "owner"]) {
    assert.deepEqual(registry.reserveQuick("quick-room", owner), {
      accepted: false,
      reason: "invalid-owner",
    });
    assert.deepEqual(registry.reserveCode(owner), {
      accepted: false,
      reason: "invalid-owner",
    });
  }
  for (const roomId of ["", "x".repeat(33), "bad/room", null, 7]) {
    assert.deepEqual(registry.reserveQuick(roomId, {}), {
      accepted: false,
      reason: "invalid-room-id",
    });
  }

  const owner = {};
  assert.equal(registry.reserveQuick("quick-room", owner).accepted, true);
  assert.deepEqual(registry.reserveQuick("quick-room", {}), {
    accepted: false,
    reason: "room-id-collision",
  });
  assert.deepEqual(registry.snapshot(), {
    liveRooms: 1,
    codeRooms: 0,
    roomIds: ["quick-room"],
  });
});
