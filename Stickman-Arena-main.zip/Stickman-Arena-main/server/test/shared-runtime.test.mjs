import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";

import { Sim, Anim, Bots } from "../src/shared-runtime.mjs";

test("shared runtime loads in a fresh headless Node process", () => {
  const runtimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    assert.equal(typeof globalThis.window, "undefined");
    const { Sim, Anim, Bots } = await import(${JSON.stringify(runtimeUrl)});
    assert.equal(typeof Sim.fixedUpdate, "function");
    assert.equal(typeof Anim.poseForFighter, "function");
    assert.equal(typeof Anim.swordBlade, "function");
    assert.equal(typeof Anim.unarmedStrike, "function");
    assert.equal(typeof Anim.gunMuzzle, "function");
    assert.equal(typeof Anim.grenadeReleaseSocket, "function");
    assert.equal(typeof Anim.localToWorld, "function");
    assert.equal(typeof Bots.makeBotInput, "function");
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
  });
  assert.equal(child.status, 0, child.stderr || child.stdout);
});

test("application bootstrap aggregates redacted framework errors and disables inherited debug output", () => {
  const debugUrl = new URL("../node_modules/@colyseus/core/build/Debug.mjs", import.meta.url).href;
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    process.env.DEBUG = "colyseus:*";
    const debug = await import(${JSON.stringify(debugUrl)});
    assert.equal(debug.debugMessage.enabled, true);
    assert.equal(debug.debugError.enabled, true);
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const {
      createOperationsLogger,
      createSecurityRejectionTracker,
    } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const logLines = [];
    const operationsLogger = createOperationsLogger({
      buildId: "pass12b4a-test",
      clock: () => 0,
      write: (line) => logLines.push(line),
    });
    const rejectionTracker = createSecurityRejectionTracker({
      clock: () => 0,
      logger: operationsLogger,
    });
    const application = createApplication(createRuntimeConfig({}), {
      operationsLogger,
      rejectionTracker,
    });
    assert.equal(application.rejectionTracker, rejectionTracker);
    for (const name of [
      "debugConnection", "debugDevMode", "debugDriver", "debugError",
      "debugMatchMaking", "debugMessage", "debugPatch", "debugPresence",
    ]) assert.equal(debug[name].enabled, false, name);
    const consoleOutput = [];
    const originalError = console.error;
    try {
      console.error = (...values) => consoleOutput.push(values.map(String).join(" "));
      debug.debugAndPrintError(new Error("PAYLOAD_CANARY_12B4A moveX=0.75"));
    } finally {
      console.error = originalError;
    }
    assert.deepEqual(consoleOutput, []);
    assert.equal(rejectionTracker.snapshot().counts.protocol, 1);
    assert.equal(rejectionTracker.flush().counts.protocol, 1);
    assert.equal(rejectionTracker.snapshot().total, 0);
    assert.equal(logLines.join("").includes("PAYLOAD_CANARY_12B4A"), false);
    assert.equal(logLines.join("").includes("moveX"), false);
    assert.deepEqual(logLines.map(JSON.parse), [
      {
        timestamp: "1970-01-01T00:00:00.000Z",
        level: "info",
        event: "service.lifecycle",
        buildId: "pass12b4a-test",
        phase: "starting",
        reason: "startup",
      },
      {
        timestamp: "1970-01-01T00:00:00.000Z",
        level: "error",
        event: "framework.error",
        buildId: "pass12b4a-test",
        reason: "framework-error",
      },
      {
        timestamp: "1970-01-01T00:00:00.000Z",
        level: "warn",
        event: "security.rejections",
        buildId: "pass12b4a-test",
        reason: "manual-flush",
        category: "protocol",
        count: 1,
      },
    ]);
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
  });
  assert.equal(child.status, 0, child.stderr || child.stdout);
});

test("public application CORS uses only configured canonical origins and service authority", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const sharedRuntimeUrl = new URL("../src/shared-runtime.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { Netcode } = await import(${JSON.stringify(sharedRuntimeUrl)});
    const runtimeConfig = createRuntimeConfig({
      STICKMAN_SERVER_MODE: "public",
      NODE_ENV: "production",
      STICKMAN_BIND_HOST: "0.0.0.0",
      STICKMAN_PUBLIC_ORIGIN: "https://arena.example",
      STICKMAN_ALLOWED_ORIGINS: "https://arena.example,https://pages.example",
    });
    const application = createApplication(runtimeConfig, {
      operationsLogger: createOperationsLogger({ write() {} }),
      serviceState: Object.freeze({ isLive: () => true, isReady: () => true }),
    });
    assert.deepEqual(application.requestPolicy, {
      mode: "public",
      allowMissingOrigin: false,
      allowedHosts: ["arena.example"],
      allowedOrigins: ["https://arena.example", "https://pages.example"],
    });
    const cors = (origin, host = "arena.example") => application.boundary.getCorsHeaders(
      new Headers({ ...(origin == null ? {} : { origin }), host }),
    )["Access-Control-Allow-Origin"];
    assert.equal(cors("https://arena.example"), "https://arena.example");
    assert.equal(cors("https://pages.example"), "https://pages.example");
    assert.equal(cors(null), "");
    assert.equal(cors(""), "");
    assert.equal(cors("https://attacker.invalid"), "");
    assert.equal(cors("https://pages.example", "attacker.invalid"), "");

    const body = JSON.stringify({
      compatibility: Netcode.createCompatibilityOffer(),
      operation: "quick-match",
      modeId: "free-for-all",
      mapId: "original-arena",
    });
    const admission = (origin) => application.boundary.onRequest(new Request(
      "https://arena.example/matchmake/joinOrCreate/arena",
      {
        method: "POST",
        headers: {
          ...(origin == null ? {} : { origin }),
          host: "arena.example",
          "content-length": String(Buffer.byteLength(body)),
          "content-type": "application/json",
        },
        body,
      },
    ));
    assert.equal(await admission("https://pages.example"), undefined);
    assert.equal((await admission(null)).status, 403);
    assert.equal((await admission("https://attacker.invalid")).status, 403);
    assert.equal(application.boundary.beforeUpgrade(new Request(
      "https://arena.example/process-1/room-1?sessionId=session-1",
      { headers: { host: "arena.example", origin: "https://pages.example" } },
    )), undefined);
    assert.equal(application.boundary.beforeUpgrade(new Request(
      "https://arena.example/process-1/room-1?sessionId=session-1",
      { headers: { host: "arena.example" } },
    )).status, 403);
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
  });
  assert.equal(child.status, 0, child.stderr || child.stdout);
});

test("Colyseus Cloud proxy metadata is stripped before the strict public edge", () => {
  const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
  const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
  const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
  const source = `
    import assert from "node:assert/strict";
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const runtimeConfig = createRuntimeConfig({
      STICKMAN_SERVER_MODE: "public",
      NODE_ENV: "production",
      STICKMAN_BIND_HOST: "0.0.0.0",
      STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
      STICKMAN_ALLOWED_ORIGINS:
        "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
      COLYSEUS_CLOUD: "provider-marker",
      NODE_APP_INSTANCE: "0",
    });
    const application = createApplication(runtimeConfig, {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    const request = {
      method: "GET",
      url: "/",
      headers: {
        host: "de-fra-1131bd95.colyseus.cloud",
        forwarded: "private-value",
        "x-forwarded-for": "private-value",
        "x-forwarded-proto": "https",
        "x-real-ip": "private-value",
      },
      rawHeaders: [
        "Host", "de-fra-1131bd95.colyseus.cloud",
        "Forwarded", "private-value",
        "X-Forwarded-For", "private-value",
        "X-Forwarded-Proto", "https",
        "X-Real-IP", "private-value",
      ],
    };
    assert.equal(application.rawRequestGuard(request), false);
    assert.deepEqual(request.headers, { host: "de-fra-1131bd95.colyseus.cloud" });
    assert.deepEqual(request.rawHeaders, ["Host", "de-fra-1131bd95.colyseus.cloud"]);

    const publicOnly = createRuntimeConfig({
      STICKMAN_SERVER_MODE: "public",
      NODE_ENV: "production",
      STICKMAN_BIND_HOST: "0.0.0.0",
      STICKMAN_PUBLIC_ORIGIN: "https://de-fra-1131bd95.colyseus.cloud",
      STICKMAN_ALLOWED_ORIGINS:
        "https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
    });
    assert.equal(publicOnly.cloudProxy, false);
    const publicApplication = createApplication(publicOnly, {
      operationsLogger: createOperationsLogger({ write() {} }),
    });
    const storedPublicHeaders = {
      host: "de-fra-1131bd95.colyseus.cloud",
      forwarded: "private-value",
      "x-forwarded-for": "private-value",
      "x-forwarded-proto": "https",
      "x-real-ip": "private-value",
    };
    const publicRequest = {
      method: "GET",
      url: "/livez",
      get headers() {
        return { ...storedPublicHeaders };
      },
      rawHeaders: [
        "Host", "de-fra-1131bd95.colyseus.cloud",
        "Forwarded", "private-value",
        "X-Forwarded-For", "private-value",
        "X-Forwarded-Proto", "https",
        "X-Real-IP", "private-value",
      ],
    };
    assert.equal(publicApplication.rawRequestGuard(publicRequest), false);
    await application.abortStartup();
    await publicApplication.abortStartup();
  `;
  const child = spawnSync(process.execPath, ["--input-type=module", "--eval", source], {
    encoding: "utf8",
  });
  assert.equal(child.status, 0, child.stderr || child.stdout);
});

test("shared runtime exposes exact simulation geometry and bot APIs", () => {
  assert.equal(Sim, globalThis.StickSim);
  assert.equal(Anim, globalThis.StickAnim);
  assert.equal(Bots, globalThis.StickBots);
  for (const name of [
    "poseForFighter",
    "localToWorld",
    "swordBlade",
    "unarmedStrike",
    "gunMuzzle",
    "grenadeReleaseSocket",
  ]) {
    assert.equal(typeof Anim[name], "function", `missing StickAnim.${name}`);
  }
});

test("createState preserves the one-human offline default", () => {
  const state = Sim.createState({ seed: 0x511ce });
  assert.equal(Sim.VERSION, 6);
  assert.deepEqual(
    { humanCount: state.config.humanCount, botCount: state.config.botCount },
    { humanCount: 1, botCount: 3 },
  );
  assert.deepEqual(state.fighters.map((fighter) => fighter.isBot), [false, true, true, true]);
});

test("createState supports explicit multi-human and bot-only topologies", () => {
  const mixed = Sim.createState({ seed: 0x511cf, humanCount: 2, botCount: 2 });
  assert.deepEqual(mixed.fighters.map((fighter) => fighter.isBot), [false, false, true, true]);
  assert.deepEqual(
    Sim.snapshot(mixed).config,
    mixed.config,
    "serialized topology must survive a snapshot",
  );

  const botsOnly = Sim.createState({ seed: 0x511d0, humanCount: 0, botCount: 2 });
  assert.deepEqual(botsOnly.fighters.map((fighter) => fighter.isBot), [true, true]);

  const humansOnly = Sim.createState({ seed: 0x511d1, humanCount: 4, botCount: 0 });
  assert.deepEqual(humansOnly.fighters.map((fighter) => fighter.isBot), [false, false, false, false]);
});

test("botCount-only callers retain one human and explicit bot count", () => {
  const state = Sim.createState({ seed: 0x511d2, botCount: 1 });
  assert.equal(state.config.humanCount, 1);
  assert.equal(state.config.botCount, 1);
  assert.deepEqual(state.fighters.map((fighter) => fighter.isBot), [false, true]);
});

test("createState clearly rejects invalid topologies", () => {
  for (const humanCount of [-1, 1.5, NaN, "2"]) {
    assert.throws(
      () => Sim.createState({ humanCount, botCount: 2 }),
      /humanCount must be a non-negative integer/,
    );
  }
  for (const botCount of [-1, 1.5, NaN, "2"]) {
    assert.throws(
      () => Sim.createState({ humanCount: 2, botCount }),
      /botCount must be a non-negative integer/,
    );
  }
  assert.throws(
    () => Sim.createState({ humanCount: 1, botCount: 0 }),
    /humanCount \+ botCount must satisfy the selected mode player limits/,
  );
  assert.throws(
    () => Sim.createState({ humanCount: 4, botCount: 1 }),
    /humanCount \+ botCount must satisfy the selected mode player limits/,
  );
});

test("deserialize rejects missing or invalid serialized topology", () => {
  const state = Sim.createState({ seed: 0x511d3, humanCount: 2, botCount: 0 });
  const missing = JSON.parse(Sim.serialize(state));
  delete missing.config.humanCount;
  assert.throws(
    () => Sim.deserialize(missing),
    /serialized state is missing human\/bot topology/,
  );

  const invalid = JSON.parse(Sim.serialize(state));
  invalid.config.humanCount = 1.5;
  assert.throws(
    () => Sim.deserialize(invalid),
    /humanCount must be a non-negative integer/,
  );
});

test("fixedUpdate and reset preserve an explicit multi-human topology", () => {
  const state = Sim.createState({ seed: 0x511d4, humanCount: 2, botCount: 0 });
  const frame = Sim.createInputFrame(state);
  Sim.fixedUpdate(state, frame, Sim.STEP);
  assert.equal(state.tick, 1);
  assert.equal(state.fighters.length, 2);

  Sim.resetMatch(state, { seed: 0x511d5 });
  assert.equal(state.config.humanCount, 2);
  assert.equal(state.config.botCount, 0);
  assert.deepEqual(state.fighters.map((fighter) => fighter.isBot), [false, false]);
});
