import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { test } from "node:test";
import { fileURLToPath } from "node:url";

const networkTool = fileURLToPath(new URL("../tools/network-profiles.mjs", import.meta.url));
const loadTool = fileURLToPath(new URL("../tools/load-soak.mjs", import.meta.url));

function runTool(path, environment = {}) {
  const child = spawnSync(process.execPath, [path], {
    encoding: "utf8",
    env: {
      PATH: process.env.PATH,
      ...environment,
    },
    maxBuffer: 2 * 1024 * 1024,
    timeout: 30_000,
  });
  assert.equal(child.error, undefined, child.error?.message);
  assert.equal(child.signal, null, child.stderr || child.stdout);
  assert.equal(child.status, 0, child.stderr || child.stdout);
  assert.equal(child.stderr, "");
  return JSON.parse(child.stdout);
}

test("Pass 12C2 deterministic network profiles exercise prediction and stale isolation", {
  timeout: 35_000,
}, () => {
  const report = runTool(networkTool);
  assert.equal(report.accepted, true);
  assert.equal(report.profiles.length, 4);
  for (const profile of report.profiles) {
    assert.equal(profile.accepted, true);
    assert.ok(profile.acceptedInputs > 0);
    assert.ok(profile.rejectedInputs > 0);
    assert.ok(profile.maxPendingInputs > 0);
    assert.ok(profile.replayedInputs > 0);
    assert.ok(profile.acknowledgedInputsPruned > 0);
    assert.ok(profile.maxAcknowledgedSequence >= 0);
    assert.ok(profile.staleCallbackDrops > 0);
    assert.equal(profile.reconnects, 1);
    assert.equal(profile.generationRestarts, 1);
    assert.equal(profile.finalGeneration, 2);
  }
  assert.equal(report.backpressure.expectedTerminalClose, true);
  assert.ok(report.backpressure.queuedBytes <= report.backpressure.ceilingBytes);
  assert.ok(report.backpressure.rejectedAtBytes > report.backpressure.ceilingBytes);
});

test("Pass 12C2 short load profile accepts traffic and proves same-port recovery", {
  timeout: 35_000,
}, () => {
  const report = runTool(loadTool, { LOAD_PORT: "2589" });
  assert.equal(report.accepted, true);
  assert.deepEqual(report.failures, []);
  assert.equal(report.configuration.rooms, 2);
  assert.equal(report.measurements.validTraffic.acknowledgedClients,
    report.measurements.validTraffic.expectedClients);
  assert.equal(report.measurements.validTraffic.inputRejections, 0);
  assert.ok(report.measurements.snapshotCount > 0);
  assert.ok(report.measurements.simulation.fixedSteps > 0);
  assert.equal(report.measurements.simulation.staleGenerationEffects, 0);
  assert.equal(report.recovery.backendResourcesCleared, true);
  assert.equal(report.recovery.stoppedPhase, true);
  assert.deepEqual(report.recovery.forbiddenResources, []);
  assert.deepEqual(report.recovery.afterShutdown.registry, {
    liveRooms: 0,
    codeRooms: 0,
  });
  assert.deepEqual(report.recovery.freshProcess, {
    live: true,
    ready: true,
    exitCode: 0,
    stopped: true,
  });
});
