import assert from "node:assert/strict";
import test from "node:test";

import {
  createFrameworkLogger,
  createFrameworkDiagnosticGate,
  createOperationsLogger,
  createSecurityRejectionTracker,
  createServiceState,
  DEFAULT_SECURITY_REJECTION_WINDOW_MS,
  MAX_SECURITY_REJECTION_COUNT,
  ROOM_LIFECYCLE_PHASES,
  SECURITY_REJECTION_CATEGORIES,
  SERVICE_PHASES,
} from "../src/operations.mjs";

test("service state is monotonic and readiness requires phase, listener, and dependencies", () => {
  const service = createServiceState();
  assert.deepEqual(service.snapshot(), {
    phase: "starting",
    ready: false,
    listenerAvailable: false,
    dependenciesAvailable: false,
  });

  service.setDependenciesAvailable(true);
  service.setListenerAvailable(true);
  assert.equal(service.snapshot().ready, false);
  assert.equal(service.transition("ready").ready, true);
  assert.equal(service.isLive(), true);
  assert.equal(service.isReady(), true);
  assert.equal(service.setDependenciesAvailable(false).ready, false);
  assert.equal(service.setDependenciesAvailable(true).ready, true);
  assert.equal(service.transition("draining").ready, false);
  assert.equal(service.isLive(), true);
  assert.equal(service.isReady(), false);
  service.setListenerAvailable(false);
  assert.equal(service.transition("stopped").phase, "stopped");
  assert.deepEqual(SERVICE_PHASES, ["starting", "ready", "draining", "stopped", "failed"]);

  assert.throws(() => service.transition("ready"), /invalid service phase transition/);
  assert.throws(() => service.transition("other"), /unknown service phase/);
  assert.throws(() => service.setListenerAvailable(1), /must be boolean/);
});

test("service state supports bounded shutdown before readiness and a failed terminal", () => {
  const beforeStart = createServiceState();
  assert.equal(beforeStart.transition("draining").phase, "draining");
  assert.equal(beforeStart.transition("stopped").phase, "stopped");

  for (const initialPhase of ["starting", "ready", "draining"]) {
    const failed = createServiceState();
    if (initialPhase === "ready") failed.transition("ready");
    if (initialPhase === "draining") failed.transition("draining");
    assert.equal(failed.transition("failed").phase, "failed");
    assert.equal(failed.transition("failed").phase, "failed", "same-phase transition is idempotent");
    assert.throws(() => failed.transition("stopped"), /invalid service phase transition/);
  }
});

test("operations logger writes one exact allowlisted JSON record per call", () => {
  const lines = [];
  const logger = createOperationsLogger({
    buildId: "pass12b4a-local",
    clock: () => 1_725_148_800_000,
    write: (line) => lines.push(line),
  });
  assert.equal(logger.info("service.lifecycle", {
    phase: "ready",
    reason: "listening",
    category: "protocol",
    count: 3,
    token: "must-not-appear",
  }), true);
  assert.equal(lines.length, 1);
  assert.equal(lines[0].endsWith("\n"), true);
  assert.equal(lines[0].slice(0, -1).includes("\n"), false);
  assert.deepEqual(JSON.parse(lines[0]), {
    timestamp: "2024-09-01T00:00:00.000Z",
    level: "info",
    event: "service.lifecycle",
    buildId: "pass12b4a-local",
    phase: "ready",
    reason: "listening",
    category: "protocol",
    count: 3,
  });
  assert.deepEqual(Object.keys(JSON.parse(lines[0])), [
    "timestamp", "level", "event", "buildId", "phase", "reason", "category", "count",
  ]);
  assert.equal(logger.info("room.lifecycle", { roomPhase: "rematch-vote" }), true);
  assert.equal(JSON.parse(lines[1]).roomPhase, "rematch-vote");

  assert.equal(logger.emit("debug", "service.debug"), false);
  assert.equal(logger.warn("line\nbreak"), false);
  assert.equal(lines.length, 2);
});

test("operations logger never reads accessors, inherited values, or string coercion hooks", () => {
  const lines = [];
  let getterCalls = 0;
  let stringCalls = 0;
  const fields = Object.create({ reason: "failed" });
  Object.defineProperty(fields, "phase", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return "ready";
    },
  });
  fields.category = {
    toString() {
      stringCalls += 1;
      return "protocol";
    },
  };
  fields.count = 1;
  const logger = createOperationsLogger({ write: (line) => lines.push(line), clock: () => 0 });

  assert.equal(logger.warn("security.rejections", fields), true);
  assert.equal(getterCalls, 0);
  assert.equal(stringCalls, 0);
  assert.deepEqual(JSON.parse(lines[0]), {
    timestamp: "1970-01-01T00:00:00.000Z",
    level: "warn",
    event: "security.rejections",
    buildId: "unknown",
    count: 1,
  });

  const hostile = new Proxy({}, {
    getOwnPropertyDescriptor() {
      throw new Error("hostile descriptor trap");
    },
  });
  assert.doesNotThrow(() => logger.error("service.failure", hostile));
});

test("operations logs every authoritative Room lifecycle through its separate allowlist", () => {
  const lines = [];
  const logger = createOperationsLogger({
    buildId: "pass12b4b-shutdown",
    clock: () => 0,
    write: (line) => lines.push(JSON.parse(line)),
  });
  for (const roomPhase of ROOM_LIFECYCLE_PHASES) {
    assert.equal(logger.info("room.lifecycle", { roomPhase }), true);
  }
  assert.deepEqual(lines.map((record) => record.roomPhase), ROOM_LIFECYCLE_PHASES);
  assert.equal(lines.every((record) => !Object.hasOwn(record, "phase")), true);
});

test("operations logger contains a failing output sink", () => {
  const logger = createOperationsLogger({
    clock: () => 0,
    write() { throw new Error("sink failure"); },
  });
  assert.doesNotThrow(() => assert.equal(logger.error("service.failure"), false));
});

test("framework logger suppresses low levels and emits only fixed warning and error records", () => {
  const lines = [];
  const operationsLogger = createOperationsLogger({
    buildId: "pass12b4a-local",
    clock: () => 0,
    write: (line) => lines.push(JSON.parse(line)),
  });
  const framework = createFrameworkLogger(operationsLogger);
  let getterCalls = 0;
  let stringCalls = 0;
  const hostile = {
    get token() {
      getterCalls += 1;
      return "secret";
    },
    toString() {
      stringCalls += 1;
      return "secret";
    },
  };

  framework.debug(hostile);
  framework.info(hostile);
  framework.trace(hostile);
  framework.warn("attacker text", hostile);
  framework.error(hostile);
  assert.equal(getterCalls, 0);
  assert.equal(stringCalls, 0);
  assert.equal(lines.length, 2);
  assert.deepEqual(lines.map(({ level, event, reason }) => ({ level, event, reason })), [
    { level: "warn", event: "framework.warning", reason: "framework-warning" },
    { level: "error", event: "framework.error", reason: "framework-error" },
  ]);
  assert.equal(JSON.stringify(lines).includes("attacker"), false);
  assert.equal(JSON.stringify(lines).includes("secret"), false);
});

test("production framework diagnostics log once per kind and window while all attempts aggregate", () => {
  let now = 0;
  const lines = [];
  const operationsLogger = createOperationsLogger({
    buildId: "pass12b4b-shutdown",
    clock: () => now,
    write: (line) => lines.push(JSON.parse(line)),
  });
  const diagnosticGate = createFrameworkDiagnosticGate({
    clock: () => now,
    logger: operationsLogger,
    windowMs: 10,
  });
  const rejectionTracker = createSecurityRejectionTracker({ clock: () => now });
  const logger = createFrameworkLogger(operationsLogger, {
    diagnosticGate,
    rejectionTracker,
  });
  logger.error(new Error("PAYLOAD_CANARY_12B4A"));
  logger.error(new Error("PAYLOAD_CANARY_12B4A"));
  logger.warn("WARNING_CANARY_12B4A");
  logger.warn("WARNING_CANARY_12B4A");
  assert.deepEqual(lines.map(({ level, event, reason }) => ({ level, event, reason })), [
    { level: "error", event: "framework.error", reason: "framework-error" },
    { level: "warn", event: "framework.warning", reason: "framework-warning" },
  ]);
  assert.equal(JSON.stringify(lines).includes("CANARY"), false);
  assert.equal(rejectionTracker.snapshot().counts.protocol, 4);
  now = 10;
  logger.error("NEW_WINDOW_CANARY_12B4A");
  assert.equal(lines.length, 3);
  assert.equal(lines[2].event, "framework.error");
  assert.equal(diagnosticGate.snapshot().errorLogged, true);
});

test("security tracker aggregates fixed categories without per-attempt log amplification", () => {
  const lines = [];
  const logger = createOperationsLogger({ clock: () => 0, write: (line) => lines.push(JSON.parse(line)) });
  const tracker = createSecurityRejectionTracker({ clock: () => 0, logger });

  for (let index = 0; index < 100; index += 1) tracker.record("protocol");
  tracker.record("http", 3);
  assert.equal(lines.length, 0);
  assert.deepEqual(tracker.snapshot(), {
    windowStartedAtMs: 0,
    windowMs: DEFAULT_SECURITY_REJECTION_WINDOW_MS,
    total: 103,
    counts: {
      http: 3,
      websocket: 0,
      matchmaking: 0,
      protocol: 100,
      control: 0,
      resource: 0,
    },
  });

  const flushed = tracker.flush();
  assert.equal(flushed.total, 103);
  assert.deepEqual(lines.map(({ event, reason, category, count }) => ({ event, reason, category, count })), [
    { event: "security.rejections", reason: "manual-flush", category: "http", count: 3 },
    { event: "security.rejections", reason: "manual-flush", category: "protocol", count: 100 },
  ]);
  assert.equal(lines.length <= SECURITY_REJECTION_CATEGORIES.length, true);
  assert.equal(tracker.snapshot().total, 0);
  assert.equal(tracker.reset().total, 0);
});

test("security tracker rotates deterministically and saturates overflow-safe counts", () => {
  let now = 50;
  const lines = [];
  const logger = createOperationsLogger({ clock: () => now, write: (line) => lines.push(JSON.parse(line)) });
  const tracker = createSecurityRejectionTracker({ clock: () => now, logger, windowMs: 100 });
  tracker.record("resource", MAX_SECURITY_REJECTION_COUNT);
  tracker.record("resource", Number.MAX_SAFE_INTEGER);
  assert.equal(tracker.snapshot().counts.resource, MAX_SECURITY_REJECTION_COUNT);
  assert.equal(tracker.snapshot().total, MAX_SECURITY_REJECTION_COUNT);

  now = 150;
  tracker.record("websocket", 2);
  assert.deepEqual(lines.map(({ reason, category, count }) => ({ reason, category, count })), [
    { reason: "window-expired", category: "resource", count: MAX_SECURITY_REJECTION_COUNT },
  ]);
  assert.equal(tracker.snapshot().windowStartedAtMs, 150);
  assert.equal(tracker.snapshot().counts.websocket, 2);
});

test("security tracker rejects hostile values without invoking their hooks", () => {
  const tracker = createSecurityRejectionTracker({ clock: () => 0 });
  let getterCalls = 0;
  let stringCalls = 0;
  const hostile = {
    get category() {
      getterCalls += 1;
      return "protocol";
    },
    toString() {
      stringCalls += 1;
      return "protocol";
    },
  };
  assert.equal(tracker.record(hostile), false);
  assert.equal(tracker.record("protocol", hostile), false);
  assert.equal(getterCalls, 0);
  assert.equal(stringCalls, 0);
  assert.equal(tracker.snapshot().total, 0);
});
