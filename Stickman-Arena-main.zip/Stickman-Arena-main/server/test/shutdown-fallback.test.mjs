import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { createConnection } from "node:net";
import test from "node:test";

import {
  PASS12B4B_DRAIN_TIMEOUT_MS,
  PASS12B4B_FORCE_CLEANUP_TIMEOUT_MS,
  PASS12B4B_MAX_TRACKED_SOCKETS,
} from "../src/app.config.mjs";

const appUrl = new URL("../src/app.config.mjs", import.meta.url).href;
const operationsUrl = new URL("../src/operations.mjs", import.meta.url).href;
const runtimeConfigUrl = new URL("../src/runtime-config.mjs", import.meta.url).href;
const startupUrl = new URL("../src/startup.mjs", import.meta.url).href;
const PRIVATE_FAILURE_TEXT = "private-shutdown-detail-must-not-escape";

function reservePort() {
  const server = createServer();
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}

function assertPortReusable(port) {
  const server = createServer();
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, "127.0.0.1", () => {
      server.close((error) => error ? reject(error) : resolve());
    });
  });
}

function collect(stream) {
  let output = "";
  stream.setEncoding("utf8");
  stream.on("data", (chunk) => {
    output += chunk;
  });
  return () => output;
}

async function waitForReady(port, child) {
  const deadline = Date.now() + 5_000;
  while (Date.now() < deadline) {
    if (child.exitCode !== null || child.signalCode !== null) {
      throw new Error("fault-injection service exited before readiness");
    }
    try {
      const response = await fetch(`http://127.0.0.1:${port}/readyz`);
      if (response.status === 200) {
        assert.deepEqual(await response.json(), { status: "ready" });
        return;
      }
    } catch {
      // Listener startup is asynchronous; retry only inside the fixed bound.
    }
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  throw new Error("fault-injection service did not become ready");
}

function waitForExit(child) {
  if (child.exitCode !== null || child.signalCode !== null) {
    return Promise.resolve({ code: child.exitCode, signal: child.signalCode });
  }
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error("fault-injection shutdown exceeded test deadline"));
    }, 5_000);
    child.once("exit", (code, signal) => {
      clearTimeout(timeout);
      resolve({ code, signal });
    });
  });
}

function openHeldSocket(port) {
  return new Promise((resolve, reject) => {
    const socket = createConnection({ host: "127.0.0.1", port });
    socket.once("error", reject);
    socket.once("connect", () => {
      socket.removeListener("error", reject);
      socket.on("error", () => {});
      socket.write([
        "GET /livez HTTP/1.1",
        `Host: 127.0.0.1:${port}`,
        "Connection: keep-alive",
        "",
      ].join("\r\n"));
      resolve(socket);
    });
  });
}

function fixedRecordView(record) {
  return {
    level: record.level,
    event: record.event,
    phase: record.phase,
    reason: record.reason,
  };
}

function createFaultInjectionSource() {
  return `
    const { createApplication } = await import(${JSON.stringify(appUrl)});
    const { createOperationsLogger } = await import(${JSON.stringify(operationsUrl)});
    const { createRuntimeConfig } = await import(${JSON.stringify(runtimeConfigUrl)});
    const { createShutdownController } = await import(${JSON.stringify(startupUrl)});
    const privateFailureText = ${JSON.stringify(PRIVATE_FAILURE_TEXT)};
    const mode = process.env.SHUTDOWN_FAULT_MODE;
    const controller = createShutdownController({
      signalTarget: process,
      onComplete(result, context) {
        const exitCode = result.accepted && !context.fatal ? 0 : 1;
        process.exitCode = exitCode;
        setImmediate(() => process.exit(exitCode));
      },
    });
    controller.install();
    const application = createApplication(
      createRuntimeConfig({ PORT: process.env.SHUTDOWN_TEST_PORT }),
      {
        drainTimeoutMs: 45,
        forceCleanupTimeoutMs: 35,
        operationsLogger: createOperationsLogger({
          buildId: "pass12b4b-shutdown",
          clock: () => 0,
          write: (line) => process.stdout.write(line),
        }),
      },
    );
    controller.attach(application);
    await application.listen();
    if (mode === "rejected") {
      application.server.gracefullyShutdown = () => Promise.reject(new Error(privateFailureText));
      application.driver.shutdown = () => Promise.reject(new Error(privateFailureText));
    } else if (mode === "hung") {
      application.server.gracefullyShutdown = () => new Promise(() => {});
      application.driver.shutdown = () => new Promise(() => {});
    } else {
      throw new Error("unknown fault mode");
    }
    application.markReady();
    await controller.wait();
  `;
}

async function runFaultCycle(mode) {
  const port = await reservePort();
  const child = spawn(process.execPath, ["--input-type=module", "--eval", createFaultInjectionSource()], {
    env: {
      NODE_ENV: "production",
      PATH: process.env.PATH,
      SHUTDOWN_FAULT_MODE: mode,
      SHUTDOWN_TEST_PORT: String(port),
    },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const stdout = collect(child.stdout);
  const stderr = collect(child.stderr);
  let socket;
  try {
    await waitForReady(port, child);
    socket = await openHeldSocket(port);
    const socketClosed = new Promise((resolve) => socket.once("close", resolve));
    const startedAt = Date.now();
    assert.equal(child.kill("SIGTERM"), true);
    assert.deepEqual(await waitForExit(child), { code: 1, signal: null });
    assert.ok(Date.now() - startedAt < 2_000, `${mode} shutdown was not bounded`);
    await socketClosed;
    await assertPortReusable(port);
  } finally {
    socket?.destroy();
    if (child.exitCode === null) child.kill("SIGKILL");
  }

  assert.equal(stderr(), "");
  const rawOutput = stdout();
  assert.equal(rawOutput.includes(PRIVATE_FAILURE_TEXT), false);
  assert.equal(rawOutput.includes("SIGTERM"), false);
  assert.equal(rawOutput.includes("Error:"), false);
  const records = rawOutput.trim().split("\n").map(JSON.parse);
  assert.equal(records.every((record) => record.buildId === "pass12b4b-shutdown"), true);
  assert.deepEqual(records.map(fixedRecordView), [
    { level: "info", event: "service.lifecycle", phase: "starting", reason: "startup" },
    { level: "info", event: "service.lifecycle", phase: "ready", reason: "listening" },
    {
      level: "info",
      event: "service.lifecycle",
      phase: "draining",
      reason: "shutdown-signal",
    },
    { level: "info", event: "service.drain", phase: "draining", reason: "drain-started" },
    {
      level: "error",
      event: "service.drain",
      phase: "failed",
      reason: mode === "hung" ? "drain-timeout" : "failed",
    },
  ]);
  assert.equal(records.some((record) => record.phase === "stopped"
    || record.reason === "stopped" || record.reason === "drain-complete"), false);
}

test("Pass 12B4B freezes the graceful and fallback shutdown resource defaults", () => {
  assert.equal(PASS12B4B_DRAIN_TIMEOUT_MS, 5_000);
  assert.equal(PASS12B4B_FORCE_CLEANUP_TIMEOUT_MS, 1_000);
  assert.equal(PASS12B4B_MAX_TRACKED_SOCKETS, 256);
});

test("a rejected real-controller drain exits 1, redacts details, and releases live resources", {
  timeout: 10_000,
}, async () => {
  await runFaultCycle("rejected");
});

test("a hung real-controller drain and fallback stay bounded and release the listener", {
  timeout: 10_000,
}, async () => {
  await runFaultCycle("hung");
});
