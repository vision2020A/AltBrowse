import assert from "node:assert/strict";
import { createServer } from "node:http";
import test from "node:test";
import { matchMaker } from "@colyseus/core";

import { createApplication } from "../src/app.config.mjs";
import { createOperationsLogger } from "../src/operations.mjs";
import { roomRegistry } from "../src/room-registry.mjs";
import { createRuntimeConfig } from "../src/runtime-config.mjs";
import { Netcode } from "../src/shared-runtime.mjs";

function deferred() {
  let resolve;
  const promise = new Promise((accept) => {
    resolve = accept;
  });
  return { promise, resolve };
}

function reservePort() {
  const server = createServer();
  return new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close((error) => error ? reject(error) : resolve(port));
    });
  });
}

function admissionOptions() {
  return {
    compatibility: Netcode.createCompatibilityOffer(),
    operation: "quick-match",
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function postAdmission(origin) {
  return fetch(`${origin}/matchmake/joinOrCreate/arena`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(admissionOptions()),
  });
}

test("shutdown drains an accepted in-flight admission and removes its Room and seat", {
  timeout: 10_000,
}, async () => {
  const port = await reservePort();
  const application = createApplication(createRuntimeConfig({ PORT: String(port) }), {
    operationsLogger: createOperationsLogger({ write() {} }),
  });
  const originalInvokeMethod = matchMaker.controller.invokeMethod;
  const responseGate = deferred();
  const reservationCreated = deferred();
  let invocationCount = 0;
  let admissionRequest;
  let shutdownRequest;

  try {
    await application.listen();
    application.markReady();
    const origin = `http://127.0.0.1:${port}`;

    matchMaker.controller.invokeMethod = async function invokeWithResponseBarrier(...args) {
      invocationCount += 1;
      const reservation = await originalInvokeMethod.apply(this, args);
      reservationCreated.resolve(reservation);
      await responseGate.promise;
      return reservation;
    };

    admissionRequest = postAdmission(origin);
    const reservation = await reservationCreated.promise;
    const roomId = reservation.roomId;
    const backend = matchMaker.getLocalRoomById(roomId);

    assert.ok(backend, "the accepted request did not create its local Room");
    assert.deepEqual(roomRegistry.snapshot(), {
      liveRooms: 1,
      codeRooms: 0,
      roomIds: [roomId],
    });
    assert.equal(application.admissionTracker.snapshot().active, 1);
    assert.equal(Object.hasOwn(backend._reservedSeats, reservation.sessionId), true);
    assert.equal(Object.hasOwn(backend._reservedSeatTimeouts, reservation.sessionId), true);

    let shutdownSettled = false;
    shutdownRequest = application.shutdown().then((result) => {
      shutdownSettled = true;
      return result;
    });

    assert.deepEqual(application.serviceState.snapshot(), {
      phase: "draining",
      ready: false,
      listenerAvailable: true,
      dependenciesAvailable: true,
    });
    assert.equal(backend.lifecycle, "closing");
    assert.equal(Object.keys(backend._reservedSeats).length, 0);
    assert.equal(Object.keys(backend._reservedSeatTimeouts).length, 0);
    assert.equal(backend.reservations.size, 0);
    assert.equal(application.admissionTracker.snapshot().active, 1);
    await Promise.resolve();
    assert.equal(shutdownSettled, false, "shutdown did not wait for the tracked response");

    const readiness = await fetch(`${origin}/readyz`);
    assert.equal(readiness.status, 503);
    assert.deepEqual(await readiness.json(), { status: "unavailable" });
    const rejected = await postAdmission(origin);
    assert.equal(rejected.status, 503);
    assert.deepEqual(await rejected.json(), { error: "service unavailable" });
    assert.equal(invocationCount, 1, "draining reached a second matchmaking invocation");
    assert.equal(application.admissionTracker.snapshot().active, 1);

    responseGate.resolve();
    const admitted = await admissionRequest;
    assert.equal(admitted.status, 200);
    assert.equal((await admitted.json()).roomId, roomId);
    assert.deepEqual(await shutdownRequest, { accepted: true, timedOut: false });

    assert.deepEqual(application.serviceState.snapshot(), {
      phase: "stopped",
      ready: false,
      listenerAvailable: false,
      dependenciesAvailable: false,
    });
    assert.equal(application.admissionTracker.snapshot().active, 0);
    assert.deepEqual(roomRegistry.snapshot(), {
      liveRooms: 0,
      codeRooms: 0,
      roomIds: [],
    });
    assert.equal(matchMaker.getLocalRoomById(roomId), undefined);
    assert.equal(await application.driver.findOne({ roomId }), undefined);
    assert.equal(application.driver.rooms.length, 0);
    assert.equal(backend.lifecycle, "disposed");
    assert.equal(backend.registeredRoomId, null);
    assert.equal(backend.clients.length, 0);
    assert.equal(backend.match.actorBySession.size, 0);
    assert.equal(backend.reservations.size, 0);
    assert.equal(Object.keys(backend._reservedSeats).length, 0);
    assert.equal(Object.keys(backend._reservedSeatTimeouts).length, 0);
  } finally {
    matchMaker.controller.invokeMethod = originalInvokeMethod;
    responseGate.resolve();
    if (admissionRequest) await admissionRequest.catch(() => {});
    if (shutdownRequest) await shutdownRequest.catch(() => {});
    else await application.shutdown().catch(() => {});
  }
});
