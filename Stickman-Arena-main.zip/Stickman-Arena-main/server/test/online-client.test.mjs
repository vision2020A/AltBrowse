import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";
import vm from "node:vm";
import { createReconnection } from "@colyseus/sdk/Reconnection";

await import("../../multiplayer.js");

const source = readFileSync(new URL("../../online-client.js", import.meta.url), "utf8");
const Multiplayer = globalThis.StickMultiplayer;

function stateAt(tick, actorId = 0) {
  return {
    version: 6,
    tick,
    config: {
      modeId: "free-for-all",
      mapId: "original-arena",
      timeLimitTicks: 10800,
      humanCount: 2,
      botCount: 2,
    },
    fighters: [0, 1, 2, 3].map((id) => ({
      id,
      isBot: id >= 2,
      x: 100 + id * 20,
      y: 200,
      prevX: 100 + id * 20,
      prevY: 200,
      vx: 0,
      vy: 0,
      prevVx: 0,
      prevVy: 0,
      facing: id === actorId ? 1 : -1,
      dead: false,
      respawn: 0,
    })),
    events: [],
  };
}

function assignment(actorId = 0, epoch = 1, overrides = {}) {
  return {
    actorId,
    epoch,
    generation: 1,
    lifecycle: "waiting",
    compatibility: structuredClone(Multiplayer.createServerHello()),
    simVersion: 6,
    modeId: "free-for-all",
    mapId: "original-arena",
    tickRate: 60,
    ...overrides,
  };
}

function compatibilityOffer() {
  return structuredClone(Multiplayer.createCompatibilityOffer());
}

function quickOptions() {
  return {
    compatibility: compatibilityOffer(),
    operation: "quick-match",
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function createOptions() {
  return {
    compatibility: compatibilityOffer(),
    operation: "create-match",
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function joinCodeOptions() {
  return {
    compatibility: compatibilityOffer(),
    operation: "join-code",
  };
}

function serverHello(overrides = {}) {
  return {
    ...structuredClone(Multiplayer.createServerHello()),
    ...overrides,
  };
}

function assertProtocolRequest(room) {
  assert.deepEqual(room.sent.at(-1), { type: "protocol-request", payload: {} });
}

function completeAdmission(room, actorId = 0, epoch = 1) {
  const hello = serverHello();
  room.emit("server-hello", hello);
  assert.deepEqual(room.sent.at(-1), { type: "hello-ack", payload: hello });
  room.emit("assignment", assignment(actorId, epoch));
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
}

function snapshot(tick, actorId = 0, epoch = 1, overrides = {}) {
  return {
    generation: 1,
    simVersion: 6,
    modeId: "free-for-all",
    mapId: "original-arena",
    seed: 123,
    tick,
    actorId,
    epoch,
    ackSequence: -1,
    stateHash: "0".repeat(64),
    state: stateAt(tick, actorId),
    events: [],
    ...overrides,
  };
}

function lifecycle(generation, phase, overrides = {}) {
  return {
    generation,
    phase,
    rematchOpen: phase === "finished" || phase === "rematch-vote",
    rematchVoted: false,
    rematchVotes: 0,
    rematchRequired: 2,
    rematchRemainingMs: phase === "finished" || phase === "rematch-vote" ? 30000 : 0,
    ...overrides,
  };
}

function input(overrides = {}) {
  return {
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: {
      jump: false,
      attack: false,
      pickup: false,
      reload: false,
      drop: false,
      rematch: false,
    },
    ...overrides,
  };
}

class FakeRoom {
  constructor(name = "room", roomId = "ABCDEFG") {
    this.name = name;
    this.roomId = roomId;
    this.messages = new Map();
    this.sent = [];
    this.dropCallbacks = [];
    this.reconnectCallbacks = [];
    this.leaveCallbacks = [];
    this.leaveCalls = 0;
    this.reconnection = { minUptime: 5000, maxEnqueuedMessages: 10, maxRetries: 15 };
  }

  onMessage(type, callback) {
    this.messages.set(type, callback);
  }

  onDrop(callback) {
    this.dropCallbacks.push(callback);
  }

  onReconnect(callback) {
    this.reconnectCallbacks.push(callback);
  }

  onLeave(callback) {
    this.leaveCallbacks.push(callback);
  }

  send(type, payload) {
    this.sent.push({ type, payload: structuredClone(payload) });
  }

  leave() {
    this.leaveCalls += 1;
  }

  emit(type, payload) {
    const callback = this.messages.get(type);
    assert.ok(callback, `missing ${type} message handler`);
    callback(structuredClone(payload));
  }

  drop() {
    for (const callback of this.dropCallbacks) callback();
  }

  reconnect() {
    for (const callback of this.reconnectCallbacks) callback();
  }

  close(code, reason) {
    for (const callback of this.leaveCallbacks) callback(code, reason);
  }
}

function createHarness({
  protocol = "http:",
  search = "?online=1",
  origin = "http://localhost:2567",
  pathname = "/",
  preloadedSdk = true,
  deferSdk = false,
  deferMatchmaking = false,
  failures = {},
  createRoomId = "ABCDEFG",
} = {}) {
  const rooms = [];
  const clientOrigins = [];
  const joinOptions = [];
  const createOptions = [];
  const joinByIdCalls = [];
  const appendedScripts = [];
  const activeScripts = [];
  const pendingMatchmaking = [];
  let now = 1000;

  function resolveRoom(room) {
    rooms.push(room);
    if (!deferMatchmaking) return Promise.resolve(room);
    return new Promise((resolve) => pendingMatchmaking.push({ resolve, room }));
  }

  class FakeClient {
    constructor(origin) {
      clientOrigins.push(origin);
    }

    joinOrCreate(name, options) {
      assert.equal(name, "arena");
      joinOptions.push(structuredClone(options));
      if (failures.quick) return Promise.reject(failures.quick);
      return resolveRoom(new FakeRoom(`room-${rooms.length + 1}`));
    }

    create(name, options) {
      assert.equal(name, "arena");
      createOptions.push(structuredClone(options));
      if (failures.create) return Promise.reject(failures.create);
      return resolveRoom(new FakeRoom(`room-${rooms.length + 1}`, createRoomId));
    }

    joinById(roomId, options) {
      joinByIdCalls.push({ roomId, options: structuredClone(options) });
      if (failures.join) return Promise.reject(failures.join);
      return resolveRoom(new FakeRoom(`room-${rooms.length + 1}`, roomId));
    }
  }

  const Sim = {
    VERSION: 6,
    DEFAULT_MODE_ID: "free-for-all",
    DEFAULT_MAP_ID: "original-arena",
    STEP: 1 / 60,
    fixedUpdate(state) {
      state.tick += 1;
      return state;
    },
  };
  const root = {
    StickSim: Sim,
    StickMultiplayer: Multiplayer,
    location: {
      protocol,
      search,
      origin,
      pathname,
    },
    performance: { now: () => now },
    document: {
      createElement(tag) {
        assert.equal(tag, "script");
        const script = {
          src: "",
          async: false,
          onload: null,
          onerror: null,
          removed: false,
          remove() {
            if (this.removed) return;
            this.removed = true;
            const index = activeScripts.indexOf(this);
            if (index >= 0) activeScripts.splice(index, 1);
          },
        };
        return script;
      },
      head: {
        appendChild(script) {
          appendedScripts.push(script);
          activeScripts.push(script);
          if (!deferSdk) {
            root.Colyseus = { Client: FakeClient };
            script.onload();
          }
        },
      },
    },
  };
  if (preloadedSdk) root.Colyseus = { Client: FakeClient };
  root.window = root;
  const context = vm.createContext({
    window: root,
    globalThis: root,
    URLSearchParams,
    JSON,
    Number,
    Object,
    Array,
    Math,
    Promise,
    Error,
    structuredClone,
  });
  vm.runInContext(source, context, { filename: "online-client.js" });
  return {
    api: root.StickOnline,
    root,
    rooms,
    clientOrigins,
    joinOptions,
    createOptions,
    joinByIdCalls,
    appendedScripts,
    activeScripts,
    resolveSdk() {
      root.Colyseus = { Client: FakeClient };
      appendedScripts.at(-1).onload();
    },
    rejectSdk() {
      appendedScripts.at(-1).onerror();
    },
    resolveMatchmaking() {
      const pending = pendingMatchmaking.shift();
      assert.ok(pending, "no deferred matchmaking request");
      pending.resolve(pending.room);
      return pending.room;
    },
    pendingMatchmaking,
    advance(ms) { now += ms; },
  };
}

test("file mode remains network-idle and cannot inject or join the SDK", async () => {
  const harness = createHarness({ protocol: "file:", search: "?online=1", preloadedSdk: false });
  assert.equal(harness.api.requested(), false);
  await assert.rejects(harness.api.quickMatch(), /unavailable from this URL/);
  assert.equal(harness.appendedScripts.length, 0);
  assert.equal(harness.rooms.length, 0);
});

test("ordinary hosted mode without the explicit query remains network-idle", async () => {
  const harness = createHarness({ protocol: "https:", search: "", preloadedSdk: false });
  assert.equal(harness.api.requested(), false);
  await assert.rejects(harness.api.quickMatch(), /unavailable from this URL/);
  assert.equal(harness.appendedScripts.length, 0);
  assert.equal(harness.clientOrigins.length, 0);
  assert.equal(harness.rooms.length, 0);
});

test("exact GitHub Pages client exposes Create/Join and uses the approved Cloud endpoint", async () => {
  const harness = createHarness({
    protocol: "https:",
    search: "",
    origin: "https://xenovoyage.github.io",
    pathname: "/Stickman-Arena/",
    preloadedSdk: false,
  });
  assert.equal(harness.api.requested(), true);
  assert.equal(harness.api.quickMatchAvailable(), false);
  assert.equal(harness.appendedScripts.length, 0, "Pages must not load Cloud before online intent");
  await harness.api.createMatch();
  assert.equal(harness.appendedScripts.length, 1);
  assert.equal(
    harness.appendedScripts[0].src,
    "https://de-fra-1131bd95.colyseus.cloud/online-sdk.js",
  );
  assert.deepEqual(harness.clientOrigins, ["https://de-fra-1131bd95.colyseus.cloud"]);
  assert.deepEqual(harness.createOptions, [createOptions()]);
});

test("similar GitHub Pages paths and foreign hosted origins remain offline by default", () => {
  for (const options of [
    {
      protocol: "https:",
      search: "",
      origin: "https://xenovoyage.github.io",
      pathname: "/Another-Game/",
    },
    {
      protocol: "https:",
      search: "",
      origin: "https://attacker.example",
      pathname: "/Stickman-Arena/",
    },
  ]) {
    const harness = createHarness({ ...options, preloadedSdk: false });
    assert.equal(harness.api.requested(), false);
    assert.equal(harness.api.quickMatchAvailable(), false);
    assert.equal(harness.appendedScripts.length, 0);
  }
});

test("explicit online mode loads only the same-origin SDK route and configures zero reconnect queue", async () => {
  const harness = createHarness({ preloadedSdk: false });
  assert.equal(harness.api.requested(), true);
  const room = await harness.api.quickMatch();
  assert.equal(harness.appendedScripts.length, 1);
  assert.equal(harness.appendedScripts[0].src, "http://localhost:2567/online-sdk.js");
  assert.deepEqual(harness.clientOrigins, ["http://localhost:2567"]);
  assert.equal(harness.api.quickMatchAvailable(), true);
  assert.deepEqual(harness.joinOptions, [quickOptions()]);
  assert.equal(room.reconnection.minUptime, 0);
  assert.equal(room.reconnection.maxEnqueuedMessages, 0);
  assert.equal(room.reconnection.maxRetries, 9);
  const pinnedDefaults = createReconnection();
  const retryDelay = (attempt) => Math.min(
    pinnedDefaults.maxDelay,
    Math.max(pinnedDefaults.minDelay, pinnedDefaults.backoff(attempt, pinnedDefaults.delay)),
  );
  const retryScheduleMs = Array.from(
    { length: room.reconnection.maxRetries },
    (_, index) => retryDelay(index + 1),
  ).reduce((total, delay) => total + delay, 0);
  assert.equal(retryScheduleMs, 26_200);
  assert.ok(retryScheduleMs + retryDelay(room.reconnection.maxRetries + 1) > 30_000);
  assert.deepEqual(room.sent, [{ type: "protocol-request", payload: {} }]);

  const hello = serverHello();
  room.emit("server-hello", hello);
  assert.deepEqual(room.sent, [
    { type: "protocol-request", payload: {} },
    { type: "hello-ack", payload: hello },
  ]);
  room.emit("assignment", assignment());
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
});

test("matchmaking exposes only exact Quick, Create, and canonical short-code joins", async () => {
  const harness = createHarness();
  assert.equal(harness.api.connect, undefined);

  const quick = harness.api.quickMatch();
  assert.equal(harness.api.createMatch(), quick, "a second admission action amplified the active request");
  await quick;
  assert.deepEqual(harness.joinOptions, [quickOptions()]);
  assert.deepEqual(harness.createOptions, []);
  assert.equal(harness.api.getStatus().matchmakingOperation, "quick-match");
  assert.equal(harness.api.getStatus().roomCode, null);

  harness.api.disconnect();
  const created = await harness.api.createMatch();
  assert.deepEqual(harness.createOptions, [createOptions()]);
  assert.equal(harness.api.getStatus().matchmakingOperation, "create-match");
  assert.equal(harness.api.getStatus().roomCode, "ABCDEFG");
  harness.api.disconnect();
  assert.equal(harness.api.getStatus().roomCode, null);

  const joined = await harness.api.joinMatch(" abcde23 ");
  assert.deepEqual(harness.joinByIdCalls, [{
    roomId: "ABCDE23",
    options: joinCodeOptions(),
  }]);
  assert.equal(harness.api.getStatus().matchmakingOperation, "join-code");
  assert.equal(harness.api.getStatus().roomCode, null);
  assert.notEqual(created, joined);
});

test("short-code validation rejects malformed and hostile values before SDK work", async () => {
  const harness = createHarness({ preloadedSdk: false });
  let getterCalls = 0;
  const accessor = {};
  Object.defineProperty(accessor, "code", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return "ABCDEFG";
    },
  });
  for (const value of [
    "", "ABCDEF", "ABCDEFGH", "ABCDI23", "ABCDO23", "ABCD023", "ABCD123",
    "ABC-D23", "ＡＢＣＤＥ２３", "A".repeat(10000), null, 1234567, accessor,
  ]) {
    await assert.rejects(harness.api.joinMatch(value), /VALID 7-CHARACTER MATCH CODE/);
  }
  assert.equal(getterCalls, 0);
  assert.equal(harness.appendedScripts.length, 0);
  assert.equal(harness.clientOrigins.length, 0);
  assert.deepEqual(harness.joinByIdCalls, []);
  assert.equal(harness.api.getStatus().detail, "ENTER A VALID 7-CHARACTER MATCH CODE");
});

test("disconnect supersedes deferred SDK loading before it can create a room", async () => {
  const harness = createHarness({ preloadedSdk: false, deferSdk: true });
  const pending = harness.api.createMatch();
  assert.equal(harness.appendedScripts.length, 1);
  harness.api.disconnect();
  harness.resolveSdk();
  await assert.rejects(pending, /CONNECTION ATTEMPT CANCELED/);
  assert.deepEqual(harness.clientOrigins, []);
  assert.deepEqual(harness.createOptions, []);
  assert.deepEqual(harness.rooms, []);
  assert.equal(harness.api.getStatus().state, "idle");
  assert.equal(harness.api.getStatus().roomCode, null);
});

test("disconnect leaves a Room that resolves after matchmaking was canceled", async () => {
  const harness = createHarness({ deferMatchmaking: true });
  const pending = harness.api.createMatch();
  await Promise.resolve();
  assert.equal(harness.pendingMatchmaking.length, 1);
  harness.api.disconnect();
  const lateRoom = harness.resolveMatchmaking();
  await assert.rejects(pending, /CONNECTION ATTEMPT CANCELED/);
  assert.equal(lateRoom.leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "idle");
  assert.equal(harness.api.getStatus().roomCode, null);
});

test("failed SDK retries remove their script nodes before another attempt", async () => {
  const harness = createHarness({ preloadedSdk: false, deferSdk: true });
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const pending = harness.api.quickMatch();
    assert.equal(harness.activeScripts.length, 1);
    harness.rejectSdk();
    await assert.rejects(pending, /CONNECTION FAILED — TRY AGAIN/);
    assert.equal(harness.activeScripts.length, 0);
    assert.equal(harness.api.getStatus().state, "error");
  }
  assert.equal(harness.appendedScripts.length, 2);
  assert.deepEqual(harness.clientOrigins, []);
  assert.deepEqual(harness.rooms, []);
});

test("matchmaking failures map only fixed codes and never reflect supplied text", async () => {
  const unavailableHarnesses = [];
  for (const code of [521, 522, 523, 524]) {
    const unavailable = Object.assign(new Error("private-room-code=ABCDEFG"), { code });
    const unavailableHarness = createHarness({ failures: { join: unavailable } });
    unavailableHarnesses.push(unavailableHarness);
    await assert.rejects(unavailableHarness.api.joinMatch("ABCDEFG"), {
      message: "MATCH CODE UNAVAILABLE OR EXPIRED",
    });
    assert.equal(unavailableHarness.api.getStatus().detail, "MATCH CODE UNAVAILABLE OR EXPIRED");
    assert.equal(unavailableHarness.api.getStatus().roomCode, null);
  }

  const limited = Object.assign(new Error("private-rate-metadata"), { status: 429 });
  const limitedHarness = createHarness({ failures: { create: limited } });
  await assert.rejects(limitedHarness.api.createMatch(), {
    message: "TOO MANY ATTEMPTS — TRY AGAIN SOON",
  });
  assert.equal(limitedHarness.api.getStatus().detail, "TOO MANY ATTEMPTS — TRY AGAIN SOON");

  const update = Object.assign(new Error("private-version-metadata"), { code: 525 });
  const updateHarness = createHarness({ failures: { quick: update } });
  await assert.rejects(updateHarness.api.quickMatch(), {
    message: "CLIENT/SERVER UPDATE REQUIRED — RELOAD",
  });
  assert.equal(updateHarness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");

  const genericHarness = createHarness({ failures: { quick: new Error("secret-token") } });
  await assert.rejects(genericHarness.api.quickMatch(), {
    message: "CONNECTION FAILED — TRY AGAIN",
  });
  assert.equal(genericHarness.api.getStatus().detail, "CONNECTION FAILED — TRY AGAIN");

  let accessorCalls = 0;
  const hostile = new Error("private-accessor-metadata");
  for (const key of ["code", "status", "statusCode", "compatibility"]) {
    Object.defineProperty(hostile, key, {
      configurable: true,
      get() {
        accessorCalls += 1;
        return key === "compatibility" ? true : 525;
      },
    });
  }
  const hostileHarness = createHarness({ failures: { quick: hostile } });
  await assert.rejects(hostileHarness.api.quickMatch(), {
    message: "CONNECTION FAILED — TRY AGAIN",
  });
  assert.equal(hostileHarness.api.getStatus().detail, "CONNECTION FAILED — TRY AGAIN");
  assert.equal(accessorCalls, 0);

  for (const harness of [
    ...unavailableHarnesses, limitedHarness, updateHarness, genericHarness, hostileHarness,
  ]) {
    assert.equal(/private|secret|ABCDEFG/.test(harness.api.getStatus().detail), false);
  }
});

test("Create fails closed when the server does not return a canonical public code", async () => {
  const harness = createHarness({ createRoomId: "internal_room_id" });
  const pending = harness.api.createMatch();
  await assert.rejects(pending);
  assert.equal(harness.rooms[0].leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
  assert.equal(harness.api.getStatus().roomCode, null);
});

test("a compatible rollback build is diagnostic and completes the same admission flow", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  const rollback = serverHello({ serverBuildId: "pass12b1-rollback.2" });
  room.emit("server-hello", rollback);
  assert.deepEqual(room.sent.at(-1), { type: "hello-ack", payload: rollback });
  room.emit("assignment", assignment(0, 1, { compatibility: rollback }));
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
  room.emit("snapshot", snapshot(20));
  room.emit("match-start", { generation: 1, tick: 20 });
  assert.equal(harness.api.getStatus().state, "playing");
});

test("gameplay messages remain inert until compatibility admission and assignment", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  assertProtocolRequest(room);

  room.emit("snapshot", snapshot(20));
  room.emit("match-start", { generation: 1, tick: 20 });
  assert.equal(harness.api.getStatus().started, false);
  assert.equal(harness.api.getStatus().actorId, null);
  assert.equal(harness.api.sendInput(input({ moveX: 1 })), null);
  assert.deepEqual(room.sent, [{ type: "protocol-request", payload: {} }]);

  const hello = serverHello();
  room.emit("server-hello", hello);
  assert.deepEqual(room.sent.at(-1), { type: "hello-ack", payload: hello });
  room.emit("snapshot", snapshot(21));
  room.emit("match-start", { generation: 1, tick: 21 });
  assert.equal(harness.api.getStatus().started, false);
  assert.equal(harness.api.getStatus().actorId, null);
  assert.notEqual(room.sent.at(-1).type, "ready");

  room.emit("assignment", assignment());
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
});

test("future-sequence input rejection keeps its fixed diagnostic identity", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room);
  room.emit("snapshot", snapshot(20));
  room.emit("match-start", { generation: 1, tick: 20 });

  room.emit("input-rejected", { generation: 1, reason: "future-sequence" });
  assert.equal(harness.api.getStatus().detail, "INPUT REJECTED: FUTURE-SEQUENCE");
  room.emit("input-rejected", { generation: 1, reason: "attacker-controlled" });
  assert.equal(harness.api.getStatus().detail, "INPUT REJECTED: INVALID-PAYLOAD");
});

test("an assignment before the server hello fails closed without readiness", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  assertProtocolRequest(room);

  room.emit("assignment", assignment());
  assert.equal(room.leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
  assert.equal(harness.api.getStatus().actorId, null);
  assert.equal(harness.api.getStatus().connected, false);
  assert.deepEqual(room.sent, [{ type: "protocol-request", payload: {} }]);
});

test("drop blocks input, a newer epoch resets prediction, and reconnect begins with fresh neutral", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room, 1, 1);
  assert.equal(harness.api.getStatus().actorId, 1);
  room.emit("snapshot", snapshot(20, 1, 1));
  assert.equal(harness.api.getStatus().connected, true);
  room.emit("match-start", { generation: 1, tick: 20 });
  assert.equal(harness.api.getStatus().started, true);
  const first = harness.api.sendInput(input({ moveX: 1 }));
  assert.equal(first.sequence, 0);
  const sentBeforeDrop = room.sent.length;

  room.drop();
  assert.equal(harness.api.getStatus().state, "reconnecting");
  assert.equal(harness.api.sendInput(input({ moveX: -1 })), null);
  assert.equal(room.sent.length, sentBeforeDrop, "no gameplay command is queued while dropped");

  room.reconnect();
  assertProtocolRequest(room);
  assert.equal(harness.api.getStatus().actorId, null);
  assert.equal(harness.api.getStatus().started, false);
  assert.equal(harness.api.renderState(), null, "reconnect clears prior prediction and interpolation state");
  assert.equal(harness.api.drainEvents().length, 0);
  assert.equal(harness.api.sendInput(input({ moveX: -1 })), null);
  const hello = serverHello();
  room.emit("server-hello", hello);
  assert.deepEqual(room.sent.at(-1), { type: "hello-ack", payload: hello });
  assert.notEqual(room.sent.at(-1).type, "ready");
  room.emit("assignment", assignment(1, 2));
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
  room.emit("lifecycle", lifecycle(1, "waiting"));
  assert.equal(harness.api.getStatus().detail, "WAITING FOR OTHER PLAYER");
  room.emit("snapshot", snapshot(24, 1, 2));
  room.emit("match-start", { generation: 1, tick: 24 });
  const freshNeutral = room.sent.at(-1);
  assert.equal(freshNeutral.type, "input");
  assert.equal(freshNeutral.payload.sequence, 0, "new epoch resets the local sequence/history");
  assert.ok(Object.values(freshNeutral.payload.buttons).every((pressed) => pressed === false));
  assert.equal(freshNeutral.payload.moveX, 0);
  assert.equal(harness.api.sendInput(input({ moveX: -1 })).sequence, 1);
});

test("stale Room callbacks cannot clear a new connection and a terminal leave is retryable", async () => {
  const harness = createHarness();
  const first = await harness.api.quickMatch();
  harness.api.disconnect();
  assert.equal(first.leaveCalls, 1);

  const second = await harness.api.quickMatch();
  completeAdmission(second);
  first.close();
  first.emit("assignment", assignment(0, 1));
  assert.equal(harness.api.getStatus().connected, true);
  assert.equal(harness.api.getStatus().state, "waiting");

  second.close();
  assert.equal(harness.api.getStatus().connected, false);
  assert.equal(harness.api.getStatus().state, "error");
  const third = await harness.api.quickMatch();
  assert.notEqual(third, second);
  assert.equal(harness.rooms.length, 3);
});

test("failed automatic reconnect uses one fixed non-reflective failure message", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room);
  room.drop();
  room.close(4003, "reconnect-token=never-reflect-me");
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "RECONNECT FAILED — START A NEW MATCH");
  assert.equal(harness.api.getStatus().detail.includes("never-reflect-me"), false);
  assert.equal(harness.api.getStatus().connected, false);
});

test("server shutdown clears an admitted match with one fixed recoverable message", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room, 1, 7);
  room.emit("snapshot", snapshot(20, 1, 7, {
    events: [{ id: 1, type: "hit", tick: 20 }],
  }));
  room.emit("match-start", { generation: 1, tick: 20 });
  assert.equal(harness.api.sendInput(input({ moveX: 1 })).sequence, 0);
  const sentBeforeClose = room.sent.length;

  room.close(4001, "deploy-secret=never-reflect-me");
  await Promise.resolve();

  const status = harness.api.getStatus();
  assert.equal(status.state, "error");
  assert.equal(status.detail, "SERVER RESTARTING — TRY AGAIN");
  assert.equal(status.detail.includes("never-reflect-me"), false);
  assert.equal(status.connected, false);
  assert.equal(status.actorId, null);
  assert.equal(status.epoch, null);
  assert.equal(status.generation, null);
  assert.equal(status.started, false);
  assert.equal(status.rematchOpen, false);
  assert.equal(harness.api.renderState(), null);
  assert.equal(harness.api.drainEvents().length, 0);
  assert.equal(harness.api.sendInput(input({ moveX: -1 })), null);
  assert.equal(room.sent.length, sentBeforeClose, "shutdown must not send or reconnect");
  assert.equal(harness.rooms.length, 1, "shutdown must not start matchmaking automatically");
});

test("server shutdown before admission uses the same fixed message without reconnecting", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  assertProtocolRequest(room);
  const sentBeforeClose = room.sent.length;

  room.close(4001, "pre-admission-private-reason");
  await Promise.resolve();

  const status = harness.api.getStatus();
  assert.equal(status.state, "error");
  assert.equal(status.detail, "SERVER RESTARTING — TRY AGAIN");
  assert.equal(status.detail.includes("private-reason"), false);
  assert.equal(status.connected, false);
  assert.equal(status.actorId, null);
  assert.equal(status.epoch, null);
  assert.equal(status.generation, null);
  assert.equal(status.started, false);
  assert.equal(harness.api.renderState(), null);
  assert.equal(harness.api.drainEvents().length, 0);
  assert.equal(room.sent.length, sentBeforeClose, "shutdown must not restart negotiation");
  assert.equal(harness.rooms.length, 1, "shutdown must not start matchmaking automatically");
});

test("incompatible assignment fails closed and allows a fresh retry", async () => {
  const harness = createHarness();
  const first = await harness.api.quickMatch();
  const hello = serverHello();
  first.emit("server-hello", hello);
  first.emit("assignment", assignment(0, 1, {
    compatibility: serverHello({ simulationSchemaVersion: 999 }),
  }));
  assert.equal(first.leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
  assert.equal(harness.api.getStatus().connected, false);
  assert.notEqual(first.sent.at(-1).type, "ready");
  await harness.api.quickMatch();
  assert.equal(harness.rooms.length, 2);
});

test("mismatched server hello and protocol errors fail closed without reflecting server text", async () => {
  const harness = createHarness();
  const first = await harness.api.quickMatch();
  first.emit("server-hello", serverHello({
    protocolVersion: Multiplayer.ONLINE_PROTOCOL_VERSION + 1,
    injected: "secret-token-should-not-appear",
  }));
  assert.equal(first.leaveCalls, 1);
  assert.deepEqual(first.sent, [{ type: "protocol-request", payload: {} }]);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
  assert.equal(harness.api.getStatus().actorId, null);
  assert.equal(harness.api.getStatus().epoch, null);
  assert.equal(harness.api.getStatus().started, false);
  assert.equal(harness.api.getStatus().connected, false);

  const second = await harness.api.quickMatch();
  assertProtocolRequest(second);
  second.emit("protocol-error", {
    code: "incompatible-client",
    reason: "reconnect-token=never-reflect-me",
  });
  assert.equal(second.leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
  assert.equal(harness.api.getStatus().detail.includes("never-reflect-me"), false);

  const third = await harness.api.quickMatch();
  assertProtocolRequest(third);
  third.close(1011, "protocol negotiation timed out");
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CONNECTION FAILED — TRY AGAIN");

  const fourth = await harness.api.quickMatch();
  assertProtocolRequest(fourth);
  fourth.close(1011, "attacker-controlled close reason");
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CONNECTION FAILED — TRY AGAIN");
  assert.equal(harness.api.getStatus().detail.includes("attacker"), false);
  assert.equal(harness.rooms.length, 4);
  assert.deepEqual(harness.joinOptions, [
    quickOptions(),
    quickOptions(),
    quickOptions(),
    quickOptions(),
  ]);
});

test("rematch controls are one-shot and a new assignment atomically resets client generation state", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room);
  room.emit("snapshot", snapshot(20));
  room.emit("match-start", { generation: 1, tick: 20 });
  const firstInput = harness.api.sendInput(input({
    moveX: 1,
    buttons: { attack: true, rematch: true },
  }));
  assert.equal(firstInput.generation, 1);
  assert.equal(firstInput.sequence, 0);
  assert.equal(firstInput.buttons.rematch, false, "gameplay input cannot become a rematch control");

  room.emit("lifecycle", lifecycle(1, "finished"));
  assert.equal(harness.api.getStatus().rematchOpen, true);
  assert.equal(harness.api.setRematchVote(true), true);
  assert.deepEqual(room.sent.at(-1), {
    type: "rematch-vote",
    payload: { generation: 1, vote: true },
  });
  assert.equal(harness.api.setRematchVote(true), false, "pending duplicate vote was amplified");
  room.emit("lifecycle", lifecycle(1, "rematch-vote", {
    rematchVoted: true,
    rematchVotes: 1,
  }));
  assert.equal(harness.api.setRematchVote(false), true);
  assert.deepEqual(room.sent.at(-1), {
    type: "rematch-vote",
    payload: { generation: 1, vote: false },
  });
  room.emit("lifecycle", lifecycle(1, "finished"));

  room.emit("lifecycle", lifecycle(1, "restarting"));
  room.emit("assignment", assignment(0, 1, { generation: 2, lifecycle: "ready", seed: 456 }));
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 2 } });
  assert.equal(harness.api.renderState(), null);
  assert.equal(harness.api.drainEvents().length, 0);
  assert.equal(harness.api.getStatus().generation, 2);
  room.emit("snapshot", snapshot(0, 0, 1, { generation: 2, seed: 456, state: stateAt(0) }));
  room.emit("match-start", { generation: 2, tick: 0 });
  const secondInput = harness.api.sendInput(input({ moveX: -1 }));
  assert.equal(secondInput.generation, 2);
  assert.equal(secondInput.sequence, 0);

  const before = harness.api.renderState();
  room.emit("snapshot", snapshot(999, 0, 1, { generation: 1, state: stateAt(999) }));
  room.emit("match-start", { generation: 1, tick: 999 });
  assert.deepEqual(harness.api.renderState(), before, "stale generation callbacks changed render state");
  assert.equal(harness.api.getStatus().generation, 2);
});

test("a results-screen reconnect clears consent and restores the frozen generation without gameplay input", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room, 0, 1);
  room.emit("snapshot", snapshot(10800, 0, 1));
  room.emit("lifecycle", lifecycle(1, "finished"));
  assert.equal(harness.api.setRematchVote(true), true);
  room.emit("lifecycle", lifecycle(1, "rematch-vote", {
    rematchVoted: true,
    rematchVotes: 1,
  }));
  assert.equal(harness.api.getStatus().rematchVoted, true);
  const sentBeforeDrop = room.sent.length;

  room.drop();
  assert.equal(harness.api.getStatus().state, "reconnecting");
  assert.equal(harness.api.getStatus().generation, 1);
  assert.equal(harness.api.getStatus().rematchOpen, false);
  assert.equal(harness.api.setRematchVote(false), false);
  assert.equal(harness.api.sendInput(input({ moveX: 1 })), null);
  assert.equal(room.sent.length, sentBeforeDrop);

  room.reconnect();
  assertProtocolRequest(room);
  const hello = serverHello();
  room.emit("server-hello", hello);
  room.emit("assignment", assignment(0, 2, { lifecycle: "finished" }));
  assert.deepEqual(room.sent.at(-1), { type: "ready", payload: { generation: 1 } });
  room.emit("snapshot", snapshot(10800, 0, 2));
  room.emit("lifecycle", lifecycle(1, "finished", {
    rematchVoted: false,
    rematchVotes: 0,
  }));
  assert.equal(harness.api.getStatus().generation, 1);
  assert.equal(harness.api.getStatus().epoch, 2);
  assert.equal(harness.api.getStatus().started, true);
  assert.equal(harness.api.getStatus().rematchOpen, true);
  assert.equal(harness.api.getStatus().rematchVoted, false);
  assert.equal(harness.api.sendInput(input({ moveX: 1 })), null);
  assert.equal(harness.api.setRematchVote(true), true);
  assert.deepEqual(room.sent.at(-1), {
    type: "rematch-vote",
    payload: { generation: 1, vote: true },
  });
});

test("an unannounced future lifecycle fails closed", async () => {
  const harness = createHarness();
  const room = await harness.api.quickMatch();
  completeAdmission(room);
  room.emit("lifecycle", lifecycle(2, "ready"));
  assert.equal(room.leaveCalls, 1);
  assert.equal(harness.api.getStatus().state, "error");
  assert.equal(harness.api.getStatus().detail, "CLIENT/SERVER UPDATE REQUIRED — RELOAD");
});
