import assert from "node:assert/strict";
import { connect as connectTcp } from "node:net";
import { after, before, beforeEach, test } from "node:test";
import vm from "node:vm";
import { CloseCode, matchMaker, Protocol } from "@colyseus/core";
import { debugMessage } from "@colyseus/core/Debug";
import { getMessageBytes } from "@colyseus/core/Protocol";
import { boot } from "@colyseus/testing";

import {
  createApplication,
  handleFixedExpressError,
} from "../src/app.config.mjs";
import {
  ArenaRoom,
  createConfiguredArenaRoom,
  PASS12B1_UNSUPPORTED_MESSAGE_REASON,
  PASS12B3B1_RECONNECT_SECONDS,
  PASS12B3B2_CONTROL_MESSAGE_LIMITS,
  PASS12B3B2_CONTROL_RATE_WINDOW_MS,
  PASS12B3B2_INITIAL_WAITING_TIMEOUT_MS,
  PASS12B3B2_INPUT_ATTEMPT_WINDOW_MS,
  PASS12B3B2_MAX_CONTROL_MESSAGES,
  PASS12B3B2_MAX_INBOUND_BYTES,
  PASS12B3B2_MAX_INBOUND_MESSAGES,
  PASS12B3B2_MAX_INPUT_ATTEMPTS,
  PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES,
  snapshotFitsOutboundBudget,
} from "../src/arena-room.mjs";
import { stateHash } from "../src/authoritative-match.mjs";
import {
  MAX_CODE_ROOMS,
  MAX_LIVE_ROOMS,
  ROOM_CODE_PATTERN,
  ROOM_SEAT_RESERVATION_SECONDS,
  roomRegistry,
} from "../src/room-registry.mjs";
import { Netcode } from "../src/shared-runtime.mjs";
import {
  createOperationsLogger,
  createSecurityRejectionTracker,
  createServiceState,
} from "../src/operations.mjs";
import { createRuntimeConfig } from "../src/runtime-config.mjs";
import {
  CREATE_MATCH_OPERATION,
  createProtocolBoundary,
  INCOMPATIBLE_CLIENT_MESSAGE,
  JOIN_CODE_OPERATION,
  QUICK_MATCH_OPERATION,
} from "../src/protocol-boundary.mjs";

let colyseus;
const matchStartHandlers = new WeakSet();
const operationsLines = [];
const application = createApplication(createRuntimeConfig({ PORT: "2568" }), {
  operationsLogger: createOperationsLogger({
    buildId: Netcode.SERVER_BUILD_ID,
    write: (line) => operationsLines.push(line),
  }),
});
const appConfig = application.server;
const guardRawLocalRequest = application.rawRequestGuard;
const pass12B1Boundary = application.boundary;
const rejectionTracker = application.rejectionTracker;
const frameworkDiagnosticGate = application.frameworkDiagnosticGate;

before(async () => {
  colyseus = await boot(appConfig);
  application.markReady();
});

after(async () => {
  if (colyseus) await colyseus.shutdown();
});

beforeEach(async () => {
  await colyseus.cleanup();
  pass12B1Boundary.reset();
  rejectionTracker.reset();
  frameworkDiagnosticGate.reset();
  operationsLines.length = 0;
});

function buttons(overrides = {}) {
  return {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
    ...overrides,
  };
}

function command(sequence, clientTick, overrides = {}) {
  return {
    generation: 1,
    sequence,
    clientTick,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: buttons(),
    ...overrides,
    buttons: buttons(overrides.buttons),
  };
}

function admissionOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return {
    compatibility,
    operation: QUICK_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function createMatchOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return {
    compatibility,
    operation: CREATE_MATCH_OPERATION,
    modeId: "free-for-all",
    mapId: "original-arena",
  };
}

function joinCodeOptions(compatibility = Netcode.createCompatibilityOffer()) {
  return { compatibility, operation: JOIN_CODE_OPERATION };
}

function rawHost(host, port) {
  return host && host.includes("{port}")
    ? host.replace("{port}", String(port))
    : `${host}:${port}`;
}

function rawUpgradeStatus({
  path = "/process-1/room-1?sessionId=session-1",
  origin,
  host = "127.0.0.1",
  extraHeaders = {},
  fullResponse = false,
} = {}) {
  return new Promise((resolve, reject) => {
    const port = colyseus.server.port;
    const socket = connectTcp(port, "127.0.0.1");
    let response = "";
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      socket.setTimeout(0);
      socket.destroy();
      if (error) reject(error);
      else resolve(value);
    };
    socket.setTimeout(2000, () => finish(new Error("raw WebSocket upgrade timed out")));
    socket.on("error", (error) => finish(error));
    socket.on("data", (chunk) => {
      response += chunk.toString("latin1");
      const headerEnd = response.indexOf("\r\n\r\n");
      if (!fullResponse && headerEnd >= 0) finish(null, response.slice(0, response.indexOf("\r\n")));
    });
    socket.on("end", () => finish(null, fullResponse
      ? response : response.slice(0, response.indexOf("\r\n"))));
    socket.on("connect", () => {
      const rawPath = path.replaceAll("{port}", String(port));
      const headers = [
        `GET ${rawPath} HTTP/${host == null ? "1.0" : "1.1"}`,
        "Connection: Upgrade",
        "Upgrade: websocket",
        "Sec-WebSocket-Version: 13",
        "Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==",
      ];
      if (host != null) headers.splice(1, 0, `Host: ${rawHost(host, port)}`);
      if (origin != null) headers.push(`Origin: ${origin.replace("{port}", String(port))}`);
      const entries = Array.isArray(extraHeaders) ? extraHeaders : Object.entries(extraHeaders);
      for (const [name, value] of entries) {
        headers.push(`${name}: ${String(value).replaceAll("{port}", String(port))}`);
      }
      socket.write(`${headers.join("\r\n")}\r\n\r\n`);
    });
  });
}

function rawHttpStatus({
  path = "/matchmake/joinOrCreate/arena",
  origin,
  host = "127.0.0.1",
  contentLength = "2",
  body = "{}",
  extraHeaders = {},
  method = "POST",
  fullResponse = false,
} = {}) {
  return new Promise((resolve, reject) => {
    const port = colyseus.server.port;
    const socket = connectTcp(port, "127.0.0.1");
    let response = "";
    let settled = false;
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      socket.setTimeout(0);
      socket.destroy();
      if (error) reject(error);
      else resolve(value);
    };
    socket.setTimeout(2000, () => finish(new Error("raw HTTP request timed out")));
    socket.on("error", (error) => finish(error));
    socket.on("data", (chunk) => {
      response += chunk.toString("latin1");
      if (!fullResponse && response.includes("\r\n\r\n")) {
        finish(null, response.slice(0, response.indexOf("\r\n")));
      }
    });
    socket.on("end", () => finish(null, fullResponse
      ? response : response.slice(0, response.indexOf("\r\n"))));
    socket.on("connect", () => {
      const rawPath = path.replaceAll("{port}", String(port));
      const headers = [
        `${method} ${rawPath} HTTP/${host == null ? "1.0" : "1.1"}`,
        "Connection: close",
        "Content-Type: application/json",
        `Content-Length: ${contentLength}`,
      ];
      if (host != null) headers.splice(1, 0, `Host: ${rawHost(host, port)}`);
      if (origin != null) headers.push(`Origin: ${origin.replace("{port}", String(port))}`);
      const entries = Array.isArray(extraHeaders) ? extraHeaders : Object.entries(extraHeaders);
      for (const [name, value] of entries) {
        headers.push(`${name}: ${String(value).replaceAll("{port}", String(port))}`);
      }
      socket.write(`${headers.join("\r\n")}\r\n\r\n${body}`);
    });
  });
}

async function captureConsole(callback) {
  const methods = ["debug", "error", "info", "log", "warn"];
  const originals = new Map(methods.map((method) => [method, console[method]]));
  const output = [];
  for (const method of methods) {
    console[method] = (...values) => output.push(values.map(String).join(" "));
  }
  try {
    const result = await callback();
    await new Promise((resolve) => setImmediate(resolve));
    return { result, output: output.join("\n") };
  } finally {
    for (const method of methods) console[method] = originals.get(method);
  }
}

test("B3B2 Room rate, waiting, and output budgets are explicit and internally coherent", () => {
  assert.equal(debugMessage.enabled, false, "decoded client payload debug must remain disabled");
  assert.equal(PASS12B3B2_INITIAL_WAITING_TIMEOUT_MS, 120_000);
  assert.equal(PASS12B3B2_MAX_INBOUND_MESSAGES, 120);
  assert.equal(PASS12B3B2_MAX_INBOUND_BYTES, 32 * 1024);
  assert.equal(PASS12B3B2_INPUT_ATTEMPT_WINDOW_MS, 1000);
  assert.equal(PASS12B3B2_MAX_INPUT_ATTEMPTS, 120);
  assert.equal(PASS12B3B2_CONTROL_RATE_WINDOW_MS, 10_000);
  assert.equal(PASS12B3B2_MAX_CONTROL_MESSAGES, 16);
  assert.deepEqual(PASS12B3B2_CONTROL_MESSAGE_LIMITS, {
    "protocol-request": 4,
    "hello-ack": 4,
    ready: 4,
    resync: 4,
    "rematch-vote": 8,
  });
  assert.equal(PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES, 256 * 1024);
  assert.equal(snapshotFitsOutboundBudget(PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES, 0), true);
  assert.equal(snapshotFitsOutboundBudget(
    PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES - 1,
    1,
  ), true);
  assert.equal(snapshotFitsOutboundBudget(PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES, 1), false);
  for (const invalid of [null, -1, 0.5, Number.NaN, Infinity]) {
    assert.equal(snapshotFitsOutboundBudget(invalid, 1), false);
  }
});

test("the Express error boundary redacts pre-header failures and delegates partial responses", () => {
  const response = {
    headersSent: false,
    statusCode: null,
    headers: null,
    body: null,
    status(statusCode) {
      this.statusCode = statusCode;
      return this;
    },
    set(headers) {
      this.headers = headers;
      return this;
    },
    send(body) {
      this.body = body;
      return this;
    },
  };
  const canary = new Error("EXPRESS_ERROR_CANARY_12B3B2");
  let delegated = null;
  handleFixedExpressError(canary, {}, response, (error) => { delegated = error; });
  assert.equal(response.statusCode, 500);
  assert.equal(response.body, '{"error":"internal server error"}');
  assert.equal(response.body.includes(canary.message), false);
  assert.equal(response.headers["Cache-Control"], "no-store");
  assert.equal(response.headers["X-Content-Type-Options"], "nosniff");
  assert.equal(delegated, null);

  response.headersSent = true;
  response.statusCode = null;
  response.body = null;
  handleFixedExpressError(canary, {}, response, (error) => { delegated = error; });
  assert.equal(delegated, canary);
  assert.equal(response.statusCode, null);
  assert.equal(response.body, null);
});

test("a pre-start reconnect must renegotiate before rebind, assignment, readiness, and start", { timeout: 15000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  await bootstrap(first);
  const sessionId = first.sessionId;
  assert.equal(backend.lifecycle, "waiting");
  assert.equal(backend.readySessions.has(sessionId), true);

  let reconnectAssignmentSends = 0;
  const sendAssignment = backend.sendAssignment.bind(backend);
  backend.sendAssignment = (client) => {
    reconnectAssignmentSends += 1;
    return sendAssignment(client);
  };
  const reconnected = new Promise((resolve) => first.onReconnect(resolve));
  first.leave(false);
  await reconnected;
  assert.equal(backend.lifecycle, "waiting");
  assert.equal(backend.match.actorBySession.has(sessionId), false);
  assert.equal(backend.readySessions.has(sessionId), false);
  assert.equal(backend.admittedSessions.has(sessionId), false);
  assert.equal(backend.negotiatingSessions.has(sessionId), true);
  assert.equal(backend.handshakeTimers.has(sessionId), true);

  const assignment = first.waitForMessage("assignment");
  const hello = await requestServerHello(first);
  assert.equal(Netcode.validateCurrentServerHello(hello).accepted, true);
  assert.equal(reconnectAssignmentSends, 0, "reconnect hello cannot assign a seat");
  assert.equal(
    backend.match.actorBySession.has(sessionId),
    false,
    "a server hello alone cannot rebind the reserved actor"
  );
  assert.equal(backend.admittedSessions.has(sessionId), false);

  first.send("hello-ack", hello);
  const rebound = await assignment;
  assert.equal(reconnectAssignmentSends, 1, "reconnect acknowledgement must assign exactly once");
  assert.deepEqual(rebound.compatibility, hello);
  assert.equal(rebound.actorId, 0);
  assert.ok(rebound.epoch > 1);
  assert.equal(backend.match.actorBySession.get(sessionId), rebound.actorId);
  assert.equal(backend.admittedSessions.has(sessionId), true);
  assert.equal(backend.negotiatingSessions.has(sessionId), false);
  assert.equal(backend.handshakeTimers.has(sessionId), false);
  assert.equal(backend.lifecycle, "waiting", "admission cannot substitute for explicit readiness");

  const reconnectSnapshot = first.waitForMessage("snapshot");
  first.send("ready", { generation: rebound.generation });
  await reconnectSnapshot;
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await bootstrap(second);
  assert.equal(backend.lifecycle, "playing");
  assert.equal(backend.locked, true);
});

async function requestServerHello(client) {
  const serverHello = client.waitForMessage("server-hello");
  client.send("protocol-request", {});
  return serverHello;
}

async function bootstrap(client) {
  if (!matchStartHandlers.has(client)) {
    client.onMessage("match-start", () => {});
    client.onMessage("lifecycle", () => {});
    client.onMessage("control-rejected", () => {});
    matchStartHandlers.add(client);
  }

  const hello = await requestServerHello(client);
  assert.equal(Netcode.validateServerHello(hello).accepted, true);
  assert.equal(Netcode.validateCurrentServerHello(hello).accepted, true);

  const assignment = client.waitForMessage("assignment");
  client.send("hello-ack", hello);
  const assigned = await assignment;
  assert.deepEqual(assigned.compatibility, hello);

  const snapshot = client.waitForMessage("snapshot");
  client.send("ready", { generation: assigned.generation });
  return [assigned, await snapshot, hello];
}

async function waitForSnapshotAck(client, sequence) {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const snapshot = await client.waitForMessage("snapshot");
    if (snapshot.ackSequence === sequence) return snapshot;
  }
  throw new Error(`no periodic snapshot acknowledged input ${sequence}`);
}

async function waitForCondition(predicate, message, timeoutMs = 1000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (predicate()) return;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(message);
}

function waitForUmdMessage(room, type, send, timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    let unsubscribe;
    const timer = setTimeout(() => {
      unsubscribe?.();
      reject(new Error(`timed out waiting for UMD ${type}`));
    }, timeoutMs);
    unsubscribe = room.onMessage(type, (message) => {
      clearTimeout(timer);
      unsubscribe();
      resolve(message);
    });
    send?.();
  });
}

async function waitForUmdState(room, predicate, label, timeoutMs = 4000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const state = room.state?.toJSON?.();
    if (state && predicate(state)) return state;
    await new Promise((resolve) => setTimeout(resolve, 10));
  }
  throw new Error(`timed out waiting for UMD state: ${label}`);
}

async function bootstrapUmd(room) {
  for (const type of [
    "match-start", "lifecycle", "control-rejected", "input-rejected", "protocol-error",
  ]) room.onMessage(type, () => {});
  const hello = await waitForUmdMessage(
    room,
    "server-hello",
    () => room.send("protocol-request", {}),
  );
  assert.equal(Netcode.validateCurrentServerHello(hello).accepted, true);
  const assignment = await waitForUmdMessage(
    room,
    "assignment",
    () => room.send("hello-ack", hello),
  );
  const snapshot = await waitForUmdMessage(
    room,
    "snapshot",
    () => room.send("ready", { generation: assignment.generation }),
  );
  return { assignment, snapshot };
}

async function assertNegotiationCleared(backend, sessionId, message) {
  await waitForCondition(
    () => !backend.negotiatingSessions.has(sessionId)
      && !backend.helloSentSessions.has(sessionId)
      && !backend.admittedSessions.has(sessionId)
      && !backend.readySessions.has(sessionId)
      && !backend.handshakeTimers.has(sessionId)
      && !backend.reservations.has(sessionId)
      && !backend.match.actorBySession.has(sessionId)
      && ![...backend.clients].some((client) => client.sessionId === sessionId),
    message,
  );
}

async function finishCurrentGeneration(backend, clients) {
  const finalSnapshots = clients.map((client) => client.waitForMessage("snapshot"));
  backend.match.state.match.ticksRemaining = 1;
  await backend.waitForNextSimulationTick();
  const snapshots = await Promise.all(finalSnapshots);
  await waitForCondition(
    () => backend.lifecycle === "finished" && backend.rematchOpen,
    "authoritative results window did not open",
  );
  assert.ok(snapshots.every((snapshot) => snapshot.generation === backend.match.generation));
  assert.ok(snapshots.every((snapshot) => snapshot.state.match.phase === "finished"));
  return snapshots;
}

test("SDK Quick, Create, and Join Code flows stay isolated and freeze the approved configuration", { timeout: 15000 }, async () => {
  const clients = [];
  const roomIds = new Set();
  try {
    const creatorOne = await colyseus.sdk.create("arena", createMatchOptions());
    const creatorTwo = await colyseus.sdk.create("arena", createMatchOptions());
    clients.push(creatorOne, creatorTwo);
    roomIds.add(creatorOne.roomId);
    roomIds.add(creatorTwo.roomId);
    assert.match(creatorOne.roomId, ROOM_CODE_PATTERN);
    assert.match(creatorTwo.roomId, ROOM_CODE_PATTERN);
    assert.notEqual(creatorOne.roomId, creatorTwo.roomId);

    for (const creator of [creatorOne, creatorTwo]) {
      const backend = colyseus.getRoomById(creator.roomId);
      const [listing] = await matchMaker.query({ roomId: creator.roomId });
      assert.ok(backend);
      assert.equal(backend.seatReservationTimeout, ROOM_SEAT_RESERVATION_SECONDS);
      assert.equal(listing?.private, true, "code rooms must not enter Quick Match queries");
      assert.equal(backend.match.state.config.modeId, "free-for-all");
      assert.equal(backend.match.state.config.mapId, "original-arena");
    }

    const quickOne = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const quickTwo = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    clients.push(quickOne, quickTwo);
    roomIds.add(quickOne.roomId);
    assert.equal(quickTwo.roomId, quickOne.roomId, "compatible Quick clients must pair");
    assert.notEqual(quickOne.roomId, creatorOne.roomId);
    assert.notEqual(quickOne.roomId, creatorTwo.roomId);
    assert.equal(
      ROOM_CODE_PATTERN.test(quickOne.roomId),
      false,
      "framework-generated Quick IDs remain outside the fixed code namespace",
    );
    const quickBackend = colyseus.getRoomById(quickOne.roomId);
    const [quickListing] = await matchMaker.query({ roomId: quickOne.roomId });
    assert.equal(quickListing?.private, false);
    assert.equal(quickBackend.match.state.config.modeId, "free-for-all");
    assert.equal(quickBackend.match.state.config.mapId, "original-arena");

    const joined = await colyseus.sdk.joinById(creatorOne.roomId, joinCodeOptions());
    clients.push(joined);
    assert.equal(joined.roomId, creatorOne.roomId, "the code must identify exactly one private room");
    const codeBackend = colyseus.getRoomById(creatorOne.roomId);
    assert.equal(codeBackend.clients.length, 2);
    const [creatorAssignment] = await bootstrap(creatorOne);
    const [joinerAssignment] = await bootstrap(joined);
    assert.notEqual(creatorAssignment.actorId, joinerAssignment.actorId);
    assert.equal(codeBackend.lifecycle, "playing");
    assert.equal(codeBackend.match.state.config.modeId, "free-for-all");
    assert.equal(codeBackend.match.state.config.mapId, "original-arena");

    await assert.rejects(
      colyseus.sdk.joinById(creatorOne.roomId, joinCodeOptions()),
      (error) => error?.code === 522 && error.message === "Match unavailable or expired."
        && !error.message.includes(creatorOne.roomId),
      "a third client receives the same fixed response as every unavailable code",
    );
    const unknownCode = ["AAAAAAA", "BBBBBBB", "CCCCCCC", "DDDDDDD"]
      .find((code) => !roomIds.has(code));
    assert.ok(unknownCode);
    await assert.rejects(
      colyseus.sdk.joinById(unknownCode, joinCodeOptions()),
      (error) => error?.code === 522 && error.message === "Match unavailable or expired."
        && !error.message.includes(unknownCode),
      "an unknown valid-shape code must not be reflected by the wire response",
    );
    for (const malformedCode of ["abcdefg", "ABCDEF", "ABCDEFGH", "ABCD0FG", "ABCDIFG", "ABCDOFG"]) {
      await assert.rejects(
        colyseus.sdk.joinById(malformedCode, joinCodeOptions()),
        (error) => Boolean(error),
        malformedCode,
      );
    }

    const registry = roomRegistry.snapshot();
    assert.ok(registry.liveRooms <= MAX_LIVE_ROOMS);
    assert.ok(registry.codeRooms <= MAX_CODE_ROOMS);
    assert.equal(registry.codeRooms, 2);
    assert.ok(registry.roomIds.includes(creatorOne.roomId));
    assert.ok(registry.roomIds.includes(creatorTwo.roomId));
    assert.ok(registry.roomIds.includes(quickOne.roomId));
  } finally {
    await Promise.allSettled(clients.map((client) => client.leave(true)));
  }

  await waitForCondition(
    () => [...roomIds].every((roomId) => !roomRegistry.snapshot().roomIds.includes(roomId)),
    "disposed SDK rooms were not released from the one-process registry",
    3000,
  );
});

test("ArenaRoom enforces code-Room capacity, releases on disposal, and admits one replacement", { timeout: 20000 }, async () => {
  const clients = [];
  try {
    for (let index = 0; index < MAX_CODE_ROOMS; index += 1) {
      pass12B1Boundary.reset();
      clients.push(await colyseus.sdk.create("arena", createMatchOptions()));
    }
    assert.equal(roomRegistry.snapshot().codeRooms, MAX_CODE_ROOMS);
    assert.equal(roomRegistry.snapshot().liveRooms, MAX_CODE_ROOMS);

    pass12B1Boundary.reset();
    await assert.rejects(colyseus.sdk.create("arena", createMatchOptions()));
    assert.equal(roomRegistry.snapshot().codeRooms, MAX_CODE_ROOMS);
    assert.equal(roomRegistry.snapshot().liveRooms, MAX_CODE_ROOMS);

    const released = clients.shift();
    await released.leave(true);
    await waitForCondition(
      () => roomRegistry.snapshot().codeRooms === MAX_CODE_ROOMS - 1,
      "disposed code Room did not release registry capacity",
      3000,
    );

    pass12B1Boundary.reset();
    const replacement = await colyseus.sdk.create("arena", createMatchOptions());
    clients.push(replacement);
    assert.match(replacement.roomId, ROOM_CODE_PATTERN);
    assert.equal(roomRegistry.snapshot().codeRooms, MAX_CODE_ROOMS);
    assert.equal(roomRegistry.snapshot().liveRooms, MAX_CODE_ROOMS);
  } finally {
    await Promise.allSettled(clients.map((client) => client.leave(true)));
  }

  await waitForCondition(
    () => roomRegistry.snapshot().codeRooms === 0 && roomRegistry.snapshot().liveRooms === 0,
    "capacity test Rooms were not released",
    3000,
  );
});

test("every direct onCreate rejection uses the initialized bounded-disposal path", { timeout: 3000 }, async () => {
  const room = new ArenaRoom();
  room.roomId = "partial-create-test";
  room.__init();
  const before = roomRegistry.snapshot();

  await assert.rejects(room.onCreate({ compatibility: null }), /incompatible/i);
  await waitForCondition(
    () => room.lifecycle === "disposed",
    "rejected onCreate retained its seat-reservation timer or skipped disposal",
    2000,
  );

  assert.deepEqual(roomRegistry.snapshot(), before);
  assert.equal(room.registeredRoomId, null);
  assert.equal(room.handshakeTimers.size, 0);
  assert.equal(room.reservations.size, 0);
});

test("a drain crossing code-Room creation preserves the fixed 503 contract", { timeout: 3000 }, async () => {
  const serviceState = createServiceState();
  serviceState.setListenerAvailable(true);
  serviceState.setDependenciesAvailable(true);
  serviceState.transition("ready");
  const ConfiguredArenaRoom = createConfiguredArenaRoom({
    operationsLogger: createOperationsLogger({
      buildId: Netcode.SERVER_BUILD_ID,
      write: () => {},
    }),
    rejectionTracker: createSecurityRejectionTracker(),
    requestPolicy: null,
    serviceState,
  });
  const room = new ConfiguredArenaRoom();
  room.roomId = "drain-create-race";
  room.__init();
  room.setPrivate = async () => {
    serviceState.transition("draining");
  };

  await assert.rejects(room.onCreate(createMatchOptions()), (error) => {
    assert.equal(error.code, 503);
    assert.equal(error.message, "service unavailable");
    return true;
  });
  await waitForCondition(
    () => room.lifecycle === "disposed",
    "drain-crossing code Room did not dispose",
    2000,
  );
  assert.equal(room.registeredRoomId, null);
  assert.equal(roomRegistry.snapshot().roomIds.includes(room.roomId), false);
});

test("matchmaking routes reject cross-operation and forged configuration options before consuming seats", { timeout: 10000 }, async () => {
  await assert.rejects(colyseus.sdk.joinOrCreate("arena", createMatchOptions()));
  await assert.rejects(colyseus.sdk.create("arena", admissionOptions()));
  await assert.rejects(colyseus.sdk.create("arena", {
    ...createMatchOptions(),
    modeId: "forged-mode",
  }));
  await assert.rejects(colyseus.sdk.create("arena", {
    ...createMatchOptions(),
    mapId: "forged-map",
  }));
  assert.equal((await matchMaker.query({ name: "arena" })).length, 0);

  const creator = await colyseus.sdk.create("arena", createMatchOptions());
  const backend = colyseus.getRoomById(creator.roomId);
  assert.equal(backend.clients.length, 1);
  await assert.rejects(colyseus.sdk.joinById(creator.roomId, admissionOptions()));
  await assert.rejects(colyseus.sdk.joinById(creator.roomId, createMatchOptions()));
  await assert.rejects(colyseus.sdk.joinById(creator.roomId, {
    ...joinCodeOptions(),
    actorId: 0,
  }));
  assert.equal(backend.clients.length, 1, "rejected join options cannot consume the second seat");
  assert.equal(backend.match.state.config.modeId, "free-for-all");
  assert.equal(backend.match.state.config.mapId, "original-arena");
  await creator.leave(true);
});

test("bad admission consumes no room or seat, then two compatible clients share and lock one room", { timeout: 10000 }, async (context) => {
  let assignmentSends = 0;
  const sendAssignment = ArenaRoom.prototype.sendAssignment;
  ArenaRoom.prototype.sendAssignment = function countAssignment(client) {
    assignmentSends += 1;
    return sendAssignment.call(this, client);
  };
  context.after(() => { ArenaRoom.prototype.sendAssignment = sendAssignment; });
  const incompatible = {
    ...Netcode.createCompatibilityOffer(),
    protocolVersion: Netcode.ONLINE_PROTOCOL_VERSION + 1,
  };
  await assert.rejects(
    colyseus.sdk.joinOrCreate("arena", admissionOptions(incompatible)),
    (error) => {
      assert.equal(error && error.code, 525);
      assert.equal(String(error && error.message), INCOMPATIBLE_CLIENT_MESSAGE);
      return true;
    }
  );
  assert.equal((await matchMaker.query({ name: "arena" })).length, 0);

  const legacyCompatibility = {
    ...Netcode.createCompatibilityOffer(),
    protocolVersion: Netcode.ONLINE_PROTOCOL_VERSION - 1,
  };
  await assert.rejects(
    colyseus.sdk.joinOrCreate("arena", { compatibility: legacyCompatibility }),
    (error) => {
      assert.equal(error && error.code, 525);
      assert.equal(String(error && error.message), INCOMPATIBLE_CLIENT_MESSAGE);
      return true;
    },
    "a pre-B3A client receives the fixed update-required path instead of a generic malformed error",
  );
  assert.equal((await matchMaker.query({ name: "arena" })).length, 0);

  await assert.rejects(
    colyseus.sdk.joinOrCreate("arena", { compatibility: null }),
    (error) => {
      assert.equal(error && error.code, 400);
      assert.equal(String(error && error.message), "invalid matchmaking request");
      return true;
    }
  );
  assert.equal((await matchMaker.query({ name: "arena" })).length, 0);

  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  assert.equal(
    backend.match.actorBySession.size,
    0,
    "HTTP/WS admission alone cannot bind an authoritative actor"
  );
  assert.equal(backend.clients.length, 1);

  await assert.rejects(
    colyseus.sdk.joinOrCreate("arena", {
      ...admissionOptions(),
      seed: -1,
      modeId: "forged-mode",
      mapId: "forged-map",
      actorId: 0,
      sessionId: "forged-session",
    }),
    (error) => {
      assert.equal(error && error.code, 400);
      assert.equal(String(error && error.message), "invalid matchmaking request");
      return true;
    }
  );
  assert.equal((await matchMaker.query({ name: "arena" })).length, 1);
  assert.equal(backend.clients.length, 1, "rejected authority options cannot consume a second seat");
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  first.onMessage("match-start", () => {});
  first.onMessage("lifecycle", () => {});
  first.onMessage("control-rejected", () => {});
  matchStartHandlers.add(first);
  const firstAssignmentMessage = first.waitForMessage("assignment");
  const firstHello = await requestServerHello(first);
  assert.equal(assignmentSends, 0, "server hello cannot precede admission with an assignment");
  first.send("hello-ack", firstHello);
  const firstAssignment = await firstAssignmentMessage;
  assert.equal(assignmentSends, 1, "one acknowledgement must produce exactly one assignment");
  assert.deepEqual(firstAssignment.compatibility, firstHello);
  const firstSnapshot = first.waitForMessage("snapshot");
  first.send("ready", { generation: firstAssignment.generation });
  await firstSnapshot;
  assert.equal(firstAssignment.actorId, 0);
  assert.equal(backend.state.started, false);
  const duplicateAckReceived = backend.waitForNextMessage();
  first.send("hello-ack", firstHello);
  await duplicateAckReceived;
  const repeatedHello = await requestServerHello(first);
  const repeatedAckReceived = backend.waitForNextMessage();
  first.send("hello-ack", repeatedHello);
  await repeatedAckReceived;
  assert.equal(backend.match.actorBySession.get(first.sessionId), firstAssignment.actorId);
  assert.equal(backend.match.snapshot(first.sessionId).epoch, firstAssignment.epoch);
  const firstServerClient = [...backend.clients]
    .find((client) => client.sessionId === first.sessionId);
  assert.ok(firstServerClient);
  let duplicateReadySnapshots = 0;
  const sendToFirst = firstServerClient.send.bind(firstServerClient);
  firstServerClient.send = (type, payload, options) => {
    if (type === "snapshot") duplicateReadySnapshots += 1;
    return sendToFirst(type, payload, options);
  };
  const duplicateReadyReceived = backend.waitForNextMessage();
  first.send("ready", { generation: firstAssignment.generation });
  await duplicateReadyReceived;
  assert.equal(duplicateReadySnapshots, 0, "duplicate ready must not amplify full snapshots");

  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  assert.equal(second.roomId, first.roomId);
  const [secondAssignment] = await bootstrap(second);
  assert.equal(secondAssignment.actorId, 1);
  assert.equal(backend.state.started, true);
  assert.equal(backend.locked, true);
  assert.equal(backend.state.modeId, "free-for-all");
  assert.equal(backend.state.mapId, "original-arena");
  assert.notEqual(backend.match.state.seed, -1);

  await backend.waitForNextSimulationTick();
  assert.ok(backend.match.state.tick > 0);
  await backend.waitForNextPatch();
  const firstProjection = first.state.toJSON();
  const secondProjection = second.state.toJSON();
  assert.deepEqual(firstProjection, secondProjection);
  assert.deepEqual(Object.keys(firstProjection), [
    "generation", "simVersion", "modeId", "mapId", "lifecycle", "started",
    "connectedPlayers", "rematchOpen", "rematchVotes", "rematchRequired",
  ]);
  assert.deepEqual(firstProjection, {
    generation: 1,
    simVersion: Netcode.SIMULATION_SCHEMA_VERSION,
    modeId: "free-for-all",
    mapId: "original-arena",
    lifecycle: "playing",
    started: true,
    connectedPlayers: 2,
    rematchOpen: false,
    rematchVotes: 0,
    rematchRequired: 2,
  });
  for (const gameplayField of ["seed", "tick", "snapshotJson", "stateHash"]) {
    assert.equal(gameplayField in firstProjection, false, `${gameplayField} leaked through public Schema`);
  }

  const third = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  assert.notEqual(third.roomId, first.roomId, "a locked regulation match is not reused by matchmaking");
});

test("an unacknowledged protocol negotiation times out without binding an actor", { timeout: 5000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(client.roomId);
  const sessionId = client.sessionId;
  client.onMessage("protocol-error", () => {});
  assert.equal(backend.negotiatingSessions.has(sessionId), true);
  assert.equal(backend.match.actorBySession.has(sessionId), false);
  const timer = backend.handshakeTimers.get(sessionId);
  assert.ok(timer && typeof timer.execute === "function");

  const left = new Promise((resolve) => client.onLeave((code, reason) => resolve({ code, reason })));
  timer.execute();
  assert.deepEqual(await left, {
    code: CloseCode.WITH_ERROR,
    reason: "protocol negotiation timed out",
  });
  await waitForCondition(
    () => !backend.negotiatingSessions.has(sessionId),
    "expired negotiation was not cleared",
  );
  assert.equal(backend.handshakeTimers.has(sessionId), false);
  assert.equal(backend.admittedSessions.has(sessionId), false);
  assert.equal(backend.readySessions.has(sessionId), false);
  assert.equal(backend.match.actorBySession.has(sessionId), false);
});

test("a cleared handshake timer cannot terminate its replacement negotiation", { timeout: 5000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(client.roomId);
  const serverClient = [...backend.clients].find((candidate) => candidate.sessionId === client.sessionId);
  const oldTimer = backend.handshakeTimers.get(client.sessionId);
  assert.ok(serverClient);
  assert.ok(oldTimer && typeof oldTimer.execute === "function");

  backend.beginNegotiation(serverClient);
  const replacementTimer = backend.handshakeTimers.get(client.sessionId);
  assert.ok(replacementTimer && replacementTimer !== oldTimer);
  oldTimer.execute();

  assert.equal(backend.handshakeTimers.get(client.sessionId), replacementTimer);
  assert.equal(backend.negotiatingSessions.has(client.sessionId), true);
  assert.equal(backend.terminalSessions.has(client.sessionId), false);
  assert.equal(backend.admittedSessions.has(client.sessionId), false);
  assert.equal(backend.match.actorBySession.has(client.sessionId), false);
});

test("pre-admission controls and invalid acknowledgements cannot bind, ready, resync, or play", { timeout: 5000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(client.roomId);
  const sessionId = client.sessionId;
  client.onMessage("protocol-error", () => {});

  for (const [type, payload] of [
    ["ready", {}],
    ["resync", {}],
  ]) {
    const received = backend.waitForNextMessage();
    client.send(type, payload);
    await received;
  }
  const rejectedInput = client.waitForMessage("input-rejected");
  client.send("input", command(0, 0));
  assert.deepEqual(await rejectedInput, { generation: 1, reason: "not-playing" });
  assert.equal(backend.match.actorBySession.has(sessionId), false);
  assert.equal(backend.admittedSessions.has(sessionId), false);
  assert.equal(backend.readySessions.has(sessionId), false);
  assert.equal(backend.lifecycle, "waiting");
  assert.equal(backend.handshakeTimers.has(sessionId), true);

  const earlyAckLeave = new Promise((resolve) => {
    client.onLeave((code, reason) => resolve({ code, reason }));
  });
  client.send("hello-ack", Netcode.createServerHello());
  assert.deepEqual(await earlyAckLeave, {
    code: CloseCode.WITH_ERROR,
    reason: "protocol negotiation failed",
  });
  await waitForCondition(
    () => !backend.negotiatingSessions.has(sessionId),
    "out-of-order acknowledgement did not clear negotiation",
  );
  assert.equal(backend.handshakeTimers.has(sessionId), false);
  assert.equal(backend.match.actorBySession.has(sessionId), false);

  const malformedClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const malformedBackend = colyseus.getRoomById(malformedClient.roomId);
  malformedClient.onMessage("protocol-error", () => {});
  const malformedHello = await requestServerHello(malformedClient);
  const malformedLeave = new Promise((resolve) => {
    malformedClient.onLeave((code, reason) => resolve({ code, reason }));
  });
  malformedClient.send("hello-ack", {
    ...malformedHello,
    serverBuildId: "invalid\nbuild",
  });
  assert.deepEqual(await malformedLeave, {
    code: CloseCode.WITH_ERROR,
    reason: "protocol negotiation failed",
  });
  await waitForCondition(
    () => !malformedBackend.negotiatingSessions.has(malformedClient.sessionId),
    "malformed acknowledgement did not clear negotiation",
  );
  assert.equal(malformedBackend.handshakeTimers.has(malformedClient.sessionId), false);
  assert.equal(malformedBackend.match.actorBySession.has(malformedClient.sessionId), false);
});

test("generation controls reject inherited, accessor, extra, and mistyped records before mutation", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.onMessage("snapshot", () => {});
  first.onMessage("lifecycle", () => {});
  first.onMessage("match-start", () => {});
  first.onMessage("control-rejected", () => {});
  matchStartHandlers.add(first);
  const backend = colyseus.getRoomById(first.roomId);
  const hello = await requestServerHello(first);
  const assignmentMessage = first.waitForMessage("assignment");
  first.send("hello-ack", hello);
  const assignment = await assignmentMessage;
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  assert.ok(serverClient);
  assert.equal(backend.readySessions.has(first.sessionId), false);

  assert.equal(backend.receiveReady(serverClient, { generation: 1, extra: true }), false);
  assert.equal(backend.receiveReady(serverClient, Object.create({ generation: 1 })), false);
  let getterCalls = 0;
  const accessorReady = {};
  Object.defineProperty(accessorReady, "generation", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return 1;
    },
  });
  assert.equal(backend.receiveReady(serverClient, accessorReady), false);
  assert.equal(getterCalls, 0);
  assert.equal(backend.readySessions.has(first.sessionId), false);

  const exactReady = Object.assign(Object.create(null), { generation: assignment.generation });
  const readySnapshot = first.waitForMessage("snapshot");
  assert.equal(backend.receiveReady(serverClient, exactReady), true);
  await readySnapshot;
  assert.equal(backend.readySessions.has(first.sessionId), true);
  assert.equal(backend.receiveResync(serverClient, { generation: 1, extra: true }), false);
  assert.equal(backend.receiveResync(serverClient, Object.create({ generation: 1 })), false);
  assert.equal(
    backend.receiveResync(serverClient, Object.assign(Object.create(null), { generation: 1 })),
    false,
    "resync became active before gameplay",
  );

  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await bootstrap(second);
  await waitForCondition(() => backend.lifecycle === "playing", "control test did not start");
  const resyncSnapshot = first.waitForMessage("snapshot");
  assert.equal(
    backend.receiveResync(serverClient, Object.assign(Object.create(null), { generation: 1 })),
    true,
  );
  await resyncSnapshot;
  await finishCurrentGeneration(backend, [first, second]);

  assert.equal(backend.receiveRematchVote(serverClient, {
    generation: 1,
    vote: true,
    extra: true,
  }), false);
  assert.equal(backend.receiveRematchVote(
    serverClient,
    Object.create({ generation: 1, vote: true }),
  ), false);
  const accessorVote = {};
  Object.defineProperties(accessorVote, {
    generation: {
      enumerable: true,
      get() {
        getterCalls += 1;
        return 1;
      },
    },
    vote: { enumerable: true, value: true },
  });
  assert.equal(backend.receiveRematchVote(serverClient, accessorVote), false);
  assert.equal(getterCalls, 0);
  assert.equal(backend.receiveRematchVote(serverClient, { generation: 1, vote: 1 }), false);
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(backend.receiveRematchVote(
    serverClient,
    Object.assign(Object.create(null), { generation: 1, vote: true }),
  ), true);
  assert.equal(backend.rematchVotes.has(first.sessionId), true);
});

test("resync amplification is capped and over-rate control attempts terminate without reservation", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  first.onMessage("snapshot", () => {});
  first.onMessage("lifecycle", () => {});
  first.onMessage("control-rejected", () => {});
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  assert.ok(serverClient);
  backend.controlRateWindows.clear();
  backend.monotonicNow = () => 1_000;

  let snapshots = 0;
  const send = serverClient.send.bind(serverClient);
  serverClient.send = (type, payload, options) => {
    if (type === "snapshot") snapshots += 1;
    return send(type, payload, options);
  };
  for (let attempt = 0; attempt < PASS12B3B2_CONTROL_MESSAGE_LIMITS.resync; attempt += 1) {
    assert.equal(backend.receiveResync(serverClient, { generation: 1 }), true);
  }
  assert.equal(snapshots, PASS12B3B2_CONTROL_MESSAGE_LIMITS.resync);

  const left = new Promise((resolve) => first.onLeave((code, reason) => resolve({ code, reason })));
  assert.equal(backend.receiveResync(serverClient, { generation: 1 }), false);
  assert.deepEqual(await left, {
    code: CloseCode.WITH_ERROR,
    reason: "connection message limit exceeded",
  });
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);
  assert.equal(backend.readySessions.has(first.sessionId), false);
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(backend.controlRateWindows.has(first.sessionId), false);
});

test("mixed control attempts share one aggregate window before payload validation", { timeout: 5000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(client.roomId);
  const serverClient = [...backend.clients].find((candidate) => candidate.sessionId === client.sessionId);
  backend.controlRateWindows.clear();
  backend.monotonicNow = () => 1_500;
  const types = ["protocol-request", "hello-ack", "ready", "resync"];
  let accepted = 0;
  for (const type of types) {
    for (let attempt = 0; attempt < 4; attempt += 1) {
      assert.equal(backend.consumeApplicationMessage(serverClient, type), true);
      accepted += 1;
    }
  }
  assert.equal(accepted, PASS12B3B2_MAX_CONTROL_MESSAGES);
  const left = new Promise((resolve) => client.onLeave(resolve));
  assert.equal(backend.consumeApplicationMessage(serverClient, "rematch-vote"), false);
  await left;
  assert.equal(backend.match.actorBySession.has(client.sessionId), false);
  assert.equal(backend.reservations.has(client.sessionId), false);
});

test("malformed input attempts consume their own cap without refreshing authority", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  backend.controlRateWindows.clear();
  backend.monotonicNow = () => 2_500;
  const before = backend.match.snapshot(first.sessionId);
  let rejections = 0;
  const send = serverClient.send.bind(serverClient);
  serverClient.send = (type, payload, options) => {
    if (type === "input-rejected") {
      rejections += 1;
      return;
    }
    return send(type, payload, options);
  };
  for (let attempt = 0; attempt < PASS12B3B2_MAX_INPUT_ATTEMPTS; attempt += 1) {
    assert.equal(backend.receiveInput(serverClient, { outcome: "forged" }), false);
  }
  assert.equal(rejections, PASS12B3B2_MAX_INPUT_ATTEMPTS);
  assert.equal(backend.match.snapshot(first.sessionId).ackSequence, before.ackSequence);
  const left = new Promise((resolve) => first.onLeave(resolve));
  assert.equal(backend.receiveInput(serverClient, { outcome: "forged" }), false);
  await left;
  assert.equal(rejections, PASS12B3B2_MAX_INPUT_ATTEMPTS);
  assert.equal(backend.reservations.has(first.sessionId), false);
});

test("snapshot backpressure terminally removes only the slow client before another send", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const firstServerClient = [...backend.clients]
    .find((client) => client.sessionId === first.sessionId);
  const secondServerClient = [...backend.clients]
    .find((client) => client.sessionId === second.sessionId);
  const originalBufferedAmount = backend.clientBufferedAmount.bind(backend);
  backend.clientBufferedAmount = (client) => client === firstServerClient
    ? PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES : originalBufferedAmount(client);
  const left = new Promise((resolve) => first.onLeave((code, reason) => resolve({ code, reason })));
  assert.equal(backend.sendSnapshot(firstServerClient), false);
  assert.deepEqual(await left, {
    code: CloseCode.WITH_ERROR,
    reason: "connection output limit exceeded",
  });
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(backend.readySessions.has(first.sessionId), false);
  assert.equal(backend.match.actorBySession.has(second.sessionId), true);
  assert.equal(backend.sendSnapshot(secondServerClient), true);
});

test("waiting-phase rejection sends cannot bypass the outbound backlog ceiling", { timeout: 10000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  client.reconnection.minUptime = 0;
  client.reconnection.maxEnqueuedMessages = 0;
  await bootstrap(client);
  const backend = colyseus.getRoomById(client.roomId);
  const serverClient = [...backend.clients]
    .find((candidate) => candidate.sessionId === client.sessionId);
  const originalBufferedAmount = backend.clientBufferedAmount.bind(backend);
  backend.clientBufferedAmount = (candidate) => candidate === serverClient
    ? PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES : originalBufferedAmount(candidate);
  const left = new Promise((resolve) => client.onLeave((code, reason) => resolve({ code, reason })));

  assert.equal(backend.receiveInput(serverClient, { outcome: "forged" }), false);
  assert.deepEqual(await left, {
    code: CloseCode.WITH_ERROR,
    reason: "connection output limit exceeded",
  });
  assert.equal(backend.match.actorBySession.has(client.sessionId), false);
  assert.equal(backend.reservations.has(client.sessionId), false);
});

test("aggregate inbound frame and byte budgets accept the exact ceiling and close once at plus one", { timeout: 10000 }, async () => {
  const messageClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const messageBackend = colyseus.getRoomById(messageClient.roomId);
  const messageServerClient = [...messageBackend.clients]
    .find((client) => client.sessionId === messageClient.sessionId);
  messageBackend.monotonicNow = () => 2_000;
  for (let count = 0; count < PASS12B3B2_MAX_INBOUND_MESSAGES; count += 1) {
    assert.equal(messageBackend.consumeInboundFrame(messageServerClient, new Uint8Array([1])), true);
  }
  const messageLeft = new Promise((resolve) => messageClient.onLeave(resolve));
  assert.equal(messageBackend.consumeInboundFrame(messageServerClient, new Uint8Array([1])), false);
  await messageLeft;
  assert.equal(messageBackend.reservations.has(messageClient.sessionId), false);

  const byteClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const byteBackend = colyseus.getRoomById(byteClient.roomId);
  const byteServerClient = [...byteBackend.clients]
    .find((client) => client.sessionId === byteClient.sessionId);
  byteBackend.monotonicNow = () => 3_000;
  for (let bytes = 0; bytes < PASS12B3B2_MAX_INBOUND_BYTES; bytes += 4096) {
    assert.equal(byteBackend.consumeInboundFrame(byteServerClient, new Uint8Array(4096)), true);
  }
  const byteLeft = new Promise((resolve) => byteClient.onLeave(resolve));
  assert.equal(byteBackend.consumeInboundFrame(byteServerClient, new Uint8Array([1])), false);
  await byteLeft;
  assert.equal(byteBackend.reservations.has(byteClient.sessionId), false);
});

test("the configured local WebSocket edge and CORS policy require exact loopback authorities", async () => {
  assert.match(await rawUpgradeStatus(), /^HTTP\/1\.1 101 /);
  assert.match(
    await rawUpgradeStatus({ origin: "http://127.0.0.1:{port}" }),
    /^HTTP\/1\.1 101 /,
  );
  assert.match(
    await rawUpgradeStatus({
      host: "localhost",
      origin: "http://localhost:{port}",
    }),
    /^HTTP\/1\.1 101 /,
  );
  assert.match(
    await rawUpgradeStatus({ origin: "https://attacker.invalid" }),
    /^HTTP\/1\.1 403 /,
  );
  assert.match(
    await rawUpgradeStatus({ origin: "http://localhost:{port}" }),
    /^HTTP\/1\.1 403 /,
  );
  assert.match(await rawUpgradeStatus({ host: null }), /^HTTP\/1\.1 400 /);
  assert.match(await rawUpgradeStatus({ host: "2130706433" }), /^HTTP\/1\.1 400 /);

  const port = colyseus.server.port;
  const allowedOrigin = `http://127.0.0.1:${port}`;
  assert.equal(pass12B1Boundary.getCorsHeaders(new Headers({
    host: `127.0.0.1:${port}`,
    origin: allowedOrigin,
  }))["Access-Control-Allow-Origin"], allowedOrigin);
  assert.equal(pass12B1Boundary.getCorsHeaders(new Headers({
    host: `127.0.0.1:${port}`,
    origin: "https://attacker.invalid",
  }))["Access-Control-Allow-Origin"], "");
  assert.equal(pass12B1Boundary.getCorsHeaders(new Headers({
    host: `attacker.invalid:${port}`,
    origin: allowedOrigin,
  }))["Access-Control-Allow-Origin"], "");
});

test("starting readiness blocks HTTP and WebSocket admission without mutating the shared service", async () => {
  assert.equal(application.serviceState.isReady(), true);
  const startingState = createServiceState();
  const isolatedTracker = createSecurityRejectionTracker();
  const isolatedBoundary = createProtocolBoundary({
    serviceState: startingState,
    rejectionTracker: isolatedTracker,
  });
  const localOrigin = "http://127.0.0.1:2567";
  const body = JSON.stringify(admissionOptions());
  const admission = await isolatedBoundary.onRequest(new Request(
    `${localOrigin}/matchmake/joinOrCreate/arena`,
    {
      method: "POST",
      headers: {
        "content-length": String(Buffer.byteLength(body)),
        "content-type": "application/json",
        host: "127.0.0.1:2567",
      },
      body,
    },
  ));
  assert.equal(admission.status, 503);
  assert.deepEqual(await admission.json(), { error: "service unavailable" });

  const upgrade = isolatedBoundary.beforeUpgrade(new Request(
    `${localOrigin}/process-1/room-1?sessionId=session-1`,
    { headers: { host: "127.0.0.1:2567" } },
  ));
  assert.equal(upgrade.status, 503);
  assert.equal((await isolatedBoundary.onRequest(new Request(`${localOrigin}/livez`))).status, 200);
  assert.equal((await isolatedBoundary.onRequest(new Request(`${localOrigin}/readyz`))).status, 503);
  assert.equal(isolatedTracker.snapshot().counts.matchmaking, 2);
  assert.equal(application.serviceState.isReady(), true);
});

test("the early raw edge redacts malformed Host, forwarding headers, and private query values", async () => {
  assert.equal(appConfig.transport.server.rawListeners("request")[0], guardRawLocalRequest);
  assert.equal(appConfig.transport.server.rawListeners("upgrade")[0], guardRawLocalRequest);
  const hostCanary = "HOST_HEADER_CANARY_12B1";
  const forwardedCanary = "FORWARDED_HEADER_CANARY_12B1";
  const queryCanary = "PRIVATE_QUERY_CANARY_12B1";
  const absoluteCanary = "ABSOLUTE_TARGET_CANARY_12B1";
  const { result: responses, output } = await captureConsole(async () => Promise.all([
    rawUpgradeStatus({
      path: `/process-1/room-1?sessionId=${queryCanary}`,
      host: `bad-${hostCanary}`,
      fullResponse: true,
    }),
    rawUpgradeStatus({
      path: `/process-1/room-1?sessionId=${queryCanary}`,
      extraHeaders: { Forwarded: `for=${forwardedCanary}` },
      fullResponse: true,
    }),
    rawUpgradeStatus({
      path: `http://attacker.invalid/process-1/room-1?reconnectionToken=${absoluteCanary}`,
      fullResponse: true,
    }),
    rawUpgradeStatus({
      path: `http://127.0.0.1:{port}/process-1/room-1?reconnectionToken=${absoluteCanary}`,
      fullResponse: true,
    }),
    rawUpgradeStatus({
      path: `/process-1/room-1?sessionId=${queryCanary}`,
      extraHeaders: [["Host", "127.0.0.1:{port}"]],
      fullResponse: true,
    }),
    rawUpgradeStatus({
      path: `/process-1/room-1?sessionId=${queryCanary}`,
      extraHeaders: [["hOsT", "127.0.0.1:{port}"]],
      fullResponse: true,
    }),
    rawHttpStatus({
      path: `/matchmake/joinOrCreate/arena?private=${queryCanary}`,
      host: `bad-${hostCanary}`,
      fullResponse: true,
    }),
    rawHttpStatus({
      path: `/matchmake/joinOrCreate/arena?private=${queryCanary}`,
      extraHeaders: { "X-Forwarded-Proto": forwardedCanary },
      fullResponse: true,
    }),
    rawHttpStatus({
      path: `/matchmake/joinOrCreate/arena?private=${queryCanary}`,
      host: `bad-${hostCanary}`,
      method: "OPTIONS",
      fullResponse: true,
    }),
  ]));
  for (const response of responses) {
    assert.match(response, /^HTTP\/1\.1 400 /);
    assert.match(response, /\r\nconnection: close\r\n/i);
  }
  assert.match(responses.at(-1), /\r\ncontent-type: application\/json; charset=utf-8\r\n/i);
  assert.match(responses.at(-1), /\r\n\r\n\{"error":"bad request"\}$/);
  const observableOutput = `${responses.join("\n")}\n${output}`;
  for (const canary of [hostCanary, forwardedCanary, queryCanary, absoluteCanary]) {
    assert.equal(
      observableOutput.includes(canary),
      false,
      `rejected metadata escaped into the fixed wire response or default console: ${canary}`,
    );
  }
});

test("unknown data, byte, request, and oversized frames fail closed without residue", { timeout: 15000 }, async () => {
  assert.notEqual(appConfig.options.devMode, true, "the regression exercises production dispatch semantics");
  const stringCanary = `STRING_TYPE_CANARY_${"x".repeat(90)}`;
  const bytesCanary = `BYTE_TYPE_CANARY_${"y".repeat(92)}`;
  const requestCanary = `REQUEST_TYPE_CANARY_12B1\n${"z".repeat(80)}`;
  const { output } = await captureConsole(async () => {
    for (const { label, transmit } of [
      { label: "unknown string data", transmit: (client) => client.send(stringCanary, {}) },
      { label: "unknown numeric data", transmit: (client) => client.send(700001, {}) },
      {
        label: "unknown string bytes",
        transmit: (client) => client.sendBytes(bytesCanary, new Uint8Array([1, 2, 3])),
      },
      {
        label: "unknown numeric bytes",
        transmit: (client) => client.sendBytes(700002, new Uint8Array([4, 5, 6])),
      },
    ]) {
      const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
      const backend = colyseus.getRoomById(client.roomId);
      const sessionId = client.sessionId;
      const left = new Promise((resolve) => {
        client.onLeave((code, reason) => resolve({ code, reason }));
      });
      transmit(client);
      assert.deepEqual(await left, {
        code: CloseCode.WITH_ERROR,
        reason: PASS12B1_UNSUPPORTED_MESSAGE_REASON,
      }, label);
      await assertNegotiationCleared(backend, sessionId, `${label} left negotiation residue`);
    }

    const requestClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const requestBackend = colyseus.getRoomById(requestClient.roomId);
    const requestSessionId = requestClient.sessionId;
    const requestLeave = new Promise((resolve) => {
      requestClient.onLeave((code, reason) => resolve({ code, reason }));
    });
    const requestRejected = assert.rejects(
      requestClient.request(requestCanary, {}, { timeout: 1000 }),
      (error) => {
        assert.equal(String(error && error.message), "connection closed before a response was received.");
        return true;
      },
    );
    assert.deepEqual(await requestLeave, {
      code: CloseCode.WITH_ERROR,
      reason: PASS12B1_UNSUPPORTED_MESSAGE_REASON,
    });
    await requestRejected;
    await assertNegotiationCleared(
      requestBackend,
      requestSessionId,
      "unknown request frame left negotiation residue",
    );

    const burstClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const burstBackend = colyseus.getRoomById(burstClient.roomId);
    const burstSessionId = burstClient.sessionId;
    let requestRejections = 0;
    const rejectUnsupportedMessage = burstBackend.rejectUnsupportedMessage.bind(burstBackend);
    burstBackend.rejectUnsupportedMessage = (client) => {
      requestRejections += 1;
      return rejectUnsupportedMessage(client);
    };
    const burstLeave = new Promise((resolve) => {
      burstClient.onLeave((code, reason) => resolve({ code, reason }));
    });
    const requestFailures = [];
    for (let index = 0; index < 500; index += 1) {
      requestFailures.push(
        burstClient.request(710000 + index, {}, { timeout: 2000 }).catch((error) => error),
      );
    }
    assert.deepEqual(await burstLeave, {
      code: CloseCode.WITH_ERROR,
      reason: PASS12B1_UNSUPPORTED_MESSAGE_REASON,
    });
    await Promise.all(requestFailures);
    assert.equal(requestRejections, 1, "queued request frames were dispatched after fixed close");
    await assertNegotiationCleared(
      burstBackend,
      burstSessionId,
      "request burst left negotiation residue",
    );

    for (const [label, opcode] of [
      ["unused reliable input opcode", Protocol.ROOM_INPUT_RELIABLE],
      ["server-only state opcode", Protocol.ROOM_STATE],
      ["modified ping opcode", Protocol.PING | 0x20],
    ]) {
      const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
      const backend = colyseus.getRoomById(client.roomId);
      const left = new Promise((resolve) => {
        client.onLeave((code, reason) => resolve({ code, reason }));
      });
      client.connection.send(new Uint8Array([opcode]));
      assert.deepEqual(await left, {
        code: CloseCode.WITH_ERROR,
        reason: PASS12B1_UNSUPPORTED_MESSAGE_REASON,
      }, label);
      await assertNegotiationCleared(backend, client.sessionId, `${label} left residue`);
    }

    const oversizedClient = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const oversizedBackend = colyseus.getRoomById(oversizedClient.roomId);
    const oversizedSessionId = oversizedClient.sessionId;
    const oversizedLeave = new Promise((resolve) => {
      oversizedClient.onLeave((code, reason) => resolve({ code, reason }));
    });
    oversizedClient.connection.send(new Uint8Array(4097));
    assert.equal((await oversizedLeave).code, 1009, "WebSocket transport did not enforce maxPayload");
    await assertNegotiationCleared(
      oversizedBackend,
      oversizedSessionId,
      "oversized frame left negotiation residue",
    );

    const survivor = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    assert.ok(colyseus.getRoomById(survivor.roomId), "the server still admits a valid client");
    await survivor.leave(true);
  });
  assert.equal(output.includes(stringCanary), false);
  assert.equal(output.includes(bytesCanary), false);
  assert.equal(output.includes(requestCanary), false);
});

test("malformed decoded payloads close once without exposing payload text to logs", { timeout: 10000 }, async () => {
  const canary = "PAYLOAD_CANARY_12B4A";
  const encodedGameplayFrame = getMessageBytes.raw(Protocol.ROOM_DATA, "input", {
    generation: 1,
    sequence: 1,
    clientTick: 0,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: buttons(),
    diagnostic: canary,
  });
  const malformedFrames = [
    Buffer.concat([encodedGameplayFrame, Buffer.from([0])]),
    getMessageBytes.raw(
      Protocol.ROOM_DATA,
      "input",
      undefined,
      Buffer.from([0xbf, 0x61, 0x62, 0x63]),
    ),
  ];

  const { output } = await captureConsole(async () => {
    for (const frame of malformedFrames) {
      const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
      const backend = colyseus.getRoomById(client.roomId);
      const left = new Promise((resolve) => client.onLeave((code, reason) => resolve({ code, reason })));
      client.connection.send(frame);
      assert.deepEqual(await left, { code: CloseCode.WITH_ERROR, reason: "" });
      await assertNegotiationCleared(
        backend,
        client.sessionId,
        "malformed decoded payload left negotiation residue",
      );
    }
  });
  assert.equal(output.includes(canary), false);
  assert.equal(output.includes("moveX"), false);
  assert.equal(output, "");
  const aggregate = rejectionTracker.flush();
  assert.equal(aggregate.total, malformedFrames.length);
  assert.equal(aggregate.counts.protocol, malformedFrames.length);
  assert.equal(rejectionTracker.snapshot().total, 0);
  const joinedLines = operationsLines.join("");
  assert.equal(joinedLines.includes(canary), false);
  assert.equal(joinedLines.includes("moveX"), false);
  assert.deepEqual(
    operationsLines.map(JSON.parse)
      .filter((record) => record.event.startsWith("framework."))
      .map(({ level, event, reason }) => ({ level, event, reason })),
    [{ level: "error", event: "framework.error", reason: "framework-error" }],
  );
  assert.deepEqual(
    operationsLines.map(JSON.parse)
      .filter((record) => record.event === "security.rejections")
      .map(({ level, event, reason, category, count }) => ({
        level, event, reason, category, count,
      })),
    [{
      level: "warn",
      event: "security.rejections",
      reason: "manual-flush",
      category: "protocol",
      count: malformedFrames.length,
    }],
  );
});

test("SDK messages carry commands only and malformed fields are rejected without authority mutation", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment], [secondAssignment]] = await Promise.all([
    bootstrap(first),
    bootstrap(second),
  ]);
  assert.notEqual(firstAssignment.actorId, secondAssignment.actorId);
  await backend.waitForNextSimulationTick();

  const tick = backend.match.state.tick;
  const validReceived = backend.waitForMessage("input");
  const periodicSnapshot = waitForSnapshotAck(first, 0);
  first.send("input", command(0, tick, { moveX: 1 }));
  await validReceived;
  const delivered = await periodicSnapshot;
  assert.equal(delivered.tick % 3, 0);
  assert.equal(delivered.ackSequence, 0);
  assert.equal(delivered.actorId, firstAssignment.actorId);
  assert.equal(delivered.epoch, 1);
  assert.equal(delivered.state.tick, delivered.tick);
  assert.equal(delivered.stateHash, stateHash(delivered.state));
  assert.ok(Array.isArray(delivered.events));
  await backend.waitForNextSimulationTick();
  assert.equal(backend.match.replayLedger().at(-1).actors[firstAssignment.actorId].moveX, 1);

  const before = backend.match.snapshot(first.sessionId);
  const rejected = first.waitForMessage("input-rejected");
  first.send("input", { ...command(1, backend.match.state.tick), position: { x: 999, y: 999 } });
  assert.deepEqual(await rejected, { generation: 1, reason: "invalid-payload" });
  const after = backend.match.snapshot(first.sessionId);
  assert.equal(after.ackSequence, before.ackSequence);
  await backend.waitForNextSimulationTick();
  assert.equal(backend.match.replayLedger().at(-1).actors[firstAssignment.actorId].moveX, 1);
});

test("an abnormal SDK drop reconnects to the same actor with neutralized input", { timeout: 15000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[assignment]] = await Promise.all([bootstrap(first), bootstrap(second)]);
  await backend.waitForNextSimulationTick();

  const heldReceived = backend.waitForNextMessage();
  first.send("input", command(5, backend.match.state.tick, {
    moveX: 1,
    buttons: { attack: true, jump: true },
  }));
  await heldReceived;

  const reconnected = new Promise((resolve) => first.onReconnect(resolve));
  first.leave(false);
  await reconnected;
  assert.equal(
    backend.match.actorBySession.has(first.sessionId),
    false,
    "transport reconnection alone cannot rebind an authoritative actor"
  );
  let prematureSnapshots = 0;
  first.onMessage("snapshot", () => { prematureSnapshots += 1; });
  for (let index = 0; index < 4; index += 1) await backend.waitForNextSimulationTick();
  assert.equal(prematureSnapshots, 0, "negotiating reconnect received authoritative snapshots");
  assert.deepEqual(Object.keys(first.state.toJSON()), [
    "generation", "simVersion", "modeId", "mapId", "lifecycle", "started",
    "connectedPlayers", "rematchOpen", "rematchVotes", "rematchRequired",
  ], "the global Schema projection exposed gameplay state during negotiation");
  const [nextAssignment] = await bootstrap(first);
  assert.equal(nextAssignment.actorId, assignment.actorId);
  assert.ok(nextAssignment.epoch > assignment.epoch);

  await backend.waitForNextSimulationTick();
  const actor = backend.match.replayLedger().at(-1).actors[assignment.actorId];
  assert.equal(actor.moveX, 0);
  assert.ok(Object.values(actor.buttons).every((pressed) => pressed === false));
});

test("reconnect storms preserve one absolute deadline and terminal closes reserve nothing", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const [[assignment]] = await Promise.all([bootstrap(first)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  assert.ok(serverClient);

  let now = 1_000;
  const windows = [];
  backend.monotonicNow = () => now;
  backend.allowReconnection = (_client, seconds) => {
    windows.push(seconds);
    return Promise.resolve();
  };

  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  const reservation = backend.reservations.get(first.sessionId);
  assert.equal(reservation.actorId, assignment.actorId);
  assert.equal(reservation.generation, 1);
  assert.equal(PASS12B3B1_RECONNECT_SECONDS, 30);
  assert.equal(backend.reconnectWindowSeconds(), 30);
  assert.equal(reservation.expiresAt, 31_000);
  assert.equal(windows.length, 1);
  assert.equal(windows[0], 30);

  now = 3_500;
  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  assert.equal(backend.reservations.get(first.sessionId), reservation);
  assert.equal(backend.reservations.get(first.sessionId).expiresAt, 31_000);
  assert.equal(windows.length, 2);
  assert.equal(windows[1], 27.5);

  now = 31_000;
  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(windows.length, 2, "expiry re-armed a reconnect window");
  assert.throws(() => backend.onReconnect(serverClient), /expired/);

  assert.deepEqual(backend.match.bind(
    first.sessionId,
    reservation.actorId,
    reservation.epoch,
  ), {
    accepted: true,
    actorId: reservation.actorId,
    epoch: reservation.epoch,
  });
  backend.terminalSessions.add(first.sessionId);
  now = 10_000;
  backend.onDrop(serverClient, CloseCode.WITH_ERROR);
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(windows.length, 2, "terminal close created a reconnect reservation");
});

test("only the exact transient transport close codes create reconnect reservations", { timeout: 15000 }, async () => {
  const cases = [
    [CloseCode.GOING_AWAY, true],
    [CloseCode.NO_STATUS_RECEIVED, true],
    [CloseCode.ABNORMAL_CLOSURE, true],
    [CloseCode.MAY_TRY_RECONNECT, true],
    [CloseCode.NORMAL_CLOSURE, false],
    [CloseCode.CONSENTED, false],
    [CloseCode.SERVER_SHUTDOWN, false],
    [CloseCode.WITH_ERROR, false],
    [CloseCode.FAILED_TO_RECONNECT, false],
    [4999, false],
  ];

  for (const [code, expectedReservation] of cases) {
    const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
    const backend = colyseus.getRoomById(client.roomId);
    await bootstrap(client);
    const serverClient = [...backend.clients]
      .find((candidate) => candidate.sessionId === client.sessionId);
    let windows = 0;
    backend.allowReconnection = () => {
      windows += 1;
      return Promise.resolve();
    };
    backend.onDrop(serverClient, code);
    assert.equal(backend.reservations.has(client.sessionId), expectedReservation, String(code));
    assert.equal(windows, expectedReservation ? 1 : 0, String(code));
    await client.leave(true);
    await waitForCondition(
      () => !roomRegistry.snapshot().roomIds.includes(client.roomId),
      `close-code test Room ${code} was not disposed`,
      2000,
    );
  }
});

test("the reservation map is the sole reconnect authority at the absolute deadline", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const [[assignment]] = await Promise.all([bootstrap(first)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  assert.ok(serverClient);

  let now = 1_000;
  backend.monotonicNow = () => now;
  backend.allowReconnection = () => Promise.resolve();
  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  const reservation = backend.reservations.get(first.sessionId);
  assert.equal(reservation.actorId, assignment.actorId);
  assert.equal(reservation.expiresAt, 31_000);

  let negotiations = 0;
  backend.beginNegotiation = () => { negotiations += 1; };
  now = reservation.expiresAt - 1;
  backend.onReconnect(serverClient);
  assert.equal(negotiations, 1, "the final millisecond of the reservation was not usable");

  backend.reservations.delete(first.sessionId);
  serverClient.userData = reservation;
  assert.throws(
    () => backend.onReconnect(serverClient),
    /expired/,
    "preserved SDK userData resurrected a revoked reservation",
  );
  assert.equal(negotiations, 1);

  backend.reservations.set(first.sessionId, {
    ...reservation,
    generation: backend.match.generation + 1,
  });
  assert.throws(() => backend.onReconnect(serverClient), /expired/);
  assert.equal(negotiations, 1, "a wrong-generation reservation entered negotiation");

  backend.reservations.set(first.sessionId, reservation);
  now = reservation.expiresAt;
  assert.throws(() => backend.onReconnect(serverClient), /expired/);
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(negotiations, 1, "the exact deadline remained inclusive");
});

test("closing synchronously clears reservations and cannot rebind a reconnecting actor", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  backend.allowReconnection = () => Promise.resolve();
  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  assert.equal(backend.reservations.has(first.sessionId), true);
  let disconnects = 0;
  const disconnect = backend.disconnect.bind(backend);
  backend.disconnect = async () => { disconnects += 1; };
  assert.equal(backend.closeRoom(CloseCode.CONSENTED), true);
  assert.equal(disconnects, 1);
  assert.equal(backend.lifecycle, "closing");
  assert.equal(backend.reservations.size, 0);
  assert.equal(backend.match.actorBySession.size, 0);
  assert.equal(backend.admittedSessions.size, 0);
  assert.equal(backend.readySessions.size, 0);
  assert.equal(backend.controlRateWindows.size, 0);
  assert.throws(() => backend.onReconnect(serverClient), /expired/);
  assert.equal(backend.match.actorBySession.size, 0);
  backend.disconnect = disconnect;
});

test("the process shutdown hook neutralizes active play before its first await", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment]] = await Promise.all([bootstrap(first), bootstrap(second)]);
  await backend.waitForNextSimulationTick();
  const received = backend.waitForNextMessage();
  first.send("input", command(4, backend.match.state.tick, {
    moveX: 1,
    buttons: { attack: true, jump: true },
  }));
  await received;
  const tick = backend.match.state.tick;
  const shutdownLifecycle = [];
  first.onMessage("lifecycle", (message) => shutdownLifecycle.push(message.phase));
  second.onMessage("lifecycle", (message) => shutdownLifecycle.push(message.phase));
  const firstLeft = new Promise((resolve) => first.onLeave((code) => resolve(code)));
  const secondLeft = new Promise((resolve) => second.onLeave((code) => resolve(code)));

  assert.equal(backend.onBeforeShutdown(), true);
  assert.equal(backend.onBeforeShutdown(), false, "repeat hook began a second disconnect");
  assert.equal(backend.lifecycle, "closing");
  assert.equal(backend.locked, true);
  assert.equal(backend.match.actorBySession.size, 0);
  assert.equal(backend.match.sessionByActor.size, 0);
  assert.equal(backend.admittedSessions.size, 0);
  assert.equal(backend.readySessions.size, 0);
  assert.equal(backend.reservations.size, 0);
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(backend.handshakeTimers.size, 0);
  assert.equal(backend.initialWaitingTimer, null);
  assert.equal(backend.resultsTimer, null);
  assert.equal(backend.generationReadyTimer, null);
  assert.equal(backend.match.inputs.stats().sessions, 0);
  backend.fixedStep({ dt: 1 / 60 });
  assert.equal(backend.match.state.tick, tick, "closing advanced authoritative gameplay");
  assert.equal(Number.isInteger(firstAssignment.actorId), true);

  assert.deepEqual(await Promise.all([firstLeft, secondLeft]), [
    CloseCode.SERVER_SHUTDOWN,
    CloseCode.SERVER_SHUTDOWN,
  ]);
  assert.equal(shutdownLifecycle.includes("closing"), false,
    "shutdown exposed transient generic closing copy before the fixed 4001 path");
  await waitForCondition(
    () => backend.lifecycle === "disposed"
      && !roomRegistry.snapshot().roomIds.includes(first.roomId),
    "process shutdown did not dispose the active Room",
    2000,
  );
});

test("process shutdown revokes an unconnected initial seat without waiting ten seconds", { timeout: 5000 }, async () => {
  const creator = await colyseus.sdk.create("arena", createMatchOptions());
  const backend = colyseus.getRoomById(creator.roomId);
  const pending = await colyseus.sdk.http.post(`/matchmake/joinById/${creator.roomId}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: joinCodeOptions(),
  });
  assert.equal(typeof pending.data.sessionId, "string");
  assert.equal(Object.keys(backend._reservedSeats).includes(pending.data.sessionId), true);
  let attemptRejected = false;
  let rejectionHandled = false;
  backend._reconnectionAttempts.PRIVATE_RECONNECT_CANARY = {
    catch(handler) {
      this.handler = handler;
      return this;
    },
    reject(error) {
      attemptRejected = error instanceof Error;
      this.handler?.(error);
      rejectionHandled = true;
    },
  };
  const left = new Promise((resolve) => creator.onLeave((code) => resolve(code)));

  assert.equal(backend.onBeforeShutdown(), true);
  assert.equal(Object.keys(backend._reservedSeats).length, 0);
  assert.equal(Object.keys(backend._reservedSeatTimeouts).length, 0);
  assert.equal(Object.keys(backend._reconnectionAttempts).length, 0);
  assert.equal(attemptRejected, true);
  assert.equal(rejectionHandled, true);
  assert.equal(backend.negotiatingSessions.size, 0);
  assert.equal(backend.handshakeTimers.size, 0);
  assert.equal(await left, CloseCode.SERVER_SHUTDOWN);
  await waitForCondition(
    () => backend.lifecycle === "disposed"
      && !roomRegistry.snapshot().roomIds.includes(creator.roomId),
    "shutdown retained the unconnected seat",
    1000,
  );
});

test("process shutdown closes results consent and every generation timer", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  await finishCurrentGeneration(backend, [first, second]);
  const vote = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: true });
  await vote;
  assert.equal(backend.rematchVotes.size, 1);
  const firstLeft = new Promise((resolve) => first.onLeave((code) => resolve(code)));
  const secondLeft = new Promise((resolve) => second.onLeave((code) => resolve(code)));

  assert.equal(backend.onBeforeShutdown(), true);
  assert.equal(backend.lifecycle, "closing");
  assert.equal(backend.rematchOpen, false);
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(backend.resultsDeadlineAt, null);
  assert.equal(backend.resultsTimer, null);
  assert.equal(backend.generationReadyDeadlineAt, null);
  assert.equal(backend.generationReadyTimer, null);
  assert.deepEqual(await Promise.all([firstLeft, secondLeft]), [
    CloseCode.SERVER_SHUTDOWN,
    CloseCode.SERVER_SHUTDOWN,
  ]);
});

test("late reconnect negotiation is bounded by the remaining absolute window", { timeout: 5000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  await bootstrap(first);
  const serverClient = [...backend.clients].find((client) => client.sessionId === first.sessionId);
  assert.ok(serverClient);

  let now = 1_000;
  backend.monotonicNow = () => now;
  backend.allowReconnection = () => Promise.resolve();
  backend.onDrop(serverClient, CloseCode.ABNORMAL_CLOSURE);
  const reservation = backend.reservations.get(first.sessionId);
  assert.equal(reservation.expiresAt, 31_000);

  const setTimeout = backend.clock.setTimeout.bind(backend.clock);
  let handshakeDelayMs = null;
  backend.clock.setTimeout = (callback, delayMs) => {
    handshakeDelayMs = delayMs;
    return setTimeout(callback, delayMs);
  };
  now = reservation.expiresAt - 500;
  backend.onReconnect(serverClient);
  assert.equal(handshakeDelayMs, 500);
  assert.equal(backend.negotiatingSessions.has(first.sessionId), true);

  first.onMessage("protocol-error", () => {});
  const left = new Promise((resolve) => {
    first.onLeave((code, reason) => resolve({ code, reason }));
  });
  backend.handshakeTimers.get(first.sessionId).execute();
  assert.deepEqual(await left, {
    code: CloseCode.WITH_ERROR,
    reason: "protocol negotiation timed out",
  });
  assert.equal(backend.reservations.has(first.sessionId), false);
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);
});

test("a pending initial seat prevents premature pre-start disposal", { timeout: 5000 }, async () => {
  const creator = await colyseus.sdk.create("arena", createMatchOptions());
  const backend = colyseus.getRoomById(creator.roomId);
  backend.seatReservationTimeout = 0.75;
  const pending = await colyseus.sdk.http.post(`/matchmake/joinById/${creator.roomId}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: joinCodeOptions(),
  });
  assert.equal(typeof pending.data.sessionId, "string");

  await creator.leave(true);
  assert.equal(
    roomRegistry.snapshot().roomIds.includes(creator.roomId),
    true,
    "the connected client departure discarded a still-valid initial seat",
  );
  await waitForCondition(
    () => !roomRegistry.snapshot().roomIds.includes(creator.roomId),
    "the Room survived its final initial-seat expiry",
    3000,
  );
  assert.equal(backend.lifecycle, "disposed");
});

test("the absolute initial waiting deadline closes one-human Rooms and stale timers cannot close play", { timeout: 10000 }, async () => {
  const waiting = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const waitingBackend = colyseus.getRoomById(waiting.roomId);
  await bootstrap(waiting);
  const waitingRoomId = waiting.roomId;
  const waitingTimer = waitingBackend.initialWaitingTimer;
  assert.ok(waitingTimer && typeof waitingTimer.execute === "function");
  assert.equal(
    waitingBackend.initialWaitingDeadlineAt - waitingBackend.monotonicNow()
      <= PASS12B3B2_INITIAL_WAITING_TIMEOUT_MS,
    true,
  );
  const left = new Promise((resolve) => waiting.onLeave(resolve));
  waitingTimer.execute();
  await left;
  await waitForCondition(
    () => !roomRegistry.snapshot().roomIds.includes(waitingRoomId),
    "initial waiting expiry did not release the Room registry slot",
  );
  assert.equal(waitingBackend.lifecycle, "disposed");
  assert.equal(waitingBackend.match.actorBySession.size, 0);
  assert.equal(waitingBackend.reservations.size, 0);
  assert.equal(waitingBackend.controlRateWindows.size, 0);

  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const playingBackend = colyseus.getRoomById(first.roomId);
  const staleTimer = playingBackend.initialWaitingTimer;
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  assert.equal(playingBackend.lifecycle, "playing");
  assert.equal(playingBackend.initialWaitingTimer, null);
  assert.equal(playingBackend.initialWaitingDeadlineAt, null);
  staleTimer.execute();
  assert.equal(playingBackend.lifecycle, "playing");
});

test("pre-start reconnect expiry disposes the abandoned Room and releases its registry slot", { timeout: 5000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  await bootstrap(first);
  const roomId = first.roomId;
  const sessionId = first.sessionId;
  backend.reconnectWindowSeconds = () => 0.5;
  first.reconnection.minUptime = 0;
  first.reconnection.maxRetries = 0;
  first.reconnection.maxEnqueuedMessages = 0;

  await first.leave(false);
  await waitForCondition(
    () => backend.reservations.has(sessionId),
    "the abnormal pre-start drop did not create a bounded reservation",
  );
  assert.equal(backend.match.actorBySession.has(sessionId), false);
  assert.equal(backend.lifecycle, "waiting");
  await waitForCondition(
    () => !roomRegistry.snapshot().roomIds.includes(roomId),
    "the abandoned pre-start Room was not disposed after reconnect expiry",
    3000,
  );
  assert.equal(backend.lifecycle, "disposed");
  assert.equal(backend.reservations.size, 0);
  assert.equal(backend.handshakeTimers.size, 0);
});

test("one connected human prevents disposal until the last playing reservation expires", { timeout: 7000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment], [secondAssignment]] = await Promise.all([
    bootstrap(first),
    bootstrap(second),
  ]);
  const roomId = first.roomId;
  backend.reconnectWindowSeconds = () => 0.5;
  for (const client of [first, second]) {
    client.reconnection.minUptime = 0;
    client.reconnection.maxRetries = 0;
    client.reconnection.maxEnqueuedMessages = 0;
  }

  await first.leave(false);
  await waitForCondition(
    () => backend.reservations.has(first.sessionId),
    "the first playing drop did not reserve its seat",
  );
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);
  assert.equal(backend.match.actorBySession.get(second.sessionId), secondAssignment.actorId);
  const neutralFrame = backend.match.inputs.frame(backend.match.state, backend.match.state.tick);
  const firstActor = neutralFrame.actors.find((actor) => actor.id === firstAssignment.actorId);
  assert.equal(firstActor.moveX, 0);
  assert.ok(Object.values(firstActor.buttons).every((pressed) => pressed === false));
  await waitForCondition(
    () => !backend.reservations.has(first.sessionId),
    "the first playing reservation did not expire",
  );
  assert.equal(roomRegistry.snapshot().roomIds.includes(roomId), true);
  assert.equal(backend.lifecycle, "playing");

  await second.leave(false);
  await waitForCondition(
    () => backend.reservations.has(second.sessionId),
    "the final playing drop did not reserve its seat",
  );
  await waitForCondition(
    () => !roomRegistry.snapshot().roomIds.includes(roomId),
    "the all-human abandoned playing Room was not disposed",
    3000,
  );
  assert.equal(backend.lifecycle, "disposed");
  assert.equal(backend.match.actorBySession.size, 0);
});

test("all-human results drops dispose after reservations and clear the result timer", { timeout: 7000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  await finishCurrentGeneration(backend, [first, second]);
  const roomId = first.roomId;
  const resultTimer = backend.resultsTimer;
  backend.reconnectWindowSeconds = () => 0.5;
  for (const client of [first, second]) {
    client.reconnection.minUptime = 0;
    client.reconnection.maxRetries = 0;
    client.reconnection.maxEnqueuedMessages = 0;
  }

  await Promise.all([first.leave(false), second.leave(false)]);
  await waitForCondition(
    () => backend.reservations.size === 2,
    "the result-screen drops did not reserve both seats",
  );
  assert.equal(backend.rematchVotes.size, 0);
  await waitForCondition(
    () => !roomRegistry.snapshot().roomIds.includes(roomId),
    "the all-human abandoned result Room was not disposed",
    3000,
  );
  assert.equal(backend.lifecycle, "disposed");
  assert.equal(backend.resultsTimer, null);
  resultTimer.execute();
  assert.equal(backend.lifecycle, "disposed", "a cleared result callback revived disposal state");
});

test("opaque reconnect tokens are room-scoped, rotate, and fail with fixed redaction", { timeout: 15000 }, async () => {
  const first = await colyseus.sdk.create("arena", createMatchOptions());
  const firstBackend = colyseus.getRoomById(first.roomId);
  const other = await colyseus.sdk.create("arena", createMatchOptions());
  const otherBackend = colyseus.getRoomById(other.roomId);
  await bootstrap(first);
  const originalToken = first.reconnectionToken;
  const opaqueToken = originalToken.slice(originalToken.indexOf(":") + 1);
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const reconnected = new Promise((resolve) => first.onReconnect(resolve));
  first.leave(false);
  await reconnected;
  await bootstrap(first);
  assert.notEqual(first.reconnectionToken, originalToken, "successful reconnect did not rotate its token");
  const firstActors = firstBackend.match.actorBySession.size;
  const otherActors = otherBackend.match.actorBySession.size;

  const { output } = await captureConsole(async () => {
    for (const staleToken of [`${other.roomId}:${opaqueToken}`, originalToken]) {
      await assert.rejects(
        colyseus.sdk.reconnect(staleToken),
        (error) => [522, 523, 524].includes(error?.code)
          && error.message === "Match unavailable or expired."
          && !error.message.includes(opaqueToken),
      );
    }
  });
  assert.equal(output.includes(opaqueToken), false, "a reconnect failure logged its opaque token");
  assert.equal(firstBackend.match.actorBySession.size, firstActors);
  assert.equal(otherBackend.match.actorBySession.size, otherActors);

  await Promise.allSettled([first.leave(true), other.leave(true)]);
});

test("terminal protocol rejection clears authority and prior rematch consent before transport close", { timeout: 15000 }, async (context) => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment]] = await Promise.all([bootstrap(first), bootstrap(second)]);
  const firstServerClient = [...backend.clients]
    .find((client) => client.sessionId === first.sessionId);
  const secondServerClient = [...backend.clients]
    .find((client) => client.sessionId === second.sessionId);
  assert.ok(firstServerClient);
  assert.ok(secondServerClient);
  first.onMessage("protocol-error", () => {});

  assert.equal(backend.receiveInput(firstServerClient, command(0, backend.match.state.tick, {
    moveX: 1,
    buttons: { attack: true },
  })), true);
  await finishCurrentGeneration(backend, [first, second]);
  assert.equal(backend.receiveRematchVote(firstServerClient, {
    generation: 1,
    vote: true,
  }), true);
  assert.equal(backend.rematchVotes.has(first.sessionId), true);

  const originalLeave = firstServerClient.leave;
  let delayedLeave = null;
  firstServerClient.leave = (code, reason) => { delayedLeave = { code, reason }; };
  context.after(() => { firstServerClient.leave = originalLeave; });
  backend.rejectProtocol(firstServerClient);

  assert.deepEqual(delayedLeave, {
    code: CloseCode.WITH_ERROR,
    reason: "protocol negotiation failed",
  });
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);
  assert.equal(backend.admittedSessions.has(first.sessionId), false);
  assert.equal(backend.readySessions.has(first.sessionId), false);
  assert.equal(backend.rematchVotes.has(first.sessionId), false);
  assert.equal(backend.reservations.has(first.sessionId), false);
  const neutralFrame = backend.match.inputs.frame(backend.match.state, backend.match.state.tick);
  const firstActor = neutralFrame.actors.find((actor) => actor.id === firstAssignment.actorId);
  assert.equal(firstActor.moveX, 0);
  assert.ok(Object.values(firstActor.buttons).every((pressed) => pressed === false));

  assert.equal(backend.receiveRematchVote(secondServerClient, {
    generation: 1,
    vote: true,
  }), true);
  assert.equal(backend.match.generation, 1, "a cleared vote counted toward unanimity");
  assert.equal(backend.rematchVotes.size, 1);

  firstServerClient.leave = originalLeave;
  originalLeave.call(firstServerClient, CloseCode.WITH_ERROR, "test cleanup");
});

test("framework disposal transitions through closing and remains idempotent", { timeout: 5000 }, async () => {
  const client = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(client.roomId);
  const transitions = [];
  const setLifecycle = backend.setLifecycle.bind(backend);
  backend.setLifecycle = (next, broadcast) => {
    transitions.push([backend.lifecycle, next, broadcast]);
    return setLifecycle(next, broadcast);
  };

  assert.equal(backend.lifecycle, "waiting");
  backend.onDispose();
  assert.deepEqual(transitions, [
    ["waiting", "closing", false],
    ["closing", "disposed", false],
  ]);
  assert.equal(backend.lifecycle, "disposed");
  assert.equal(backend.handshakeTimers.size, 0);
  assert.equal(backend.negotiatingSessions.size, 0);
  backend.onDispose();
  assert.equal(backend.lifecycle, "disposed");
  assert.equal(transitions.length, 2);
});

test("unanimous rematch voting advances exactly one generation through a fresh ready barrier", { timeout: 15000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment], [secondAssignment]] = await Promise.all([
    bootstrap(first),
    bootstrap(second),
  ]);
  assert.equal(firstAssignment.generation, 1);
  assert.equal(secondAssignment.generation, 1);
  const initialSeed = backend.match.state.seed;
  const finalSnapshots = await finishCurrentGeneration(backend, [first, second]);
  assert.ok(finalSnapshots.every((snapshot) => snapshot.generation === 1));
  const staleResultsTimer = backend.resultsTimer;
  const resultDeadline = backend.resultsDeadlineAt;

  let received = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: true });
  await received;
  assert.equal(backend.lifecycle, "rematch-vote");
  assert.equal(backend.rematchVotes.size, 1);
  assert.equal(backend.resultsDeadlineAt, resultDeadline, "a vote extended the result deadline");

  received = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: true });
  await received;
  assert.equal(backend.rematchVotes.size, 1, "duplicate vote was not idempotent");
  assert.equal(backend.resultsDeadlineAt, resultDeadline);

  received = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: false });
  await received;
  assert.equal(backend.lifecycle, "finished");
  assert.equal(backend.rematchVotes.size, 0);

  received = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: true });
  await received;
  const firstNextAssignment = first.waitForMessage("assignment");
  const secondNextAssignment = second.waitForMessage("assignment");
  received = backend.waitForNextMessage();
  second.send("rematch-vote", { generation: 1, vote: true });
  await received;
  const [nextFirst, nextSecond] = await Promise.all([firstNextAssignment, secondNextAssignment]);

  assert.equal(backend.match.generation, 2);
  assert.equal(nextFirst.generation, 2);
  assert.equal(nextSecond.generation, 2);
  assert.equal(nextFirst.actorId, firstAssignment.actorId);
  assert.equal(nextSecond.actorId, secondAssignment.actorId);
  assert.equal(nextFirst.epoch, firstAssignment.epoch);
  assert.equal(nextSecond.epoch, secondAssignment.epoch);
  assert.notEqual(backend.match.state.seed, initialSeed);
  assert.equal(backend.match.state.tick, 0);
  assert.deepEqual(backend.match.replayLedger(), []);
  assert.deepEqual(backend.match.drainEvents(), []);
  assert.equal(backend.readySessions.size, 0);
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(backend.resultsTimer, null);
  assert.ok(backend.generationReadyTimer);
  staleResultsTimer.execute();
  assert.equal(backend.lifecycle, "ready", "cleared old result timer closed the new generation");

  const staleInput = first.waitForMessage("input-rejected");
  first.send("input", command(99, 0, { generation: 1 }));
  assert.deepEqual(await staleInput, { generation: 2, reason: "stale-generation" });
  const futureReady = first.waitForMessage("control-rejected");
  first.send("ready", { generation: 3 });
  assert.deepEqual(await futureReady, {
    generation: 2,
    control: "ready",
    reason: "future-generation",
  });
  const staleVote = first.waitForMessage("control-rejected");
  first.send("rematch-vote", { generation: 1, vote: true });
  assert.deepEqual(await staleVote, {
    generation: 2,
    control: "rematch-vote",
    reason: "stale-generation",
  });
  assert.equal(backend.readySessions.size, 0);

  const generationReadyTimer = backend.generationReadyTimer;
  const firstBootstrap = first.waitForMessage("snapshot");
  const secondBootstrap = second.waitForMessage("snapshot");
  first.send("ready", { generation: 2 });
  second.send("ready", { generation: 2 });
  const [firstGenerationTwo, secondGenerationTwo] = await Promise.all([
    firstBootstrap,
    secondBootstrap,
  ]);
  assert.equal(firstGenerationTwo.tick, 0);
  assert.equal(secondGenerationTwo.tick, 0);
  await waitForCondition(() => backend.lifecycle === "playing", "generation two did not start");
  assert.equal(backend.generationReadyTimer, null);
  generationReadyTimer.execute();
  assert.equal(backend.lifecycle, "playing", "cleared readiness timer closed active play");

  received = backend.waitForNextMessage();
  first.send("input", command(0, 0, { generation: 2, moveX: 1 }));
  await received;
  await backend.waitForNextSimulationTick();
  assert.equal(backend.match.replayLedger().at(-1).actors[firstAssignment.actorId].moveX, 1);
});

test("a result-screen drop withdraws consent and reconnect restores only the same generation seat", { timeout: 15000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  first.reconnection.minUptime = 0;
  first.reconnection.maxEnqueuedMessages = 0;
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const [[firstAssignment]] = await Promise.all([bootstrap(first), bootstrap(second)]);
  await finishCurrentGeneration(backend, [first, second]);
  const deadline = backend.resultsDeadlineAt;

  let received = backend.waitForNextMessage();
  first.send("rematch-vote", { generation: 1, vote: true });
  await received;
  assert.equal(backend.rematchVotes.size, 1);

  const reconnected = new Promise((resolve) => first.onReconnect(resolve));
  first.leave(false);
  await reconnected;
  assert.equal(backend.rematchVotes.size, 0, "disconnect retained rematch consent");
  assert.equal(backend.lifecycle, "finished");
  assert.equal(backend.resultsDeadlineAt, deadline, "reconnect transport extended results");
  assert.equal(backend.match.generation, 1);
  assert.equal(backend.match.actorBySession.has(first.sessionId), false);

  const [rebound, frozen] = await bootstrap(first);
  assert.equal(rebound.generation, 1);
  assert.equal(rebound.actorId, firstAssignment.actorId);
  assert.ok(rebound.epoch > firstAssignment.epoch);
  assert.equal(frozen.state.match.phase, "finished");
  assert.equal(backend.resultsDeadlineAt, deadline);
  assert.equal(backend.rematchVotes.size, 0);
});

test("the results deadline closes deterministically and stale timeout callbacks cannot mutate later state", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  await finishCurrentGeneration(backend, [first, second]);
  const generation = backend.match.generation;
  const deadline = backend.resultsDeadlineAt;
  const timer = backend.resultsTimer;
  let disconnects = 0;
  const disconnect = backend.disconnect.bind(backend);
  backend.disconnect = async () => { disconnects += 1; };
  backend.monotonicNow = () => deadline;
  assert.equal(backend.expireResultsWindow(generation), true);
  assert.equal(backend.lifecycle, "closing");
  assert.equal(backend.rematchOpen, false);
  assert.equal(backend.rematchVotes.size, 0);
  assert.equal(disconnects, 1);
  assert.equal(backend.expireResultsWindow(generation), false);
  timer.execute();
  assert.equal(disconnects, 1, "cleared result timer repeated terminal cleanup");
  backend.disconnect = disconnect;
});

test("the fresh-generation readiness deadline closes once and ignores stale callbacks", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  const second = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  await Promise.all([bootstrap(first), bootstrap(second)]);
  await finishCurrentGeneration(backend, [first, second]);

  const firstAssignment = first.waitForMessage("assignment");
  const secondAssignment = second.waitForMessage("assignment");
  first.send("rematch-vote", { generation: 1, vote: true });
  second.send("rematch-vote", { generation: 1, vote: true });
  await Promise.all([firstAssignment, secondAssignment]);
  assert.equal(backend.match.generation, 2);
  assert.equal(backend.lifecycle, "ready");
  const deadline = backend.generationReadyDeadlineAt;
  const timer = backend.generationReadyTimer;
  let disconnects = 0;
  const disconnect = backend.disconnect.bind(backend);
  backend.disconnect = async () => { disconnects += 1; };
  backend.monotonicNow = () => deadline;

  assert.equal(backend.expireGenerationReadiness(2), true);
  assert.equal(backend.lifecycle, "closing");
  assert.equal(backend.match.actorBySession.size, 0);
  assert.equal(disconnects, 1);
  assert.equal(backend.expireGenerationReadiness(2), false);
  timer.execute();
  assert.equal(disconnects, 1, "cleared readiness timer repeated terminal cleanup");
  backend.disconnect = disconnect;
});

test("a consensual SDK leave releases Room readiness and authoritative actor ownership", { timeout: 10000 }, async () => {
  const first = await colyseus.sdk.joinOrCreate("arena", admissionOptions());
  const backend = colyseus.getRoomById(first.roomId);
  await bootstrap(first);
  const sessionId = first.sessionId;
  assert.equal(backend.match.actorBySession.get(sessionId), 0);
  assert.equal(backend.readySessions.has(sessionId), true);

  await first.leave(true);
  await waitForCondition(
    () => !backend.match.actorBySession.has(sessionId),
    "consensual leave did not release the authoritative actor"
  );
  assert.equal(backend.readySessions.has(sessionId), false);
  assert.equal(backend.reservations.has(sessionId), false);
});

test("served browser SDK Create/Join Code decodes Schema through a rematch generation", { timeout: 15000 }, async () => {
  const sdk = await colyseus.http.get("/online-sdk.js");
  const source = String(sdk.data);
  assert.match(source, /colyseus\.js@0\.18\.2 - @colyseus\/schema 5\.0\.8/);

  const priorColyseus = globalThis.Colyseus;
  const clients = [];
  try {
    vm.runInThisContext(source, { filename: "online-sdk.js" });
    assert.equal(typeof globalThis.Colyseus?.Client, "function");
    const origin = `http://127.0.0.1:${colyseus.server.port}`;
    const first = await new globalThis.Colyseus.Client(origin)
      .create("arena", createMatchOptions());
    clients.push(first);
    assert.match(first.roomId, ROOM_CODE_PATTERN);
    const firstBootstrap = await bootstrapUmd(first);
    const second = await new globalThis.Colyseus.Client(origin)
      .joinById(first.roomId, joinCodeOptions());
    clients.push(second);
    const secondBootstrap = await bootstrapUmd(second);
    assert.equal(first.roomId, second.roomId);
    assert.deepEqual(
      [firstBootstrap.assignment.actorId, secondBootstrap.assignment.actorId],
      [0, 1],
    );

    const backend = colyseus.getRoomById(first.roomId);
    const generationOne = {
      generation: 1,
      simVersion: Netcode.SIMULATION_SCHEMA_VERSION,
      modeId: "free-for-all",
      mapId: "original-arena",
      lifecycle: "playing",
      started: true,
      connectedPlayers: 2,
      rematchOpen: false,
      rematchVotes: 0,
      rematchRequired: 2,
    };
    for (const room of clients) {
      assert.deepEqual(await waitForUmdState(
        room,
        (state) => state.generation === 1 && state.lifecycle === "playing"
          && state.started && state.connectedPlayers === 2,
        "generation 1 playing",
      ), generationOne);
    }

    backend.match.state.match.ticksRemaining = 1;
    await backend.waitForNextSimulationTick();
    for (const room of clients) {
      await waitForUmdState(
        room,
        (state) => state.generation === 1 && state.lifecycle === "finished"
          && state.rematchOpen,
        "generation 1 finished",
      );
    }

    const firstAssignment = waitForUmdMessage(first, "assignment");
    const secondAssignment = waitForUmdMessage(second, "assignment");
    first.send("rematch-vote", { generation: 1, vote: true });
    second.send("rematch-vote", { generation: 1, vote: true });
    const assignments = await Promise.all([firstAssignment, secondAssignment]);
    assert.deepEqual(assignments.map((assignment) => assignment.generation), [2, 2]);

    const firstSnapshot = waitForUmdMessage(first, "snapshot");
    const secondSnapshot = waitForUmdMessage(second, "snapshot");
    first.send("ready", { generation: 2 });
    second.send("ready", { generation: 2 });
    const snapshots = await Promise.all([firstSnapshot, secondSnapshot]);
    assert.deepEqual(snapshots.map((snapshot) => snapshot.generation), [2, 2]);
    for (const room of clients) {
      await waitForUmdState(
        room,
        (state) => state.generation === 2 && state.lifecycle === "playing"
          && state.started && state.connectedPlayers === 2
          && !state.rematchOpen && state.rematchVotes === 0,
        "generation 2 playing",
      );
    }
  } finally {
    await Promise.allSettled(clients.map((room) => room.leave()));
    if (priorColyseus === undefined) delete globalThis.Colyseus;
    else globalThis.Colyseus = priorColyseus;
  }
});

test("local HTTP surface serves exact liveness/readiness, the offline shell, and the installed SDK", async () => {
  for (const [path, expected] of [
    ["/livez", { status: "live" }],
    ["/readyz", { status: "ready" }],
  ]) {
    const health = await colyseus.http.get(path);
    assert.deepEqual(health.data, expected);
    assert.equal(health.headers["cache-control"], "no-store");
    assert.equal(health.headers["x-content-type-options"], "nosniff");
    assert.match(String(health.headers["content-type"]), /^application\/json; charset=utf-8/i);
  }

  const index = await colyseus.http.get("/");
  assert.match(index.data, /<!doctype html>/i);
  assert.match(index.data, /src="online-client\.js\?v=/);
  const assetUrls = [...index.data.matchAll(/(?:href|src)="([^"?]+\?v=[a-f0-9]{12})"/g)]
    .map((match) => match[1]);
  assert.equal(assetUrls.length, 10);
  for (const assetUrl of assetUrls) {
    const asset = await colyseus.http.get(`/${assetUrl}`);
    assert.ok(String(asset.data).length > 0, `${assetUrl} was not served`);
  }
  const onlineIndex = await colyseus.http.get("/?online=1");
  assert.match(onlineIndex.data, /<!doctype html>/i);

  const bareAsset = await colyseus.http.get("/styles.css");
  assert.ok(String(bareAsset.data).length > 0);

  const sdk = await colyseus.http.get("/online-sdk.js");
  assert.match(String(sdk.headers["content-type"]), /javascript/);
  assert.match(sdk.data, /Colyseus/);

  await assert.rejects(colyseus.http.get("/server/package.json"), (error) => {
    assert.equal(error && error.statusCode, 404);
    return true;
  });
  for (const path of ["/health", "/__healthcheck", "/livez?detail=private", "/readyz?detail=private"]) {
    await assert.rejects(colyseus.http.get(path), (error) => {
      assert.equal(error && error.statusCode, 404);
      assert.deepEqual(error.data, { error: "not found" });
      assert.equal(error.headers["cache-control"], "no-store");
      assert.equal(error.headers["x-content-type-options"], "nosniff");
      return true;
    });
  }
  await assert.rejects(colyseus.http.get("/?online=0"), (error) => {
    assert.equal(error && error.statusCode, 404);
    return true;
  });
  await assert.rejects(colyseus.http.get("/index.html"), (error) => {
    assert.equal(error && error.statusCode, 404);
    return true;
  });
  await assert.rejects(colyseus.http.get("/%73tyles.css"), (error) => {
    assert.equal(error && error.statusCode, 404);
    return true;
  });
  await assert.rejects(colyseus.http.get("/sim.js?v=000000000000"), (error) => {
    assert.equal(error && error.statusCode, 404);
    return true;
  });

  for (const path of ["/livez", "/readyz"]) {
    const methodRejected = await rawHttpStatus({
      method: "POST",
      path,
      fullResponse: true,
    });
    assert.match(methodRejected, /^HTTP\/1\.1 405 /);
    assert.match(methodRejected, /\r\ncache-control: no-store\r\n/i);
    assert.match(methodRejected, /\r\nx-content-type-options: nosniff\r\n/i);
    assert.match(methodRejected, /\r\n\r\n\{"error":"method not allowed"\}$/);
  }

  const staticCanary = "STATIC_PATH_CANARY_12B3B2";
  const fixedNotFound = await rawHttpStatus({
    method: "POST",
    path: `/${staticCanary}%3Cscript%3E?private=${staticCanary}`,
    fullResponse: true,
  });
  assert.match(fixedNotFound, /^HTTP\/1\.1 404 /);
  assert.match(fixedNotFound, /\r\ncache-control: no-store\r\n/i);
  assert.match(fixedNotFound, /\r\nx-content-type-options: nosniff\r\n/i);
  assert.match(fixedNotFound, /\r\n\r\n\{"error":"not found"\}$/);
  assert.equal(fixedNotFound.includes(staticCanary), false);

  assert.match(
    await rawHttpStatus({ origin: "https://attacker.invalid" }),
    /^HTTP\/1\.1 403 /,
  );
  assert.match(
    await rawHttpStatus({ contentLength: "1025" }),
    /^HTTP\/1\.1 413 /,
  );
  assert.match(
    await rawHttpStatus({ path: "/matchmake/joinOrCreate/arena?serverUrl=invalid" }),
    /^HTTP\/1\.1 404 /,
  );
});
