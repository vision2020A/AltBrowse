export const DEFAULT_SERVER_PORT = 2567;
export const MAX_ALLOWED_ORIGINS = 16;
export const MAX_ORIGIN_CHARS = 255;
export const MAX_ALLOWED_ORIGINS_CHARS = 4095;

export const FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS = Object.freeze([
  "REDIS_URI",
  "COLYSEUS_LATENCY",
  "COLYSEUS_PRESENCE_SHORT_TIMEOUT",
  "COLYSEUS_MAX_CONCURRENT_CREATE_ROOM_WAIT_TIME",
]);
export const COLYSEUS_CLOUD_ENVIRONMENT_KEY = "COLYSEUS_CLOUD";
export const COLYSEUS_CLOUD_INSTANCE_KEY = "NODE_APP_INSTANCE";
export const COLYSEUS_CLOUD_ROLLOUT_INSTANCES = Object.freeze(["0", "1"]);
export const COLYSEUS_CLOUD_SOCKET_DIRECTORY = "/run/colyseus";

const ALLOWED_STICKMAN_ENVIRONMENT_KEYS = new Set([
  "STICKMAN_SERVER_MODE",
  "STICKMAN_BIND_HOST",
  "STICKMAN_PUBLIC_ORIGIN",
  "STICKMAN_ALLOWED_ORIGINS",
]);
const PUBLIC_ONLY_ENVIRONMENT_KEYS = Object.freeze([
  "STICKMAN_BIND_HOST",
  "STICKMAN_PUBLIC_ORIGIN",
  "STICKMAN_ALLOWED_ORIGINS",
]);
const PUBLIC_BIND_HOSTS = new Set(["0.0.0.0", "::"]);
const CLOUD_ROLLOUT_INSTANCES = new Set(COLYSEUS_CLOUD_ROLLOUT_INSTANCES);

export class RuntimeConfigError extends Error {
  constructor(key, reason) {
    super(`Invalid runtime configuration: ${key} (${reason})`);
    this.name = "RuntimeConfigError";
    this.key = key;
    this.reason = reason;
  }
}

function fail(key, reason) {
  throw new RuntimeConfigError(key, reason);
}

function environmentNames(environment) {
  if (!environment || typeof environment !== "object" || Array.isArray(environment)) {
    fail("environment", "invalid-record");
  }
  try {
    return Object.getOwnPropertyNames(environment);
  } catch {
    fail("environment", "invalid-record");
  }
}

function ownEnvironmentValue(environment, key) {
  let descriptor;
  try {
    descriptor = Object.getOwnPropertyDescriptor(environment, key);
  } catch {
    fail(key, "invalid-value");
  }
  if (!descriptor) return undefined;
  if (!Object.prototype.hasOwnProperty.call(descriptor, "value")
      || typeof descriptor.value !== "string") {
    fail(key, "invalid-value");
  }
  return descriptor.value;
}

function hasOwnEnvironmentKey(environment, key) {
  try {
    return Object.prototype.hasOwnProperty.call(environment, key);
  } catch {
    fail(key, "invalid-value");
  }
}

function readPort(environment) {
  if (!hasOwnEnvironmentKey(environment, "PORT")) return DEFAULT_SERVER_PORT;
  const value = ownEnvironmentValue(environment, "PORT");
  if (!/^[1-9]\d{0,4}$/.test(value)) fail("PORT", "invalid-port");
  const port = Number(value);
  if (!Number.isSafeInteger(port) || port > 65535 || String(port) !== value) {
    fail("PORT", "invalid-port");
  }
  return port;
}

function canonicalHttpsOrigin(value, key) {
  if (typeof value !== "string" || value.length < 1 || value.length > MAX_ORIGIN_CHARS) {
    fail(key, "invalid-origin");
  }
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    fail(key, "invalid-origin");
  }
  if (parsed.protocol !== "https:" || parsed.origin !== value
      || parsed.username || parsed.password) {
    fail(key, "invalid-origin");
  }
  return parsed;
}

function readAllowedOrigins(environment, publicOrigin) {
  const key = "STICKMAN_ALLOWED_ORIGINS";
  const value = ownEnvironmentValue(environment, key);
  if (typeof value !== "string" || value.length < 1
      || value.length > MAX_ALLOWED_ORIGINS_CHARS) {
    fail(key, "invalid-list");
  }
  const values = value.split(",");
  if (values.length < 1 || values.length > MAX_ALLOWED_ORIGINS) {
    fail(key, "invalid-list");
  }
  const seen = new Set();
  for (const origin of values) {
    canonicalHttpsOrigin(origin, key);
    if (seen.has(origin)) fail(key, "duplicate-origin");
    seen.add(origin);
  }
  if (!seen.has(publicOrigin)) fail(key, "missing-public-origin");
  return Object.freeze(values);
}

function localOrigin(host, port) {
  return new URL(`http://${host}:${port}`).origin;
}

export function colyseusCloudUnixSocketPath(nodeAppInstance) {
  if (!CLOUD_ROLLOUT_INSTANCES.has(nodeAppInstance)) {
    fail(COLYSEUS_CLOUD_INSTANCE_KEY, "unsupported-topology-override");
  }
  return `${COLYSEUS_CLOUD_SOCKET_DIRECTORY}/${
    DEFAULT_SERVER_PORT + Number(nodeAppInstance)
  }.sock`;
}

function makeLocalConfig(port) {
  const allowedOrigins = Object.freeze([
    localOrigin("127.0.0.1", port),
    localOrigin("localhost", port),
  ]);
  const allowedAuthorities = Object.freeze(allowedOrigins.map((origin) => new URL(origin).host));
  return Object.freeze({
    serverMode: "local",
    bindHost: "127.0.0.1",
    port,
    publicOrigin: null,
    allowedOrigins,
    allowedAuthorities,
    allowMissingOrigin: true,
    cloudProxy: false,
    listenPath: null,
  });
}

function makePublicConfig(environment, port, cloudProxy) {
  if (ownEnvironmentValue(environment, "NODE_ENV") !== "production") {
    fail("NODE_ENV", "required-production");
  }
  const bindHost = ownEnvironmentValue(environment, "STICKMAN_BIND_HOST");
  if (!PUBLIC_BIND_HOSTS.has(bindHost)) fail("STICKMAN_BIND_HOST", "invalid-bind-host");

  const publicUrl = canonicalHttpsOrigin(
    ownEnvironmentValue(environment, "STICKMAN_PUBLIC_ORIGIN"),
    "STICKMAN_PUBLIC_ORIGIN",
  );
  const publicOrigin = publicUrl.origin;
  const allowedOrigins = readAllowedOrigins(environment, publicOrigin);
  return Object.freeze({
    serverMode: "public",
    bindHost,
    port,
    publicOrigin,
    allowedOrigins,
    allowedAuthorities: Object.freeze([publicUrl.host]),
    allowMissingOrigin: false,
    cloudProxy,
    listenPath: cloudProxy
      ? colyseusCloudUnixSocketPath(
        ownEnvironmentValue(environment, COLYSEUS_CLOUD_INSTANCE_KEY),
      )
      : null,
  });
}

export function createRuntimeConfig(environment) {
  const names = environmentNames(environment);
  for (const key of FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS) {
    if (names.includes(key)) fail(key, "unsupported-topology-override");
  }
  if (names.some((key) => key.startsWith("STICKMAN_")
      && !ALLOWED_STICKMAN_ENVIRONMENT_KEYS.has(key))) {
    fail("STICKMAN_*", "unknown-variable");
  }

  const mode = hasOwnEnvironmentKey(environment, "STICKMAN_SERVER_MODE")
    ? ownEnvironmentValue(environment, "STICKMAN_SERVER_MODE")
    : "local";
  if (mode !== "local" && mode !== "public") {
    fail("STICKMAN_SERVER_MODE", "invalid-mode");
  }
  const cloudEnvironment = names.includes(COLYSEUS_CLOUD_ENVIRONMENT_KEY);
  const cloudInstance = names.includes(COLYSEUS_CLOUD_INSTANCE_KEY);
  if (cloudEnvironment) ownEnvironmentValue(environment, COLYSEUS_CLOUD_ENVIRONMENT_KEY);
  if (mode !== "public" && (cloudEnvironment || cloudInstance)) {
    fail(
      cloudEnvironment ? COLYSEUS_CLOUD_ENVIRONMENT_KEY : COLYSEUS_CLOUD_INSTANCE_KEY,
      "not-allowed-in-local-mode",
    );
  }
  if (mode === "public" && cloudEnvironment !== cloudInstance) {
    fail(
      cloudEnvironment ? COLYSEUS_CLOUD_INSTANCE_KEY : COLYSEUS_CLOUD_ENVIRONMENT_KEY,
      "unsupported-topology-override",
    );
  }
  if (cloudInstance
      && !CLOUD_ROLLOUT_INSTANCES.has(
        ownEnvironmentValue(environment, COLYSEUS_CLOUD_INSTANCE_KEY),
      )) {
    fail(COLYSEUS_CLOUD_INSTANCE_KEY, "unsupported-topology-override");
  }
  const port = readPort(environment);
  if (mode === "public") return makePublicConfig(environment, port, cloudEnvironment);

  for (const key of PUBLIC_ONLY_ENVIRONMENT_KEYS) {
    if (hasOwnEnvironmentKey(environment, key)) fail(key, "not-allowed-in-local-mode");
  }
  return makeLocalConfig(port);
}

export function isRequestOriginAllowed(config, origin) {
  if (origin == null) return config.allowMissingOrigin === true;
  return typeof origin === "string" && config.allowedOrigins.includes(origin);
}

export function isRequestAuthorityAllowed(config, authority) {
  return typeof authority === "string" && config.allowedAuthorities.includes(authority);
}

export function isRequestPolicyAllowed(config, origin, authority) {
  if (!isRequestOriginAllowed(config, origin)
      || !isRequestAuthorityAllowed(config, authority)) return false;
  if (config.serverMode === "local" && origin != null) {
    try {
      return new URL(origin).host === authority;
    } catch {
      return false;
    }
  }
  return true;
}
