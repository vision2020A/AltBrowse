import crypto from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import path from "node:path";
import { createServer } from "node:http";
import { performance } from "node:perf_hooks";
import { fileURLToPath } from "node:url";
import {
  CloseCode,
  createRouter,
  defineRoom,
  defineServer,
  LocalDriver,
  LocalPresence,
  matchMaker,
} from "@colyseus/core";
import {
  debugConnection,
  debugDevMode,
  debugDriver,
  debugError,
  debugMatchMaking,
  debugMessage,
  debugPatch,
  debugPresence,
} from "@colyseus/core/Debug";
import { WebSocketTransport } from "@colyseus/ws-transport";
import { createConfiguredArenaRoom } from "./arena-room.mjs";
import {
  createFrameworkLogger,
  createFrameworkDiagnosticGate,
  createOperationsLogger,
  createSecurityRejectionTracker,
  createServiceState,
} from "./operations.mjs";
import {
  createProtocolBoundary,
  DEFAULT_LOCAL_REQUEST_POLICY,
  isAllowedRawHost,
  isSafeOriginFormTarget,
  PASS12B1_MAX_HEADER_BYTES,
  PASS12B1_MAX_WS_PAYLOAD_BYTES,
  PASS12B1_RAW_REJECTION_HEADER,
  PASS12B1_RAW_REJECTION_PATH,
} from "./protocol-boundary.mjs";
import { isRoomCode, roomRegistry } from "./room-registry.mjs";
import { Netcode } from "./shared-runtime.mjs";

export const PASS12B4A_STARTUP_LISTEN_TIMEOUT_MS = 10_000;
export const PASS12B4A_STARTUP_CLEANUP_TIMEOUT_MS = 1_000;
export const PASS12B4B_DRAIN_TIMEOUT_MS = 5_000;
export const PASS12B4B_FORCE_CLEANUP_TIMEOUT_MS = 1_000;
export const PASS12B4B_MAX_TRACKED_SOCKETS = 256;

const EDGE_REJECTION_BAD_REQUEST = "bad-request";
const EDGE_REJECTION_METHOD = "method-not-allowed";
const EDGE_REJECTION_NOT_FOUND = "not-found";

const serverRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../..");
const publicFiles = new Set([
  "styles.css", "sim.js", "animation.js", "bot.js", "touch.js",
  "input.js", "audio.js", "multiplayer.js", "online-client.js", "game.js"
]);
const publicCacheQueries = new Map([...publicFiles]
  .map((file) => {
    const digest = crypto.createHash("sha256")
      .update(fs.readFileSync(path.join(serverRoot, file)))
      .digest("hex")
      .slice(0, 12);
    return [`/${file}`, `?v=${digest}`];
  }));

// The pinned framework can format decoded client payloads both through its
// debug namespaces and through its error logger before application validation.
// Disable inherited debug output and replace detail-bearing framework logs with
// a structured adapter that discards every supplied argument.
for (const namespace of [
  debugConnection,
  debugDevMode,
  debugDriver,
  debugError,
  debugMatchMaking,
  debugMessage,
  debugPatch,
  debugPresence,
]) namespace.enabled = false;

function sendFixedError(response, status, error) {
  response.status(status)
    .set({
      "Cache-Control": "no-store",
      Connection: "close",
      "Content-Type": "application/json; charset=utf-8",
      "X-Content-Type-Options": "nosniff",
    })
    .send(JSON.stringify({ error }));
}

function boundedDuration(value, fallback, maximum) {
  return Number.isSafeInteger(value) && value >= 1 && value <= maximum ? value : fallback;
}

function settleBefore(promise, deadlineAt) {
  const remainingMs = Math.max(0, Math.ceil(deadlineAt - performance.now()));
  if (remainingMs === 0) return Promise.resolve("timed-out");
  let timer;
  const timeout = new Promise((resolve) => {
    timer = setTimeout(() => resolve("timed-out"), remainingMs);
  });
  return Promise.race([
    Promise.resolve(promise).then(() => "completed", () => "failed"),
    timeout,
  ]).finally(() => clearTimeout(timer));
}

function createAdmissionTracker(serviceState) {
  let active = 0;
  const trackedResponses = new WeakSet();
  const idleWaiters = new Set();

  function finish(response) {
    if (!trackedResponses.delete(response)) return;
    active -= 1;
    if (active !== 0) return;
    for (const resolve of idleWaiters) resolve();
    idleWaiters.clear();
  }

  function observe(request, response) {
    if (!response || typeof response.once !== "function" || trackedResponses.has(response)
        || !serviceState.isReady() || request.method !== "POST"
        || typeof request.url !== "string" || !request.url.startsWith("/matchmake/")) return;
    trackedResponses.add(response);
    active += 1;
    const complete = () => finish(response);
    response.once("finish", complete);
    response.once("close", complete);
  }

  function waitForIdle() {
    if (active === 0) return Promise.resolve();
    return new Promise((resolve) => idleWaiters.add(resolve));
  }

  return Object.freeze({
    observe,
    snapshot: () => Object.freeze({ active }),
    waitForIdle,
  });
}

export function handleFixedExpressError(error, _request, response, next, operationsLogger = null) {
  if (response.headersSent) return next(error);
  operationsLogger?.error("http.unexpected-error", { reason: "failed" });
  sendFixedError(response, 500, "internal server error");
}

function hasAllowedPublicQuery(request) {
  const queryIndex = request.originalUrl.indexOf("?");
  if (queryIndex < 0) return true;
  const query = request.originalUrl.slice(queryIndex);
  if (request.path === "/") return query === "?online=1";
  return publicCacheQueries.get(request.path) === query;
}

function isForwardingHeaderName(name) {
  return name === "forwarded"
    || name.startsWith("x-forwarded-")
    || name === "x-real-ip"
    || name === "x-client-ip"
    || name === "x-original-host"
    || name === "x-original-url"
    || name === "x-rewrite-url";
}

function hasForwardingHeader(headers) {
  return Object.keys(headers || {}).some((name) => isForwardingHeaderName(name));
}

function stripCloudProxyHeaders(request) {
  if (request.headers && typeof request.headers === "object") {
    for (const name of Object.keys(request.headers)) {
      if (isForwardingHeaderName(name)) delete request.headers[name];
    }
  }
  if (!Array.isArray(request.rawHeaders)) return;
  const retained = [];
  for (let index = 0; index < request.rawHeaders.length; index += 2) {
    const name = request.rawHeaders[index];
    const value = request.rawHeaders[index + 1];
    if (typeof name === "string" && isForwardingHeaderName(name.toLowerCase())) continue;
    retained.push(name, value);
  }
  request.rawHeaders.splice(0, request.rawHeaders.length, ...retained);
}

function inspectRawHeaders(request, requestPolicy, allowProxyHeaders = false) {
  if (!Array.isArray(request.rawHeaders) || request.rawHeaders.length % 2 !== 0) {
    return { validHost: false, hasRejectedHeader: true };
  }
  const hosts = [];
  let hasRejectedHeader = false;
  for (let index = 0; index < request.rawHeaders.length; index += 2) {
    const name = request.rawHeaders[index];
    const value = request.rawHeaders[index + 1];
    if (typeof name !== "string" || typeof value !== "string") {
      hasRejectedHeader = true;
      continue;
    }
    const lowerName = name.toLowerCase();
    if (lowerName === "host") hosts.push(value);
    if (lowerName === PASS12B1_RAW_REJECTION_HEADER) hasRejectedHeader = true;
    else if (!allowProxyHeaders && isForwardingHeaderName(lowerName)) hasRejectedHeader = true;
  }
  return {
    validHost: hosts.length === 1
      && hosts[0] === request.headers?.host
      && isAllowedRawHost(hosts[0], requestPolicy),
    hasRejectedHeader,
  };
}

function isFrameworkPreflightTarget(value) {
  if (typeof value !== "string" || value.includes("?")) return false;
  if (value === "/matchmake/joinOrCreate/arena"
      || value === "/matchmake/create/arena") return true;
  const codePrefix = "/matchmake/joinById/";
  if (value.startsWith(codePrefix)) return isRoomCode(value.slice(codePrefix.length));
  return /^\/matchmake\/reconnect\/[A-Za-z0-9_-]{1,32}$/.test(value);
}

function replaceWithFixedEdgeRejection(request, rejection) {
  request.method = "GET";
  request.url = PASS12B1_RAW_REJECTION_PATH;
  request.headers = {
    host: "127.0.0.1",
    [PASS12B1_RAW_REJECTION_HEADER]: rejection,
  };
  if (Array.isArray(request.rawHeaders)) {
    request.rawHeaders.length = 0;
    request.rawHeaders.push(
      "Host", "127.0.0.1",
      PASS12B1_RAW_REJECTION_HEADER, rejection,
    );
  }
}

// This listener is registered before the transport and Express listeners. It
// replaces rejected request metadata before framework URL parsing or logging,
// while an internal marker makes the normal boundary return a fixed response.
export function createRawRequestGuard(
  requestPolicy = DEFAULT_LOCAL_REQUEST_POLICY,
  cloudProxy = false,
) {
  const allowProxyHeaders = cloudProxy === true || requestPolicy.mode === "public";
  return function guardRawRequest(request) {
    if (allowProxyHeaders) stripCloudProxyHeaders(request);
    const raw = inspectRawHeaders(request, requestPolicy, allowProxyHeaders);
    const clientSetMarker = request.headers?.[PASS12B1_RAW_REJECTION_HEADER] !== undefined;
    if (!clientSetMarker && raw.validHost && !raw.hasRejectedHeader
        && (allowProxyHeaders || !hasForwardingHeader(request.headers))
        && isSafeOriginFormTarget(request.url)) {
      if (request.method !== "OPTIONS" || isFrameworkPreflightTarget(request.url)) return false;

      // Colyseus answers OPTIONS before its normal request hook or Express.
      // Preserve only the exact matchmaking preflights it owns. Convert every
      // other OPTIONS target into one internal fixed response so probes retain
      // their method contract and hidden/static paths cannot inherit a 204.
      const rejection = request.url === "/livez" || request.url === "/readyz"
        ? EDGE_REJECTION_METHOD : EDGE_REJECTION_NOT_FOUND;
      replaceWithFixedEdgeRejection(request, rejection);
      return true;
    }

    // Colyseus answers every OPTIONS request before its normal request hook.
    // Normalize rejected methods too, so malformed preflight-shaped traffic
    // cannot bypass the fixed, redacted Express rejection below.
    replaceWithFixedEdgeRejection(request, EDGE_REJECTION_BAD_REQUEST);
    return true;
  };
}

export const guardRawLocalRequest = createRawRequestGuard();
export const pass12B3ExposedMethods = Object.freeze([
  "joinOrCreate",
  "create",
  "joinById",
  "reconnect",
]);

function requestPolicyFor(runtimeConfig) {
  return Object.freeze({
    mode: runtimeConfig.serverMode,
    allowMissingOrigin: runtimeConfig.allowMissingOrigin,
    allowedHosts: runtimeConfig.allowedAuthorities,
    allowedOrigins: runtimeConfig.allowedOrigins,
  });
}

export function createApplication(runtimeConfig, options = {}) {
  if (!runtimeConfig || typeof runtimeConfig !== "object") {
    throw new TypeError("runtimeConfig is required");
  }
  const requestPolicy = requestPolicyFor(runtimeConfig);
  const serviceState = options.serviceState || createServiceState();
  const operationsLogger = options.operationsLogger || createOperationsLogger({
    buildId: Netcode.SERVER_BUILD_ID,
  });
  const rejectionTracker = options.rejectionTracker || createSecurityRejectionTracker({
    logger: operationsLogger,
  });
  const frameworkDiagnosticGate = options.frameworkDiagnosticGate
    || createFrameworkDiagnosticGate({ logger: operationsLogger });
  const frameworkLogger = createFrameworkLogger(operationsLogger, {
    diagnosticGate: frameworkDiagnosticGate,
    rejectionTracker,
  });
  const presence = new LocalPresence();
  const driver = new LocalDriver();
  const drainTimeoutMs = boundedDuration(
    options.drainTimeoutMs,
    PASS12B4B_DRAIN_TIMEOUT_MS,
    60_000,
  );
  const forceCleanupTimeoutMs = boundedDuration(
    options.forceCleanupTimeoutMs,
    PASS12B4B_FORCE_CLEANUP_TIMEOUT_MS,
    10_000,
  );
  const rawRequestGuard = createRawRequestGuard(requestPolicy, runtimeConfig.cloudProxy);
  const admissionTracker = createAdmissionTracker(serviceState);
  const boundary = createProtocolBoundary({
    requestPolicy,
    serviceState,
    rejectionTracker,
    isLocalRoom: (roomId) => Boolean(matchMaker.getLocalRoomById(roomId)),
  });
  const httpServer = createServer({ maxHeaderSize: PASS12B1_MAX_HEADER_BYTES });
  httpServer.maxConnections = PASS12B4B_MAX_TRACKED_SOCKETS;
  httpServer.on("request", rawRequestGuard);
  httpServer.on("request", admissionTracker.observe);
  httpServer.on("upgrade", rawRequestGuard);
  const openSockets = new Set();
  const preRequestSockets = new Set();
  httpServer.on("connection", (socket) => {
    if (openSockets.size >= PASS12B4B_MAX_TRACKED_SOCKETS) {
      socket.destroy();
      return;
    }
    openSockets.add(socket);
    preRequestSockets.add(socket);
    socket.once("close", () => {
      openSockets.delete(socket);
      preRequestSockets.delete(socket);
    });
  });
  httpServer.on("request", (request) => preRequestSockets.delete(request.socket));
  httpServer.on("upgrade", (request) => preRequestSockets.delete(request.socket));

  // Colyseus deliberately prepends its router when it binds after listen(). Keep
  // the metadata scrubber ahead of that late listener as well; otherwise an
  // invalid Host or forwarding scheme can reach URL construction first.
  const nodePrependListener = httpServer.prependListener;
  httpServer.prependListener = function prependWithRawGuard(eventName, listener) {
    const result = nodePrependListener.call(this, eventName, listener);
    if (eventName === "request" && listener !== rawRequestGuard) {
      this.removeListener("request", rawRequestGuard);
      nodePrependListener.call(this, "request", rawRequestGuard);
    }
    return result;
  };

  matchMaker.controller.exposedMethods = [...pass12B3ExposedMethods];
  matchMaker.controller.getCorsHeaders = (headers) => boundary.getCorsHeaders(headers);
  const ConfiguredArenaRoom = createConfiguredArenaRoom({
    operationsLogger,
    rejectionTracker,
    requestPolicy,
    serviceState,
  });
  let frameworkShutdownCompleted = false;
  const server = defineServer({
    gracefullyShutdown: false,
    rooms: {
      arena: defineRoom(ConfiguredArenaRoom),
    },
    routes: createRouter({}, {
      onRequest: boundary.onRequest,
      onResponse: boundary.onResponse,
    }),
    transport: new WebSocketTransport({
      server: httpServer,
      maxPayload: PASS12B1_MAX_WS_PAYLOAD_BYTES,
      beforeUpgrade: boundary.beforeUpgrade,
    }),
    presence,
    driver,
    selectProcessIdToCreateRoom: async () => matchMaker.processId,
    logger: frameworkLogger,
    auth: false,
    greet: false,
    express: (app) => {
      app.disable("x-powered-by");
      app.use((request, response, next) => {
        const rejection = request.headers[PASS12B1_RAW_REJECTION_HEADER];
        if (rejection === undefined) return next();
        if (rejection === EDGE_REJECTION_METHOD) {
          return sendFixedError(response, 405, "method not allowed");
        }
        if (rejection === EDGE_REJECTION_NOT_FOUND) {
          return sendFixedError(response, 404, "not found");
        }
        return sendFixedError(response, 400, "bad request");
      });
      app.use((request, response, next) => {
        if (hasAllowedPublicQuery(request)) return next();
        sendFixedError(response, 404, "not found");
      });
      app.all(["/livez", "/readyz"], (request, response) => {
        if (request.method !== "GET") return sendFixedError(response, 405, "method not allowed");
        const live = serviceState.isLive();
        const ready = serviceState.isReady();
        const accepted = request.path === "/livez" ? live : ready;
        response.status(accepted ? 200 : 503)
          .set({
            "Cache-Control": "no-store",
            "Content-Type": "application/json; charset=utf-8",
            "X-Content-Type-Options": "nosniff",
          })
          .send(JSON.stringify({ status: accepted
            ? (request.path === "/livez" ? "live" : "ready") : "unavailable" }));
      });
      app.get("/online-sdk.js", (_request, response) => {
        response.sendFile(path.join(serverRoot, "server/node_modules/@colyseus/sdk/dist/colyseus.js"));
      });
      app.get("/", (_request, response) => response.sendFile(path.join(serverRoot, "index.html")));
      app.get("/:file", (request, response, next) => {
        if (!publicFiles.has(request.params.file)) return next();
        const queryIndex = request.originalUrl.indexOf("?");
        const rawPath = queryIndex < 0 ? request.originalUrl : request.originalUrl.slice(0, queryIndex);
        if (rawPath !== `/${request.params.file}`) return next();
        response.sendFile(path.join(serverRoot, request.params.file));
      });
      app.use((_request, response) => sendFixedError(response, 404, "not found"));
      app.use((error, request, response, next) => handleFixedExpressError(
        error, request, response, next, operationsLogger,
      ));
    },
  });
  server.onShutdown(() => {
    frameworkShutdownCompleted = true;
  });

  let listenPromise = null;
  let shutdownStarted = false;
  let shutdownMustFail = false;
  let shutdownPromise = null;
  let forceCleanupPromise = null;

  function markReady() {
    if (shutdownStarted || serviceState.snapshot().phase !== "starting"
        || !(presence instanceof LocalPresence) || !(driver instanceof LocalDriver)
        || httpServer.listening !== true) throw new Error("service cannot become ready");
    serviceState.setDependenciesAvailable(true);
    serviceState.setListenerAvailable(true);
    serviceState.transition("ready");
    operationsLogger.info("service.lifecycle", { phase: "ready", reason: "listening" });
    return serviceState.snapshot();
  }

  function prepareCloudUnixSocket(socketPath) {
    return new Promise((resolve, reject) => {
      const client = net.createConnection({ path: socketPath });
      client.once("connect", () => {
        client.end();
        reject(new Error("listener unavailable"));
      });
      client.once("error", () => {
        fs.unlink(socketPath, () => resolve());
      });
    });
  }

  function notifyProcessReady() {
    if (typeof process.send !== "function") return;
    try {
      process.send("ready");
    } catch {
      // PM2 wait_ready is best-effort after the official Cloud socket is bound.
    }
  }

  function listen() {
    if (listenPromise) return listenPromise;
    if (shutdownStarted) return Promise.reject(new Error("listener unavailable"));
    listenPromise = new Promise((resolve, reject) => {
      let settled = false;
      const finish = (accepted) => {
        if (settled) return;
        settled = true;
        clearTimeout(timeout);
        httpServer.removeListener("error", rejectListen);
        if (accepted && !shutdownStarted) {
          if (runtimeConfig.listenPath) notifyProcessReady();
          resolve();
        } else reject(new Error("listener unavailable"));
      };
      const rejectListen = () => finish(false);
      const timeout = setTimeout(rejectListen, PASS12B4A_STARTUP_LISTEN_TIMEOUT_MS);
      timeout.unref();
      httpServer.once("error", rejectListen);
      const startListen = () => {
        try {
          // Pinned @colyseus/tools listen(socketPath, 0) is the official Core
          // Cloud workaround: hostname 0 skips tools recursion and binds the
          // provider Unix socket nginx already proxies.
          const pending = runtimeConfig.listenPath
            ? server.listen(runtimeConfig.listenPath, 0)
            : server.listen(runtimeConfig.port, runtimeConfig.bindHost);
          Promise.resolve(pending).then(() => finish(true), rejectListen);
        } catch {
          rejectListen();
        }
      };
      if (runtimeConfig.listenPath) {
        prepareCloudUnixSocket(runtimeConfig.listenPath).then(startListen, rejectListen);
      } else {
        startListen();
      }
    });
    return listenPromise;
  }

  function observeHttpClose() {
    if (!httpServer.listening) return Promise.resolve();
    return new Promise((resolve) => httpServer.once("close", resolve));
  }

  function observeWebSocketClose() {
    const webSocketServer = server.transport?.wss;
    if (!listenPromise || !webSocketServer || webSocketServer._state === 2) {
      return Promise.resolve();
    }
    return new Promise((resolve) => webSocketServer.once("close", resolve));
  }

  function closeCurrentRooms() {
    for (const roomId of roomRegistry.snapshot().roomIds) {
      const room = matchMaker.getLocalRoomById(roomId);
      if (!room) continue;
      try {
        void Promise.resolve(room.lock()).catch(() => {});
      } catch {
        // The Room shutdown hook below still owns authority cleanup.
      }
      try {
        room.onBeforeShutdown();
      } catch {
        // The bounded process fallback remains authoritative on hook failure.
      }
    }
  }

  function forceCloseCurrentRooms() {
    let accepted = true;
    for (const roomId of roomRegistry.snapshot().roomIds) {
      const room = matchMaker.getLocalRoomById(roomId);
      if (!room) continue;
      try {
        room.closeRoom(CloseCode.SERVER_SHUTDOWN);
      } catch {
        accepted = false;
      }
    }
    return accepted;
  }

  function beginCloudHttpDrain() {
    if (!runtimeConfig.cloudProxy) return true;
    try {
      httpServer.close();
      httpServer.closeIdleConnections();
      for (const socket of [...preRequestSockets]) socket.destroy();
      return true;
    } catch {
      return false;
    }
  }

  function forceCleanup() {
    if (forceCleanupPromise) return forceCleanupPromise;
    forceCleanupPromise = (async () => {
      let accepted = forceCloseCurrentRooms();
      try {
        matchMaker.stats.clearAutoPersistInterval();
      } catch {
        accepted = false;
      }
      try {
        for (const client of server.transport?.wss?.clients || []) client.terminate();
      } catch {
        accepted = false;
      }
      for (const socket of [...openSockets]) {
        try {
          socket.destroy();
        } catch {
          accepted = false;
        }
      }
      try {
        server.transport?.shutdown();
      } catch {
        accepted = false;
      }
      try {
        httpServer.closeAllConnections();
        httpServer.closeIdleConnections();
        httpServer.close();
      } catch {
        accepted = false;
      }
      try {
        presence.shutdown();
      } catch {
        accepted = false;
      }
      let driverShutdown;
      try {
        driverShutdown = driver.shutdown();
      } catch {
        accepted = false;
      }
      if (driverShutdown !== undefined) {
        const driverOutcome = await settleBefore(
          driverShutdown,
          performance.now() + forceCleanupTimeoutMs,
        );
        if (driverOutcome !== "completed") accepted = false;
      }
      return accepted;
    })();
    return forceCleanupPromise;
  }

  function finishShutdown(accepted, timedOut) {
    serviceState.setListenerAvailable(false);
    serviceState.setDependenciesAvailable(false);
    const current = serviceState.snapshot().phase;
    if (current === "draining") serviceState.transition(accepted ? "stopped" : "failed");
    const phase = serviceState.snapshot().phase;
    if (accepted) {
      operationsLogger.info("service.drain", { phase, reason: "drain-complete" });
      operationsLogger.info("service.lifecycle", { phase, reason: "stopped" });
    } else {
      operationsLogger.error("service.drain", {
        phase,
        reason: timedOut ? "drain-timeout" : "failed",
      });
    }
    return Object.freeze({ accepted, timedOut });
  }

  function shutdown(reason = "shutdown-signal") {
    if (reason === "failed") shutdownMustFail = true;
    if (shutdownPromise) return shutdownPromise;
    const phase = serviceState.snapshot().phase;
    if (phase === "stopped" || phase === "failed") {
      shutdownPromise = Promise.resolve(Object.freeze({
        accepted: phase === "stopped",
        timedOut: false,
      }));
      return shutdownPromise;
    }
    shutdownStarted = true;
    if (phase === "starting" || phase === "ready") serviceState.transition("draining");
    operationsLogger.info("service.lifecycle", {
      phase: "draining",
      reason: reason === "failed" ? "failed" : "shutdown-signal",
    });
    operationsLogger.info("service.drain", { phase: "draining", reason: "drain-started" });
    rejectionTracker.flush();
    closeCurrentRooms();

    shutdownPromise = (async () => {
      const deadlineAt = performance.now() + drainTimeoutMs;
      const admissionOutcome = await settleBefore(admissionTracker.waitForIdle(), deadlineAt);
      if (admissionOutcome !== "completed") {
        await forceCleanup();
        return finishShutdown(false, admissionOutcome === "timed-out");
      }
      if (listenPromise) {
        const listenOutcome = await settleBefore(listenPromise.catch(() => {}), deadlineAt);
        if (listenOutcome !== "completed") {
          await forceCleanup();
          return finishShutdown(false, listenOutcome === "timed-out");
        }
      }
      const httpClosed = observeHttpClose();
      const webSocketClosed = observeWebSocketClose();
      if (!beginCloudHttpDrain()) {
        await forceCleanup();
        return finishShutdown(false, false);
      }
      let graceful;
      try {
        graceful = server.gracefullyShutdown(false);
      } catch {
        await forceCleanup();
        return finishShutdown(false, false);
      }
      const gracefulOutcome = await settleBefore(
        Promise.all([graceful, httpClosed, webSocketClosed]),
        deadlineAt,
      );
      if (gracefulOutcome !== "completed" || !frameworkShutdownCompleted
          || admissionTracker.snapshot().active !== 0 || roomRegistry.snapshot().liveRooms !== 0) {
        await forceCleanup();
        return finishShutdown(false, gracefulOutcome === "timed-out");
      }
      return finishShutdown(!shutdownMustFail, false);
    })();
    return shutdownPromise;
  }

  async function abortStartup() {
    serviceState.setListenerAvailable(false);
    serviceState.setDependenciesAvailable(false);
    const phase = serviceState.snapshot().phase;
    if (phase === "starting" || phase === "ready") serviceState.transition("failed");
    let timeout;
    try {
      const graceful = Promise.resolve(server.gracefullyShutdown(false))
        .then(() => true, () => false);
      const bounded = new Promise((resolve) => {
        timeout = setTimeout(() => resolve(false), PASS12B4A_STARTUP_CLEANUP_TIMEOUT_MS);
        timeout.unref();
      });
      await Promise.race([graceful, bounded]);
    } catch {
      // The direct cleanup below is the fixed fallback for framework failure.
    } finally {
      clearTimeout(timeout);
      matchMaker.stats.clearAutoPersistInterval();
    }
    try {
      server.transport?.shutdown();
    } catch {
      // Startup cleanup is best-effort and never reflects transport details.
    }
    try {
      httpServer.closeAllConnections();
      httpServer.close();
    } catch {
      // The listener may not have reached the bound state.
    }
    try {
      presence.shutdown();
    } catch {
      // LocalPresence shutdown is synchronous, but cleanup remains contained.
    }
    try {
      await driver.shutdown();
    } catch {
      // LocalDriver has no external resource; never expose unexpected details.
    }
    return serviceState.snapshot();
  }

  operationsLogger.info("service.lifecycle", { phase: "starting", reason: "startup" });
  return Object.freeze({
    admissionTracker,
    abortStartup,
    boundary,
    driver,
    frameworkDiagnosticGate,
    httpServer,
    listen,
    markReady,
    operationsLogger,
    presence,
    rawRequestGuard,
    rejectionTracker,
    requestPolicy,
    runtimeConfig,
    server,
    serviceState,
    shutdown,
  });
}
