import { CloseCode, Protocol, Room, ServerError } from "@colyseus/core";
import { performance } from "node:perf_hooks";
import { ArenaPublicState } from "./state-schema.mjs";
import {
  AuthoritativeMatch,
  ONLINE_HUMAN_COUNT,
  SNAPSHOT_INTERVAL_TICKS,
  SnapshotLimitError,
} from "./authoritative-match.mjs";
import {
  authorizeAdmission,
  CREATE_MATCH_OPERATION,
  INCOMPATIBLE_CLIENT_MESSAGE,
  JOIN_CODE_OPERATION,
  QUICK_MATCH_OPERATION,
  validateAdmissionOptions,
  validateAdmissionAuth,
} from "./protocol-boundary.mjs";
import {
  ROOM_SEAT_RESERVATION_SECONDS,
  roomRegistry,
} from "./room-registry.mjs";
import { Netcode } from "./shared-runtime.mjs";

const RECONNECT_SECONDS = 30;
const HANDSHAKE_TIMEOUT_MS = 3000;
const REMATCH_WINDOW_MS = 30_000;
const GENERATION_READY_TIMEOUT_MS = 10_000;
const INITIAL_WAITING_TIMEOUT_MS = 120_000;
const PROTOCOL_ERROR_CODE = "client-update-required";
const UNSUPPORTED_MESSAGE_REASON = "unsupported message";
const RATE_LIMIT_REASON = "connection message limit exceeded";
const BACKPRESSURE_REASON = "connection output limit exceeded";
const INBOUND_RATE_WINDOW_MS = 1000;
const MAX_INBOUND_MESSAGES_PER_WINDOW = 120;
const MAX_INBOUND_BYTES_PER_WINDOW = 32 * 1024;
const CONTROL_RATE_WINDOW_MS = 10_000;
const MAX_CONTROL_MESSAGES_PER_WINDOW = 16;
const CONTROL_MESSAGE_LIMITS = Object.freeze({
  "protocol-request": 4,
  "hello-ack": 4,
  ready: 4,
  resync: 4,
  "rematch-vote": 8,
});
const INPUT_ATTEMPT_WINDOW_MS = 1000;
const MAX_INPUT_ATTEMPTS_PER_WINDOW = 120;
const MAX_OUTBOUND_BUFFERED_BYTES = 256 * 1024;
// Colyseus protocol opcodes occupy the low five bits. @colyseus/core exports
// Protocol but not its mask; keep this pinned-framework edge covered by live
// request-frame regressions whenever the server dependency changes.
const COLYSEUS_PROTOCOL_CODE_MASK = 0x1f;
const RECONNECTABLE_CLOSE_CODES = new Set([
  CloseCode.GOING_AWAY,
  CloseCode.NO_STATUS_RECEIVED,
  CloseCode.ABNORMAL_CLOSURE,
  CloseCode.MAY_TRY_RECONNECT,
]);
const ALLOWED_CLIENT_PROTOCOL_CODES = new Set([
  Protocol.JOIN_ROOM,
  Protocol.LEAVE_ROOM,
  Protocol.ROOM_DATA,
  Protocol.ROOM_DATA_BYTES,
  Protocol.PING,
]);

const LIFECYCLE_TRANSITIONS = Object.freeze({
  waiting: new Set(["ready", "closing"]),
  ready: new Set(["waiting", "playing", "closing"]),
  playing: new Set(["finished", "closing"]),
  finished: new Set(["rematch-vote", "restarting", "closing"]),
  "rematch-vote": new Set(["finished", "restarting", "closing"]),
  restarting: new Set(["ready", "closing"]),
  closing: new Set(["disposed"]),
  disposed: new Set(),
});

function readExactDataRecord(value, expectedKeys) {
  try {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) return null;
    if (Object.getOwnPropertySymbols(value).length !== 0) return null;
    const names = Object.getOwnPropertyNames(value).sort();
    const expected = expectedKeys.slice().sort();
    if (names.length !== expected.length) return null;
    const values = Object.create(null);
    for (let index = 0; index < expected.length; index += 1) {
      if (names[index] !== expected[index]) return null;
      const descriptor = Object.getOwnPropertyDescriptor(value, expected[index]);
      if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return null;
      values[expected[index]] = descriptor.value;
    }
    return values;
  } catch {
    return null;
  }
}

function isExactEmptyRecord(value) {
  return readExactDataRecord(value, []) !== null;
}

function readGeneration(value) {
  try {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) return null;
    const descriptor = Object.getOwnPropertyDescriptor(value, "generation");
    if (!descriptor || !descriptor.enumerable || !("value" in descriptor)) return null;
    return Number.isSafeInteger(descriptor.value) && descriptor.value > 0
      ? descriptor.value : null;
  } catch {
    return null;
  }
}

function generationRejection(generation, current) {
  if (generation === null) return "invalid-payload";
  if (generation < current) return "stale-generation";
  if (generation > current) return "future-generation";
  return null;
}

function consumeFixedWindow(record, now, limit, windowMs, amount = 1) {
  if (!Number.isFinite(now) || !Number.isSafeInteger(amount) || amount < 1) return false;
  if (record.startedAt == null || now < record.startedAt || now - record.startedAt >= windowMs) {
    record.startedAt = now;
    record.count = 0;
  }
  if (record.count + amount > limit) return false;
  record.count += amount;
  return true;
}

export function snapshotFitsOutboundBudget(bufferedAmount, snapshotBytes) {
  return Number.isSafeInteger(bufferedAmount) && bufferedAmount >= 0
    && Number.isSafeInteger(snapshotBytes) && snapshotBytes >= 0
    && bufferedAmount + snapshotBytes <= MAX_OUTBOUND_BUFFERED_BYTES;
}

export class ArenaRoom extends Room {
  maxClients = ONLINE_HUMAN_COUNT;
  // Colyseus owns both initial/reconnect seat reservations and disposes only
  // after its connected-client and reservation counts are empty. Keep that
  // supported lifecycle explicit instead of racing it with an application
  // timer that cannot safely observe framework-owned initial seat holds.
  autoDispose = true;
  patchRate = 50;
  maxMessagesPerSecond = 120;
  seatReservationTimeout = ROOM_SEAT_RESERVATION_SECONDS;
  messages = {
    _: (client) => this.rejectUnsupportedMessage(client),
    input: (client, payload) => this.receiveInput(client, payload),
    "protocol-request": (client, payload) => this.receiveProtocolRequest(client, payload),
    "hello-ack": (client, payload) => this.receiveHelloAck(client, payload),
    ready: (client, payload) => this.receiveReady(client, payload),
    resync: (client, payload) => this.receiveResync(client, payload),
    "rematch-vote": (client, payload) => this.receiveRematchVote(client, payload),
  };

  static onAuth(token, options, context) {
    return authorizeAdmission(token, options, context);
  }

  operationsLogger() {
    return this.constructor.stickmanOperations?.operationsLogger || null;
  }

  serviceState() {
    return this.constructor.stickmanOperations?.serviceState || null;
  }

  serviceAcceptsAdmission() {
    const serviceState = this.serviceState();
    return serviceState === null || serviceState.isReady();
  }

  rejectionTracker() {
    return this.constructor.stickmanOperations?.rejectionTracker || null;
  }

  recordSecurityRejection(category) {
    this.rejectionTracker()?.record(category);
  }

  logLifecycle() {
    this.operationsLogger()?.info("room.lifecycle", { roomPhase: this.lifecycle });
  }

  async onCreate(options) {
    this.roomOperation = null;
    this.roomKind = null;
    this.registeredRoomId = null;
    this.creatorSessionId = null;
    // Colyseus may still dispose an instance whose async onCreate() rejects.
    // Initialize every cleanup-owned field before validation or the first
    // awaited/throwing allocation so every failed creation has the same
    // bounded, idempotent disposal path as a fully created Room.
    this.lifecycle = "waiting";
    this.reservations = new Map();
    this.negotiatingSessions = new Set();
    this.helloSentSessions = new Set();
    this.admittedSessions = new Set();
    this.handshakeTimers = new Map();
    this.readySessions = new Set();
    this.rematchVotes = new Set();
    this.rematchOpen = false;
    this.resultsDeadlineAt = null;
    this.resultsTimer = null;
    this.generationReadyTimer = null;
    this.generationReadyDeadlineAt = null;
    this.initialWaitingTimer = null;
    this.initialWaitingDeadlineAt = null;
    this.monotonicNow = () => performance.now();
    this.rejectingClients = new WeakSet();
    this.inboundRateWindows = new WeakMap();
    this.controlRateWindows = new Map();
    this.terminalSessions = new Set();
    this.rejectedInputs = 0;

    try {
      if (!this.serviceAcceptsAdmission()) throw new ServerError(503, "service unavailable");
      // The edge pairs each operation with its one official matchmaking
      // method, and the Room independently verifies the creation contract
      // before it allocates authoritative state or process-local capacity.
      const admission = validateAdmissionOptions(options);
      if (!admission.accepted
          || (admission.operation !== QUICK_MATCH_OPERATION
            && admission.operation !== CREATE_MATCH_OPERATION)) {
        throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
      }
      this.roomOperation = admission.operation;
      this.roomKind = admission.operation === QUICK_MATCH_OPERATION ? "quick" : "code";
      const registration = this.roomKind === "quick"
        ? roomRegistry.reserveQuick(this.roomId, this)
        : roomRegistry.reserveCode(this);
      if (!registration.accepted) throw new Error("room capacity reached");
      this.registeredRoomId = registration.roomId;
      if (this.roomKind === "code") {
        this.roomId = registration.roomId;
        await this.setPrivate(true, false);
        if (!this.serviceAcceptsAdmission()) throw new ServerError(503, "service unavailable");
      }

      // Match identity and seed remain server-owned: only the approved default
      // mode/map enter gameplay state, regardless of matchmaking operation.
      this.match = new AuthoritativeMatch();
      this.state = new ArenaPublicState();
      this.syncProjection();
      this.setFixedTimestep((context) => this.fixedStep(context), 60);
      this.startInitialWaitingTimer();
      this.logLifecycle();
    } catch (error) {
      this.releaseRoomRegistration();
      // __init() arms the framework's seat-reservation auto-dispose timer
      // before onCreate(). Toggle the public autoDispose property so the
      // framework clears that ten-second timer and re-arms its shorter default
      // cleanup path without depending on Room's private timer API.
      this.autoDispose = false;
      this.autoDispose = true;
      throw error;
    }
  }

  consumeInboundFrame(client, buffer) {
    const byteLength = buffer && Number(buffer.byteLength);
    if (!Number.isSafeInteger(byteLength) || byteLength < 1) {
      return this.terminateClient(client, UNSUPPORTED_MESSAGE_REASON);
    }
    let record = this.inboundRateWindows.get(client);
    if (!record) {
      record = {
        messages: { startedAt: null, count: 0 },
        bytes: { startedAt: null, count: 0 },
      };
      this.inboundRateWindows.set(client, record);
    }
    const now = this.monotonicNow();
    if (!consumeFixedWindow(
      record.messages,
      now,
      MAX_INBOUND_MESSAGES_PER_WINDOW,
      INBOUND_RATE_WINDOW_MS,
    ) || !consumeFixedWindow(
      record.bytes,
      now,
      MAX_INBOUND_BYTES_PER_WINDOW,
      INBOUND_RATE_WINDOW_MS,
      byteLength,
    )) return this.terminateClient(client, RATE_LIMIT_REASON);
    return true;
  }

  consumeApplicationMessage(client, type) {
    const sessionId = client && client.sessionId;
    const limit = type === "input" ? MAX_INPUT_ATTEMPTS_PER_WINDOW : CONTROL_MESSAGE_LIMITS[type];
    if (typeof sessionId !== "string" || !Number.isSafeInteger(limit)) {
      return this.terminateClient(client, UNSUPPORTED_MESSAGE_REASON);
    }
    let session = this.controlRateWindows.get(sessionId);
    if (!session) {
      session = { aggregate: { startedAt: null, count: 0 }, types: new Map() };
      this.controlRateWindows.set(sessionId, session);
    }
    let record = session.types.get(type);
    if (!record) {
      record = { startedAt: null, count: 0 };
      session.types.set(type, record);
    }
    const now = this.monotonicNow();
    const windowMs = type === "input" ? INPUT_ATTEMPT_WINDOW_MS : CONTROL_RATE_WINDOW_MS;
    if (!consumeFixedWindow(record, now, limit, windowMs)) {
      return this.terminateClient(client, RATE_LIMIT_REASON);
    }
    if (type !== "input" && !consumeFixedWindow(
      session.aggregate,
      now,
      MAX_CONTROL_MESSAGES_PER_WINDOW,
      CONTROL_RATE_WINDOW_MS,
    )) return this.terminateClient(client, RATE_LIMIT_REASON);
    return true;
  }

  receiveInput(client, payload) {
    if (!this.consumeApplicationMessage(client, "input")) return false;
    if (!this.admittedSessions.has(client.sessionId)
        || !this.match.actorBySession.has(client.sessionId)) {
      return this.rejectInput(client, "not-playing");
    }
    const generationReason = generationRejection(readGeneration(payload), this.match.generation);
    if (generationReason) return this.rejectInput(client, generationReason);
    if (!this.readySessions.has(client.sessionId) || this.lifecycle !== "playing") {
      return this.rejectInput(client, "not-playing");
    }
    const result = this.match.accept(client.sessionId, payload);
    if (!result.accepted) return this.rejectInput(client, result.reason);
    return true;
  }

  rejectInput(client, reason) {
    this.rejectedInputs += 1;
    this.recordSecurityRejection("control");
    this.sendBounded(client, "input-rejected", { generation: this.match.generation, reason });
    return false;
  }

  rejectControl(client, control, reason) {
    this.recordSecurityRejection("control");
    this.sendBounded(client, "control-rejected", {
      generation: this.match.generation,
      control,
      reason,
    });
    return false;
  }

  terminateClient(client, reason) {
    if (this.rejectingClients.has(client)) return false;
    this.rejectingClients.add(client);
    this.recordSecurityRejection(
      reason === RATE_LIMIT_REASON || reason === BACKPRESSURE_REASON ? "resource" : "protocol",
    );
    this.terminalSessions.add(client.sessionId);
    this.clearTerminalSession(client.sessionId);
    // Unsupported raw opcodes bypass RoomMessages' wildcard and reach this
    // Room-level frame guard before Colyseus's private force-close helper.
    // Stop queued message dispatch exactly once before issuing the fixed close.
    if (client.ref && typeof client.ref.removeAllListeners === "function") {
      client.ref.removeAllListeners("message");
    }
    client.leave(CloseCode.WITH_ERROR, reason);
    return false;
  }

  rejectUnsupportedMessage(client) {
    return this.terminateClient(client, UNSUPPORTED_MESSAGE_REASON);
  }

  _onMessage(client, buffer) {
    if (!this.consumeInboundFrame(client, buffer)) return false;
    const firstByte = buffer && buffer[0];
    if (!Number.isInteger(firstByte)) return this.rejectUnsupportedMessage(client);
    const code = firstByte & COLYSEUS_PROTOCOL_CODE_MASK;
    const modifiers = firstByte & ~COLYSEUS_PROTOCOL_CODE_MASK;
    if (modifiers !== 0 || !ALLOWED_CLIENT_PROTOCOL_CODES.has(code)) {
      return this.rejectUnsupportedMessage(client);
    }
    return super._onMessage(client, buffer);
  }

  receiveProtocolRequest(client, payload) {
    if (!this.consumeApplicationMessage(client, "protocol-request")) return false;
    if (!isExactEmptyRecord(payload)) {
      this.rejectProtocol(client);
      return false;
    }
    if (this.admittedSessions.has(client.sessionId)) {
      return this.sendBounded(client, "server-hello", Netcode.createServerHello());
    }
    if (!this.negotiatingSessions.has(client.sessionId)) {
      this.rejectProtocol(client);
      return false;
    }
    this.helloSentSessions.add(client.sessionId);
    return this.sendBounded(client, "server-hello", Netcode.createServerHello());
  }

  receiveHelloAck(client, payload) {
    if (!this.consumeApplicationMessage(client, "hello-ack")) return false;
    if (this.admittedSessions.has(client.sessionId)
        && Netcode.validateCurrentServerHello(payload).accepted
        && validateAdmissionAuth(client.auth)) return true;
    if (!this.negotiatingSessions.has(client.sessionId)
        || !this.helloSentSessions.has(client.sessionId)
        || !Netcode.validateCurrentServerHello(payload).accepted
        || !validateAdmissionAuth(client.auth)) {
      this.rejectProtocol(client);
      return false;
    }
    return this.completeAdmission(client);
  }

  receiveReady(client, payload) {
    if (!this.consumeApplicationMessage(client, "ready")) return false;
    if (!this.admittedSessions.has(client.sessionId)
        || !this.match.actorBySession.has(client.sessionId)) return false;
    const record = readExactDataRecord(payload, ["generation"]);
    const generation = record && Number.isSafeInteger(record.generation) && record.generation > 0
      ? record.generation : null;
    const reason = generationRejection(generation, this.match.generation);
    if (reason) return this.rejectControl(client, "ready", reason);
    if (this.lifecycle === "closing" || this.lifecycle === "disposed") {
      return this.rejectControl(client, "ready", "room-closing");
    }
    if (this.initialWaitingDeadlineAt != null
        && this.monotonicNow() >= this.initialWaitingDeadlineAt) {
      this.expireInitialWaiting(this.match.generation);
      return this.rejectControl(client, "ready", "room-closing");
    }
    if (this.generationReadyDeadlineAt != null
        && this.monotonicNow() >= this.generationReadyDeadlineAt) {
      this.expireGenerationReadiness(this.match.generation);
      return this.rejectControl(client, "ready", "room-closing");
    }
    if (this.readySessions.has(client.sessionId)) return true;
    this.readySessions.add(client.sessionId);
    if (!this.sendBootstrap(client)) return false;
    this.startIfReady();
    this.syncProjection();
    return true;
  }

  receiveResync(client, payload) {
    if (!this.consumeApplicationMessage(client, "resync")) return false;
    if (!this.admittedSessions.has(client.sessionId)
        || !this.match.actorBySession.has(client.sessionId)) return false;
    const record = readExactDataRecord(payload, ["generation"]);
    const generation = record && Number.isSafeInteger(record.generation) && record.generation > 0
      ? record.generation : null;
    const reason = generationRejection(generation, this.match.generation);
    if (reason) return this.rejectControl(client, "resync", reason);
    if (!this.readySessions.has(client.sessionId)) {
      return this.rejectControl(client, "resync", "not-active");
    }
    if (!["playing", "finished", "rematch-vote"].includes(this.lifecycle)) {
      return this.rejectControl(client, "resync", "not-active");
    }
    if (!this.sendSnapshot(client)) return false;
    this.sendLifecycle(client);
    return true;
  }

  receiveRematchVote(client, payload) {
    if (!this.consumeApplicationMessage(client, "rematch-vote")) return false;
    if (!this.admittedSessions.has(client.sessionId)
        || !this.match.actorBySession.has(client.sessionId)) return false;
    const record = readExactDataRecord(payload, ["generation", "vote"]);
    const generation = record && Number.isSafeInteger(record.generation) && record.generation > 0
      ? record.generation : null;
    const reason = generationRejection(generation, this.match.generation);
    if (reason) return this.rejectControl(client, "rematch-vote", reason);
    if (!this.readySessions.has(client.sessionId)) {
      return this.rejectControl(client, "rematch-vote", "not-active");
    }
    if (!record || typeof record.vote !== "boolean") {
      return this.rejectControl(client, "rematch-vote", "invalid-payload");
    }
    if (!this.rematchOpen || !["finished", "rematch-vote"].includes(this.lifecycle)) {
      return this.rejectControl(client, "rematch-vote", "rematch-closed");
    }
    if (this.resultsDeadlineAt == null || this.monotonicNow() >= this.resultsDeadlineAt) {
      this.expireResultsWindow(this.match.generation);
      return this.rejectControl(client, "rematch-vote", "rematch-closed");
    }
    const voted = this.rematchVotes.has(client.sessionId);
    if (voted === record.vote) return true;
    if (record.vote) this.rematchVotes.add(client.sessionId);
    else this.rematchVotes.delete(client.sessionId);
    this.setLifecycle(this.rematchVotes.size ? "rematch-vote" : "finished");
    if (record.vote) this.restartIfUnanimous();
    return true;
  }

  onJoin(client, options) {
    if (!["waiting", "ready"].includes(this.lifecycle)) throw new Error("match already started");
    if (this.initialWaitingDeadlineAt == null
        || this.monotonicNow() >= this.initialWaitingDeadlineAt) {
      this.expireInitialWaiting(this.match.generation);
      throw new Error("match unavailable");
    }
    const admission = validateAdmissionOptions(options);
    if (!admission.accepted
        || !validateAdmissionAuth(client.auth)
        || client.auth.operation !== admission.operation
        || client.auth.modeId !== admission.modeId
        || client.auth.mapId !== admission.mapId) throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
    if (this.roomKind === "quick") {
      if (admission.operation !== QUICK_MATCH_OPERATION) {
        throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
      }
    } else if (this.roomKind === "code") {
      if (admission.operation === CREATE_MATCH_OPERATION) {
        if (this.creatorSessionId !== null && this.creatorSessionId !== client.sessionId) {
          throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
        }
        this.creatorSessionId = client.sessionId;
      } else if (admission.operation !== JOIN_CODE_OPERATION) {
        throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
      }
    } else {
      throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
    }
    client.userData = {};
    this.beginNegotiation(client);
    this.syncProjection();
  }

  onDrop(client, code) {
    this.clearNegotiation(client.sessionId);
    this.admittedSessions.delete(client.sessionId);
    this.readySessions.delete(client.sessionId);
    this.rematchVotes.delete(client.sessionId);
    const priorReservation = this.reservations.get(client.sessionId);
    const released = this.match.disconnect(client.sessionId);
    const reconnectable = !this.terminalSessions.has(client.sessionId)
      && RECONNECTABLE_CLOSE_CODES.has(code)
      && this.lifecycle !== "closing" && this.lifecycle !== "disposed";
    if (released.accepted && reconnectable) {
      const reservation = {
        ...released,
        generation: this.match.generation,
        expiresAt: this.monotonicNow() + this.reconnectWindowSeconds() * 1000,
      };
      this.reservations.set(client.sessionId, reservation);
      client.userData = reservation;
    } else if (!released.accepted && reconnectable && priorReservation
        && priorReservation.generation === this.match.generation
        && priorReservation.expiresAt > this.monotonicNow()) {
      client.userData = priorReservation;
    } else {
      this.reservations.delete(client.sessionId);
      client.userData = {};
    }
    this.updateLifecycleAfterDeparture();
    this.syncProjection();
    const reservation = this.reservations.get(client.sessionId);
    if (reconnectable && reservation) {
      const remainingSeconds = Math.max(0, (reservation.expiresAt - this.monotonicNow()) / 1000);
      if (remainingSeconds > 0) this.allowReconnection(client, remainingSeconds).catch(() => {});
    } else {
      this.controlRateWindows.delete(client.sessionId);
    }
  }

  onReconnect(client) {
    if (this.lifecycle === "closing" || this.lifecycle === "disposed") {
      this.reservations.delete(client.sessionId);
      this.controlRateWindows.delete(client.sessionId);
      throw new Error("reconnection seat expired");
    }
    if (["waiting", "ready"].includes(this.lifecycle)
        && this.initialWaitingDeadlineAt != null
        && this.monotonicNow() >= this.initialWaitingDeadlineAt) {
      this.expireInitialWaiting(this.match.generation);
      throw new Error("reconnection seat expired");
    }
    if (this.generationReadyDeadlineAt != null
        && this.monotonicNow() >= this.generationReadyDeadlineAt) {
      this.expireGenerationReadiness(this.match.generation);
      throw new Error("reconnection seat expired");
    }
    if (!validateAdmissionAuth(client.auth)) throw new Error(INCOMPATIBLE_CLIENT_MESSAGE);
    const reservation = this.reservations.get(client.sessionId);
    if (!reservation || reservation.actorId == null
        || reservation.generation !== this.match.generation
        || !Number.isFinite(reservation.expiresAt) || reservation.expiresAt <= this.monotonicNow()) {
      this.reservations.delete(client.sessionId);
      client.userData = {};
      throw new Error("reconnection seat expired");
    }
    client.userData = reservation;
    this.beginNegotiation(client);
    this.syncProjection();
  }

  beginNegotiation(client) {
    this.clearNegotiation(client.sessionId);
    this.admittedSessions.delete(client.sessionId);
    this.readySessions.delete(client.sessionId);
    this.rematchVotes.delete(client.sessionId);
    this.negotiatingSessions.add(client.sessionId);
    const reservation = this.reservations.get(client.sessionId);
    const timeoutMs = reservation && Number.isFinite(reservation.expiresAt)
      ? Math.max(1, Math.min(HANDSHAKE_TIMEOUT_MS, reservation.expiresAt - this.monotonicNow()))
      : HANDSHAKE_TIMEOUT_MS;
    const timer = this.clock.setTimeout(() => {
      if (this.handshakeTimers.get(client.sessionId) !== timer
          || !this.negotiatingSessions.has(client.sessionId)) return;
      this.sendBounded(client, "protocol-error", { code: PROTOCOL_ERROR_CODE });
      this.terminateClient(client, "protocol negotiation timed out");
    }, timeoutMs);
    this.handshakeTimers.set(client.sessionId, timer);
  }

  clearNegotiation(sessionId) {
    this.negotiatingSessions.delete(sessionId);
    this.helloSentSessions.delete(sessionId);
    const timer = this.handshakeTimers.get(sessionId);
    if (timer && typeof timer.clear === "function") timer.clear();
    this.handshakeTimers.delete(sessionId);
  }

  rejectProtocol(client) {
    if (this.rejectingClients.has(client)) return false;
    this.sendBounded(client, "protocol-error", { code: PROTOCOL_ERROR_CODE });
    return this.terminateClient(client, "protocol negotiation failed");
  }

  clearTerminalSession(sessionId) {
    this.clearNegotiation(sessionId);
    this.admittedSessions.delete(sessionId);
    this.readySessions.delete(sessionId);
    this.rematchVotes.delete(sessionId);
    this.reservations.delete(sessionId);
    this.controlRateWindows.delete(sessionId);
    if (this.match.actorBySession.has(sessionId)) this.match.disconnect(sessionId);
    this.updateLifecycleAfterDeparture();
    this.syncProjection();
  }

  completeAdmission(client) {
    if (this.lifecycle === "closing" || this.lifecycle === "disposed") {
      this.rejectProtocol(client);
      return false;
    }
    if (["waiting", "ready"].includes(this.lifecycle)
        && this.initialWaitingDeadlineAt != null
        && this.monotonicNow() >= this.initialWaitingDeadlineAt) {
      this.expireInitialWaiting(this.match.generation);
      return false;
    }
    if (this.generationReadyDeadlineAt != null
        && this.monotonicNow() >= this.generationReadyDeadlineAt) {
      this.expireGenerationReadiness(this.match.generation);
      return false;
    }
    const reservation = this.reservations.get(client.sessionId);
    const reconnecting = reservation && Number.isInteger(reservation.actorId)
      && Number.isInteger(reservation.epoch) && Number.isInteger(reservation.generation)
      && Number.isFinite(reservation.expiresAt);
    if (reconnecting && (reservation.generation !== this.match.generation
        || reservation.expiresAt <= this.monotonicNow())) {
      this.rejectProtocol(client);
      return false;
    }
    const reservedActorIds = [...this.reservations.entries()]
      .filter(([sessionId]) => sessionId !== client.sessionId)
      .map(([, entry]) => entry.actorId);
    const bound = reconnecting
      ? this.match.bind(client.sessionId, reservation.actorId, reservation.epoch)
      : this.match.bind(client.sessionId, undefined, 1, reservedActorIds);
    if (!bound.accepted) {
      this.rejectProtocol(client);
      return false;
    }
    this.clearNegotiation(client.sessionId);
    this.reservations.delete(client.sessionId);
    this.terminalSessions.delete(client.sessionId);
    this.admittedSessions.add(client.sessionId);
    client.userData = {
      actorId: bound.actorId,
      epoch: bound.epoch,
      generation: this.match.generation,
    };
    this.updatePrestartLifecycle();
    if (!this.sendAssignment(client)) return false;
    this.syncProjection();
    return true;
  }

  updatePrestartLifecycle() {
    if (!["waiting", "ready"].includes(this.lifecycle)) return;
    const next = this.match.actorBySession.size === ONLINE_HUMAN_COUNT ? "ready" : "waiting";
    if (next !== this.lifecycle) this.setLifecycle(next);
  }

  startIfReady() {
    if (!["waiting", "ready"].includes(this.lifecycle)
        || this.match.actorBySession.size !== ONLINE_HUMAN_COUNT
        || this.admittedSessions.size !== ONLINE_HUMAN_COUNT
        || this.readySessions.size !== ONLINE_HUMAN_COUNT
        || this.reservations.size !== 0) return false;
    if (this.generationReadyDeadlineAt != null
        && this.monotonicNow() >= this.generationReadyDeadlineAt) {
      this.expireGenerationReadiness(this.match.generation);
      return false;
    }
    this.clearGenerationReadyTimer();
    this.clearInitialWaitingTimer();
    this.lock();
    this.setLifecycle("playing");
    for (const client of [...this.clients]) {
      if (this.admittedSessions.has(client.sessionId)) {
        this.sendBounded(client, "match-start", {
          generation: this.match.generation,
          tick: this.match.state.tick,
        });
      }
    }
    return true;
  }

  onLeave(client) {
    this.clearNegotiation(client.sessionId);
    this.reservations.delete(client.sessionId);
    this.terminalSessions.delete(client.sessionId);
    this.admittedSessions.delete(client.sessionId);
    this.readySessions.delete(client.sessionId);
    this.rematchVotes.delete(client.sessionId);
    this.controlRateWindows.delete(client.sessionId);
    if (this.match.actorBySession.has(client.sessionId)) this.match.disconnect(client.sessionId);
    client.userData = {};
    this.updateLifecycleAfterDeparture();
    this.syncProjection();
  }

  reconnectWindowSeconds() {
    return RECONNECT_SECONDS;
  }

  updateLifecycleAfterDeparture() {
    if (["waiting", "ready"].includes(this.lifecycle)) {
      this.updatePrestartLifecycle();
    } else if (["finished", "rematch-vote"].includes(this.lifecycle)) {
      this.setLifecycle(this.rematchVotes.size ? "rematch-vote" : "finished");
    }
  }

  clientBufferedAmount(client) {
    const value = client && client.ref && client.ref.bufferedAmount;
    return Number.isSafeInteger(value) && value >= 0 ? value : null;
  }

  sendBounded(client, type, payload) {
    let bytes;
    try {
      bytes = Buffer.byteLength(JSON.stringify({ type, payload }), "utf8");
    } catch {
      this.closeForResourceLimit();
      return false;
    }
    if (!snapshotFitsOutboundBudget(this.clientBufferedAmount(client), bytes)) {
      return this.terminateClient(client, BACKPRESSURE_REASON);
    }
    client.send(type, payload);
    const bufferedAfterSend = this.clientBufferedAmount(client);
    if (bufferedAfterSend == null || bufferedAfterSend > MAX_OUTBOUND_BUFFERED_BYTES) {
      return this.terminateClient(client, BACKPRESSURE_REASON);
    }
    return true;
  }

  sendSnapshot(client, events = []) {
    let snapshot;
    try {
      snapshot = this.match.snapshot(client.sessionId, events);
    } catch (error) {
      if (!(error instanceof SnapshotLimitError)) throw error;
      this.closeForResourceLimit();
      return false;
    }
    return this.sendBounded(client, "snapshot", snapshot);
  }

  closeForResourceLimit() {
    return this.closeRoom(CloseCode.WITH_ERROR);
  }

  clearFrameworkSeatReservations() {
    // Pinned Colyseus 0.18 keeps unconsumed initial/reconnect seats in these
    // public-runtime underscore records. Room.disconnect() rejects reconnect
    // promises but otherwise waits for an ordinary seat timeout when a peer is
    // still connected. Clear only enumerable reservations before disconnect so
    // a ten-second seat cannot outlive the five-second process drain.
    const seats = this._reservedSeats;
    const timeouts = this._reservedSeatTimeouts;
    if (seats && typeof seats === "object" && timeouts && typeof timeouts === "object") {
      for (const sessionId of Object.keys(seats)) {
        try {
          clearTimeout(timeouts[sessionId]);
        } catch {
          // Reservation deletion below is still fail-closed for late upgrades.
        }
        delete timeouts[sessionId];
        delete seats[sessionId];
      }
    }
    const attempts = this._reconnectionAttempts;
    if (attempts && typeof attempts === "object") {
      for (const token of Object.keys(attempts)) {
        const attempt = attempts[token];
        try {
          attempt?.catch?.(() => {});
          attempt?.reject?.(new ServerError(CloseCode.NORMAL_CLOSURE, "server shutdown"));
        } catch {
          // Deletion remains fail-closed; the process deadline bounds the peer.
        }
        delete attempts[token];
      }
    }
    try {
      clearTimeout(this._autoDisposeTimeout);
    } catch {
      // disconnect() below remains the terminal cleanup owner.
    }
    this._autoDisposeTimeout = undefined;
  }

  closeRoom(closeCode = CloseCode.CONSENTED) {
    if (this.lifecycle === "closing" || this.lifecycle === "disposed") return false;
    const lifecycleClients = [...this.clients]
      .filter((client) => this.admittedSessions.has(client.sessionId));
    this.setLifecycle("closing", false);
    this.clearInitialWaitingTimer();
    this.clearResultsTimer();
    this.clearGenerationReadyTimer();
    this.rematchOpen = false;
    this.resultsDeadlineAt = null;
    this.rematchVotes.clear();
    for (const client of [...this.clients]) this.terminalSessions.add(client.sessionId);
    for (const sessionId of [...this.match.actorBySession.keys()]) this.match.disconnect(sessionId);
    for (const sessionId of [...this.handshakeTimers.keys()]) this.clearNegotiation(sessionId);
    this.admittedSessions.clear();
    this.readySessions.clear();
    this.negotiatingSessions.clear();
    this.helloSentSessions.clear();
    this.reservations.clear();
    this.controlRateWindows.clear();
    this.clearFrameworkSeatReservations();
    this.syncProjection();
    if (closeCode !== CloseCode.SERVER_SHUTDOWN) {
      for (const client of lifecycleClients) {
        try {
          this.sendBounded(client, "lifecycle", this.lifecyclePayload(client.sessionId));
        } catch {
          // Authority is already neutralized; notification delivery is best-effort.
        }
      }
    }
    void this.disconnect(closeCode);
    return true;
  }

  onBeforeShutdown() {
    try {
      void Promise.resolve(this.lock()).catch(() => {});
    } catch {
      // closeRoom remains the synchronous authority boundary.
    }
    return this.closeRoom(CloseCode.SERVER_SHUTDOWN);
  }

  fixedStep(context) {
    if (!context || context.dt !== 1 / 60) throw new Error("Colyseus fixed timestep drifted from 60 Hz");
    for (const client of [...this.clients]) {
      const bufferedAmount = this.clientBufferedAmount(client);
      if (bufferedAmount == null || bufferedAmount > MAX_OUTBOUND_BUFFERED_BYTES) {
        this.terminateClient(client, BACKPRESSURE_REASON);
      }
    }
    if (this.lifecycle !== "playing") return;
    this.match.step(context.dt);
    const finished = this.match.state.match.phase === "finished";
    this.syncProjection();
    if (finished || this.match.state.tick % SNAPSHOT_INTERVAL_TICKS === 0) {
      let events;
      try {
        events = this.match.drainEvents();
      } catch (error) {
        if (!(error instanceof SnapshotLimitError)) throw error;
        this.closeForResourceLimit();
        return;
      }
      for (const client of [...this.clients]) {
        if (this.admittedSessions.has(client.sessionId)
            && this.readySessions.has(client.sessionId)) {
          this.sendSnapshot(client, events);
          if (this.lifecycle === "closing") return;
        }
      }
    }
    if (finished) this.openRematchWindow();
  }

  openRematchWindow() {
    if (this.lifecycle !== "playing" || this.match.state.match.phase !== "finished") return false;
    this.rematchVotes.clear();
    this.rematchOpen = true;
    this.resultsDeadlineAt = this.monotonicNow() + REMATCH_WINDOW_MS;
    this.setLifecycle("finished");
    const generation = this.match.generation;
    const timer = this.clock.setTimeout(() => {
      if (this.resultsTimer !== timer) return;
      this.resultsTimer = null;
      this.expireResultsWindow(generation, true);
    }, REMATCH_WINDOW_MS);
    this.resultsTimer = timer;
    return true;
  }

  restartIfUnanimous() {
    if (!this.rematchOpen || !["finished", "rematch-vote"].includes(this.lifecycle)) return false;
    if (this.resultsDeadlineAt == null || this.monotonicNow() >= this.resultsDeadlineAt) {
      this.expireResultsWindow(this.match.generation);
      return false;
    }
    const connected = [...this.clients].filter((client) => this.admittedSessions.has(client.sessionId)
      && this.readySessions.has(client.sessionId)
      && this.match.actorBySession.has(client.sessionId));
    if (connected.length !== ONLINE_HUMAN_COUNT
        || this.admittedSessions.size !== ONLINE_HUMAN_COUNT
        || this.readySessions.size !== ONLINE_HUMAN_COUNT
        || this.match.actorBySession.size !== ONLINE_HUMAN_COUNT
        || this.reservations.size !== 0
        || this.negotiatingSessions.size !== 0
        || connected.some((client) => !this.rematchVotes.has(client.sessionId))) return false;

    this.rematchOpen = false;
    this.resultsDeadlineAt = null;
    this.clearResultsTimer();
    this.rematchVotes.clear();
    this.setLifecycle("restarting");
    const restarted = this.match.restartGeneration();
    if (!restarted.accepted) throw new Error("authoritative rematch restart failed");
    this.readySessions.clear();
    for (const client of connected) {
      client.userData = {
        actorId: this.match.actorBySession.get(client.sessionId),
        epoch: this.match.epochs.get(client.sessionId),
        generation: this.match.generation,
      };
    }
    this.setLifecycle("ready", false);
    this.startGenerationReadyTimer();
    for (const client of connected) this.sendAssignment(client);
    this.broadcastLifecycle();
    return true;
  }

  startGenerationReadyTimer() {
    this.clearGenerationReadyTimer();
    const generation = this.match.generation;
    this.generationReadyDeadlineAt = this.monotonicNow() + GENERATION_READY_TIMEOUT_MS;
    const timer = this.clock.setTimeout(() => {
      if (this.generationReadyTimer !== timer) return;
      this.generationReadyTimer = null;
      this.expireGenerationReadiness(generation, true);
    }, GENERATION_READY_TIMEOUT_MS);
    this.generationReadyTimer = timer;
  }

  startInitialWaitingTimer() {
    this.clearInitialWaitingTimer();
    const generation = this.match.generation;
    this.initialWaitingDeadlineAt = this.monotonicNow() + INITIAL_WAITING_TIMEOUT_MS;
    const timer = this.clock.setTimeout(() => {
      if (this.initialWaitingTimer !== timer) return;
      this.initialWaitingTimer = null;
      this.expireInitialWaiting(generation, true);
    }, INITIAL_WAITING_TIMEOUT_MS);
    this.initialWaitingTimer = timer;
  }

  expireInitialWaiting(generation, force = false) {
    if (generation !== this.match.generation
        || !["waiting", "ready"].includes(this.lifecycle)
        || (!force && (this.initialWaitingDeadlineAt == null
          || this.monotonicNow() < this.initialWaitingDeadlineAt))) return false;
    return this.closeRoom(CloseCode.CONSENTED);
  }

  expireResultsWindow(generation, force = false) {
    if (generation !== this.match.generation || !this.rematchOpen
        || !["finished", "rematch-vote"].includes(this.lifecycle)
        || (!force && (this.resultsDeadlineAt == null
          || this.monotonicNow() < this.resultsDeadlineAt))) return false;
    return this.closeRoom(CloseCode.CONSENTED);
  }

  expireGenerationReadiness(generation, force = false) {
    if (generation !== this.match.generation
        || !["waiting", "ready"].includes(this.lifecycle)
        || (!force && (this.generationReadyDeadlineAt == null
          || this.monotonicNow() < this.generationReadyDeadlineAt))) return false;
    return this.closeRoom(CloseCode.CONSENTED);
  }

  clearInitialWaitingTimer() {
    const timer = this.initialWaitingTimer;
    if (timer && typeof timer.clear === "function") timer.clear();
    this.initialWaitingTimer = null;
    this.initialWaitingDeadlineAt = null;
  }

  clearResultsTimer() {
    const timer = this.resultsTimer;
    if (timer && typeof timer.clear === "function") timer.clear();
    this.resultsTimer = null;
  }

  clearGenerationReadyTimer() {
    const timer = this.generationReadyTimer;
    if (timer && typeof timer.clear === "function") timer.clear();
    this.generationReadyTimer = null;
    this.generationReadyDeadlineAt = null;
  }

  setLifecycle(next, broadcast = true) {
    if (next === this.lifecycle) {
      this.syncProjection();
      if (broadcast) this.broadcastLifecycle();
      return;
    }
    const allowed = LIFECYCLE_TRANSITIONS[this.lifecycle];
    if (!allowed || !allowed.has(next)) {
      throw new Error(`invalid Arena lifecycle transition: ${this.lifecycle} -> ${next}`);
    }
    this.lifecycle = next;
    this.syncProjection();
    if (broadcast) this.broadcastLifecycle();
    this.logLifecycle();
  }

  lifecyclePayload(sessionId) {
    const remaining = this.rematchOpen && this.resultsDeadlineAt != null
      ? Math.ceil(Math.max(0, Math.min(
        REMATCH_WINDOW_MS,
        this.resultsDeadlineAt - this.monotonicNow(),
      ))) : 0;
    return {
      generation: this.match.generation,
      phase: this.lifecycle,
      rematchOpen: this.rematchOpen,
      rematchVoted: this.rematchVotes.has(sessionId),
      rematchVotes: this.rematchVotes.size,
      rematchRequired: ONLINE_HUMAN_COUNT,
      rematchRemainingMs: remaining,
    };
  }

  sendLifecycle(client) {
    if (this.admittedSessions.has(client.sessionId)) {
      return this.sendBounded(client, "lifecycle", this.lifecyclePayload(client.sessionId));
    }
    return true;
  }

  broadcastLifecycle() {
    for (const client of this.clients) this.sendLifecycle(client);
  }

  sendAssignment(client) {
    const userData = client.userData || {};
    return this.sendBounded(client, "assignment", {
      actorId: userData.actorId,
      epoch: userData.epoch,
      generation: this.match.generation,
      lifecycle: this.lifecycle,
      simVersion: this.match.state.version,
      modeId: this.match.state.config.modeId,
      mapId: this.match.state.config.mapId,
      seed: this.match.state.seed,
      tickRate: 60,
      compatibility: Netcode.createServerHello(),
    });
  }

  sendBootstrap(client) {
    if (!this.sendSnapshot(client)) return false;
    if (!this.sendLifecycle(client)) return false;
    if (this.lifecycle === "playing") {
      if (!this.sendBounded(client, "match-start", {
        generation: this.match.generation,
        tick: this.match.state.tick,
      })) return false;
    }
    return true;
  }

  syncProjection() {
    if (!this.state || this.lifecycle === "disposed") return;
    const projection = this.match.projection({
      started: this.lifecycle === "playing",
      lifecycle: this.lifecycle,
      rematchOpen: this.rematchOpen,
      rematchVotes: this.rematchVotes.size,
      rematchRequired: ONLINE_HUMAN_COUNT,
    });
    for (const [key, value] of Object.entries(projection)) this.state[key] = value;
  }

  releaseRoomRegistration() {
    if (this.registeredRoomId === null) return false;
    const released = roomRegistry.release(this.registeredRoomId, this);
    if (released) this.registeredRoomId = null;
    return released;
  }

  onDispose() {
    if (this.lifecycle !== "closing" && this.lifecycle !== "disposed") {
      this.setLifecycle("closing", false);
    }
    this.clearInitialWaitingTimer();
    this.clearResultsTimer();
    this.clearGenerationReadyTimer();
    for (const timer of this.handshakeTimers.values()) {
      if (timer && typeof timer.clear === "function") timer.clear();
    }
    this.handshakeTimers.clear();
    this.rematchVotes.clear();
    this.readySessions.clear();
    this.admittedSessions.clear();
    this.negotiatingSessions.clear();
    this.helloSentSessions.clear();
    this.reservations.clear();
    this.controlRateWindows.clear();
    this.terminalSessions.clear();
    this.releaseRoomRegistration();
    if (this.lifecycle !== "disposed") this.setLifecycle("disposed", false);
  }
}

export function createConfiguredArenaRoom({
  operationsLogger,
  rejectionTracker,
  requestPolicy,
  serviceState,
}) {
  class ConfiguredArenaRoom extends ArenaRoom {
    static onAuth(token, options, context) {
      if (serviceState != null && !serviceState.isReady()) {
        throw new ServerError(503, "service unavailable");
      }
      return authorizeAdmission(token, options, context, requestPolicy);
    }
  }
  ConfiguredArenaRoom.stickmanOperations = Object.freeze({
    operationsLogger,
    rejectionTracker,
    serviceState,
  });
  return ConfiguredArenaRoom;
}

export const PASS12B3B1_RECONNECT_SECONDS = RECONNECT_SECONDS;
export const PASS12B1_HANDSHAKE_TIMEOUT_MS = HANDSHAKE_TIMEOUT_MS;
export const PASS12B1_UNSUPPORTED_MESSAGE_REASON = UNSUPPORTED_MESSAGE_REASON;
export const PASS12B2_REMATCH_WINDOW_MS = REMATCH_WINDOW_MS;
export const PASS12B2_GENERATION_READY_TIMEOUT_MS = GENERATION_READY_TIMEOUT_MS;
export const PASS12B3B2_INITIAL_WAITING_TIMEOUT_MS = INITIAL_WAITING_TIMEOUT_MS;
export const PASS12B3B2_INBOUND_RATE_WINDOW_MS = INBOUND_RATE_WINDOW_MS;
export const PASS12B3B2_MAX_INBOUND_MESSAGES = MAX_INBOUND_MESSAGES_PER_WINDOW;
export const PASS12B3B2_MAX_INBOUND_BYTES = MAX_INBOUND_BYTES_PER_WINDOW;
export const PASS12B3B2_CONTROL_RATE_WINDOW_MS = CONTROL_RATE_WINDOW_MS;
export const PASS12B3B2_MAX_CONTROL_MESSAGES = MAX_CONTROL_MESSAGES_PER_WINDOW;
export const PASS12B3B2_CONTROL_MESSAGE_LIMITS = CONTROL_MESSAGE_LIMITS;
export const PASS12B3B2_INPUT_ATTEMPT_WINDOW_MS = INPUT_ATTEMPT_WINDOW_MS;
export const PASS12B3B2_MAX_INPUT_ATTEMPTS = MAX_INPUT_ATTEMPTS_PER_WINDOW;
export const PASS12B3B2_MAX_OUTBOUND_BUFFERED_BYTES = MAX_OUTBOUND_BUFFERED_BYTES;
