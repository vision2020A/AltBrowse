const OWNED_SHUTDOWN_EVENTS = Object.freeze(["SIGTERM", "SIGINT", "uncaughtException"]);
const OWNED_SIGNAL_EVENTS = Object.freeze(["SIGTERM", "SIGINT"]);

export function createShutdownController(options = {}) {
  const signalTarget = options.signalTarget || process;
  const onComplete = typeof options.onComplete === "function" ? options.onComplete : null;
  if (!signalTarget || typeof signalTarget.on !== "function"
      || typeof signalTarget.removeListener !== "function") {
    throw new TypeError("signal target must expose on() and removeListener()");
  }
  let application = null;
  let requestedEvent = null;
  let installed = false;
  let captureInstalled = false;
  let settled = false;
  let lateFatalReported = false;
  let settledResult = null;
  let runningPromise = null;
  let resolveCompletion;
  const completion = new Promise((resolve) => {
    resolveCompletion = resolve;
  });

  function normalizeResult(result) {
    return Object.freeze({
      accepted: result?.accepted === true,
      timedOut: result?.timedOut === true,
    });
  }

  function dispose() {
    if (!installed) return false;
    installed = false;
    for (const event of OWNED_SIGNAL_EVENTS) {
      signalTarget.removeListener(event, handlers[event]);
    }
    if (captureInstalled) {
      captureInstalled = false;
      signalTarget.setUncaughtExceptionCaptureCallback(null);
    } else {
      signalTarget.removeListener("uncaughtException", handlers.uncaughtException);
    }
    signalTarget.removeListener("unhandledRejection", handlers.unhandledRejection);
    return true;
  }

  function settle(result) {
    if (settled) return;
    settled = true;
    const normalized = normalizeResult(result);
    const fatal = requestedEvent === "uncaughtException";
    const finalResult = fatal
      ? Object.freeze({ accepted: false, timedOut: normalized.timedOut })
      : normalized;
    settledResult = finalResult;
    resolveCompletion(finalResult);
    try {
      onComplete?.(finalResult, Object.freeze({ fatal }));
    } catch {
      // Completion reporting never re-enters or expands shutdown authority.
    }
  }

  function begin() {
    if (!requestedEvent || !application || runningPromise) return runningPromise;
    try {
      runningPromise = Promise.resolve(application.shutdown(
        requestedEvent === "uncaughtException" ? "failed" : "shutdown-signal",
      ));
    } catch {
      runningPromise = Promise.reject(new Error("shutdown unavailable"));
    }
    runningPromise.then(settle, () => settle({ accepted: false, timedOut: false }));
    return runningPromise;
  }

  function request(event) {
    if (!OWNED_SHUTDOWN_EVENTS.includes(event)) throw new TypeError("unknown shutdown event");
    if (requestedEvent === null || event === "uncaughtException") requestedEvent = event;
    if (event === "uncaughtException" && application && runningPromise) {
      try {
        application.shutdown("failed");
      } catch {
        // The original in-flight shutdown remains the bounded cleanup owner.
      }
    }
    if (settled && event === "uncaughtException" && !lateFatalReported) {
      lateFatalReported = true;
      const finalResult = Object.freeze({
        accepted: false,
        timedOut: settledResult?.timedOut === true,
      });
      try {
        onComplete?.(finalResult, Object.freeze({ fatal: true }));
      } catch {
        // Late fatal reporting only raises the already-scheduled process outcome.
      }
      return completion;
    }
    begin();
    return completion;
  }

  const handlers = Object.freeze({
    SIGTERM: () => request("SIGTERM"),
    SIGINT: () => request("SIGINT"),
    uncaughtException: () => request("uncaughtException"),
    unhandledRejection: () => {
      request("uncaughtException");
      // Stop EventEmitter dispatch before later framework reporters receive the
      // private rejection. Node routes this redacted sentinel to our exclusive
      // exception-capture callback, which only rejoins the same failed drain.
      if (captureInstalled) throw null;
    },
  });

  function install() {
    if (installed) return false;
    const supportsCapture = typeof signalTarget.setUncaughtExceptionCaptureCallback === "function"
      && typeof signalTarget.hasUncaughtExceptionCaptureCallback === "function";
    if (supportsCapture && signalTarget.hasUncaughtExceptionCaptureCallback()) {
      throw new Error("shutdown capture unavailable");
    }
    try {
      if (supportsCapture) {
        signalTarget.setUncaughtExceptionCaptureCallback(handlers.uncaughtException);
        captureInstalled = true;
      } else {
        signalTarget.on("uncaughtException", handlers.uncaughtException);
      }
      for (const event of OWNED_SIGNAL_EVENTS) signalTarget.on(event, handlers[event]);
      if (typeof signalTarget.prependListener === "function") {
        signalTarget.prependListener("unhandledRejection", handlers.unhandledRejection);
      } else {
        signalTarget.on("unhandledRejection", handlers.unhandledRejection);
      }
      installed = true;
    } catch {
      for (const event of OWNED_SIGNAL_EVENTS) {
        signalTarget.removeListener(event, handlers[event]);
      }
      signalTarget.removeListener("uncaughtException", handlers.uncaughtException);
      signalTarget.removeListener("unhandledRejection", handlers.unhandledRejection);
      if (captureInstalled) {
        captureInstalled = false;
        try {
          signalTarget.setUncaughtExceptionCaptureCallback(null);
        } catch {
          // Installation still fails closed when cleanup cannot release capture.
        }
      }
      throw new Error("shutdown capture unavailable");
    }
    return true;
  }

  function attach(nextApplication) {
    if (!nextApplication || typeof nextApplication.shutdown !== "function") {
      throw new TypeError("application must expose shutdown()");
    }
    if (application && application !== nextApplication) {
      throw new Error("shutdown application already attached");
    }
    application = nextApplication;
    begin();
    return application;
  }

  function fail() {
    settle({ accepted: false, timedOut: false });
    return completion;
  }

  return Object.freeze({
    attach,
    dispose,
    fail,
    hasRequested: () => requestedEvent !== null,
    install,
    request,
    wait: () => completion,
  });
}

export async function startConfiguredApplication(
  runtimeConfig,
  loadApplication = undefined,
  options = undefined,
) {
  const loader = typeof loadApplication === "function"
    ? loadApplication
    : () => import("./app.config.mjs");
  const shutdownController = options?.shutdownController || null;
  let application;
  try {
    const module = await loader();
    if (!module || typeof module.createApplication !== "function") {
      throw new TypeError("application factory unavailable");
    }
    application = module.createApplication(runtimeConfig);
    shutdownController?.attach(application);
    if (shutdownController?.hasRequested()) {
      await shutdownController.wait();
      return Object.freeze({ accepted: false, interrupted: true, application });
    }
    await application.listen();
    if (shutdownController?.hasRequested()) {
      await shutdownController.wait();
      return Object.freeze({ accepted: false, interrupted: true, application });
    }
    application.markReady();
    return Object.freeze({ accepted: true, application });
  } catch {
    if (shutdownController?.hasRequested()) {
      if (!application) shutdownController.fail();
      await shutdownController.wait();
      return Object.freeze({
        accepted: false,
        interrupted: true,
        application: application || null,
      });
    }
    try {
      await application?.abortStartup();
    } catch {
      // Startup failure handling must stay fixed even if cleanup itself fails.
    }
    return Object.freeze({ accepted: false, application: application || null });
  }
}
