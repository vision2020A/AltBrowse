import crypto from "node:crypto";
import { Sim, Bots, Netcode } from "./shared-runtime.mjs";
import { MultiHumanInputAggregator } from "./input-aggregator.mjs";

export const ONLINE_HUMAN_COUNT = 2;
export const ONLINE_BOT_COUNT = 2;
export const SNAPSHOT_INTERVAL_TICKS = 3;
export const INITIAL_MATCH_GENERATION = 1;

const REPLAY_ANALOG_FIELDS = Object.freeze(["moveX", "moveY", "aimX", "aimY"]);
const REPLAY_BUTTON_FIELDS = Object.freeze([
  "jump", "attack", "pickup", "reload", "drop", "rematch",
]);
const REPLAY_CHUNK_CAPACITY = 256;

export class SnapshotLimitError extends Error {
  constructor(message) {
    super(message);
    this.name = "SnapshotLimitError";
  }
}

export function snapshotJsonBytes(snapshot) {
  return Buffer.byteLength(JSON.stringify(snapshot), "utf8");
}

class CompactReplayLedger {
  constructor(actorIds, maxEntries) {
    this.actorIds = Object.freeze(actorIds.slice());
    this.maxEntries = maxEntries;
    this.length = 0;
    this.capacity = 0;
    this.chunks = [];
  }

  allocateChunk() {
    const capacity = Math.min(REPLAY_CHUNK_CAPACITY, this.maxEntries - this.capacity);
    if (capacity < 1) throw new RangeError("authoritative replay ledger exceeded regulation bound");
    const actorCount = this.actorIds.length;
    this.chunks.push({
      capacity,
      ticks: new Uint32Array(capacity),
      analogs: new Float64Array(capacity * actorCount * REPLAY_ANALOG_FIELDS.length),
      weapons: new Uint8Array(capacity * actorCount),
      buttons: new Uint8Array(capacity * actorCount),
    });
    this.capacity += capacity;
  }

  chunkAt(entry) {
    const chunk = this.chunks[Math.floor(entry / REPLAY_CHUNK_CAPACITY)];
    if (!chunk) throw new RangeError("authoritative replay chunk is unavailable");
    return { chunk, localEntry: entry % REPLAY_CHUNK_CAPACITY };
  }

  append(frame) {
    if (this.length >= this.maxEntries) {
      throw new RangeError("authoritative replay ledger exceeded regulation bound");
    }
    if (this.length >= this.capacity) this.allocateChunk();
    const entry = this.length;
    const { chunk, localEntry } = this.chunkAt(entry);
    const actorCount = this.actorIds.length;
    chunk.ticks[localEntry] = frame.tick;
    for (let actorIndex = 0; actorIndex < actorCount; actorIndex += 1) {
      const actor = frame.actors[actorIndex];
      if (!actor || actor.id !== this.actorIds[actorIndex]) {
        throw new Error("authoritative replay actor order changed");
      }
      const actorOffset = localEntry * actorCount + actorIndex;
      const analogOffset = actorOffset * REPLAY_ANALOG_FIELDS.length;
      for (let fieldIndex = 0; fieldIndex < REPLAY_ANALOG_FIELDS.length; fieldIndex += 1) {
        chunk.analogs[analogOffset + fieldIndex] = actor[REPLAY_ANALOG_FIELDS[fieldIndex]];
      }
      chunk.weapons[actorOffset] = actor.weaponSlot == null ? 0 : actor.weaponSlot;
      let mask = 0;
      for (let buttonIndex = 0; buttonIndex < REPLAY_BUTTON_FIELDS.length; buttonIndex += 1) {
        if (actor.buttons[REPLAY_BUTTON_FIELDS[buttonIndex]]) mask |= 1 << buttonIndex;
      }
      chunk.buttons[actorOffset] = mask;
    }
    this.length += 1;
  }

  toArray() {
    const result = new Array(this.length);
    const actorCount = this.actorIds.length;
    for (let entry = 0; entry < this.length; entry += 1) {
      const { chunk, localEntry } = this.chunkAt(entry);
      const actors = new Array(actorCount);
      for (let actorIndex = 0; actorIndex < actorCount; actorIndex += 1) {
        const actorOffset = localEntry * actorCount + actorIndex;
        const analogOffset = actorOffset * REPLAY_ANALOG_FIELDS.length;
        const mask = chunk.buttons[actorOffset];
        const buttonRecord = {};
        for (let buttonIndex = 0; buttonIndex < REPLAY_BUTTON_FIELDS.length; buttonIndex += 1) {
          buttonRecord[REPLAY_BUTTON_FIELDS[buttonIndex]] = Boolean(mask & (1 << buttonIndex));
        }
        actors[actorIndex] = {
          id: this.actorIds[actorIndex],
          moveX: chunk.analogs[analogOffset],
          moveY: chunk.analogs[analogOffset + 1],
          aimX: chunk.analogs[analogOffset + 2],
          aimY: chunk.analogs[analogOffset + 3],
          weaponSlot: chunk.weapons[actorOffset] || null,
          buttons: buttonRecord,
        };
      }
      result[entry] = { tick: chunk.ticks[localEntry], actors };
    }
    return result;
  }

  reset(actorIds) {
    if (actorIds.length !== this.actorIds.length
        || actorIds.some((actorId, index) => actorId !== this.actorIds[index])) {
      throw new Error("authoritative replay actor order changed across generation");
    }
    for (const chunk of this.chunks) {
      chunk.ticks.fill(0);
      chunk.analogs.fill(0);
      chunk.weapons.fill(0);
      chunk.buttons.fill(0);
    }
    this.length = 0;
  }

  stats() {
    const actorCount = this.actorIds.length;
    const bytesPerEntry = Uint32Array.BYTES_PER_ELEMENT
      + actorCount * REPLAY_ANALOG_FIELDS.length * Float64Array.BYTES_PER_ELEMENT
      + actorCount * Uint8Array.BYTES_PER_ELEMENT * 2;
    const retainedBytes = this.chunks.reduce((total, chunk) => total
      + chunk.ticks.byteLength + chunk.analogs.byteLength
      + chunk.weapons.byteLength + chunk.buttons.byteLength, 0);
    return Object.freeze({
      entries: this.length,
      capacity: this.capacity,
      maxEntries: this.maxEntries,
      retainedBytes,
      maxRetainedBytes: this.maxEntries * bytesPerEntry,
    });
  }
}

function copy(value) {
  return JSON.parse(JSON.stringify(value));
}

export function stateHash(state) {
  return crypto.createHash("sha256").update(Sim.serialize(state)).digest("hex");
}

export function serverSeed() {
  const seed = crypto.randomBytes(4).readUInt32LE(0);
  return seed || 0x51a7f00d;
}

function validSeed(value) {
  return Number.isSafeInteger(value) && value >= 1 && value <= 0xffffffff;
}

export class AuthoritativeMatch {
  constructor(options = {}) {
    const humanCount = options.humanCount ?? ONLINE_HUMAN_COUNT;
    const botCount = options.botCount ?? ONLINE_BOT_COUNT;
    const initialSeed = options.seed ?? serverSeed();
    if (!validSeed(initialSeed)) throw new RangeError("seed must be a nonzero unsigned 32-bit integer");
    if (options.seedSource !== undefined && typeof options.seedSource !== "function") {
      throw new TypeError("seedSource must be a function");
    }
    this.humanCount = humanCount;
    this.botCount = botCount;
    this.generation = INITIAL_MATCH_GENERATION;
    this.seedSource = options.seedSource || serverSeed;
    this.inputOptions = {
      maxFutureTicks: options.maxFutureTicks,
      maxPastTicks: options.maxPastTicks,
      maxMessagesPerSecond: options.maxMessagesPerSecond,
      maxSequenceAdvance: options.maxSequenceAdvance,
      maxHeldInputTicks: options.maxHeldInputTicks,
    };
    this.state = Sim.createState({
      seed: initialSeed,
      humanCount,
      botCount,
      modeId: Sim.DEFAULT_MODE_ID,
      mapId: Sim.DEFAULT_MAP_ID
    });
    this.humanActorIds = this.state.fighters.filter((fighter) => !fighter.isBot).map((fighter) => fighter.id);
    this.botActorIds = this.state.fighters.filter((fighter) => fighter.isBot).map((fighter) => fighter.id);
    this.sessionByActor = new Map();
    this.actorBySession = new Map();
    this.epochs = new Map();
    this.pendingEvents = [];
    this.pendingEventDrops = 0;
    this.ledger = this.createReplayLedger();
    this.inputs = this.createInputs();
  }

  createReplayLedger() {
    return new CompactReplayLedger(
      this.state.fighters.map((fighter) => fighter.id),
      this.state.config.timeLimitTicks,
    );
  }

  createInputs() {
    return new MultiHumanInputAggregator({
      actorIds: this.state.fighters.map((fighter) => fighter.id),
      botActorIds: this.botActorIds,
      makeBotInput: (simState, fighter) => Bots.makeBotInput(simState, fighter),
      generation: this.generation,
      ...this.inputOptions,
    });
  }

  nextSeed() {
    const candidate = this.seedSource();
    if (!validSeed(candidate)) {
      throw new RangeError("seedSource must return a nonzero unsigned 32-bit integer");
    }
    if (candidate !== this.state.seed) return candidate;
    return ((candidate + 0x9e3779b9) >>> 0) || 0x6d2b79f5;
  }

  bind(sessionId, requestedActorId, epoch = 1, reservedActorIds = []) {
    if (typeof sessionId !== "string" || !sessionId || this.actorBySession.has(sessionId)) {
      return { accepted: false, reason: "session-bound" };
    }
    const reserved = new Set(Array.isArray(reservedActorIds) ? reservedActorIds : []);
    let actorId = requestedActorId;
    if (actorId == null) {
      actorId = this.humanActorIds.find((id) => !this.sessionByActor.has(id) && !reserved.has(id));
    }
    if (!this.humanActorIds.includes(actorId) || this.sessionByActor.has(actorId)) {
      return { accepted: false, reason: "seat-unavailable" };
    }
    const result = this.inputs.bind(sessionId, actorId, epoch);
    if (!result.accepted) return result;
    this.actorBySession.set(sessionId, actorId);
    this.sessionByActor.set(actorId, sessionId);
    this.epochs.set(sessionId, epoch);
    return { accepted: true, actorId, epoch };
  }

  disconnect(sessionId) {
    const actorId = this.actorBySession.get(sessionId);
    if (actorId == null) return { accepted: false, reason: "session-unbound" };
    const epoch = (this.epochs.get(sessionId) || 1) + 1;
    this.inputs.unbind(sessionId);
    this.actorBySession.delete(sessionId);
    this.sessionByActor.delete(actorId);
    this.epochs.delete(sessionId);
    return { accepted: true, actorId, epoch };
  }

  accept(sessionId, payload, nowMs) {
    return this.inputs.accept(sessionId, payload, this.state.tick, nowMs);
  }

  restartGeneration() {
    if (this.state.match.phase !== "finished") {
      return { accepted: false, reason: "match-not-finished", generation: this.generation };
    }
    if (this.generation >= Number.MAX_SAFE_INTEGER) {
      throw new RangeError("match generation exhausted");
    }
    const bindings = [...this.actorBySession.entries()].map(([sessionId, actorId]) => ({
      sessionId,
      actorId,
      epoch: this.epochs.get(sessionId),
    }));
    const seed = this.nextSeed();
    this.generation += 1;
    Sim.resetMatch(this.state, { seed });
    this.inputs = this.createInputs();
    for (const binding of bindings) {
      const rebound = this.inputs.bind(binding.sessionId, binding.actorId, binding.epoch);
      if (!rebound.accepted) throw new Error("failed to preserve actor binding across generation");
    }
    this.pendingEvents = [];
    this.pendingEventDrops = 0;
    this.ledger.reset(this.state.fighters.map((fighter) => fighter.id));
    return { accepted: true, generation: this.generation, seed };
  }

  step(dt = Sim.STEP) {
    if (dt !== Sim.STEP) throw new Error("AuthoritativeMatch requires dt = 1/60");
    if (this.state.match.phase !== "playing") return this.state;
    const frame = this.inputs.frame(this.state, this.state.tick);
    Sim.fixedUpdate(this.state, frame, Sim.STEP);
    this.ledger.append(frame);
    this.captureEvents(this.state.events);
    return this.state;
  }

  captureEvents(events) {
    if (!Array.isArray(events) || events.length === 0) return;
    this.pendingEvents.push(...copy(events));
    if (this.pendingEvents.length > Netcode.MAX_SNAPSHOT_EVENTS) {
      const overflow = this.pendingEvents.length - Netcode.MAX_SNAPSHOT_EVENTS;
      this.pendingEvents.splice(0, overflow);
      this.pendingEventDrops += overflow;
    }
  }

  drainEvents() {
    const events = this.pendingEvents;
    this.pendingEvents = [];
    if (this.pendingEventDrops) {
      const dropped = this.pendingEventDrops;
      this.pendingEventDrops = 0;
      throw new SnapshotLimitError(`authoritative event backlog dropped ${dropped} events`);
    }
    return events;
  }

  snapshot(sessionId, events = []) {
    if (!Array.isArray(events) || events.length > Netcode.MAX_SNAPSHOT_EVENTS) {
      throw new SnapshotLimitError("authoritative snapshot event batch exceeds its limit");
    }
    const ack = this.inputs.ackFor(sessionId);
    const actorId = this.actorBySession.has(sessionId) ? this.actorBySession.get(sessionId) : null;
    const serialized = Sim.serialize(this.state);
    const snapshot = {
      generation: this.generation,
      simVersion: Sim.VERSION,
      modeId: this.state.config.modeId,
      mapId: this.state.config.mapId,
      seed: this.state.seed,
      tick: this.state.tick,
      actorId,
      epoch: this.epochs.get(sessionId) ?? null,
      ackSequence: ack ? ack.sequence : -1,
      stateHash: crypto.createHash("sha256").update(serialized).digest("hex"),
      state: JSON.parse(serialized),
      events: copy(events)
    };
    if (snapshotJsonBytes(snapshot) > Netcode.MAX_SNAPSHOT_JSON_BYTES) {
      throw new SnapshotLimitError("authoritative snapshot exceeds its byte limit");
    }
    return snapshot;
  }

  projection({ started, lifecycle, rematchOpen, rematchVotes, rematchRequired }) {
    return {
      generation: this.generation,
      simVersion: Sim.VERSION,
      modeId: this.state.config.modeId,
      mapId: this.state.config.mapId,
      lifecycle,
      started: !!started,
      connectedPlayers: this.actorBySession.size,
      rematchOpen: !!rematchOpen,
      rematchVotes,
      rematchRequired,
    };
  }

  replayLedger() {
    return this.ledger.toArray();
  }

  replayLedgerStats() {
    return this.ledger.stats();
  }
}
