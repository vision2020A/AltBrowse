import { schema, t } from "@colyseus/schema";

// Colyseus owns this small transport projection. The canonical simulation
// remains the plain serializable StickSim state held privately by ArenaRoom.
export const ArenaPublicState = schema({
  generation: t.number(),
  simVersion: t.number(),
  modeId: t.string(),
  mapId: t.string(),
  lifecycle: t.string(),
  started: t.boolean(),
  connectedPlayers: t.number(),
  rematchOpen: t.boolean(),
  rematchVotes: t.number(),
  rematchRequired: t.number()
}, "ArenaPublicState");
