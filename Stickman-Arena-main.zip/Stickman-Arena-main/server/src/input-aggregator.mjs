export const INPUT_ROOT_KEYS = Object.freeze([
  "generation",
  "sequence",
  "clientTick",
  "moveX",
  "moveY",
  "aimX",
  "aimY",
  "weaponSlot",
  "buttons",
]);

export const INPUT_BUTTON_KEYS = Object.freeze([
  "jump",
  "attack",
  "pickup",
  "reload",
  "drop",
  "rematch",
]);

export const HELD_BUTTON_KEYS = Object.freeze(["attack"]);
export const EDGE_BUTTON_KEYS = Object.freeze([
  "jump",
  "pickup",
  "reload",
  "drop",
]);

export const DEFAULT_MAX_FUTURE_TICKS = 120;
export const DEFAULT_MAX_PAST_TICKS = 30;
export const DEFAULT_MAX_MESSAGES_PER_SECOND = 120;
export const DEFAULT_MAX_SEQUENCE_ADVANCE = 120;
export const DEFAULT_MAX_HELD_INPUT_TICKS = 60;

const ROOT_KEY_SET = new Set(INPUT_ROOT_KEYS);
const BUTTON_KEY_SET = new Set(INPUT_BUTTON_KEYS);

function isSafeNonnegativeInteger(value) {
  return Number.isSafeInteger(value) && value >= 0;
}

function readPlainDataObjectWithExactKeys(value, keys, keySet) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) return false;

  const ownKeys = Reflect.ownKeys(value);
  if (ownKeys.length !== keys.length) return false;
  const values = Object.create(null);
  for (const key of ownKeys) {
    if (typeof key !== "string" || !keySet.has(key)) return false;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor) || descriptor.enumerable !== true) return false;
    values[key] = descriptor.value;
  }
  for (const key of keys) {
    if (!Object.prototype.hasOwnProperty.call(value, key)) return false;
  }
  return values;
}

function validAnalog(value) {
  return Number.isFinite(value) && value >= -1 && value <= 1;
}

function normalizePayload(payload) {
  try {
    const root = readPlainDataObjectWithExactKeys(payload, INPUT_ROOT_KEYS, ROOT_KEY_SET);
    if (!root) return null;
    if (!Number.isSafeInteger(root.generation) || root.generation < 1) return null;
    if (!isSafeNonnegativeInteger(root.sequence)) return null;
    if (!isSafeNonnegativeInteger(root.clientTick)) return null;
    if (!validAnalog(root.moveX) || !validAnalog(root.moveY)) return null;
    if (!validAnalog(root.aimX) || !validAnalog(root.aimY)) return null;
    if (root.weaponSlot !== null
        && (!Number.isInteger(root.weaponSlot)
          || root.weaponSlot < 1
          || root.weaponSlot > 6)) return null;
    const buttons = readPlainDataObjectWithExactKeys(root.buttons, INPUT_BUTTON_KEYS, BUTTON_KEY_SET);
    if (!buttons) return null;
    for (const key of INPUT_BUTTON_KEYS) {
      if (typeof buttons[key] !== "boolean") return null;
    }
    // Pass 12 owns authoritative rematch lifecycle and match generations.
    // Pass 11 keeps the canonical field present but accepts only its neutral
    // value so one client cannot reset a Room or roll the snapshot tick back.
    if (buttons.rematch) return null;
    return {
      generation: root.generation,
      sequence: root.sequence,
      clientTick: root.clientTick,
      moveX: root.moveX,
      moveY: root.moveY,
      aimX: root.aimX,
      aimY: root.aimY,
      weaponSlot: root.weaponSlot,
      buttons: {
        jump: buttons.jump,
        attack: buttons.attack,
        pickup: buttons.pickup,
        reload: buttons.reload,
        drop: buttons.drop,
        rematch: buttons.rematch,
      },
    };
  } catch {
    return null;
  }
}

function neutralEdges() {
  return {
    jump: false,
    pickup: false,
    reload: false,
    drop: false,
  };
}

function newSession(actorId, epoch) {
  return {
    actorId,
    epoch,
    hasAcceptedInput: false,
    held: {
      moveX: 0,
      moveY: 0,
      aimX: 1,
      aimY: 0,
      attack: false,
    },
    attackEdge: false,
    edges: neutralEdges(),
    weaponSlot: null,
    lastSequence: -1,
    ack: null,
    acceptedAtMs: [],
    lastAcceptedAtMs: null,
    lastAcceptedAuthoritativeTick: null,
  };
}

function neutralizeSession(session) {
  session.hasAcceptedInput = false;
  session.held.moveX = 0;
  session.held.moveY = 0;
  session.held.aimX = 1;
  session.held.aimY = 0;
  session.held.attack = false;
  session.attackEdge = false;
  session.edges = neutralEdges();
  session.weaponSlot = null;
}

function validSessionId(sessionId) {
  return typeof sessionId === "string" && sessionId.length > 0;
}

function validEpoch(epoch) {
  return isSafeNonnegativeInteger(epoch);
}

function validActorId(actorId) {
  return isSafeNonnegativeInteger(actorId);
}

function positiveSafeInteger(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function neutralActor(actorId, fighter) {
  const facing = fighter && Number.isFinite(fighter.facing) && fighter.facing < 0 ? -1 : 1;
  return {
    id: actorId,
    moveX: 0,
    moveY: 0,
    aimX: facing,
    aimY: 0,
    weaponSlot: null,
    buttons: {
      jump: false,
      attack: false,
      pickup: false,
      reload: false,
      drop: false,
      rematch: false,
    },
  };
}

function cloneBotActor(input, actorId) {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    throw new TypeError(`makeBotInput returned an invalid input for actor ${actorId}`);
  }
  const buttons = input.buttons;
  if (buttons === null || typeof buttons !== "object" || Array.isArray(buttons)) {
    throw new TypeError(`makeBotInput returned invalid buttons for actor ${actorId}`);
  }
  return {
    id: actorId,
    moveX: input.moveX,
    moveY: input.moveY,
    aimX: input.aimX,
    aimY: input.aimY,
    weaponSlot: input.weaponSlot,
    buttons: {
      jump: buttons.jump,
      attack: buttons.attack,
      pickup: buttons.pickup,
      reload: buttons.reload,
      drop: buttons.drop,
      rematch: buttons.rematch,
    },
  };
}

export class MultiHumanInputAggregator {
  #actorIds;
  #actorIdSet;
  #botActorIds;
  #makeBotInput;
  #maxFutureTicks;
  #maxPastTicks;
  #maxMessagesPerSecond;
  #maxSequenceAdvance;
  #maxHeldInputTicks;
  #generation;
  #sessions = new Map();
  #ownersByActor = new Map();
  #accepted = 0;
  #rejected = 0;
  #rejections = new Map();

  constructor({
    actorIds,
    botActorIds,
    makeBotInput,
    maxFutureTicks = DEFAULT_MAX_FUTURE_TICKS,
    maxPastTicks = DEFAULT_MAX_PAST_TICKS,
    maxMessagesPerSecond = DEFAULT_MAX_MESSAGES_PER_SECOND,
    maxSequenceAdvance = DEFAULT_MAX_SEQUENCE_ADVANCE,
    maxHeldInputTicks = DEFAULT_MAX_HELD_INPUT_TICKS,
    generation = 1,
  } = {}) {
    if (!Array.isArray(actorIds) || actorIds.length === 0) {
      throw new TypeError("actorIds must be a non-empty array");
    }
    if (!Array.isArray(botActorIds)) throw new TypeError("botActorIds must be an array");
    if (typeof makeBotInput !== "function") throw new TypeError("makeBotInput must be a function");
    if (!isSafeNonnegativeInteger(maxFutureTicks)) throw new RangeError("maxFutureTicks must be a safe nonnegative integer");
    if (!isSafeNonnegativeInteger(maxPastTicks)) throw new RangeError("maxPastTicks must be a safe nonnegative integer");
    if (!positiveSafeInteger(maxMessagesPerSecond)) {
      throw new RangeError("maxMessagesPerSecond must be a positive safe integer");
    }
    if (!positiveSafeInteger(maxSequenceAdvance)) {
      throw new RangeError("maxSequenceAdvance must be a positive safe integer");
    }
    if (!positiveSafeInteger(maxHeldInputTicks)) {
      throw new RangeError("maxHeldInputTicks must be a positive safe integer");
    }
    if (!positiveSafeInteger(generation)) {
      throw new RangeError("generation must be a positive safe integer");
    }

    const sortedActors = actorIds.slice().sort((left, right) => left - right);
    if (sortedActors.some((actorId) => !validActorId(actorId))) {
      throw new TypeError("actorIds must contain only safe nonnegative integers");
    }
    for (let index = 1; index < sortedActors.length; index += 1) {
      if (sortedActors[index] === sortedActors[index - 1]) throw new TypeError("actorIds must be unique");
    }

    const botSet = new Set();
    for (const actorId of botActorIds) {
      if (!validActorId(actorId) || !sortedActors.includes(actorId)) {
        throw new TypeError("botActorIds must be unique actorIds");
      }
      if (botSet.has(actorId)) throw new TypeError("botActorIds must be unique actorIds");
      botSet.add(actorId);
    }

    this.#actorIds = Object.freeze(sortedActors);
    this.#actorIdSet = new Set(sortedActors);
    this.#botActorIds = botSet;
    this.#makeBotInput = makeBotInput;
    this.#maxFutureTicks = maxFutureTicks;
    this.#maxPastTicks = maxPastTicks;
    this.#maxMessagesPerSecond = maxMessagesPerSecond;
    this.#maxSequenceAdvance = maxSequenceAdvance;
    this.#maxHeldInputTicks = maxHeldInputTicks;
    this.#generation = generation;
  }

  bind(sessionId, actorId, epoch = 0) {
    if (!validSessionId(sessionId)) return { accepted: false, reason: "invalid-session" };
    if (!validEpoch(epoch)) return { accepted: false, reason: "invalid-epoch" };
    if (!this.#actorIdSet.has(actorId)) return { accepted: false, reason: "unknown-actor" };
    if (this.#botActorIds.has(actorId)) return { accepted: false, reason: "bot-owned" };

    const existingSession = this.#sessions.get(sessionId);
    if (existingSession) {
      if (existingSession.actorId === actorId && existingSession.epoch === epoch) {
        return { accepted: true, reason: "already-bound", actorId, epoch };
      }
      return { accepted: false, reason: "session-already-bound" };
    }
    if (this.#ownersByActor.has(actorId)) return { accepted: false, reason: "actor-owned" };

    this.#sessions.set(sessionId, newSession(actorId, epoch));
    this.#ownersByActor.set(actorId, sessionId);
    return { accepted: true, reason: "bound", actorId, epoch };
  }

  unbind(sessionId) {
    if (!validSessionId(sessionId)) return { accepted: false, reason: "invalid-session" };
    const session = this.#sessions.get(sessionId);
    if (!session) return { accepted: false, reason: "unbound-session" };

    this.#sessions.delete(sessionId);
    if (this.#ownersByActor.get(session.actorId) === sessionId) {
      this.#ownersByActor.delete(session.actorId);
    }
    return { accepted: true, reason: "unbound", actorId: session.actorId, epoch: session.epoch };
  }

  reconnect(oldSessionId, newSessionId, epoch) {
    if (!validSessionId(oldSessionId) || !validSessionId(newSessionId)) {
      return { accepted: false, reason: "invalid-session" };
    }
    const oldSession = this.#sessions.get(oldSessionId);
    if (!oldSession) return { accepted: false, reason: "unbound-session" };
    if (newSessionId !== oldSessionId && this.#sessions.has(newSessionId)) {
      return { accepted: false, reason: "session-already-bound" };
    }

    const nextEpoch = epoch === undefined ? oldSession.epoch + 1 : epoch;
    if (!validEpoch(nextEpoch)) return { accepted: false, reason: "invalid-epoch" };
    if (nextEpoch <= oldSession.epoch) return { accepted: false, reason: "stale-epoch" };

    const replacement = newSession(oldSession.actorId, nextEpoch);
    if (newSessionId !== oldSessionId) this.#sessions.delete(oldSessionId);
    this.#sessions.set(newSessionId, replacement);
    this.#ownersByActor.set(oldSession.actorId, newSessionId);
    return {
      accepted: true,
      reason: "reconnected",
      actorId: oldSession.actorId,
      epoch: nextEpoch,
    };
  }

  accept(sessionId, payload, authoritativeTick, nowMs = Date.now()) {
    const reject = (reason) => {
      this.#rejected += 1;
      this.#rejections.set(reason, (this.#rejections.get(reason) || 0) + 1);
      return { accepted: false, reason };
    };

    const session = this.#sessions.get(sessionId);
    if (!session) return reject("unbound-session");
    const input = normalizePayload(payload);
    if (!input) return reject("invalid-payload");
    if (input.generation < this.#generation) return reject("stale-generation");
    if (input.generation > this.#generation) return reject("future-generation");
    if (!isSafeNonnegativeInteger(authoritativeTick)) return reject("invalid-authoritative-tick");
    if (!Number.isFinite(nowMs) || nowMs < 0) return reject("invalid-time");
    if (session.lastAcceptedAtMs !== null && nowMs < session.lastAcceptedAtMs) {
      return reject("time-regression");
    }
    if (input.sequence <= session.lastSequence) return reject("stale-sequence");
    if (input.sequence - session.lastSequence > this.#maxSequenceAdvance) {
      return reject("future-sequence");
    }
    if (input.clientTick > authoritativeTick
        && input.clientTick - authoritativeTick > this.#maxFutureTicks) return reject("future-tick");
    if (input.clientTick < authoritativeTick
        && authoritativeTick - input.clientTick > this.#maxPastTicks) return reject("past-tick");

    const cutoff = nowMs - 1000;
    const recentAccepts = session.acceptedAtMs.filter((acceptedAt) => acceptedAt > cutoff);
    if (recentAccepts.length >= this.#maxMessagesPerSecond) return reject("rate-limit");

    session.held.moveX = input.moveX;
    session.held.moveY = input.moveY;
    session.held.aimX = input.aimX;
    session.held.aimY = input.aimY;
    session.attackEdge = session.attackEdge || input.buttons.attack;
    session.held.attack = input.buttons.attack;
    for (const key of EDGE_BUTTON_KEYS) {
      session.edges[key] = session.edges[key] || input.buttons[key];
    }
    if (input.weaponSlot !== null) session.weaponSlot = input.weaponSlot;
    session.hasAcceptedInput = true;
    session.lastSequence = input.sequence;
    session.ack = {
      sequence: input.sequence,
      clientTick: input.clientTick,
      authoritativeTick,
    };
    recentAccepts.push(nowMs);
    session.acceptedAtMs = recentAccepts;
    session.lastAcceptedAtMs = nowMs;
    session.lastAcceptedAuthoritativeTick = authoritativeTick;
    this.#accepted += 1;
    return { accepted: true, reason: "accepted" };
  }

  frame(state, authoritativeTick) {
    if (!isSafeNonnegativeInteger(authoritativeTick)) {
      throw new RangeError("authoritativeTick must be a safe nonnegative integer");
    }
    if (state === null || typeof state !== "object" || !Array.isArray(state.fighters)) {
      throw new TypeError("state.fighters must be an array");
    }

    const fightersById = new Map();
    for (const fighter of state.fighters) {
      if (fighter && validActorId(fighter.id) && !fightersById.has(fighter.id)) {
        fightersById.set(fighter.id, fighter);
      }
    }
    for (const actorId of this.#actorIds) {
      if (!fightersById.has(actorId)) throw new Error(`state is missing fighter ${actorId}`);
    }

    const actors = [];
    const sessionsToClear = [];
    for (const actorId of this.#actorIds) {
      const fighter = fightersById.get(actorId);

      if (this.#botActorIds.has(actorId)) {
        const botInput = this.#makeBotInput(state, fighter);
        actors.push(cloneBotActor(botInput, actorId));
        continue;
      }

      const ownerId = this.#ownersByActor.get(actorId);
      const session = ownerId === undefined ? null : this.#sessions.get(ownerId);
      if (session && session.hasAcceptedInput
          && authoritativeTick - session.lastAcceptedAuthoritativeTick >= this.#maxHeldInputTicks) {
        neutralizeSession(session);
      }
      if (!session || !session.hasAcceptedInput) {
        actors.push(neutralActor(actorId, fighter));
        continue;
      }

      actors.push({
        id: actorId,
        moveX: session.held.moveX,
        moveY: session.held.moveY,
        aimX: session.held.aimX,
        aimY: session.held.aimY,
        weaponSlot: session.weaponSlot,
        buttons: {
          jump: session.edges.jump,
          // Preserve a quick press/release pair delivered between fixed
          // steps while still holding automatic rifle fire across gaps.
          attack: session.held.attack || session.attackEdge,
          pickup: session.edges.pickup,
          reload: session.edges.reload,
          drop: session.edges.drop,
          rematch: false,
        },
      });
      sessionsToClear.push(session);
    }
    for (const session of sessionsToClear) {
      session.attackEdge = false;
      session.edges = neutralEdges();
      session.weaponSlot = null;
    }
    return { tick: authoritativeTick, actors };
  }

  ackFor(sessionId) {
    const session = this.#sessions.get(sessionId);
    return session && session.ack ? { ...session.ack } : null;
  }

  actorFor(sessionId) {
    const session = this.#sessions.get(sessionId);
    return session ? session.actorId : null;
  }

  stats() {
    const rejections = Object.create(null);
    for (const [reason, count] of [...this.#rejections.entries()].sort(([left], [right]) => left.localeCompare(right))) {
      rejections[reason] = count;
    }
    return {
      accepted: this.#accepted,
      rejected: this.#rejected,
      sessions: this.#sessions.size,
      actors: this.#actorIds.length,
      botActors: this.#botActorIds.size,
      rejections,
    };
  }
}
