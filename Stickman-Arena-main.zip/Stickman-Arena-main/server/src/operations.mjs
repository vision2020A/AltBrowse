const SERVICE_PHASE_SET = new Set([
  "starting",
  "ready",
  "draining",
  "stopped",
  "failed",
]);

export const ROOM_LIFECYCLE_PHASES = Object.freeze([
  "waiting",
  "ready",
  "playing",
  "finished",
  "rematch-vote",
  "restarting",
  "closing",
  "disposed",
]);

const ROOM_LIFECYCLE_PHASE_SET = new Set(ROOM_LIFECYCLE_PHASES);

const NEXT_SERVICE_PHASES = Object.freeze({
  starting: new Set(["ready", "draining", "failed"]),
  ready: new Set(["draining", "failed"]),
  draining: new Set(["stopped", "failed"]),
  stopped: new Set(),
  failed: new Set(),
});

export const SERVICE_PHASES = Object.freeze([
  "starting",
  "ready",
  "draining",
  "stopped",
  "failed",
]);

export const SECURITY_REJECTION_CATEGORIES = Object.freeze([
  "http",
  "websocket",
  "matchmaking",
  "protocol",
  "control",
  "resource",
]);

export const OPERATION_LOG_REASONS = Object.freeze([
  "startup",
  "configuration-invalid",
  "listening",
  "dependency-unavailable",
  "shutdown-signal",
  "drain-started",
  "drain-complete",
  "drain-timeout",
  "stopped",
  "failed",
  "framework-warning",
  "framework-error",
  "window-expired",
  "manual-flush",
]);

export const MAX_SECURITY_REJECTION_COUNT = 1_000_000;
export const DEFAULT_SECURITY_REJECTION_WINDOW_MS = 10_000;
export const DEFAULT_FRAMEWORK_DIAGNOSTIC_WINDOW_MS = 10_000;

const SECURITY_REJECTION_CATEGORY_SET = new Set(SECURITY_REJECTION_CATEGORIES);
const OPERATION_LOG_REASON_SET = new Set(OPERATION_LOG_REASONS);
const LOG_LEVEL_SET = new Set(["info", "warn", "error"]);
const SAFE_BUILD_ID = /^[a-z0-9](?:[a-z0-9.-]{0,62}[a-z0-9])?$/;
const SAFE_EVENT = /^[a-z][a-z0-9]*(?:[.-][a-z0-9]+)*$/;
const MIN_DATE_MS = -8_640_000_000_000_000;
const MAX_DATE_MS = 8_640_000_000_000_000;

function ownDataValue(record, key) {
  if ((typeof record !== "object" && typeof record !== "function") || record === null) {
    return undefined;
  }
  try {
    const descriptor = Object.getOwnPropertyDescriptor(record, key);
    return descriptor && Object.hasOwn(descriptor, "value") ? descriptor.value : undefined;
  } catch {
    return undefined;
  }
}

function validBuildId(value) {
  return typeof value === "string" && value.length <= 64 && SAFE_BUILD_ID.test(value);
}

function validEvent(value) {
  return typeof value === "string" && value.length <= 64 && SAFE_EVENT.test(value);
}

function readClock(clock) {
  try {
    const value = clock();
    if (Number.isSafeInteger(value) && value >= MIN_DATE_MS && value <= MAX_DATE_MS) return value;
  } catch {
    // A diagnostic clock must not make logging inspect or stringify its failure.
  }
  return 0;
}

function fixedTimestamp(clock) {
  return new Date(readClock(clock)).toISOString();
}

function addAllowedLogFields(target, fields) {
  const phase = ownDataValue(fields, "phase");
  if (typeof phase === "string" && SERVICE_PHASE_SET.has(phase)) target.phase = phase;

  const roomPhase = ownDataValue(fields, "roomPhase");
  if (typeof roomPhase === "string" && ROOM_LIFECYCLE_PHASE_SET.has(roomPhase)) {
    target.roomPhase = roomPhase;
  }

  const reason = ownDataValue(fields, "reason");
  if (typeof reason === "string" && OPERATION_LOG_REASON_SET.has(reason)) target.reason = reason;

  const category = ownDataValue(fields, "category");
  if (typeof category === "string" && SECURITY_REJECTION_CATEGORY_SET.has(category)) {
    target.category = category;
  }

  const count = ownDataValue(fields, "count");
  if (Number.isSafeInteger(count) && count >= 0 && count <= MAX_SECURITY_REJECTION_COUNT) {
    target.count = count;
  }
}

function captureEmitter(logger) {
  const emit = ownDataValue(logger, "emit");
  return typeof emit === "function" ? emit : null;
}

export function createServiceState() {
  let phase = "starting";
  let listenerAvailable = false;
  let dependenciesAvailable = false;

  function snapshot() {
    return Object.freeze({
      phase,
      ready: phase === "ready" && listenerAvailable && dependenciesAvailable,
      listenerAvailable,
      dependenciesAvailable,
    });
  }

  function transition(nextPhase) {
    if (typeof nextPhase !== "string" || !SERVICE_PHASE_SET.has(nextPhase)) {
      throw new TypeError("unknown service phase");
    }
    if (nextPhase === phase) return snapshot();
    if (!NEXT_SERVICE_PHASES[phase].has(nextPhase)) {
      throw new Error(`invalid service phase transition from ${phase}`);
    }
    phase = nextPhase;
    return snapshot();
  }

  function setListenerAvailable(value) {
    if (typeof value !== "boolean") throw new TypeError("listener availability must be boolean");
    listenerAvailable = value;
    return snapshot();
  }

  function setDependenciesAvailable(value) {
    if (typeof value !== "boolean") throw new TypeError("dependency availability must be boolean");
    dependenciesAvailable = value;
    return snapshot();
  }

  function isLive() {
    return phase === "starting" || phase === "ready" || phase === "draining";
  }

  function isReady() {
    return phase === "ready" && listenerAvailable && dependenciesAvailable;
  }

  return Object.freeze({
    isLive,
    isReady,
    snapshot,
    transition,
    setListenerAvailable,
    setDependenciesAvailable,
  });
}

export function createOperationsLogger(options = undefined) {
  const suppliedBuildId = ownDataValue(options, "buildId");
  const buildId = validBuildId(suppliedBuildId) ? suppliedBuildId : "unknown";
  const suppliedClock = ownDataValue(options, "clock");
  const clock = typeof suppliedClock === "function" ? suppliedClock : Date.now;
  const suppliedWrite = ownDataValue(options, "write");
  const write = typeof suppliedWrite === "function"
    ? suppliedWrite
    : (line) => process.stdout.write(line);

  function emit(level, event, fields = undefined) {
    if (typeof level !== "string" || !LOG_LEVEL_SET.has(level) || !validEvent(event)) return false;
    const record = {
      timestamp: fixedTimestamp(clock),
      level,
      event,
      buildId,
    };
    addAllowedLogFields(record, fields);
    try {
      write(`${JSON.stringify(record)}\n`);
      return true;
    } catch {
      return false;
    }
  }

  return Object.freeze({
    emit,
    info: (event, fields) => emit("info", event, fields),
    warn: (event, fields) => emit("warn", event, fields),
    error: (event, fields) => emit("error", event, fields),
  });
}

export function createFrameworkDiagnosticGate(options = undefined) {
  const suppliedClock = ownDataValue(options, "clock");
  const clock = typeof suppliedClock === "function" ? suppliedClock : Date.now;
  const suppliedWindowMs = ownDataValue(options, "windowMs");
  const windowMs = Number.isSafeInteger(suppliedWindowMs)
    && suppliedWindowMs >= 1
    && suppliedWindowMs <= 60_000
    ? suppliedWindowMs
    : DEFAULT_FRAMEWORK_DIAGNOSTIC_WINDOW_MS;
  const loggerEmit = captureEmitter(ownDataValue(options, "logger"));
  if (!loggerEmit) throw new TypeError("operations logger must expose emit");
  let windowStartedAtMs = readClock(clock);
  const seen = { warning: false, error: false };

  function resetAt(now) {
    windowStartedAtMs = now;
    seen.warning = false;
    seen.error = false;
  }

  function record(kind) {
    if (kind !== "warning" && kind !== "error") return false;
    const now = readClock(clock);
    if (now < windowStartedAtMs || now - windowStartedAtMs >= windowMs) resetAt(now);
    if (seen[kind]) return false;
    seen[kind] = true;
    return loggerEmit(
      kind === "error" ? "error" : "warn",
      `framework.${kind}`,
      { reason: kind === "error" ? "framework-error" : "framework-warning" },
    );
  }

  function reset() {
    resetAt(readClock(clock));
    return snapshot();
  }

  function snapshot() {
    return Object.freeze({
      windowStartedAtMs,
      windowMs,
      warningLogged: seen.warning,
      errorLogged: seen.error,
    });
  }

  return Object.freeze({ record, reset, snapshot });
}

export function createFrameworkLogger(operationsLogger, options = undefined) {
  const emit = captureEmitter(operationsLogger);
  if (!emit) throw new TypeError("operations logger must expose emit");
  const rejectionTracker = ownDataValue(options, "rejectionTracker");
  const diagnosticGate = ownDataValue(options, "diagnosticGate");
  const record = ownDataValue(rejectionTracker, "record");
  const recordDiagnostic = ownDataValue(diagnosticGate, "record");
  return Object.freeze({
    debug() {},
    info() {},
    trace() {},
    warn() {
      if (typeof record === "function") record("protocol");
      if (typeof recordDiagnostic === "function") recordDiagnostic("warning");
      else emit("warn", "framework.warning", { reason: "framework-warning" });
    },
    error() {
      if (typeof record === "function") record("protocol");
      if (typeof recordDiagnostic === "function") recordDiagnostic("error");
      else emit("error", "framework.error", { reason: "framework-error" });
    },
  });
}

export function createSecurityRejectionTracker(options = undefined) {
  const suppliedClock = ownDataValue(options, "clock");
  const clock = typeof suppliedClock === "function" ? suppliedClock : Date.now;
  const suppliedWindowMs = ownDataValue(options, "windowMs");
  const windowMs = Number.isSafeInteger(suppliedWindowMs)
    && suppliedWindowMs >= 1
    && suppliedWindowMs <= 60_000
    ? suppliedWindowMs
    : DEFAULT_SECURITY_REJECTION_WINDOW_MS;
  const loggerEmit = captureEmitter(ownDataValue(options, "logger"));
  const counts = Object.fromEntries(SECURITY_REJECTION_CATEGORIES.map((category) => [category, 0]));
  let windowStartedAtMs = readClock(clock);

  function zeroCounts() {
    for (const category of SECURITY_REJECTION_CATEGORIES) counts[category] = 0;
  }

  function totalCount() {
    let total = 0;
    for (const category of SECURITY_REJECTION_CATEGORIES) {
      total = Math.min(MAX_SECURITY_REJECTION_COUNT, total + counts[category]);
    }
    return total;
  }

  function snapshot() {
    return Object.freeze({
      windowStartedAtMs,
      windowMs,
      total: totalCount(),
      counts: Object.freeze({ ...counts }),
    });
  }

  function emitSnapshot(current, reason) {
    if (!loggerEmit) return;
    for (const category of SECURITY_REJECTION_CATEGORIES) {
      const count = current.counts[category];
      if (count > 0) {
        loggerEmit("warn", "security.rejections", { reason, category, count });
      }
    }
  }

  function finishWindow(now, reason) {
    const current = snapshot();
    emitSnapshot(current, reason);
    zeroCounts();
    windowStartedAtMs = now;
    return current;
  }

  function record(category, amount = 1) {
    if (typeof category !== "string" || !SECURITY_REJECTION_CATEGORY_SET.has(category)) return false;
    if (!Number.isSafeInteger(amount) || amount < 1) return false;
    const now = readClock(clock);
    if (now >= windowStartedAtMs && now - windowStartedAtMs >= windowMs) {
      finishWindow(now, "window-expired");
    }
    counts[category] = Math.min(MAX_SECURITY_REJECTION_COUNT, counts[category] + amount);
    return true;
  }

  function flush() {
    return finishWindow(readClock(clock), "manual-flush");
  }

  function reset() {
    zeroCounts();
    windowStartedAtMs = readClock(clock);
    return snapshot();
  }

  return Object.freeze({
    record,
    flush,
    reset,
    snapshot,
  });
}
