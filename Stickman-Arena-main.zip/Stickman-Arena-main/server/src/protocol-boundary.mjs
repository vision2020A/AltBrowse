import { ErrorCode, ServerError } from "@colyseus/core";
import { isRoomCode } from "./room-registry.mjs";
import { Netcode, Sim } from "./shared-runtime.mjs";

export const PASS12B1_MAX_HTTP_BODY_BYTES = 1024;
export const PASS12B1_MAX_WS_PAYLOAD_BYTES = 4096;
export const PASS12B1_MAX_UPGRADE_URL_CHARS = 512;
export const PASS12B1_RATE_WINDOW_MS = 10_000;
export const PASS12B1_HTTP_ADMISSION_LIMIT = 60;
export const PASS12B1_WS_UPGRADE_LIMIT = 120;
export const PASS12B1_MAX_HEADER_BYTES = 8192;
export const PASS12B1_MAX_RAW_URL_CHARS = 1024;
export const PASS12B1_RAW_REJECTION_HEADER = "x-stickman-edge-rejected";
export const PASS12B1_RAW_REJECTION_PATH = "/__stickman-edge-rejected";
export const PASS12B3_QUICK_MATCH_LIMIT = 30;
export const PASS12B3_CREATE_MATCH_LIMIT = 6;
export const PASS12B3_JOIN_CODE_LIMIT = 30;
export const PASS12B3_RECONNECT_LIMIT = 30;

export const QUICK_MATCH_OPERATION = "quick-match";
export const CREATE_MATCH_OPERATION = "create-match";
export const JOIN_CODE_OPERATION = "join-code";

export const INCOMPATIBLE_CLIENT_MESSAGE =
  "Client/server versions are incompatible. Reload the game and try again.";
export const ORIGIN_REJECTED_MESSAGE = "Connection origin is not allowed.";
export const MATCH_UNAVAILABLE_MESSAGE = "Match unavailable or expired.";

const REJECTED_CORS_ORIGIN = "";
const MATCHMAKING_PATH = /^\/matchmake\/(joinOrCreate|create|joinById|reconnect)\/([^/]+)$/;
const ROOM_ID = /^[A-Za-z0-9_-]{1,32}$/;
const WEBSOCKET_PATH = /^\/[A-Za-z0-9_-]{1,32}\/[A-Za-z0-9_-]{1,32}$/;
const SESSION_ID = /^[A-Za-z0-9_-]{1,32}$/;
const RECONNECTION_TOKEN = /^[A-Za-z0-9_-]{1,64}$/;
const UPGRADE_QUERY_KEYS = new Set(["sessionId", "reconnectionToken", "skipHandshake"]);

export const DEFAULT_LOCAL_REQUEST_POLICY = Object.freeze({
  mode: "local",
  allowMissingOrigin: true,
  allowedHosts: Object.freeze([]),
  allowedOrigins: Object.freeze([]),
});

function isPlainRecord(value) {
  try {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  } catch {
    return false;
  }
}

function exactOwnDataRecord(value, keys) {
  try {
    if (!isPlainRecord(value) || Object.getOwnPropertySymbols(value).length !== 0) return false;
    const names = Object.getOwnPropertyNames(value).sort();
    const expected = [...keys].sort();
    if (names.length !== expected.length) return false;
    for (let index = 0; index < expected.length; index += 1) {
      if (names[index] !== expected[index]) return false;
      const descriptor = Object.getOwnPropertyDescriptor(value, expected[index]);
      if (!descriptor || !descriptor.enumerable
          || !Object.prototype.hasOwnProperty.call(descriptor, "value")) return false;
    }
    return true;
  } catch {
    return false;
  }
}

function ownDataValue(value, key) {
  return Object.getOwnPropertyDescriptor(value, key).value;
}

function readHeader(headers, name) {
  if (!headers || typeof headers.get !== "function") return null;
  const value = headers.get(name);
  return typeof value === "string" ? value : null;
}

export function isAllowedLocalOrigin(origin) {
  if (origin == null || origin === "") return true;
  if (typeof origin !== "string" || origin.length > 128) return false;
  let parsed;
  try {
    parsed = new URL(origin);
  } catch {
    return false;
  }
  if (parsed.origin !== origin || parsed.protocol !== "http:"
      || parsed.username || parsed.password) return false;
  if (parsed.hostname !== "127.0.0.1" && parsed.hostname !== "localhost") return false;
  if (parsed.port !== "" && (!/^\d{1,5}$/.test(parsed.port)
      || Number(parsed.port) < 1 || Number(parsed.port) > 65535)) return false;
  return true;
}

function parseLocalRequestUrl(value) {
  if (typeof value !== "string" || value.length > 1024) return null;
  let parsed;
  try {
    parsed = new URL(value);
  } catch {
    return null;
  }
  if (parsed.protocol !== "http:" || parsed.username || parsed.password
      || (parsed.hostname !== "127.0.0.1" && parsed.hostname !== "localhost")) return null;
  if (parsed.port !== "" && (!/^\d{1,5}$/.test(parsed.port)
      || Number(parsed.port) < 1 || Number(parsed.port) > 65535)) return null;
  return parsed;
}

export function isAllowedLocalRequest(origin, requestUrl) {
  const request = parseLocalRequestUrl(requestUrl);
  if (!request || !isAllowedLocalOrigin(origin)) return false;
  if (origin == null || origin === "") return true;
  try {
    return new URL(origin).origin === request.origin;
  } catch {
    return false;
  }
}

export function isAllowedRawLocalHost(host) {
  if (typeof host !== "string" || host.length < 1 || host.length > 128) return false;
  const raw = /^(127\.0\.0\.1|localhost)(?::([1-9]\d{0,4}))?$/.exec(host);
  return Boolean(raw && (!raw[2] || Number(raw[2]) <= 65535));
}

function isExactRequestPolicy(policy) {
  if (!exactOwnDataRecord(policy, [
    "mode", "allowMissingOrigin", "allowedHosts", "allowedOrigins",
  ])) return false;
  try {
    const mode = ownDataValue(policy, "mode");
    const allowMissingOrigin = ownDataValue(policy, "allowMissingOrigin");
    const allowedHosts = ownDataValue(policy, "allowedHosts");
    const allowedOrigins = ownDataValue(policy, "allowedOrigins");
    if ((mode !== "local" && mode !== "public")
        || typeof allowMissingOrigin !== "boolean"
        || !Array.isArray(allowedHosts) || !Array.isArray(allowedOrigins)) return false;
    if (mode === "local") {
      return allowMissingOrigin
        && allowedHosts.length === allowedOrigins.length
        && allowedHosts.length <= 16
        && allowedHosts.every((value) => typeof value === "string" && value.length <= 255)
        && allowedOrigins.every((value) => typeof value === "string" && value.length <= 255);
    }
    return !allowMissingOrigin
      && allowedHosts.length >= 1 && allowedHosts.length <= 16
      && allowedOrigins.length >= 1 && allowedOrigins.length <= 16
      && allowedHosts.every((value) => typeof value === "string" && value.length <= 255)
      && allowedOrigins.every((value) => typeof value === "string" && value.length <= 255)
      && new Set(allowedHosts).size === allowedHosts.length
      && new Set(allowedOrigins).size === allowedOrigins.length;
  } catch {
    return false;
  }
}

function requireRequestPolicy(policy) {
  if (!isExactRequestPolicy(policy)) throw new TypeError("invalid request policy");
  return policy;
}

export function isAllowedRawHost(host, policy = DEFAULT_LOCAL_REQUEST_POLICY) {
  if (!isExactRequestPolicy(policy)) return false;
  if (policy.mode === "local" && policy.allowedHosts.length === 0) {
    return isAllowedRawLocalHost(host);
  }
  return typeof host === "string" && policy.allowedHosts.includes(host);
}

export function isSafeOriginFormTarget(value) {
  return typeof value === "string"
    && value.length >= 1
    && value.length <= PASS12B1_MAX_RAW_URL_CHARS
    && value.startsWith("/")
    && !value.startsWith("//")
    && !value.includes("\\")
    && !value.includes("#")
    && !/[\u0000-\u0020\u007f]/.test(value);
}

export function isAllowedLocalHost(host, requestUrl) {
  if (!isAllowedRawLocalHost(host)) return false;
  const request = parseLocalRequestUrl(requestUrl);
  const declared = parseLocalRequestUrl(`http://${host}/`);
  return Boolean(request && declared && request.host === declared.host);
}

function parsePublicRequestUrl(value) {
  if (typeof value !== "string" || value.length > 1024) return null;
  try {
    const parsed = new URL(value);
    if ((parsed.protocol !== "http:" && parsed.protocol !== "https:")
        || parsed.username || parsed.password) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function isAllowedConfiguredOrigin(origin, policy = DEFAULT_LOCAL_REQUEST_POLICY) {
  if (!isExactRequestPolicy(policy)) return false;
  if (policy.mode === "local" && policy.allowedOrigins.length === 0) {
    return isAllowedLocalOrigin(origin);
  }
  if (origin == null) return policy.allowMissingOrigin;
  if (origin === "") return false;
  return typeof origin === "string" && policy.allowedOrigins.includes(origin);
}

export function isAllowedConfiguredHost(host, requestUrl, policy = DEFAULT_LOCAL_REQUEST_POLICY) {
  if (!isExactRequestPolicy(policy)) return false;
  if (policy.mode === "local" && policy.allowedHosts.length === 0) {
    return isAllowedLocalHost(host, requestUrl);
  }
  const request = parsePublicRequestUrl(requestUrl);
  return Boolean(request && isAllowedRawHost(host, policy) && request.host === host);
}

export function isAllowedConfiguredRequest(
  origin,
  requestUrl,
  policy = DEFAULT_LOCAL_REQUEST_POLICY,
) {
  if (!isExactRequestPolicy(policy)) return false;
  if (policy.mode === "local" && policy.allowedHosts.length === 0) {
    return isAllowedLocalRequest(origin, requestUrl);
  }
  const request = parsePublicRequestUrl(requestUrl);
  if (!request || !policy.allowedHosts.includes(request.host)
      || !isAllowedConfiguredOrigin(origin, policy)) return false;
  if (policy.mode === "local" && origin != null && origin !== "") {
    try {
      return new URL(origin).host === request.host;
    } catch {
      return false;
    }
  }
  return true;
}

function invalidOptions() {
  return Object.freeze({ accepted: false, reason: "invalid-options" });
}

function incompatibleClient() {
  return Object.freeze({ accepted: false, reason: "incompatible-client" });
}

function readOperation(options) {
  try {
    if (!isPlainRecord(options) || Object.getOwnPropertySymbols(options).length !== 0) return null;
    const descriptor = Object.getOwnPropertyDescriptor(options, "operation");
    return descriptor && descriptor.enumerable
      && Object.prototype.hasOwnProperty.call(descriptor, "value")
      && typeof descriptor.value === "string" ? descriptor.value : null;
  } catch {
    return null;
  }
}

function isLegacyQuickMatchOptions(options) {
  if (!exactOwnDataRecord(options, ["compatibility"])) return false;
  try {
    const result = Netcode.validateCompatibilityOffer(ownDataValue(options, "compatibility"));
    return result.accepted || result.reason !== "invalid-record";
  } catch {
    return false;
  }
}

export function validateAdmissionOptions(options) {
  const operation = readOperation(options);
  const keys = operation === JOIN_CODE_OPERATION
    ? ["compatibility", "operation"]
    : ["compatibility", "operation", "modeId", "mapId"];
  if (!exactOwnDataRecord(options, keys)) return invalidOptions();
  if (operation !== QUICK_MATCH_OPERATION
      && operation !== CREATE_MATCH_OPERATION
      && operation !== JOIN_CODE_OPERATION) return invalidOptions();
  try {
    if (operation !== JOIN_CODE_OPERATION
        && (ownDataValue(options, "modeId") !== Sim.DEFAULT_MODE_ID
          || ownDataValue(options, "mapId") !== Sim.DEFAULT_MAP_ID)) return invalidOptions();
    if (!Netcode.validateCompatibilityOffer(ownDataValue(options, "compatibility")).accepted) {
      return incompatibleClient();
    }
    return Object.freeze({
      accepted: true,
      operation,
      modeId: Sim.DEFAULT_MODE_ID,
      mapId: Sim.DEFAULT_MAP_ID,
    });
  } catch {
    return invalidOptions();
  }
}

export function validateAdmissionAuth(auth) {
  if (!exactOwnDataRecord(auth, ["compatibility", "operation", "modeId", "mapId"])) return false;
  try {
    const operation = ownDataValue(auth, "operation");
    return (operation === QUICK_MATCH_OPERATION
        || operation === CREATE_MATCH_OPERATION
        || operation === JOIN_CODE_OPERATION)
      && ownDataValue(auth, "modeId") === Sim.DEFAULT_MODE_ID
      && ownDataValue(auth, "mapId") === Sim.DEFAULT_MAP_ID
      && Netcode.validateCompatibilityOffer(ownDataValue(auth, "compatibility")).accepted;
  } catch {
    return false;
  }
}

export function validateMatchmakingRequest(method, target, options) {
  const admission = validateAdmissionOptions(options);
  if (!admission.accepted && admission.reason !== "incompatible-client") return admission;
  const operation = admission.accepted ? admission.operation : readOperation(options);
  const accepted = (method === "joinOrCreate"
      && target === "arena"
      && operation === QUICK_MATCH_OPERATION)
    || (method === "create"
      && target === "arena"
      && operation === CREATE_MATCH_OPERATION)
    || (method === "joinById"
      && isRoomCode(target)
      && operation === JOIN_CODE_OPERATION);
  if (!accepted) {
    return Object.freeze({ accepted: false, reason: "invalid-matchmaking-request" });
  }
  return admission;
}

function readMatchmakingRoute(context) {
  const request = context && context.req;
  if (!request || request.method !== "POST" || typeof request.url !== "string") return null;
  let url;
  try {
    url = new URL(request.url);
  } catch {
    return null;
  }
  const match = url.pathname.match(MATCHMAKING_PATH);
  if (url.search || url.hash || !match || !isSupportedMatchmakingTarget(match[1], match[2])) {
    return null;
  }
  return Object.freeze({ method: match[1], target: match[2] });
}

export function authorizeAdmission(
  token,
  options,
  context,
  requestPolicy = DEFAULT_LOCAL_REQUEST_POLICY,
) {
  if (token != null && token !== "") {
    throw new ServerError(ErrorCode.AUTH_FAILED, INCOMPATIBLE_CLIENT_MESSAGE);
  }
  const origin = readHeader(context && context.headers, "origin");
  const host = readHeader(context && context.headers, "host");
  const requestUrl = context && context.req && typeof context.req.url === "string"
    ? context.req.url : host ? `http://${host}/` : "";
  if (!isAllowedConfiguredHost(host, requestUrl, requestPolicy)
      || !isAllowedConfiguredRequest(origin, requestUrl, requestPolicy)) {
    throw new ServerError(ErrorCode.AUTH_FAILED, ORIGIN_REJECTED_MESSAGE);
  }
  const admission = validateAdmissionOptions(options);
  const route = readMatchmakingRoute(context);
  if (!admission.accepted || !route
      || !validateMatchmakingRequest(route.method, route.target, options).accepted) {
    throw new ServerError(ErrorCode.AUTH_FAILED, INCOMPATIBLE_CLIENT_MESSAGE);
  }
  return {
    compatibility: Netcode.createCompatibilityOffer(),
    operation: admission.operation,
    modeId: admission.modeId,
    mapId: admission.mapId,
  };
}

export function createFixedWindowLimiter({ limit, windowMs, now = Date.now }) {
  if (!Number.isSafeInteger(limit) || limit < 1) throw new TypeError("limit must be a positive integer");
  if (!Number.isSafeInteger(windowMs) || windowMs < 1) {
    throw new TypeError("windowMs must be a positive integer");
  }
  if (typeof now !== "function") throw new TypeError("now must be a function");
  let windowStartedAt = null;
  let count = 0;

  return Object.freeze({
    consume() {
      const current = Number(now());
      if (!Number.isFinite(current)) throw new Error("rate-limit clock must be finite");
      if (windowStartedAt == null || current < windowStartedAt
          || current - windowStartedAt >= windowMs) {
        windowStartedAt = current;
        count = 0;
      }
      if (count >= limit) {
        return Object.freeze({
          accepted: false,
          retryAfterSeconds: Math.max(1, Math.ceil((windowStartedAt + windowMs - current) / 1000)),
        });
      }
      count += 1;
      return Object.freeze({ accepted: true, retryAfterSeconds: 0 });
    },
    snapshot() {
      return Object.freeze({ windowStartedAt, count, limit, windowMs });
    },
    reset() {
      windowStartedAt = null;
      count = 0;
    },
  });
}

function safeJsonResponse(status, error, extraHeaders = {}) {
  return new Response(JSON.stringify({ error }), {
    status,
    headers: {
      "cache-control": "no-store",
      connection: "close",
      "content-type": "application/json; charset=utf-8",
      "x-content-type-options": "nosniff",
      ...extraHeaders,
    },
  });
}

function hasOneQueryValue(searchParams, key, pattern) {
  const values = searchParams.getAll(key);
  return values.length === 1 && pattern.test(values[0]);
}

export function isAllowedUpgradeUrl(value) {
  let url;
  try {
    url = new URL(value);
  } catch {
    return false;
  }
  if (url.hash || /%|\+/.test(url.pathname + url.search) || !WEBSOCKET_PATH.test(url.pathname)
      || url.pathname.length + url.search.length > PASS12B1_MAX_UPGRADE_URL_CHARS) return false;
  const names = [];
  for (const key of url.searchParams.keys()) {
    if (!UPGRADE_QUERY_KEYS.has(key)) return false;
    names.push(key);
  }
  if (!hasOneQueryValue(url.searchParams, "sessionId", SESSION_ID)) return false;
  const reconnectValues = url.searchParams.getAll("reconnectionToken");
  if (reconnectValues.length > 1
      || (reconnectValues.length === 1 && !RECONNECTION_TOKEN.test(reconnectValues[0]))) return false;
  const skipValues = url.searchParams.getAll("skipHandshake");
  if (skipValues.length > 1
      || (skipValues.length === 1 && skipValues[0] !== "true")) return false;
  if (skipValues.length === 1 && reconnectValues.length !== 1) return false;
  return names.length === new Set(names).size;
}

function isSupportedMatchmakingTarget(method, target) {
  if (method === "joinOrCreate" || method === "create") return target === "arena";
  if (method === "joinById") return isRoomCode(target);
  return method === "reconnect" && ROOM_ID.test(target);
}

function validateReconnectBody(value) {
  if (!exactOwnDataRecord(value, ["reconnectionToken"])) return false;
  try {
    const token = ownDataValue(value, "reconnectionToken");
    return typeof token === "string" && RECONNECTION_TOKEN.test(token);
  } catch {
    return false;
  }
}

export function createProtocolBoundary({
  now = Date.now,
  httpLimit = PASS12B1_HTTP_ADMISSION_LIMIT,
  upgradeLimit = PASS12B1_WS_UPGRADE_LIMIT,
  quickMatchLimit = PASS12B3_QUICK_MATCH_LIMIT,
  createMatchLimit = PASS12B3_CREATE_MATCH_LIMIT,
  joinCodeLimit = PASS12B3_JOIN_CODE_LIMIT,
  reconnectLimit = PASS12B3_RECONNECT_LIMIT,
  requestPolicy = DEFAULT_LOCAL_REQUEST_POLICY,
  serviceState = null,
  rejectionTracker = null,
  isLocalRoom = null,
} = {}) {
  requireRequestPolicy(requestPolicy);
  if (serviceState != null && (typeof serviceState !== "object"
      || typeof serviceState.isLive !== "function"
      || typeof serviceState.isReady !== "function")) {
    throw new TypeError("serviceState must expose isLive() and isReady()");
  }
  if (rejectionTracker != null && (typeof rejectionTracker !== "object"
      || typeof rejectionTracker.record !== "function")) {
    throw new TypeError("rejectionTracker must expose record()");
  }
  if (isLocalRoom != null && typeof isLocalRoom !== "function") {
    throw new TypeError("isLocalRoom must be a function");
  }
  const httpLimiter = createFixedWindowLimiter({
    limit: httpLimit,
    windowMs: PASS12B1_RATE_WINDOW_MS,
    now,
  });
  const upgradeLimiter = createFixedWindowLimiter({
    limit: upgradeLimit,
    windowMs: PASS12B1_RATE_WINDOW_MS,
    now,
  });
  const operationLimiters = Object.freeze({
    [QUICK_MATCH_OPERATION]: createFixedWindowLimiter({
      limit: quickMatchLimit,
      windowMs: PASS12B1_RATE_WINDOW_MS,
      now,
    }),
    [CREATE_MATCH_OPERATION]: createFixedWindowLimiter({
      limit: createMatchLimit,
      windowMs: PASS12B1_RATE_WINDOW_MS,
      now,
    }),
    [JOIN_CODE_OPERATION]: createFixedWindowLimiter({
      limit: joinCodeLimit,
      windowMs: PASS12B1_RATE_WINDOW_MS,
      now,
    }),
    reconnect: createFixedWindowLimiter({
      limit: reconnectLimit,
      windowMs: PASS12B1_RATE_WINDOW_MS,
      now,
    }),
  });

  function getCorsHeaders(headers) {
    const origin = readHeader(headers, "origin");
    const host = readHeader(headers, "host");
    const allowedHost = isAllowedRawHost(host, requestPolicy);
    return {
      "Access-Control-Allow-Origin": origin && isAllowedConfiguredOrigin(origin, requestPolicy)
        && allowedHost
        && isAllowedConfiguredRequest(origin, `http://${host}/`, requestPolicy)
        ? origin : REJECTED_CORS_ORIGIN,
      "Access-Control-Allow-Credentials": "false",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "POST,OPTIONS",
      "Access-Control-Max-Age": "600",
      Vary: "Origin",
    };
  }

  async function onRequest(request) {
    const url = new URL(request.url);
    if (request.headers.get(PASS12B1_RAW_REJECTION_HEADER) === "1") {
      return safeJsonResponse(400, "bad request");
    }
    if (url.pathname === "/__healthcheck") {
      return safeJsonResponse(404, "not found");
    }
    if (url.pathname === "/livez" || url.pathname === "/readyz") {
      if (url.search || url.hash) return safeJsonResponse(404, "not found");
      if (request.method !== "GET") return safeJsonResponse(405, "method not allowed");
      const live = serviceState == null || serviceState.isLive();
      const ready = serviceState == null || serviceState.isReady();
      const accepted = url.pathname === "/livez" ? live : ready;
      return new Response(JSON.stringify({ status: accepted
        ? (url.pathname === "/livez" ? "live" : "ready") : "unavailable" }), {
        status: accepted ? 200 : 503,
        headers: {
          "cache-control": "no-store",
          "content-type": "application/json; charset=utf-8",
          "x-content-type-options": "nosniff",
        },
      });
    }
    if (!url.pathname.startsWith("/matchmake/")) return undefined;

    if (serviceState != null && !serviceState.isReady()) {
      rejectionTracker?.record("matchmaking");
      return safeJsonResponse(503, "service unavailable");
    }

    const origin = request.headers.get("origin");
    if (!isAllowedConfiguredHost(request.headers.get("host"), request.url, requestPolicy)
        || !isAllowedConfiguredRequest(origin, request.url, requestPolicy)) {
      rejectionTracker?.record("http");
      return safeJsonResponse(403, "origin not allowed");
    }
    const rate = httpLimiter.consume();
    if (!rate.accepted) {
      rejectionTracker?.record("http");
      return safeJsonResponse(429, "admission rate limit exceeded", {
        "retry-after": String(rate.retryAfterSeconds),
      });
    }
    if (request.method !== "POST") return safeJsonResponse(405, "method not allowed");

    const match = url.pathname.match(MATCHMAKING_PATH);
    if (url.search || url.hash || !match || !isSupportedMatchmakingTarget(match[1], match[2])) {
      return safeJsonResponse(404, "not found");
    }
    if (request.headers.has("authorization")) {
      return safeJsonResponse(400, "authorization is not accepted");
    }
    const contentEncoding = request.headers.get("content-encoding");
    if (contentEncoding && contentEncoding.trim().toLowerCase() !== "identity") {
      return safeJsonResponse(415, "content encoding is not accepted");
    }
    if (request.headers.has("transfer-encoding")) {
      return safeJsonResponse(411, "content-length required");
    }
    const contentType = request.headers.get("content-type");
    if (!contentType || contentType.split(";", 1)[0].trim().toLowerCase() !== "application/json") {
      return safeJsonResponse(415, "application/json required");
    }
    const rawLength = request.headers.get("content-length");
    if (!rawLength || !/^(0|[1-9]\d{0,3})$/.test(rawLength)) {
      return safeJsonResponse(411, "content-length required");
    }
    const length = Number(rawLength);
    if (length === 0) return safeJsonResponse(400, "request body required");
    if (length > PASS12B1_MAX_HTTP_BODY_BYTES) {
      return safeJsonResponse(413, "request body too large");
    }

    const operation = match[1] === "joinOrCreate" ? QUICK_MATCH_OPERATION
      : match[1] === "create" ? CREATE_MATCH_OPERATION
        : match[1] === "joinById" ? JOIN_CODE_OPERATION : "reconnect";
    const operationRate = operationLimiters[operation].consume();
    if (!operationRate.accepted) {
      return safeJsonResponse(429, "admission rate limit exceeded", {
        "retry-after": String(operationRate.retryAfterSeconds),
      });
    }

    let rawBody;
    try {
      rawBody = await request.clone().text();
    } catch {
      return safeJsonResponse(400, "malformed request body");
    }
    const actualLength = new TextEncoder().encode(rawBody).byteLength;
    if (actualLength !== length) return safeJsonResponse(400, "invalid content length");
    if (actualLength > PASS12B1_MAX_HTTP_BODY_BYTES) {
      return safeJsonResponse(413, "request body too large");
    }
    let requestBody;
    try {
      requestBody = JSON.parse(rawBody);
    } catch {
      return safeJsonResponse(400, "malformed request body");
    }
    if (match[1] === "reconnect") {
      if (!validateReconnectBody(requestBody)) {
        return safeJsonResponse(400, "invalid reconnect request");
      }
    } else {
      const admission = validateMatchmakingRequest(match[1], match[2], requestBody);
      if (!admission.accepted && admission.reason !== "incompatible-client") {
        if (match[1] === "joinOrCreate" && match[2] === "arena"
            && isLegacyQuickMatchOptions(requestBody)) {
          if (serviceState != null && !serviceState.isReady()) {
            rejectionTracker?.record("matchmaking");
            return safeJsonResponse(503, "service unavailable");
          }
          return undefined;
        }
        return safeJsonResponse(400, "invalid matchmaking request");
      }
    }
    if (isLocalRoom != null && (match[1] === "reconnect" || match[1] === "joinById")) {
      let local = false;
      try {
        local = isLocalRoom(match[2]) === true;
      } catch {
        local = false;
      }
      if (!local) {
        rejectionTracker?.record("matchmaking");
        return safeJsonResponse(ErrorCode.MATCHMAKE_INVALID_ROOM_ID, MATCH_UNAVAILABLE_MESSAGE);
      }
    }
    if (serviceState != null && !serviceState.isReady()) {
      rejectionTracker?.record("matchmaking");
      return safeJsonResponse(503, "service unavailable");
    }
    return undefined;
  }

  function onResponse(response) {
    if (!(response instanceof Response)) return undefined;
    if (response.status === 503) return safeJsonResponse(503, "service unavailable");
    if (![ErrorCode.MATCHMAKE_INVALID_CRITERIA, ErrorCode.MATCHMAKE_INVALID_ROOM_ID,
          ErrorCode.MATCHMAKE_UNHANDLED, ErrorCode.MATCHMAKE_EXPIRED]
          .includes(response.status)) return undefined;
    return safeJsonResponse(response.status, MATCH_UNAVAILABLE_MESSAGE);
  }

  function beforeUpgrade(request) {
    if (request.headers.has(PASS12B1_RAW_REJECTION_HEADER)) {
      return new Response(null, { status: 400 });
    }
    if (serviceState != null && !serviceState.isReady()) {
      rejectionTracker?.record("matchmaking");
      return new Response(null, { status: 503 });
    }
    const origin = request.headers.get("origin");
    if (!isAllowedConfiguredHost(request.headers.get("host"), request.url, requestPolicy)
        || !isAllowedConfiguredRequest(origin, request.url, requestPolicy)) {
      rejectionTracker?.record("websocket");
      return new Response(null, { status: 403 });
    }
    const rate = upgradeLimiter.consume();
    if (!rate.accepted) {
      rejectionTracker?.record("websocket");
      return new Response(null, {
        status: 429,
        headers: { "retry-after": String(rate.retryAfterSeconds) },
      });
    }
    if (!isAllowedUpgradeUrl(request.url)) return new Response(null, { status: 400 });
    return undefined;
  }

  function reset() {
    httpLimiter.reset();
    upgradeLimiter.reset();
    for (const limiter of Object.values(operationLimiters)) limiter.reset();
  }

  return Object.freeze({
    beforeUpgrade,
    getCorsHeaders,
    onRequest,
    httpLimiter,
    operationLimiters,
    reset,
    onResponse,
    upgradeLimiter,
  });
}
