import { createOperationsLogger } from "./operations.mjs";
import { createRuntimeConfig } from "./runtime-config.mjs";
import { createShutdownController, startConfiguredApplication } from "./startup.mjs";

const SERVER_BUILD_ID = "pass12b4b-shutdown";
const startupLogger = createOperationsLogger({
  buildId: SERVER_BUILD_ID,
  write: (line) => process.stderr.write(line),
});

async function preloadCloudEnvironment() {
  if (!Object.prototype.hasOwnProperty.call(process.env, "COLYSEUS_CLOUD")) return true;
  const methods = ["debug", "error", "info", "log", "warn"];
  const originals = new Map(methods.map((method) => [method, console[method]]));
  try {
    for (const method of methods) console[method] = () => {};
    await import("@colyseus/tools/loadenv");
    return true;
  } catch {
    return false;
  } finally {
    for (const method of methods) console[method] = originals.get(method);
  }
}

let exitScheduled = false;
const shutdownController = createShutdownController({
  signalTarget: process,
  onComplete(result, context) {
    const exitCode = result.accepted && !context.fatal ? 0 : 1;
    process.exitCode = process.exitCode === 1 || exitCode === 1 ? 1 : 0;
    if (exitScheduled) return;
    exitScheduled = true;
    setImmediate(() => process.exit(process.exitCode === 0 ? 0 : 1));
  },
});
let shutdownInstalled = false;
try {
  shutdownInstalled = shutdownController.install();
} catch {
  startupLogger.error("service.failure", {
    phase: "failed",
    reason: "failed",
  });
  process.exitCode = 1;
  exitScheduled = true;
  setImmediate(() => process.exit(1));
}

let runtimeConfig;
const cloudEnvironmentReady = shutdownInstalled ? await preloadCloudEnvironment() : false;
if (shutdownInstalled && !cloudEnvironmentReady) {
  startupLogger.error("service.configuration", { reason: "configuration-invalid" });
  process.exitCode = 1;
  shutdownController.dispose();
}
if (shutdownInstalled && cloudEnvironmentReady) {
  try {
    runtimeConfig = createRuntimeConfig(process.env);
  } catch {
    startupLogger.error("service.configuration", { reason: "configuration-invalid" });
    process.exitCode = 1;
    shutdownController.dispose();
  }
}

if (runtimeConfig) {
  const startup = await startConfiguredApplication(runtimeConfig, undefined, {
    shutdownController,
  });
  if (!startup.accepted && !startup.interrupted) {
    const logger = startup.application?.operationsLogger || startupLogger;
    logger.error("service.failure", {
      phase: "failed",
      reason: "failed",
    });
    process.exitCode = 1;
    shutdownController.dispose();
  }
}
