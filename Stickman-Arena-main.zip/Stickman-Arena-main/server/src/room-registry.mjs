import { randomInt as cryptoRandomInt } from "node:crypto";

export const ROOM_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
export const ROOM_CODE_LENGTH = 7;
export const ROOM_CODE_PATTERN = /^[A-HJ-NP-Z2-9]{7}$/;
const QUICK_ROOM_ID_PATTERN = /^[A-Za-z0-9_-]{1,32}$/;
export const MAX_LIVE_ROOMS = 64;
export const MAX_CODE_ROOMS = 16;
export const ROOM_CODE_ATTEMPTS = 16;
export const ROOM_SEAT_RESERVATION_SECONDS = 10;

export function isRoomCode(value) {
  return typeof value === "string" && ROOM_CODE_PATTERN.test(value);
}

function positiveSafeInteger(value, name) {
  if (!Number.isSafeInteger(value) || value < 1) {
    throw new RangeError(`${name} must be a positive safe integer`);
  }
  return value;
}

function validOwner(owner) {
  return (typeof owner === "object" && owner !== null) || typeof owner === "function";
}

function accepted(roomId) {
  return Object.freeze({ accepted: true, roomId });
}

function rejected(reason) {
  return Object.freeze({ accepted: false, reason });
}

export function createRoomRegistry({
  randomInt = cryptoRandomInt,
  maxLiveRooms = MAX_LIVE_ROOMS,
  maxCodeRooms = MAX_CODE_ROOMS,
  attempts = ROOM_CODE_ATTEMPTS,
} = {}) {
  if (typeof randomInt !== "function") throw new TypeError("randomInt must be a function");
  positiveSafeInteger(maxLiveRooms, "maxLiveRooms");
  positiveSafeInteger(maxCodeRooms, "maxCodeRooms");
  positiveSafeInteger(attempts, "attempts");
  if (maxCodeRooms > maxLiveRooms) {
    throw new RangeError("maxCodeRooms cannot exceed maxLiveRooms");
  }

  const rooms = new Map();
  let codeRooms = 0;

  function reserveQuick(roomId, owner) {
    if (typeof roomId !== "string" || !QUICK_ROOM_ID_PATTERN.test(roomId)) {
      return rejected("invalid-room-id");
    }
    if (!validOwner(owner)) return rejected("invalid-owner");
    if (rooms.size >= maxLiveRooms) return rejected("room-capacity");
    if (rooms.has(roomId)) return rejected("room-id-collision");
    rooms.set(roomId, Object.freeze({ owner, code: false }));
    return accepted(roomId);
  }

  function nextRoomCode() {
    let result = "";
    for (let index = 0; index < ROOM_CODE_LENGTH; index += 1) {
      const selected = randomInt(0, ROOM_CODE_ALPHABET.length);
      if (!Number.isSafeInteger(selected)
          || selected < 0 || selected >= ROOM_CODE_ALPHABET.length) {
        throw new RangeError("randomInt returned an out-of-range value");
      }
      result += ROOM_CODE_ALPHABET[selected];
    }
    return result;
  }

  function reserveCode(owner) {
    if (!validOwner(owner)) return rejected("invalid-owner");
    if (rooms.size >= maxLiveRooms) return rejected("room-capacity");
    if (codeRooms >= maxCodeRooms) return rejected("code-capacity");
    for (let attempt = 0; attempt < attempts; attempt += 1) {
      const roomId = nextRoomCode();
      if (rooms.has(roomId)) continue;
      rooms.set(roomId, Object.freeze({ owner, code: true }));
      codeRooms += 1;
      return accepted(roomId);
    }
    return rejected("code-collision");
  }

  function release(roomId, owner) {
    const registered = rooms.get(roomId);
    if (!registered || registered.owner !== owner) return false;
    rooms.delete(roomId);
    if (registered.code) codeRooms -= 1;
    return true;
  }

  function snapshot() {
    return Object.freeze({
      liveRooms: rooms.size,
      codeRooms,
      roomIds: Object.freeze([...rooms.keys()].sort()),
    });
  }

  return Object.freeze({ reserveQuick, reserveCode, release, snapshot });
}

export const roomRegistry = createRoomRegistry();
