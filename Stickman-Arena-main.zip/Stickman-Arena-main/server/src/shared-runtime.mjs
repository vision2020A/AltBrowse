await import("../../sim.js");
await import("../../animation.js");
await import("../../bot.js");
await import("../../multiplayer.js");

const Sim = globalThis.StickSim;
const Anim = globalThis.StickAnim;
const Bots = globalThis.StickBots;
const Netcode = globalThis.StickMultiplayer;

function requireApi(owner, api, names) {
  if (!api || typeof api !== "object") {
    throw new Error(`Stickman Arena server: ${owner} failed to load`);
  }
  for (const name of names) {
    if (typeof api[name] !== "function") {
      throw new Error(`Stickman Arena server: ${owner}.${name} is required`);
    }
  }
}

requireApi("StickSim", Sim, [
  "createState",
  "createInputFrame",
  "fixedUpdate",
  "serialize",
  "deserialize",
]);

// These are the exact authored animation functions consulted by sim.js for
// authoritative melee contact, firearm muzzle/direction, and grenade release
// geometry. Failing at process startup is safer than silently using fallbacks.
requireApi("StickAnim", Anim, [
  "poseForFighter",
  "localToWorld",
  "swordBlade",
  "unarmedStrike",
  "gunMuzzle",
  "grenadeReleaseSocket",
]);

requireApi("StickBots", Bots, ["makeInputs", "makeBotInput"]);
requireApi("StickMultiplayer", Netcode, [
  "createCompatibilityOffer",
  "validateCompatibilityOffer",
  "createServerHello",
  "validateServerHello",
  "validateCurrentServerHello",
]);

export { Sim, Anim, Bots, Netcode };
