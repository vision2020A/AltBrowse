(function (root, factory) {
  "use strict";
  var api = factory(root);
  root.StickSim = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function (root) {
  "use strict";

  var STEP = 1 / 60;
  var VERSION = 6;
  var DEFAULT_REGULATION_TICKS = 60 * 180;
  var TAU = Math.PI * 2;
  var LAND_POSE_MIN_IMPACT = 60;
  var GUN_AIM = Object.freeze({
    minStep: -17,
    maxStep: 17,
    stepDegrees: 3,
    minDegrees: -51,
    maxDegrees: 51,
    facingDeadzone: 0.12
  });
  var GUN_AIM_DIRECTIONS = Object.freeze([
    Object.freeze({ x: 0.62932039104983750, y: -0.77714596145697079 }),
    Object.freeze({ x: 0.66913060635885824, y: -0.74314482547739424 }),
    Object.freeze({ x: 0.70710678118654757, y: -0.70710678118654746 }),
    Object.freeze({ x: 0.74314482547739424, y: -0.66913060635885824 }),
    Object.freeze({ x: 0.77714596145697090, y: -0.62932039104983739 }),
    Object.freeze({ x: 0.80901699437494745, y: -0.58778525229247314 }),
    Object.freeze({ x: 0.83867056794542405, y: -0.54463903501502708 }),
    Object.freeze({ x: 0.86602540378443871, y: -0.49999999999999994 }),
    Object.freeze({ x: 0.89100652418836790, y: -0.45399049973954675 }),
    Object.freeze({ x: 0.91354545764260087, y: -0.40673664307580015 }),
    Object.freeze({ x: 0.93358042649720174, y: -0.35836794954530027 }),
    Object.freeze({ x: 0.95105651629515353, y: -0.30901699437494740 }),
    Object.freeze({ x: 0.96592582628906831, y: -0.25881904510252074 }),
    Object.freeze({ x: 0.97814760073380569, y: -0.20791169081775931 }),
    Object.freeze({ x: 0.98768834059513777, y: -0.15643446504023087 }),
    Object.freeze({ x: 0.99452189536827329, y: -0.10452846326765346 }),
    Object.freeze({ x: 0.99862953475457383, y: -0.052335956242943828 }),
    Object.freeze({ x: 1.0000000000000000, y: 0.0000000000000000 }),
    Object.freeze({ x: 0.99862953475457383, y: 0.052335956242943828 }),
    Object.freeze({ x: 0.99452189536827329, y: 0.10452846326765346 }),
    Object.freeze({ x: 0.98768834059513777, y: 0.15643446504023087 }),
    Object.freeze({ x: 0.97814760073380569, y: 0.20791169081775931 }),
    Object.freeze({ x: 0.96592582628906831, y: 0.25881904510252074 }),
    Object.freeze({ x: 0.95105651629515353, y: 0.30901699437494740 }),
    Object.freeze({ x: 0.93358042649720174, y: 0.35836794954530027 }),
    Object.freeze({ x: 0.91354545764260087, y: 0.40673664307580015 }),
    Object.freeze({ x: 0.89100652418836790, y: 0.45399049973954675 }),
    Object.freeze({ x: 0.86602540378443871, y: 0.49999999999999994 }),
    Object.freeze({ x: 0.83867056794542405, y: 0.54463903501502708 }),
    Object.freeze({ x: 0.80901699437494745, y: 0.58778525229247314 }),
    Object.freeze({ x: 0.77714596145697090, y: 0.62932039104983739 }),
    Object.freeze({ x: 0.74314482547739424, y: 0.66913060635885824 }),
    Object.freeze({ x: 0.70710678118654757, y: 0.70710678118654746 }),
    Object.freeze({ x: 0.66913060635885824, y: 0.74314482547739424 }),
    Object.freeze({ x: 0.62932039104983750, y: 0.77714596145697079 })
  ]);

  var RULES = Object.freeze({
    hz: 60,
    // Compatibility alias; mode.rules.regulationTicks is authoritative.
    timeLimitTicks: DEFAULT_REGULATION_TICKS,
    maxHealth: 100,
    respawnTicks: 96,
    spawnProtectionTicks: 42,
    fighterHeight: 154,
    fighterRadius: 25,
    runSpeed: 430,
    runGaitRate: 1.22,
    runEntryPhaseForward: 4.8,
    runEntryPhaseReverse: 21,
    groundAccel: 2850,
    airAccel: 1550,
    friction: 2350,
    gravity: 2100,
    jumpSpeed: 940,
    maxFallSpeed: 1100,
    hazardDamage: 4,
    hazardCooldown: 60,
    pickupRadius: 62,
    pickupRespawnTicks: 60 * 10,
    healthPickupAmount: 30
  });

  var WEAPONS = Object.freeze({
    unarmed: Object.freeze({ slot: 1, damage: 10, cooldown: 30, activeStart: 7, activeEnd: 10, duration: 30, knockback: 245, hitstun: 7 }),
    sword: Object.freeze({ slot: 2, damage: 24, cooldown: 44, activeStart: 11, activeEnd: 16, duration: 44, knockback: 440, hitstun: 12 }),
    pistol: Object.freeze({ slot: 3, damage: 18, cooldown: 44, reload: 72, mag: 8, reserve: 32, speed: 1420, life: 72, knockback: 275, hitstun: 7, spread: 0 }),
    shotgun: Object.freeze({ slot: 4, damage: 4, shotCap: 32, pellets: 8, cooldown: 78, reload: 90, mag: 4, reserve: 16, speed: 1260, life: 32, knockback: 135, hitstun: 7, spread: 0.19, falloffStart: 170, falloffEnd: 520, minDamageScale: 0.35 }),
    rifle: Object.freeze({ slot: 5, damage: 3, cooldown: 5, reload: 96, mag: 36, reserve: 108, speed: 1550, life: 68, knockback: 115, hitstun: 4, spread: 0.032, automatic: true }),
    grenade: Object.freeze({ slot: 6, damage: 48, cooldown: 60, count: 3, fuse: 120, radius: 190, throwSpeed: 760, knockback: 680, hitstun: 14, releaseAge: 16, duration: 38 })
  });

  // Slot zero means "no switch"; serializable command slots are 1-based.
  var SLOT_WEAPONS = [null, "unarmed", "sword", "pistol", "shotgun", "rifle", "grenade"];
  var COLORS = ["#26e3ff", "#ff4e64", "#ffd052", "#5cff91"];
  var NAMES = ["YOU", "RAZOR", "NOVA", "HEX"];
  var DEFAULT_MODE_ID = "free-for-all";
  var DEFAULT_MAP_ID = "original-arena";

  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.keys(value).forEach(function (key) { deepFreeze(value[key]); });
    return Object.freeze(value);
  }

  var MODE_CATALOG = deepFreeze({
    "free-for-all": {
      id: "free-for-all",
      label: "Free-for-All Deathmatch",
      playerLimits: { min: 2, max: 4 },
      teamStructure: "free-for-all",
      rules: {
        regulationTicks: DEFAULT_REGULATION_TICKS,
        scoreScope: "individual",
        scoreRule: "defeats",
        scorePerDefeat: 1,
        resultRule: "highest-score",
        tieRule: "draw"
      }
    }
  });

  var MAP_CATALOG = deepFreeze({
    "original-arena": {
      id: "original-arena",
      label: "Original Arena",
      supportedModeIds: ["free-for-all"],
      width: 1920,
      height: 1080,
      groundY: 880,
      platforms: [
        { id: 0, x: 0, y: 880, w: 835, h: 200, ground: true },
        { id: 7, x: 1085, y: 880, w: 835, h: 200, ground: true },
        { id: 8, x: 790, y: 820, w: 340, h: 24, bridge: true },
        { id: 1, x: 145, y: 685, w: 405, h: 24 },
        { id: 2, x: 670, y: 630, w: 580, h: 24 },
        { id: 3, x: 1370, y: 685, w: 405, h: 24 },
        { id: 4, x: 390, y: 465, w: 370, h: 22 },
        { id: 5, x: 1160, y: 465, w: 370, h: 22 },
        { id: 6, x: 820, y: 305, w: 280, h: 22 }
      ],
      hazards: [
        { id: 0, kind: "energy", x: 835, y: 910, w: 250, h: 170, damage: RULES.hazardDamage }
      ],
      pickups: [
        { id: 100, kind: "weapon", weapon: "sword", x: 345, y: 650 },
        { id: 101, kind: "weapon", weapon: "pistol", x: 960, y: 595 },
        { id: 102, kind: "weapon", weapon: "shotgun", x: 1575, y: 650 },
        { id: 103, kind: "weapon", weapon: "rifle", x: 575, y: 430 },
        { id: 104, kind: "weapon", weapon: "grenade", x: 1345, y: 430 },
        { id: 105, kind: "ammo", weapon: "ammo", x: 960, y: 270 },
        { id: 106, kind: "health", x: 960, y: 785 }
      ],
      botRoutes: {
        topObjective: {
          fromPlatformId: 2,
          toPlatformId: 6,
          viaPlatformIds: [4, 5]
        }
      },
      spawns: [
        { x: 260, y: 880, platformId: 0, tier: 0 },
        { x: 705, y: 880, platformId: 0, tier: 0 },
        { x: 1215, y: 880, platformId: 7, tier: 0 },
        { x: 1660, y: 880, platformId: 7, tier: 0 },
        { x: 225, y: 685, platformId: 1, tier: 1 },
        { x: 790, y: 630, platformId: 2, tier: 1 },
        { x: 1695, y: 685, platformId: 3, tier: 1 },
        { x: 455, y: 465, platformId: 4, tier: 2 },
        { x: 1465, y: 465, platformId: 5, tier: 2 },
        { x: 875, y: 305, platformId: 6, tier: 2 },
        { x: 1045, y: 305, platformId: 6, tier: 2 }
      ]
    }
  });

  function clamp(n, lo, hi) { return n < lo ? lo : n > hi ? hi : n; }
  function approach(n, target, amount) {
    if (n < target) return Math.min(n + amount, target);
    if (n > target) return Math.max(n - amount, target);
    return target;
  }
  function hypot(x, y) { return Math.sqrt(x * x + y * y); }
  function normalize(x, y, fallbackX, fallbackY) {
    var d = hypot(x, y);
    return d > 0.00001 ? { x: x / d, y: y / d } : { x: fallbackX, y: fallbackY };
  }
  function symmetricAimStep(value) {
    // atan2-to-degrees can land a few ulps below an exact half step. The tiny
    // tolerance makes the documented half-away-from-zero rule deterministic
    // without materially widening a 3-degree bucket.
    var magnitude = Math.floor(Math.abs(value) / GUN_AIM.stepDegrees + 0.5 + 1e-12);
    if (magnitude === 0) return 0;
    return clamp(value < 0 ? -magnitude : magnitude, GUN_AIM.minStep, GUN_AIM.maxStep);
  }
  function resolveGunAim(aimX, aimY, priorFacing, committedStep) {
    var facing = priorFacing < 0 ? -1 : 1;
    var x = Number(aimX);
    var y = Number(aimY);
    if (!Number.isFinite(x)) x = 0;
    if (!Number.isFinite(y)) y = 0;
    var normalized = normalize(x, y, facing, 0);
    var hasCommittedStep = Number.isFinite(committedStep);
    if (!hasCommittedStep) {
      if (normalized.x < -GUN_AIM.facingDeadzone) facing = -1;
      else if (normalized.x > GUN_AIM.facingDeadzone) facing = 1;
    }

    var step;
    if (hasCommittedStep) {
      step = clamp(committedStep < 0 ? Math.ceil(committedStep) : Math.floor(committedStep),
        GUN_AIM.minStep, GUN_AIM.maxStep);
    } else {
      var localDegrees = Math.atan2(normalized.y, Math.abs(normalized.x)) * 180 / Math.PI;
      step = symmetricAimStep(clamp(localDegrees, GUN_AIM.minDegrees, GUN_AIM.maxDegrees));
    }
    if (step === 0) step = 0;
    var local = GUN_AIM_DIRECTIONS[step - GUN_AIM.minStep];
    return {
      step: step,
      degrees: step * GUN_AIM.stepDegrees,
      radians: step * GUN_AIM.stepDegrees * Math.PI / 180,
      facing: facing,
      x: local.x * facing,
      y: local.y
    };
  }
  function grenadeLaunchDirection(aimX, aimY, facing) {
    var face = facing < 0 ? -1 : 1;
    var x = Number(aimX);
    var y = Number(aimY);
    if (!Number.isFinite(x)) x = face;
    if (!Number.isFinite(y)) y = 0;
    var aim = normalize(x, y, face, -0.2);
    return normalize(aim.x, Math.min(aim.y, 0.35) - 0.22, face, -0.3);
  }
  function copyButtons(buttons) {
    buttons = buttons || {};
    return {
      jump: !!buttons.jump,
      attack: !!(buttons.attack || buttons.fire),
      pickup: !!(buttons.pickup || buttons.interact),
      reload: !!buttons.reload,
      drop: !!buttons.drop,
      rematch: !!buttons.rematch
    };
  }
  function edge(now, old, key) { return !!now[key] && !old[key]; }

  function hashSeed(seed) {
    var value = Number(seed);
    if (!isFinite(value)) value = 0x51a7f00d;
    value = value >>> 0;
    return value || 0x6d2b79f5;
  }
  function randomUint(state) {
    var x = state.rng >>> 0;
    x ^= x << 13;
    x ^= x >>> 17;
    x ^= x << 5;
    state.rng = x >>> 0;
    return state.rng;
  }
  function random(state) { return randomUint(state) / 4294967296; }
  function randomRange(state, lo, hi) { return lo + (hi - lo) * random(state); }

  function shuffledSpawnIndexes(state, indexes) {
    var result = indexes.slice();
    for (var i = result.length - 1; i > 0; i -= 1) {
      var swapIndex = randomUint(state) % (i + 1);
      var value = result[i];
      result[i] = result[swapIndex];
      result[swapIndex] = value;
    }
    return result;
  }

  function matchDefinition(modeId, mapId) {
    if (typeof modeId !== "string" || !Object.prototype.hasOwnProperty.call(MODE_CATALOG, modeId)) {
      throw new Error("StickSim: unknown modeId");
    }
    if (typeof mapId !== "string" || !Object.prototype.hasOwnProperty.call(MAP_CATALOG, mapId)) {
      throw new Error("StickSim: unknown mapId");
    }
    var mode = MODE_CATALOG[modeId];
    var map = MAP_CATALOG[mapId];
    if (map.supportedModeIds.indexOf(modeId) < 0) {
      throw new Error("StickSim: incompatible modeId/mapId");
    }
    return { mode: mode, map: map };
  }

  function hasOwn(value, key) {
    return !!value && Object.prototype.hasOwnProperty.call(value, key);
  }

  function optionIdentity(options, key, fallback) {
    if (hasOwn(options, key)) return options[key];
    if (key in Object(options)) throw new Error("StickSim: unknown " + key);
    return fallback;
  }

  function validateTopologyCounts(humanCount, botCount, playerLimits) {
    if (!Number.isInteger(humanCount) || humanCount < 0) {
      throw new Error("StickSim: humanCount must be a non-negative integer");
    }
    if (!Number.isInteger(botCount) || botCount < 0) {
      throw new Error("StickSim: botCount must be a non-negative integer");
    }
    var count = humanCount + botCount;
    if (count < playerLimits.min || count > playerLimits.max) {
      throw new Error("StickSim: humanCount + botCount must satisfy the selected mode player limits");
    }
    return count;
  }

  function stateMatchDefinition(state) {
    var config = hasOwn(state, "config") ? state.config : null;
    if (!hasOwn(config, "modeId")) throw new Error("StickSim: unknown modeId");
    if (!hasOwn(config, "mapId")) throw new Error("StickSim: unknown mapId");
    var definition = matchDefinition(config.modeId, config.mapId);
    if (!hasOwn(config, "timeLimitTicks")
      || config.timeLimitTicks !== definition.mode.rules.regulationTicks) {
      throw new Error("StickSim: serialized rules do not match modeId");
    }
    if (!hasOwn(config, "humanCount") || !hasOwn(config, "botCount")) {
      throw new Error("StickSim: serialized state is missing human/bot topology");
    }
    validateTopologyCounts(config.humanCount, config.botCount, definition.mode.playerLimits);
    return definition;
  }

  function validateModeMap(modeId, mapId) {
    matchDefinition(modeId, mapId);
    return true;
  }

  function chooseInitialSpawnIndexes(state, count, map) {
    var tierOrder = shuffledSpawnIndexes(state, [0, 1, 2]);
    var tierPools = [0, 1, 2].map(function (tier) {
      var indexes = [];
      for (var i = 0; i < map.spawns.length; i += 1) {
        if (map.spawns[i].tier === tier) indexes.push(i);
      }
      return shuffledSpawnIndexes(state, indexes);
    });
    var result = [];
    for (var fighterIndex = 0; fighterIndex < count; fighterIndex += 1) {
      var tier = tierOrder[fighterIndex % tierOrder.length];
      result.push(tierPools[tier].pop());
    }
    return result;
  }

  function cloneAuthored(value) {
    return JSON.parse(JSON.stringify(value));
  }

  function createArena(map) {
    return {
      width: map.width,
      height: map.height,
      groundY: map.groundY,
      platforms: cloneAuthored(map.platforms),
      hazards: cloneAuthored(map.hazards)
    };
  }

  function blankAmmo() {
    return {
      pistol: { mag: 0, reserve: 0 },
      shotgun: { mag: 0, reserve: 0 },
      rifle: { mag: 0, reserve: 0 },
      grenade: { count: 0 }
    };
  }

  function grantWeapon(fighter, weapon, full) {
    if (!WEAPONS[weapon]) return;
    fighter.inventory[weapon] = true;
    if (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle") {
      var data = WEAPONS[weapon];
      var ammo = fighter.ammo[weapon];
      if (full) {
        ammo.mag = data.mag;
        ammo.reserve = Math.max(ammo.reserve, data.reserve);
      } else {
        ammo.mag = Math.max(ammo.mag, Math.ceil(data.mag * 0.5));
        ammo.reserve = Math.min(data.reserve * 2, ammo.reserve + data.mag * 2);
      }
    } else if (weapon === "grenade") {
      fighter.ammo.grenade.count = full ? WEAPONS.grenade.count : Math.min(6, fighter.ammo.grenade.count + 2);
    }
  }

  function placeFighterAtSpawn(fighter, spawnIndex, arena, map) {
    var spawn = map.spawns[spawnIndex];
    fighter.spawnIndex = spawnIndex;
    fighter.x = spawn.x;
    fighter.y = spawn.y;
    fighter.prevX = spawn.x;
    fighter.prevY = spawn.y;
    fighter.vx = 0;
    fighter.vy = 0;
    fighter.facing = spawn.x < arena.width * 0.5 ? 1 : -1;
    fighter.prevVx = 0;
    fighter.prevVy = 0;
    fighter.prevGrounded = true;
    fighter.prevFacing = fighter.facing;
    fighter.aimX = fighter.facing;
    fighter.aimY = 0;
    fighter.aimFacing = fighter.facing;
    fighter.aimStep = 0;
    fighter.grounded = true;
    fighter.platformId = spawn.platformId;
    fighter.dropThrough = 0;
    fighter.landTimer = 0;
    if (fighter.locomotion) {
      fighter.locomotion = {
        kind: "idle", age: 0, gaitPhase: 0,
        previousKind: "idle", previousAge: 0, previousGaitPhase: 0,
        previousVx: 0, previousTravelSign: fighter.facing, previousMoveIntent: false,
        previousEntryKind: "idle", previousEntryAge: 0,
        previousTurn: null, previousLandExit: null, previousRunExit: null,
        travelSign: fighter.facing, moveIntent: false,
        turn: null, landExit: null, runExit: null
      };
    }
  }

  function createFighter(id, isBot, spawnIndex, arena, map) {
    var ammo = blankAmmo();
    var fighter = {
      id: id,
      name: NAMES[id] || ("BOT " + id),
      color: COLORS[id % COLORS.length],
      isBot: !!isBot,
      drawScale: 1.18,
      spawnIndex: spawnIndex,
      x: 0,
      y: 0,
      prevX: 0,
      prevY: 0,
      vx: 0,
      vy: 0,
      prevVx: 0,
      prevVy: 0,
      prevGrounded: true,
      prevFacing: 1,
      facing: 1,
      aimX: 1,
      aimY: 0,
      aimFacing: 1,
      aimStep: 0,
      grounded: true,
      platformId: null,
      dropThrough: 0,
      health: RULES.maxHealth,
      maxHealth: RULES.maxHealth,
      hitstun: 0,
      hurtCooldown: 0,
      hazardCooldown: 0,
      invuln: RULES.spawnProtectionTicks,
      dead: false,
      respawn: 0,
      respawnVisual: 0,
      life: { kind: "alive", age: 0 },
      score: 0,
      deaths: 0,
      weapon: "unarmed",
      inventory: { unarmed: true, sword: false, pistol: false, shotgun: false, rifle: false, grenade: false },
      ammo: ammo,
      cooldown: 0,
      reload: 0,
      attack: null,
      attackAge: 0,
      recoil: 0,
      landTimer: 0,
      locomotion: {
        kind: "idle", age: 0, gaitPhase: 0,
        previousKind: "idle", previousAge: 0, previousGaitPhase: 0,
        previousVx: 0, previousTravelSign: 1, previousMoveIntent: false,
        previousEntryKind: "idle", previousEntryAge: 0,
        previousTurn: null, previousLandExit: null, previousRunExit: null,
        travelSign: 1, moveIntent: false,
        turn: null, landExit: null, runExit: null
      },
      anim: "idle",
      animTick: 0,
      action: "idle",
      actionAge: 0,
      lastHitBy: null,
      prevButtons: copyButtons(null)
    };
    placeFighterAtSpawn(fighter, spawnIndex, arena, map);
    return fighter;
  }

  function createPickups(map) {
    return map.pickups.map(function (pickup) {
      var runtimePickup = cloneAuthored(pickup);
      runtimePickup.active = true;
      runtimePickup.respawn = 0;
      return runtimePickup;
    });
  }

  function createState(options) {
    options = options || {};
    var modeId = optionIdentity(options, "modeId", DEFAULT_MODE_ID);
    var mapId = optionIdentity(options, "mapId", DEFAULT_MAP_ID);
    var definition = matchDefinition(modeId, mapId);
    if (Object.prototype.hasOwnProperty.call(options, "timeLimitTicks")) {
      throw new Error("StickSim: timeLimitTicks is owned by the selected mode");
    }
    var timeLimitTicks = definition.mode.rules.regulationTicks;
    var humanCount = hasOwn(options, "humanCount") ? options.humanCount : 1;
    var maximumBots = definition.mode.playerLimits.max - 1;
    var botCount = hasOwn(options, "botCount") ? options.botCount : maximumBots;
    var count = validateTopologyCounts(humanCount, botCount, definition.mode.playerLimits);
    var seed = hashSeed(options.seed == null ? 0x51a7f00d : options.seed);
    var arena = createArena(definition.map);
    var state = {
      version: VERSION,
      tick: 0,
      seed: seed,
      rng: seed,
      config: {
        humanCount: humanCount,
        botCount: botCount,
        timeLimitTicks: timeLimitTicks,
        modeId: modeId,
        mapId: mapId
      },
      arena: arena,
      fighters: [],
      projectiles: [],
      grenades: [],
      pickups: createPickups(definition.map),
      shotGroups: {},
      nextEntityId: 1000,
      match: {
        phase: "playing",
        ticksRemaining: timeLimitTicks,
        winnerId: null,
        reason: null
      },
      events: []
    };
    var spawnIndexes = chooseInitialSpawnIndexes(state, count, definition.map);
    for (var i = 0; i < count; i += 1) {
      state.fighters.push(createFighter(i, i >= humanCount, spawnIndexes[i], arena, definition.map));
    }
    return state;
  }

  function createInputFrame(state) {
    var actors = [];
    var fighters = state && state.fighters ? state.fighters.slice().sort(byId) : [];
    for (var i = 0; i < fighters.length; i += 1) {
      actors.push({
        id: fighters[i].id,
        moveX: 0,
        moveY: 0,
        aimX: fighters[i].facing,
        aimY: 0,
        weaponSlot: null,
        buttons: copyButtons(null)
      });
    }
    return { tick: state ? state.tick : 0, actors: actors };
  }

  function byId(a, b) { return a.id - b.id; }
  function readActorInputs(frame) {
    var map = Object.create(null);
    if (!frame) return map;
    var list = Array.isArray(frame) ? frame : (frame.actors || frame.inputs || []);
    if (Array.isArray(list)) {
      for (var i = 0; i < list.length; i += 1) if (list[i] && list[i].id != null) map[list[i].id] = list[i];
    } else {
      var keys = Object.keys(list).sort();
      for (var k = 0; k < keys.length; k += 1) {
        var item = list[keys[k]] || {};
        if (item.id == null) item = Object.assign({ id: Number(keys[k]) }, item);
        map[item.id] = item;
      }
    }
    return map;
  }

  function normalizedInput(raw, fighter) {
    raw = raw || {};
    var moveX = Number(raw.moveX);
    var moveY = Number(raw.moveY);
    if (!Number.isFinite(moveX)) moveX = 0;
    if (!Number.isFinite(moveY)) moveY = 0;
    moveX = clamp(moveX, -1, 1);
    moveY = clamp(moveY, -1, 1);
    var rawAimX = Number(raw.aimX);
    var rawAimY = Number(raw.aimY);
    if (!Number.isFinite(rawAimX)) rawAimX = 0;
    if (!Number.isFinite(rawAimY)) rawAimY = 0;
    var aim = normalize(rawAimX, rawAimY, fighter.aimFacing < 0 ? -1 : fighter.facing, 0);
    return {
      id: fighter.id,
      moveX: moveX,
      moveY: moveY,
      aimX: aim.x,
      aimY: aim.y,
      weaponSlot: raw.weaponSlot == null ? null : raw.weaponSlot,
      buttons: copyButtons(raw.buttons)
    };
  }

  function emit(state, type, data) {
    var event = { id: state.nextEntityId++, tick: state.tick, type: type };
    if (data) {
      var keys = Object.keys(data);
      for (var i = 0; i < keys.length; i += 1) event[keys[i]] = data[keys[i]];
    }
    state.events.push(event);
    return event;
  }

  function emitCue(state, type, data) {
    // Presentation cues are unique within their fixed-step event frame but do
    // not consume gameplay entity IDs. A future authoritative transport can
    // identify them by tick plus this negative, tick-local ID.
    var event = { id: -(state.events.length + 1), tick: state.tick, type: type };
    if (data) {
      var keys = Object.keys(data);
      for (var i = 0; i < keys.length; i += 1) event[keys[i]] = data[keys[i]];
    }
    state.events.push(event);
    return event;
  }

  function setAnim(fighter, name, force) {
    if (force || fighter.anim !== name) {
      fighter.anim = name;
      fighter.animTick = 0;
    } else {
      fighter.animTick += 1;
    }
    fighter.action = fighter.anim;
    fighter.actionAge = fighter.animTick;
  }

  function chooseRespawnIndex(state, fighter) {
    var map = stateMatchDefinition(state).map;
    var candidates = [];
    for (var i = 0; i < map.spawns.length; i += 1) {
      if (i !== fighter.spawnIndex) candidates.push(i);
    }
    var clear = candidates.filter(function (spawnIndex) {
      var spawn = map.spawns[spawnIndex];
      return state.fighters.every(function (other) {
        if (other.id === fighter.id) return true;
        return hypot(spawn.x - other.x, spawn.y - other.y) >= RULES.fighterHeight;
      });
    });
    if (clear.length) return clear[randomUint(state) % clear.length];

    var bestIndex = candidates[0];
    var bestDistance = -1;
    for (var c = 0; c < candidates.length; c += 1) {
      var candidate = map.spawns[candidates[c]];
      var nearest = Infinity;
      for (var f = 0; f < state.fighters.length; f += 1) {
        var other = state.fighters[f];
        if (other.id === fighter.id) continue;
        nearest = Math.min(nearest, hypot(candidate.x - other.x, candidate.y - other.y));
      }
      if (nearest > bestDistance) {
        bestDistance = nearest;
        bestIndex = candidates[c];
      }
    }
    return bestIndex;
  }

  function respawnFighter(state, fighter) {
    var map = stateMatchDefinition(state).map;
    placeFighterAtSpawn(fighter, chooseRespawnIndex(state, fighter), state.arena, map);
    fighter.health = fighter.maxHealth;
    fighter.hitstun = 0;
    fighter.hurtCooldown = 0;
    fighter.hazardCooldown = 0;
    fighter.invuln = RULES.spawnProtectionTicks;
    fighter.dead = false;
    fighter.respawn = 0;
    fighter.respawnVisual = 24;
    fighter.life = { kind: "respawn", age: 0 };
    fighter.cooldown = 0;
    fighter.reload = 0;
    fighter.attack = null;
    fighter.attackAge = 0;
    fighter.recoil = 0;
    fighter.locomotion = {
      kind: "idle", age: 0, gaitPhase: 0,
      previousKind: "idle", previousAge: 0, previousGaitPhase: 0,
      previousVx: 0, previousTravelSign: fighter.facing, previousMoveIntent: false,
      previousEntryKind: "idle", previousEntryAge: 0,
      previousTurn: null, previousLandExit: null, previousRunExit: null,
      travelSign: fighter.facing, moveIntent: false,
      turn: null, landExit: null, runExit: null
    };
    setAnim(fighter, "respawn", true);
    emit(state, "respawn", { fighterId: fighter.id, x: fighter.x, y: fighter.y });
  }

  function resetMatch(state, options) {
    options = options || {};
    var definition = stateMatchDefinition(state);
    var next = createState({
      seed: options.seed == null ? state.seed : options.seed,
      humanCount: state.config.humanCount,
      botCount: state.config.botCount,
      modeId: definition.mode.id,
      mapId: definition.map.id
    });
    var keys = Object.keys(state);
    for (var i = 0; i < keys.length; i += 1) delete state[keys[i]];
    var nextKeys = Object.keys(next);
    for (var k = 0; k < nextKeys.length; k += 1) state[nextKeys[k]] = next[nextKeys[k]];
    return state;
  }

  function chooseWeapon(fighter, slot) {
    var weapon = null;
    if (typeof slot === "string") weapon = slot;
    else if (slot != null) weapon = SLOT_WEAPONS[slot | 0];
    if (!weapon || !WEAPONS[weapon] || !fighter.inventory[weapon]) return;
    if (fighter.attack || fighter.reload || fighter.hitstun || fighter.dead) return;
    fighter.weapon = weapon;
  }

  function startReload(state, fighter) {
    var weapon = fighter.weapon;
    var data = WEAPONS[weapon];
    var ammo = fighter.ammo[weapon];
    if (!ammo || !data.reload || fighter.reload || fighter.attack || fighter.cooldown || fighter.hitstun) return false;
    if (ammo.mag >= data.mag || ammo.reserve <= 0) return false;
    fighter.reload = data.reload;
    setAnim(fighter, "reload", true);
    emit(state, "reloadStart", { fighterId: fighter.id, weapon: weapon });
    return true;
  }

  function finishReload(state, fighter) {
    var data = WEAPONS[fighter.weapon];
    var ammo = fighter.ammo[fighter.weapon];
    if (!data || !ammo || !data.mag) return;
    var moved = Math.min(data.mag - ammo.mag, ammo.reserve);
    ammo.mag += moved;
    ammo.reserve -= moved;
    emit(state, "reload", { fighterId: fighter.id, weapon: fighter.weapon, amount: moved });
  }

  function poseFor(fighter) {
    var anim = root.StickAnim;
    if (!anim || typeof anim.poseForFighter !== "function") return null;
    try { return anim.poseForFighter(fighter); } catch (error) { return null; }
  }

  function normalizeSegment(value) {
    if (!value) return null;
    if (Array.isArray(value) && value.length >= 2) return { x1: value[0].x, y1: value[0].y, x2: value[1].x, y2: value[1].y };
    if (value.a && value.b) return { x1: value.a.x, y1: value.a.y, x2: value.b.x, y2: value.b.y };
    if (value.start && value.end) return { x1: value.start.x, y1: value.start.y, x2: value.end.x, y2: value.end.y };
    if (isFinite(value.x1) && isFinite(value.y1) && isFinite(value.x2) && isFinite(value.y2)) return { x1: value.x1, y1: value.y1, x2: value.x2, y2: value.y2 };
    return null;
  }

  function worldPoint(anim, pose, fighter, point) {
    if (!point) return null;
    if (anim && typeof anim.localToWorld === "function") {
      try {
        var scale = isFinite(fighter.drawScale) ? fighter.drawScale : 1;
        var footAnchored = { x: fighter.x, y: fighter.y - 61 * scale, drawScale: scale };
        return anim.localToWorld(pose, footAnchored, point);
      } catch (error) {}
    }
    var fallbackScale = isFinite(fighter.drawScale) ? fighter.drawScale : 1;
    return { x: fighter.x + point.x * fallbackScale, y: fighter.y - 61 * fallbackScale + point.y * fallbackScale };
  }

  function worldSegment(anim, pose, fighter, value) {
    var segment = normalizeSegment(value);
    if (!segment) return null;
    var a = worldPoint(anim, pose, fighter, { x: segment.x1, y: segment.y1 });
    var b = worldPoint(anim, pose, fighter, { x: segment.x2, y: segment.y2 });
    return { x1: a.x, y1: a.y, x2: b.x, y2: b.y };
  }

  function swordFallback(fighter) {
    var age = fighter.attack ? fighter.attack.age : fighter.attackAge;
    var t = clamp((age - WEAPONS.sword.activeStart) / Math.max(1, WEAPONS.sword.activeEnd - WEAPONS.sword.activeStart), 0, 1);
    var angle = -1.05 + 2.1 * t;
    var handX = fighter.x + fighter.facing * 28;
    var handY = fighter.y - 93;
    var dx = Math.cos(angle) * fighter.facing;
    var dy = Math.sin(angle);
    return { x1: handX, y1: handY, x2: handX + dx * 116, y2: handY + dy * 116 };
  }

  function swordSegment(fighter) {
    var anim = root.StickAnim;
    var pose = poseFor(fighter);
    if (anim && pose && typeof anim.swordBlade === "function") {
      try {
        var segment = worldSegment(anim, pose, fighter, anim.swordBlade(pose, fighter));
        if (segment) return segment;
      } catch (error) {}
    }
    return swordFallback(fighter);
  }

  function unarmedFallback(fighter) {
    var age = fighter.attack ? fighter.attack.age : fighter.attackAge;
    var t = clamp((age - WEAPONS.unarmed.activeStart) / Math.max(1, WEAPONS.unarmed.activeEnd - WEAPONS.unarmed.activeStart), 0, 1);
    return {
      x1: fighter.x + fighter.facing * (20 + t * 10),
      y1: fighter.y - 94,
      x2: fighter.x + fighter.facing * (64 + t * 15),
      y2: fighter.y - 91 + t * 4
    };
  }

  function unarmedSegment(fighter) {
    var anim = root.StickAnim;
    var pose = poseFor(fighter);
    if (anim && pose && typeof anim.unarmedStrike === "function") {
      try {
        var segment = worldSegment(anim, pose, fighter, anim.unarmedStrike(pose, fighter));
        if (segment) return segment;
      } catch (error) {}
    }
    return unarmedFallback(fighter);
  }

  function pointFrom(value) {
    if (!value) return null;
    if (isFinite(value.x) && isFinite(value.y)) return { x: value.x, y: value.y };
    if (value.muzzle && isFinite(value.muzzle.x) && isFinite(value.muzzle.y)) return { x: value.muzzle.x, y: value.muzzle.y };
    return null;
  }

  function gunMuzzle(fighter) {
    var anim = root.StickAnim;
    var pose = poseFor(fighter);
    if (anim && pose && typeof anim.gunMuzzle === "function") {
      try {
        var point = pointFrom(anim.gunMuzzle(pose, fighter.weapon, fighter));
        if (point) return worldPoint(anim, pose, fighter, point);
      } catch (error) {}
    }
    var resolved = resolveGunAim(
      fighter.aimX,
      fighter.aimY,
      fighter.attack && fighter.attack.kind === "gun" ? fighter.attack.facing : fighter.aimFacing,
      fighter.attack && fighter.attack.kind === "gun" ? fighter.attack.aimStep : fighter.aimStep
    );
    var length = fighter.weapon === "pistol" ? 61 : fighter.weapon === "shotgun" ? 88 : 96;
    return { x: fighter.x + resolved.x * length, y: fighter.y - 96 + resolved.y * length };
  }

  function gunDirection(fighter) {
    var anim = root.StickAnim;
    var pose = poseFor(fighter);
    if (anim && pose && typeof anim.gunMuzzle === "function") {
      try {
        var socket = anim.gunMuzzle(pose, fighter.weapon, fighter);
        if (socket && socket.direction) return normalize(socket.direction.x, socket.direction.y, fighter.facing, 0);
      } catch (error) {}
    }
    var fallback = resolveGunAim(
      fighter.aimX,
      fighter.aimY,
      fighter.attack && fighter.attack.kind === "gun" ? fighter.attack.facing : fighter.aimFacing,
      fighter.attack && fighter.attack.kind === "gun" ? fighter.attack.aimStep : fighter.aimStep
    );
    return { x: fallback.x, y: fallback.y };
  }

  function grenadeReleasePoint(fighter) {
    var anim = root.StickAnim;
    var pose = poseFor(fighter);
    if (anim && pose && typeof anim.grenadeReleaseSocket === "function") {
      try {
        var socket = anim.grenadeReleaseSocket(pose);
        var point = socket && pointFrom(socket.center || socket.grip || socket);
        if (point) return worldPoint(anim, pose, fighter, point);
      } catch (error) {}
    }
    var attack = fighter.attack || {};
    var launch = grenadeLaunchDirection(attack.aimX, attack.aimY, attack.facing);
    return { x: fighter.x + launch.x * 42, y: fighter.y - 104 + launch.y * 24 };
  }

  function rotate(vec, angle) {
    var c = Math.cos(angle);
    var s = Math.sin(angle);
    return { x: vec.x * c - vec.y * s, y: vec.x * s + vec.y * c };
  }

  function spawnBullet(state, fighter, weapon, muzzle, aim, group, spread) {
    var data = WEAPONS[weapon];
    var direction = spread ? rotate(aim, spread) : aim;
    state.projectiles.push({
      id: state.nextEntityId++,
      ownerId: fighter.id,
      weapon: weapon,
      groupId: group,
      x: muzzle.x,
      y: muzzle.y,
      prevX: muzzle.x,
      prevY: muzzle.y,
      vx: direction.x * data.speed,
      vy: direction.y * data.speed,
      life: data.life,
      damage: data.damage,
      knockback: data.knockback,
      hitstun: data.hitstun
    });
  }

  function shotgunImpactAtDistance(distance, baseDamage) {
    var data = WEAPONS.shotgun;
    var travelDistance = Number.isFinite(distance) ? Math.max(0, distance) : 0;
    var damageBase = Number.isFinite(baseDamage) && baseDamage > 0 ? baseDamage : data.damage;
    var scale = 1;
    if (travelDistance > data.falloffStart) {
      var progress = clamp(
        (travelDistance - data.falloffStart) / (data.falloffEnd - data.falloffStart),
        0,
        1
      );
      scale = 1 - progress * (1 - data.minDamageScale);
    }
    var damage = Math.max(1, Math.round(damageBase * scale));
    return { damage: damage, scale: scale, acceptedScale: damage / damageBase };
  }

  function shotgunImpact(bullet, travelTicks) {
    var distance = Math.max(0, travelTicks) * hypot(bullet.vx, bullet.vy) * STEP;
    return shotgunImpactAtDistance(distance, bullet.damage);
  }

  function fireGun(state, fighter) {
    var weapon = fighter.weapon;
    var data = WEAPONS[weapon];
    var ammo = fighter.ammo[weapon];
    if (!ammo || !data.speed || ammo.mag <= 0) {
      if (ammo && ammo.reserve > 0) startReload(state, fighter);
      else emit(state, "dryFire", { fighterId: fighter.id, weapon: weapon });
      fighter.cooldown = Math.max(fighter.cooldown, 8);
      return false;
    }
    ammo.mag -= 1;
    fighter.cooldown = data.cooldown;
    fighter.recoil = weapon === "shotgun" ? 12 : weapon === "rifle" ? 5 : 8;
    var committedAim = resolveGunAim(fighter.aimX, fighter.aimY, fighter.aimFacing, fighter.aimStep);
    fighter.attack = {
      kind: "gun", weapon: weapon, age: 0, duration: 12,
      facing: committedAim.facing, aimStep: committedAim.step, hitIds: []
    };
    fighter.facing = committedAim.facing;
    fighter.attackAge = 0;
    setAnim(fighter, "fire", true);
    var aim = gunDirection(fighter);
    var muzzle = gunMuzzle(fighter);
    var group = state.nextEntityId++;
    if (weapon === "shotgun") {
      state.shotGroups[group] = { cap: data.shotCap, remaining: data.pellets, born: state.tick };
      for (var i = 0; i < data.pellets; i += 1) {
        var fraction = data.pellets === 1 ? 0 : i / (data.pellets - 1);
        var evenSpread = (fraction * 2 - 1) * data.spread;
        var jitter = randomRange(state, -0.018, 0.018);
        spawnBullet(state, fighter, weapon, muzzle, aim, group, evenSpread + jitter);
      }
    } else {
      var spread = data.spread ? randomRange(state, -data.spread, data.spread) : 0;
      spawnBullet(state, fighter, weapon, muzzle, aim, group, spread);
    }
    fighter.vx -= aim.x * (weapon === "shotgun" ? 52 : weapon === "rifle" ? 7 : 15);
    emit(state, "fire", {
      fighterId: fighter.id, weapon: weapon,
      x: muzzle.x, y: muzzle.y, aimX: aim.x, aimY: aim.y,
      aimStep: committedAim.step, facing: committedAim.facing
    });
    return true;
  }

  function startMelee(state, fighter, weapon) {
    var data = WEAPONS[weapon];
    fighter.attack = { kind: "melee", weapon: weapon, age: 0, duration: data.duration, facing: fighter.facing < 0 ? -1 : 1, hitIds: [] };
    fighter.attackAge = 0;
    fighter.cooldown = data.cooldown;
    fighter.reload = 0;
    setAnim(fighter, weapon, true);
    emit(state, "attack", { fighterId: fighter.id, weapon: weapon });
  }

  function startGrenade(state, fighter) {
    if (fighter.ammo.grenade.count <= 0) {
      emit(state, "dryFire", { fighterId: fighter.id, weapon: "grenade" });
      fighter.cooldown = 8;
      return;
    }
    var aim = normalize(fighter.aimX, fighter.aimY, fighter.facing, 0);
    fighter.attack = {
      kind: "grenade",
      weapon: "grenade",
      age: 0,
      duration: WEAPONS.grenade.duration,
      released: false,
      aimX: aim.x,
      aimY: aim.y,
      facing: fighter.facing < 0 ? -1 : 1,
      hitIds: []
    };
    fighter.attackAge = 0;
    fighter.cooldown = WEAPONS.grenade.cooldown;
    setAnim(fighter, "grenade", true);
    emit(state, "attack", { fighterId: fighter.id, weapon: "grenade" });
  }

  function releaseGrenade(state, fighter) {
    var data = WEAPONS.grenade;
    if (fighter.ammo.grenade.count <= 0) return;
    fighter.ammo.grenade.count -= 1;
    var attack = fighter.attack;
    var launch = grenadeLaunchDirection(attack.aimX, attack.aimY, attack.facing);
    var release = grenadeReleasePoint(fighter);
    state.grenades.push({
      id: state.nextEntityId++,
      ownerId: fighter.id,
      x: release.x,
      y: release.y,
      prevX: release.x,
      prevY: release.y,
      vx: fighter.vx * 0.4 + launch.x * data.throwSpeed,
      vy: launch.y * data.throwSpeed,
      fuse: data.fuse,
      bounces: 0,
      radius: 10
    });
    emit(state, "grenadeThrow", {
      fighterId: fighter.id, x: release.x, y: release.y,
      aimX: launch.x, aimY: launch.y, facing: attack.facing
    });
  }

  function attackPressed(state, fighter, input, held) {
    var mayRetriggerRifle = fighter.weapon === "rifle" && fighter.attack && fighter.attack.kind === "gun";
    if (fighter.dead || fighter.hitstun || fighter.reload || fighter.cooldown || (fighter.attack && !mayRetriggerRifle)) return;
    var weapon = fighter.weapon;
    if (weapon === "unarmed" || weapon === "sword") startMelee(state, fighter, weapon);
    else if (weapon === "grenade") startGrenade(state, fighter);
    else if (held || edge(input.buttons, fighter.prevButtons, "attack")) fireGun(state, fighter);
  }

  function pointSegmentDistanceSquared(px, py, x1, y1, x2, y2) {
    var dx = x2 - x1;
    var dy = y2 - y1;
    var length2 = dx * dx + dy * dy;
    var t = length2 ? ((px - x1) * dx + (py - y1) * dy) / length2 : 0;
    t = clamp(t, 0, 1);
    var x = x1 + dx * t;
    var y = y1 + dy * t;
    var ox = px - x;
    var oy = py - y;
    return ox * ox + oy * oy;
  }

  function segmentHitsFighter(segment, fighter, radiusPad) {
    var r = RULES.fighterRadius + (radiusPad || 0);
    return pointSegmentDistanceSquared(fighter.x, fighter.y - 67, segment.x1, segment.y1, segment.x2, segment.y2) <= r * r ||
      pointSegmentDistanceSquared(fighter.x, fighter.y - 124, segment.x1, segment.y1, segment.x2, segment.y2) <= (r + 2) * (r + 2);
  }

  function closestPointOnSegment(px, py, segment) {
    var dx = segment.x2 - segment.x1;
    var dy = segment.y2 - segment.y1;
    var length2 = dx * dx + dy * dy;
    var amount = length2
      ? ((px - segment.x1) * dx + (py - segment.y1) * dy) / length2
      : 0;
    amount = clamp(amount, 0, 1);
    return {
      x: segment.x1 + dx * amount,
      y: segment.y1 + dy * amount
    };
  }

  function meleeContactPoint(segment, fighter, radiusPad) {
    var r = RULES.fighterRadius + (radiusPad || 0);
    var torsoY = fighter.y - 67;
    var headY = fighter.y - 124;
    var torsoDistance = pointSegmentDistanceSquared(
      fighter.x, torsoY, segment.x1, segment.y1, segment.x2, segment.y2
    );
    var headDistance = pointSegmentDistanceSquared(
      fighter.x, headY, segment.x1, segment.y1, segment.x2, segment.y2
    );
    var torsoHit = torsoDistance <= r * r;
    var headHit = headDistance <= (r + 2) * (r + 2);
    if (!torsoHit && !headHit) return null;
    return torsoHit && (!headHit || torsoDistance <= headDistance)
      ? closestPointOnSegment(fighter.x, torsoY, segment)
      : closestPointOnSegment(fighter.x, headY, segment);
  }

  function segmentCircleTime(x1, y1, x2, y2, cx, cy, radius) {
    var dx = x2 - x1;
    var dy = y2 - y1;
    var fx = x1 - cx;
    var fy = y1 - cy;
    var a = dx * dx + dy * dy;
    if (a < 0.000001) return fx * fx + fy * fy <= radius * radius ? 0 : null;
    var b = 2 * (fx * dx + fy * dy);
    var c = fx * fx + fy * fy - radius * radius;
    var disc = b * b - 4 * a * c;
    if (disc < 0) return null;
    var rootDisc = Math.sqrt(disc);
    var t1 = (-b - rootDisc) / (2 * a);
    var t2 = (-b + rootDisc) / (2 * a);
    if (t1 >= 0 && t1 <= 1) return t1;
    if (t2 >= 0 && t2 <= 1) return t2;
    return null;
  }

  function segmentAabbTime(x1, y1, x2, y2, box) {
    var dx = x2 - x1;
    var dy = y2 - y1;
    var t0 = 0;
    var t1 = 1;
    var pairs = [
      [-dx, x1 - box.x], [dx, box.x + box.w - x1],
      [-dy, y1 - box.y], [dy, box.y + box.h - y1]
    ];
    for (var i = 0; i < pairs.length; i += 1) {
      var p = pairs[i][0];
      var q = pairs[i][1];
      if (Math.abs(p) < 0.000001) {
        if (q < 0) return null;
      } else {
        var r = q / p;
        if (p < 0) {
          if (r > t1) return null;
          if (r > t0) t0 = r;
        } else {
          if (r < t0) return null;
          if (r < t1) t1 = r;
        }
      }
    }
    return t0;
  }

  function queueDamage(queue, victim, attackerId, amount, knockbackX, knockbackY, hitstun, weapon, groupId, x, y, tangentX, tangentY) {
    queue.push({
      victimId: victim.id,
      attackerId: attackerId,
      damage: amount,
      knockbackX: knockbackX,
      knockbackY: knockbackY,
      hitstun: hitstun,
      weapon: weapon,
      groupId: groupId == null ? null : groupId,
      x: x,
      y: y,
      tangentX: Number.isFinite(tangentX) ? tangentX : null,
      tangentY: Number.isFinite(tangentY) ? tangentY : null
    });
  }

  function resolveMelee(state, queue) {
    var fighters = state.fighters.slice().sort(byId);
    for (var i = 0; i < fighters.length; i += 1) {
      var attacker = fighters[i];
      var attack = attacker.attack;
      if (!attack || attack.kind !== "melee") continue;
      var data = WEAPONS[attack.weapon];
      if (attack.age < data.activeStart || attack.age > data.activeEnd) continue;
      var segment = attack.weapon === "sword" ? swordSegment(attacker) : unarmedSegment(attacker);
      var tangent = normalize(
        segment.x2 - segment.x1,
        segment.y2 - segment.y1,
        attack.facing,
        0
      );
      if (attack.age === data.activeStart) {
        emitCue(state, "meleeSwing", {
          fighterId: attacker.id,
          weapon: attack.weapon,
          facing: attack.facing,
          x1: segment.x1,
          y1: segment.y1,
          x2: segment.x2,
          y2: segment.y2
        });
      }
      for (var j = 0; j < fighters.length; j += 1) {
        var victim = fighters[j];
        if (victim.id === attacker.id || victim.dead || victim.invuln || attack.hitIds.indexOf(victim.id) !== -1) continue;
        var radiusPad = attack.weapon === "sword" ? 8 : 5;
        if (!segmentHitsFighter(segment, victim, radiusPad)) continue;
        var contact = meleeContactPoint(segment, victim, radiusPad);
        attack.hitIds.push(victim.id);
        var direction = normalize(victim.x - attacker.x, (victim.y - 72) - (attacker.y - 90), attacker.facing, -0.15);
        queueDamage(queue, victim, attacker.id, data.damage, direction.x * data.knockback, Math.min(-130, direction.y * data.knockback - 90), data.hitstun, attack.weapon, null, contact.x, contact.y, tangent.x, tangent.y);
      }
    }
  }

  function resolveBullets(state, queue) {
    var survivors = [];
    var fighters = state.fighters.slice().sort(byId);
    var platforms = state.arena.platforms.slice().sort(byId);
    for (var i = 0; i < state.projectiles.length; i += 1) {
      var bullet = state.projectiles[i];
      bullet.prevX = bullet.x;
      bullet.prevY = bullet.y;
      bullet.x += bullet.vx * STEP;
      bullet.y += bullet.vy * STEP;
      bullet.life -= 1;
      var best = null;
      for (var j = 0; j < fighters.length; j += 1) {
        var fighter = fighters[j];
        if (fighter.id === bullet.ownerId || fighter.dead || fighter.invuln) continue;
        var torsoT = segmentCircleTime(bullet.prevX, bullet.prevY, bullet.x, bullet.y, fighter.x, fighter.y - 68, RULES.fighterRadius + 3);
        var headT = segmentCircleTime(bullet.prevX, bullet.prevY, bullet.x, bullet.y, fighter.x, fighter.y - 124, RULES.fighterRadius + 3);
        var t = torsoT == null ? headT : headT == null ? torsoT : Math.min(torsoT, headT);
        if (t != null && (!best || t < best.t || (t === best.t && fighter.id < best.fighter.id))) best = { t: t, fighter: fighter };
      }
      var wallT = null;
      for (var p = 0; p < platforms.length; p += 1) {
        var tWall = segmentAabbTime(bullet.prevX, bullet.prevY, bullet.x, bullet.y, platforms[p]);
        if (tWall != null && (wallT == null || tWall < wallT)) wallT = tWall;
      }
      if (best && (wallT == null || best.t < wallT)) {
        var hitX = bullet.prevX + (bullet.x - bullet.prevX) * best.t;
        var hitY = bullet.prevY + (bullet.y - bullet.prevY) * best.t;
        var dir = normalize(bullet.vx, bullet.vy, 1, 0);
        var impactDamage = bullet.damage;
        var impactScale = 1;
        if (bullet.weapon === "shotgun") {
          var shotGroup = state.shotGroups[bullet.groupId];
          var fullTravelTicks = shotGroup
            ? Math.max(0, state.tick - shotGroup.born)
            : Math.max(0, WEAPONS.shotgun.life - bullet.life - 1);
          var impact = shotgunImpact(bullet, fullTravelTicks + best.t);
          impactDamage = impact.damage;
          impactScale = impact.acceptedScale;
        }
        queueDamage(queue, best.fighter, bullet.ownerId, impactDamage, dir.x * bullet.knockback * impactScale, (dir.y * bullet.knockback - 65) * impactScale, bullet.hitstun, bullet.weapon, bullet.groupId, hitX, hitY);
        emit(state, "bulletHit", { projectileId: bullet.id, fighterId: best.fighter.id, weapon: bullet.weapon, x: hitX, y: hitY });
        if (state.shotGroups[bullet.groupId]) state.shotGroups[bullet.groupId].remaining -= 1;
      } else if (wallT != null) {
        emit(state, "spark", { weapon: bullet.weapon, x: bullet.prevX + (bullet.x - bullet.prevX) * wallT, y: bullet.prevY + (bullet.y - bullet.prevY) * wallT });
        if (state.shotGroups[bullet.groupId]) state.shotGroups[bullet.groupId].remaining -= 1;
      } else if (bullet.life > 0 && bullet.x > -100 && bullet.x < state.arena.width + 100 && bullet.y > -100 && bullet.y < state.arena.height + 100) {
        survivors.push(bullet);
      } else if (state.shotGroups[bullet.groupId]) {
        state.shotGroups[bullet.groupId].remaining -= 1;
      }
    }
    state.projectiles = survivors;
  }

  function platformLanding(arena, x, oldY, newY, radius, ignoreId) {
    var result = null;
    for (var i = 0; i < arena.platforms.length; i += 1) {
      var p = arena.platforms[i];
      if (p.id === ignoreId) continue;
      if (x + radius < p.x || x - radius > p.x + p.w) continue;
      if (oldY <= p.y && newY >= p.y && (!result || p.y < result.y)) result = p;
    }
    return result;
  }

  function resolveGrenades(state, queue) {
    var alive = [];
    for (var i = 0; i < state.grenades.length; i += 1) {
      var grenade = state.grenades[i];
      grenade.prevX = grenade.x;
      grenade.prevY = grenade.y;
      grenade.vy = Math.min(grenade.vy + RULES.gravity * STEP, RULES.maxFallSpeed);
      var nextX = grenade.x + grenade.vx * STEP;
      var nextY = grenade.y + grenade.vy * STEP;
      if (nextX < 12 || nextX > state.arena.width - 12) {
        grenade.vx *= -0.62;
        nextX = clamp(nextX, 12, state.arena.width - 12);
        grenade.bounces += 1;
      }
      var landing = grenade.vy >= 0 ? platformLanding(state.arena, nextX, grenade.y + grenade.radius, nextY + grenade.radius, grenade.radius, null) : null;
      if (landing) {
        nextY = landing.y - grenade.radius;
        grenade.vy *= -0.54;
        grenade.vx *= 0.78;
        if (Math.abs(grenade.vy) < 55) grenade.vy = 0;
        grenade.bounces += 1;
        emit(state, "grenadeBounce", { grenadeId: grenade.id, x: nextX, y: nextY });
      }
      grenade.x = nextX;
      grenade.y = nextY;
      grenade.fuse -= 1;
      if (grenade.fuse <= 0 || grenade.y > state.arena.height + 60) {
        explodeGrenade(state, grenade, queue);
      } else {
        alive.push(grenade);
      }
    }
    state.grenades = alive;
  }

  function explodeGrenade(state, grenade, queue) {
    var data = WEAPONS.grenade;
    emit(state, "explosion", { grenadeId: grenade.id, ownerId: grenade.ownerId, x: grenade.x, y: grenade.y, radius: data.radius });
    var fighters = state.fighters.slice().sort(byId);
    for (var i = 0; i < fighters.length; i += 1) {
      var fighter = fighters[i];
      if (fighter.dead || fighter.invuln) continue;
      var dx = fighter.x - grenade.x;
      var dy = (fighter.y - 78) - grenade.y;
      var dist = hypot(dx, dy);
      if (dist > data.radius) continue;
      var strength = 1 - dist / data.radius;
      var damage = Math.max(8, Math.round(data.damage * (0.35 + strength * 0.65)));
      var direction = normalize(dx, dy, fighter.id === grenade.ownerId ? fighter.facing : 1, -0.4);
      var knock = data.knockback * (0.38 + strength * 0.62);
      queueDamage(queue, fighter, grenade.ownerId, damage, direction.x * knock, Math.min(-190, direction.y * knock - 140), data.hitstun, "grenade", grenade.id, fighter.x, fighter.y - 78);
    }
  }

  function flushDamage(state, queue) {
    if (!queue.length) return;
    queue.sort(function (a, b) {
      return a.victimId - b.victimId || (a.groupId == null ? -1 : a.groupId) - (b.groupId == null ? -1 : b.groupId) || a.attackerId - b.attackerId;
    });
    var grouped = [];
    var groupMap = Object.create(null);
    for (var i = 0; i < queue.length; i += 1) {
      var hit = queue[i];
      var key = hit.groupId == null ? ("single:" + i) : (hit.victimId + ":" + hit.groupId);
      var bucket = groupMap[key];
      if (!bucket) {
        bucket = {
          victimId: hit.victimId,
          attackerId: hit.attackerId,
          damage: 0,
          knockbackX: 0,
          knockbackY: 0,
          hitstun: 0,
          weapon: hit.weapon,
          groupId: hit.groupId,
          x: hit.x,
          y: hit.y,
          tangentX: hit.tangentX,
          tangentY: hit.tangentY
        };
        groupMap[key] = bucket;
        grouped.push(bucket);
      }
      var storedGroup = hit.groupId == null ? null : state.shotGroups[hit.groupId];
      var cap = hit.weapon === "shotgun" && storedGroup ? storedGroup.cap : Infinity;
      var accepted = Math.min(hit.damage, Math.max(0, cap - bucket.damage));
      if (accepted > 0) {
        var ratio = accepted / hit.damage;
        bucket.damage += accepted;
        bucket.knockbackX += hit.knockbackX * ratio;
        bucket.knockbackY += hit.knockbackY * ratio;
        bucket.hitstun = Math.max(bucket.hitstun, hit.hitstun);
      }
    }

    var victims = Object.create(null);
    for (var g = 0; g < grouped.length; g += 1) {
      var entry = grouped[g];
      if (!victims[entry.victimId]) victims[entry.victimId] = [];
      victims[entry.victimId].push(entry);
    }
    var ids = Object.keys(victims).map(Number).sort(function (a, b) { return a - b; });
    for (var v = 0; v < ids.length; v += 1) {
      var victim = fighterById(state, ids[v]);
      if (!victim || victim.dead || victim.invuln || victim.hurtCooldown) continue;
      var presentationBeforeHit = presentationSnapshot(victim);
      var hits = victims[ids[v]];
      var total = 0;
      var kx = 0;
      var ky = 0;
      var stun = 0;
      var killer = hits[0];
      for (var h = 0; h < hits.length; h += 1) {
        total += hits[h].damage;
        kx += hits[h].knockbackX;
        ky += hits[h].knockbackY;
        stun = Math.max(stun, hits[h].hitstun);
        if (hits[h].damage > killer.damage || (hits[h].damage === killer.damage && hits[h].attackerId < killer.attackerId)) killer = hits[h];
        emit(state, "hit", {
          fighterId: victim.id,
          attackerId: hits[h].attackerId,
          weapon: hits[h].weapon,
          damage: hits[h].damage,
          x: hits[h].x,
          y: hits[h].y,
          tangentX: hits[h].tangentX,
          tangentY: hits[h].tangentY
        });
      }
      victim.health = Math.max(0, victim.health - total);
      victim.vx += clamp(kx, -760, 760);
      victim.vy = Math.min(victim.vy, clamp(ky, -860, 480));
      victim.grounded = false;
      victim.platformId = null;
      victim.hitstun = Math.max(victim.hitstun, stun);
      victim.hurtCooldown = 2;
      victim.lastHitBy = killer.attackerId;
      setAnim(victim, "hit", true);
      if (victim.health <= 0) defeatFighter(state, victim, killer.attackerId, killer.weapon, presentationBeforeHit);
    }
  }

  function fighterById(state, id) {
    for (var i = 0; i < state.fighters.length; i += 1) if (state.fighters[i].id === id) return state.fighters[i];
    return null;
  }

  function runExitSnapshot(runExit) {
    if (!runExit) return null;
    var copy = Object.assign({}, runExit);
    copy.sourceTurn = runExit.sourceTurn ? Object.assign({}, runExit.sourceTurn) : null;
    copy.sourceLandExit = runExit.sourceLandExit
      ? Object.assign({}, runExit.sourceLandExit)
      : null;
    return copy;
  }

  function locomotionSnapshot(locomotion) {
    if (!locomotion) return null;
    var copy = Object.assign({}, locomotion);
    copy.turn = locomotion.turn ? Object.assign({}, locomotion.turn) : null;
    copy.landExit = locomotion.landExit ? Object.assign({}, locomotion.landExit) : null;
    copy.runExit = runExitSnapshot(locomotion.runExit);
    copy.previousTurn = locomotion.previousTurn ? Object.assign({}, locomotion.previousTurn) : null;
    copy.previousLandExit = locomotion.previousLandExit
      ? Object.assign({}, locomotion.previousLandExit)
      : null;
    copy.previousRunExit = runExitSnapshot(locomotion.previousRunExit);
    return copy;
  }

  function presentationSnapshot(fighter) {
    var attack = fighter.attack;
    return {
      facing: fighter.facing,
      weapon: fighter.weapon,
      aimX: fighter.aimX,
      aimY: fighter.aimY,
      aimFacing: fighter.aimFacing,
      aimStep: fighter.aimStep,
      grounded: fighter.grounded,
      vx: fighter.vx,
      vy: fighter.vy,
      prevVx: fighter.prevVx,
      prevVy: fighter.prevVy,
      animTick: fighter.animTick,
      locomotion: locomotionSnapshot(fighter.locomotion),
      attack: attack ? {
        kind: attack.kind,
        weapon: attack.weapon,
        age: attack.age,
        duration: attack.duration,
        facing: attack.facing,
        aimStep: attack.aimStep,
        aimX: attack.aimX,
        aimY: attack.aimY,
        released: !!attack.released
      } : null,
      action: fighter.action,
      actionAge: fighter.actionAge,
      reload: fighter.reload,
      hitstun: fighter.hitstun
    };
  }

  function defeatFighter(state, victim, attackerId, weapon, presentationSource) {
    if (victim.dead) return;
    victim.dead = true;
    victim.health = 0;
    victim.respawn = RULES.respawnTicks;
    victim.respawnVisual = 0;
    victim.life = {
      kind: "defeated",
      age: 0,
      source: presentationSource || presentationSnapshot(victim)
    };
    victim.deaths += 1;
    victim.attack = null;
    victim.reload = 0;
    victim.cooldown = 0;
    victim.hitstun = 0;
    victim.invuln = 0;
    victim.vy = Math.min(victim.vy, -260);
    setAnim(victim, "defeat", true);
    var attacker = fighterById(state, attackerId);
    if (attacker && attacker.id !== victim.id) {
      var scoreRules = stateMatchDefinition(state).mode.rules;
      if (scoreRules.scoreRule !== "defeats") throw new Error("StickSim: unsupported score rule");
      attacker.score += scoreRules.scorePerDefeat;
    }
    emit(state, "defeat", { fighterId: victim.id, attackerId: attackerId, weapon: weapon, score: attacker ? attacker.score : null });
  }

  function updateFighterPhysics(state, fighter, input) {
    fighter.prevX = fighter.x;
    fighter.prevY = fighter.y;
    fighter.prevVx = fighter.vx;
    fighter.prevVy = fighter.vy;
    fighter.prevGrounded = fighter.grounded;
    if (fighter.dead) {
      fighter.vy = Math.min(fighter.vy + RULES.gravity * STEP, RULES.maxFallSpeed);
      var deadY = fighter.y + fighter.vy * STEP;
      var deadLand = fighter.vy >= 0 ? platformLanding(state.arena, fighter.x, fighter.y, deadY, RULES.fighterRadius, null) : null;
      if (deadLand) {
        fighter.y = deadLand.y;
        fighter.vy = 0;
        fighter.vx = approach(fighter.vx, 0, RULES.friction * STEP * 0.4);
        fighter.x += fighter.vx * STEP;
      } else {
        fighter.y = deadY;
        fighter.x += fighter.vx * STEP;
      }
      fighter.x = clamp(fighter.x, 18, state.arena.width - 18);
      setAnim(fighter, "defeat", false);
      return;
    }

    if (fighter.dropThrough > 0) fighter.dropThrough -= 1;
    var control = fighter.hitstun ? 0.18 : fighter.attack && fighter.attack.kind === "melee" ? 0.35 : 1;
    var targetVx = input.moveX * RULES.runSpeed * control;
    var accel = fighter.grounded ? RULES.groundAccel : RULES.airAccel;
    if (Math.abs(input.moveX) > 0.01) fighter.vx = approach(fighter.vx, targetVx, accel * STEP);
    else fighter.vx = approach(fighter.vx, 0, (fighter.grounded ? RULES.friction : RULES.airAccel * 0.14) * STEP);

    if (fighter.grounded && edge(input.buttons, fighter.prevButtons, "drop")) {
      var dropSupport = null;
      for (var d = 0; d < state.arena.platforms.length; d += 1) {
        if (state.arena.platforms[d].id === fighter.platformId) {
          dropSupport = state.arena.platforms[d];
          break;
        }
      }
      if (dropSupport && !dropSupport.ground) {
        fighter.grounded = false;
        fighter.landTimer = 0;
        fighter.dropThrough = 12;
        fighter.platformId = null;
        fighter.y += 3;
      }
    }

    if (fighter.grounded && edge(input.buttons, fighter.prevButtons, "jump") && !fighter.hitstun) {
      fighter.grounded = false;
      fighter.landTimer = 0;
      fighter.platformId = null;
      fighter.vy = -RULES.jumpSpeed;
      emit(state, "jump", { fighterId: fighter.id, x: fighter.x, y: fighter.y });
    }

    fighter.x = clamp(fighter.x + fighter.vx * STEP, 18, state.arena.width - 18);
    if (fighter.grounded) {
      var support = null;
      for (var s = 0; s < state.arena.platforms.length; s += 1) {
        var candidate = state.arena.platforms[s];
        if (candidate.id === fighter.platformId && fighter.x + RULES.fighterRadius >= candidate.x && fighter.x - RULES.fighterRadius <= candidate.x + candidate.w) support = candidate;
      }
      if (!support) {
        fighter.grounded = false;
        fighter.platformId = null;
      } else {
        fighter.y = support.y;
        fighter.vy = 0;
      }
    }
    if (!fighter.grounded) {
      fighter.vy = Math.min(fighter.vy + RULES.gravity * STEP, RULES.maxFallSpeed);
      var nextY = fighter.y + fighter.vy * STEP;
      var ignore = fighter.dropThrough ? fighter.platformId : null;
      var landing = fighter.vy >= 0 && !fighter.dropThrough ? platformLanding(state.arena, fighter.x, fighter.y, nextY, RULES.fighterRadius, ignore) : null;
      if (landing) {
        var impact = fighter.vy;
        fighter.y = landing.y;
        fighter.vy = 0;
        fighter.grounded = true;
        fighter.platformId = landing.id;
        // Even a quiet platform landing gets the short authored settle pose;
        // sound/particle events remain reserved for forceful impacts.
        if (impact > LAND_POSE_MIN_IMPACT) fighter.landTimer = 8;
        if (impact > 330) {
          emit(state, "land", { fighterId: fighter.id, x: fighter.x, y: fighter.y, strength: clamp((impact - 300) / 600, 0, 1) });
        }
      } else {
        fighter.y = nextY;
      }
    }

    if (fighter.y > state.arena.height + 100) defeatFighter(state, fighter, fighter.lastHitBy, "fall");
  }

  function updateHazards(state, queue) {
    var fighters = state.fighters.slice().sort(byId);
    var hazards = state.arena.hazards || [];
    for (var h = 0; h < hazards.length; h += 1) {
      var hazard = hazards[h];
      var hazardCenter = hazard.x + hazard.w * 0.5;
      for (var i = 0; i < fighters.length; i += 1) {
        var f = fighters[i];
        if (f.dead || f.invuln || f.hazardCooldown) continue;
        if (f.x > hazard.x && f.x < hazard.x + hazard.w && f.y > hazard.y) {
          f.hazardCooldown = RULES.hazardCooldown;
          queueDamage(queue, f, f.lastHitBy, hazard.damage, (f.x < hazardCenter ? -1 : 1) * 135, -300, 6, "hazard", null, f.x, f.y - 25);
          emit(state, "hazard", { fighterId: f.id, x: f.x, y: f.y });
        }
      }
    }
  }

  function canCollectPickup(fighter, pickup) {
    if (!fighter || !pickup || !pickup.active || fighter.dead) return false;
    if (pickup.kind !== "health") return true;
    return fighter.health < fighter.maxHealth;
  }

  function usePickup(state, fighter) {
    var best = null;
    var bestD2 = Infinity;
    for (var i = 0; i < state.pickups.length; i += 1) {
      var pickup = state.pickups[i];
      if (!canCollectPickup(fighter, pickup)) continue;
      var dx = pickup.x - fighter.x;
      var dy = pickup.y - (fighter.y - 35);
      var d2 = dx * dx + dy * dy;
      if (d2 <= RULES.pickupRadius * RULES.pickupRadius && (d2 < bestD2 || (d2 === bestD2 && pickup.id < best.id))) {
        best = pickup;
        bestD2 = d2;
      }
    }
    if (!best) return;
    var amount = 0;
    if (best.kind === "weapon") {
      grantWeapon(fighter, best.weapon, false);
      fighter.weapon = best.weapon;
    } else if (best.kind === "ammo") {
      ["pistol", "shotgun", "rifle"].forEach(function (weapon) {
        fighter.ammo[weapon].reserve = Math.min(WEAPONS[weapon].reserve * 2, fighter.ammo[weapon].reserve + Math.ceil(WEAPONS[weapon].reserve * 0.45));
      });
      fighter.ammo.grenade.count = Math.min(6, fighter.ammo.grenade.count + 1);
    } else if (best.kind === "health") {
      amount = Math.min(RULES.healthPickupAmount, fighter.maxHealth - fighter.health);
      fighter.health = Math.min(fighter.maxHealth, fighter.health + amount);
    } else {
      return;
    }
    best.active = false;
    best.respawn = RULES.pickupRespawnTicks;
    var event = { fighterId: fighter.id, pickupId: best.id, kind: best.kind, x: best.x, y: best.y };
    if (best.weapon) event.weapon = best.weapon;
    if (best.kind === "health") {
      event.amount = amount;
      event.health = fighter.health;
    }
    emit(state, "pickup", event);
  }

  function tickPickups(state) {
    for (var i = 0; i < state.pickups.length; i += 1) {
      var pickup = state.pickups[i];
      if (!pickup.active && pickup.respawn > 0) {
        pickup.respawn -= 1;
        if (pickup.respawn <= 0) {
          pickup.active = true;
          var event = { pickupId: pickup.id, kind: pickup.kind, x: pickup.x, y: pickup.y };
          if (pickup.weapon) event.weapon = pickup.weapon;
          emit(state, "pickupRespawn", event);
        }
      }
    }
  }

  function updateTimersAndAttacks(state, fighter) {
    if (fighter.dead && fighter.life && fighter.life.kind === "defeated") fighter.life.age += 1;
    if (!fighter.dead && fighter.respawnVisual > 0) {
      fighter.respawnVisual -= 1;
      if (!fighter.life || fighter.life.kind !== "respawn") fighter.life = { kind: "respawn", age: 0 };
      else fighter.life.age += 1;
      if (fighter.respawnVisual === 0) fighter.life = { kind: "alive", age: 0 };
    }
    if (fighter.cooldown > 0) fighter.cooldown -= 1;
    if (fighter.hitstun > 0) fighter.hitstun -= 1;
    if (fighter.hurtCooldown > 0) fighter.hurtCooldown -= 1;
    if (fighter.hazardCooldown > 0) fighter.hazardCooldown -= 1;
    if (fighter.invuln > 0) fighter.invuln -= 1;
    if (fighter.recoil > 0) fighter.recoil -= 1;
    if (fighter.landTimer > 0) fighter.landTimer -= 1;
    if (fighter.reload > 0) {
      fighter.reload -= 1;
      if (fighter.reload === 0) finishReload(state, fighter);
    }
    if (fighter.attack) {
      fighter.attack.age += 1;
      fighter.attackAge = fighter.attack.age;
      fighter.actionAge = fighter.attack.age;
      if (fighter.attack.kind === "grenade" && !fighter.attack.released && fighter.attack.age >= WEAPONS.grenade.releaseAge) {
        fighter.attack.released = true;
        releaseGrenade(state, fighter);
      }
      if (fighter.attack.age >= fighter.attack.duration) {
        fighter.attack = null;
        fighter.attackAge = 0;
      }
    }
  }

  function updateLocomotion(fighter, input) {
    var kind;
    if (fighter.dead) kind = "defeat";
    else if (!fighter.grounded) kind = fighter.vy < 0 ? "jump" : "fall";
    else if (fighter.landTimer) kind = "land";
    else if (Math.abs(fighter.vx) > 45 || Math.abs(input.moveX) > 0.1) kind = "run";
    else kind = "idle";
    var locomotion = fighter.locomotion || {
      kind: kind, age: 0, gaitPhase: 0,
      previousKind: kind, previousAge: 0, previousGaitPhase: 0,
      previousVx: fighter.prevVx || 0,
      previousTravelSign: fighter.facing < 0 ? -1 : 1,
      previousMoveIntent: Math.abs(input.moveX) > 0.1,
      previousEntryKind: kind, previousEntryAge: 0,
      previousTurn: null, previousLandExit: null, previousRunExit: null,
      travelSign: fighter.facing < 0 ? -1 : 1,
      moveIntent: Math.abs(input.moveX) > 0.1,
      turn: null,
      landExit: null,
      runExit: null
    };
    var priorKind = locomotion.kind;
    if (kind === "idle" && (priorKind === "run" || priorKind === "running")
      && locomotion.runExit) {
      // Finish an already-bounded support release before opening a second
      // run-to-idle edge. This prevents two outer transitions from expiring
      // together without recursively nesting their source descriptors.
      kind = "run";
    }
    var priorAge = Number.isFinite(locomotion.age) ? locomotion.age : 0;
    var priorEntryKind = locomotion.previousKind || priorKind;
    var priorEntryAge = Number.isFinite(locomotion.previousAge) ? locomotion.previousAge : 0;
    var priorMoveIntent = !!locomotion.moveIntent;
    var priorTravelSign = locomotion.travelSign < 0 ? -1 : 1;
    var nextMoveIntent = Math.abs(input.moveX) > 0.1;
    var pendingRunExit = null;
    if (!locomotion.runExit
      && (priorKind === "run" || priorKind === "running")
      && kind === "idle") {
      // A committed support leg can be far from the uncommitted run/idle
      // target at the run-to-idle threshold. Coasting remains on the ordinary
      // run rig; once idle begins, freeze only the compact scalar source state
      // and release it over a bounded presentation transition. Never cache
      // renderer-owned pose points in the authoritative snapshot.
      pendingRunExit = {
        age: 0,
        duration: 6,
        sourceKind: priorKind,
        sourceAge: priorAge,
        sourceGaitPhase: Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0,
        sourceVx: Number.isFinite(fighter.prevVx) ? fighter.prevVx : 0,
        sourceTravelSign: priorTravelSign,
        sourceMoveIntent: priorMoveIntent,
        sourcePreviousKind: locomotion.previousKind || priorKind,
        sourcePreviousAge: Number.isFinite(locomotion.previousAge) ? locomotion.previousAge : 0,
        sourcePreviousGaitPhase: Number.isFinite(locomotion.previousGaitPhase)
          ? locomotion.previousGaitPhase
          : (Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0),
        sourcePreviousVx: Number.isFinite(locomotion.previousVx) ? locomotion.previousVx : 0,
        sourcePreviousTravelSign: locomotion.previousTravelSign < 0
          ? -1
          : locomotion.previousTravelSign > 0
            ? 1
            : priorTravelSign,
        sourcePreviousMoveIntent: !!locomotion.previousMoveIntent,
        sourcePreviousEntryKind: locomotion.previousEntryKind || locomotion.previousKind || priorKind,
        sourcePreviousEntryAge: Number.isFinite(locomotion.previousEntryAge)
          ? locomotion.previousEntryAge
          : 0,
        sourceTurn: locomotion.turn ? Object.assign({}, locomotion.turn) : null,
        sourceLandExit: locomotion.landExit ? Object.assign({}, locomotion.landExit) : null
      };
    }
    if (priorKind === kind) {
      locomotion.age = priorAge + 1;
    } else {
      locomotion.previousKind = priorKind;
      locomotion.previousAge = priorAge;
      locomotion.previousGaitPhase = Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0;
      locomotion.previousVx = Number.isFinite(fighter.prevVx) ? fighter.prevVx : 0;
      locomotion.previousTravelSign = priorTravelSign;
      locomotion.previousMoveIntent = priorMoveIntent;
      locomotion.previousEntryKind = priorEntryKind;
      locomotion.previousEntryAge = priorEntryAge;
      locomotion.previousTurn = locomotion.turn || null;
      locomotion.previousLandExit = locomotion.landExit || null;
      locomotion.previousRunExit = locomotion.runExit || null;
      locomotion.kind = kind;
      locomotion.age = 0;
      if (kind !== "idle" && kind !== "run") locomotion.turn = null;
    }
    var createdLandExit = false;
    if ((priorKind === "land" || priorKind === "landing") && (kind === "idle" || kind === "run")) {
      locomotion.landExit = {
        age: 0,
        duration: 6,
        sourceAge: priorAge,
        sourceTravelSign: priorTravelSign,
        sourcePreviousKind: priorEntryKind,
        sourcePreviousAge: priorEntryAge
      };
      createdLandExit = true;
    } else if (kind !== "idle" && kind !== "run") {
      locomotion.landExit = null;
    }
    if (!createdLandExit && locomotion.landExit) {
      locomotion.landExit.age += 1;
      if (locomotion.landExit.age >= locomotion.landExit.duration) locomotion.landExit = null;
    }
    var createdRunExit = false;
    if (pendingRunExit) {
      locomotion.runExit = pendingRunExit;
      createdRunExit = true;
    } else if (kind !== "idle" && kind !== "run") {
      locomotion.runExit = null;
    }
    if (!createdRunExit && locomotion.runExit) {
      locomotion.runExit.age += 1;
      if (locomotion.runExit.age >= locomotion.runExit.duration) locomotion.runExit = null;
    }
    locomotion.moveIntent = nextMoveIntent;
    if (kind === "run") {
      var travelSign = Math.abs(fighter.vx) > 1
        ? (fighter.vx < 0 ? -1 : 1)
        : (Math.abs(input.moveX) > 0.01 ? (input.moveX < 0 ? -1 : 1) : (locomotion.travelSign || 1));
      var hadActiveTurn = !!locomotion.turn;
      if (hadActiveTurn) {
        locomotion.turn.age += 1;
        if (locomotion.turn.age >= locomotion.turn.duration) locomotion.turn = null;
      }
      if (!hadActiveTurn && (priorKind === "idle"
        || (priorKind === "run" && locomotion.travelSign !== travelSign))) {
        // Preserve only the scalar state needed to reconstruct the prior
        // authored pose. This keeps turn blending deterministic and compact
        // without caching renderer-owned points in the simulation snapshot.
        locomotion.turn = {
          age: 0,
          duration: 8,
          sourceKind: priorKind,
          sourceAge: priorAge,
          sourceGaitPhase: Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0,
          sourceVx: Number.isFinite(fighter.prevVx) ? fighter.prevVx : 0,
          sourceTravelSign: locomotion.travelSign < 0 ? -1 : 1,
          sourceMoveIntent: priorMoveIntent,
          sourcePreviousKind: locomotion.previousKind,
          sourcePreviousAge: locomotion.previousAge
        };
      }
      if (!hadActiveTurn && (priorKind !== "run" || locomotion.travelSign !== travelSign)) {
        locomotion.gaitPhase = travelSign === (fighter.facing < 0 ? -1 : 1)
          ? RULES.runEntryPhaseForward
          : RULES.runEntryPhaseReverse;
      } else {
        var gaitSpeed = clamp(Math.abs(fighter.vx) / RULES.runSpeed, 0, 1.15);
        locomotion.gaitPhase = (locomotion.gaitPhase + gaitSpeed * RULES.runGaitRate) % 32;
      }
      if (!hadActiveTurn) locomotion.travelSign = travelSign;
    } else if (kind === "idle" && locomotion.turn) {
      locomotion.turn.age += 1;
      if (locomotion.turn.age >= locomotion.turn.duration) locomotion.turn = null;
    }
    fighter.locomotion = locomotion;
  }

  function updateAnimation(fighter, input) {
    updateLocomotion(fighter, input);
    if (fighter.dead) { setAnim(fighter, "defeat", false); return; }
    if (fighter.hitstun) { setAnim(fighter, "hit", false); return; }
    if (fighter.reload) {
      var reloadLength = WEAPONS[fighter.weapon] && WEAPONS[fighter.weapon].reload || fighter.reload;
      fighter.anim = "reload";
      fighter.animTick = reloadLength - fighter.reload;
      fighter.action = "reload";
      fighter.actionAge = fighter.animTick;
      return;
    }
    if (fighter.attack) {
      var action = fighter.attack.kind === "gun" ? "fire" : fighter.attack.weapon;
      fighter.anim = action;
      fighter.animTick = fighter.attack.age;
      fighter.action = action;
      fighter.actionAge = fighter.attack.age;
      return;
    }
    if (!fighter.grounded) { setAnim(fighter, fighter.vy < 0 ? "jump" : "fall", false); return; }
    if (fighter.landTimer) { setAnim(fighter, "land", false); return; }
    if (Math.abs(fighter.vx) > 45 || Math.abs(input.moveX) > 0.1) { setAnim(fighter, "run", false); return; }
    var aimKind = fighter.aimY < -0.32 ? "aimHigh" : fighter.aimY > 0.32 ? "aimLow" : "idle";
    setAnim(fighter, aimKind, false);
  }

  function updateMatch(state) {
    if (state.match.phase !== "playing") return;
    state.match.ticksRemaining = Math.max(0, state.match.ticksRemaining - 1);
    if (state.match.ticksRemaining !== 0) return;
    var modeRules = stateMatchDefinition(state).mode.rules;
    if (modeRules.resultRule !== "highest-score" || modeRules.tieRule !== "draw") {
      throw new Error("StickSim: unsupported result rule");
    }
    var fighters = state.fighters.slice().sort(byId);
    var sorted = fighters.slice().sort(function (a, b) { return b.score - a.score || a.id - b.id; });
    var hasUniqueLeader = sorted.length > 0 && (sorted.length === 1 || sorted[0].score !== sorted[1].score);
    var winner = hasUniqueLeader ? sorted[0] : null;
    state.match.phase = "finished";
    state.match.winnerId = winner ? winner.id : null;
    state.match.reason = winner ? "time" : "draw";
    emit(state, "matchEnd", { winnerId: state.match.winnerId, reason: state.match.reason });
  }

  function cleanShotGroups(state) {
    var keys = Object.keys(state.shotGroups);
    for (var i = 0; i < keys.length; i += 1) {
      var group = state.shotGroups[keys[i]];
      if (group.remaining <= 0 || state.tick - group.born > 120) delete state.shotGroups[keys[i]];
    }
  }

  function fixedUpdate(state, frame, dt) {
    if (!state || state.version !== VERSION) throw new Error("StickSim: incompatible or missing state");
    stateMatchDefinition(state);
    if (Math.abs((dt == null ? STEP : dt) - STEP) > 0.0000001) throw new Error("StickSim.fixedUpdate requires dt = 1/60");
    if ((frame && (frame.command === "restart" || frame.command === "rematch")) || (state.match.phase === "finished" && frame && frame.rematch)) {
      return resetMatch(state, { seed: state.seed });
    }
    state.events = [];
    state.tick += 1;
    tickPickups(state);
    var inputMap = readActorInputs(frame);
    var fighters = state.fighters.slice().sort(byId);
    var inputs = Object.create(null);
    var anyRematch = false;

    for (var i = 0; i < fighters.length; i += 1) {
      var fighter = fighters[i];
      var input = normalizedInput(inputMap[fighter.id], fighter);
      inputs[fighter.id] = input;
      anyRematch = anyRematch || input.buttons.rematch;
      updateTimersAndAttacks(state, fighter);
      if (fighter.dead) {
        if (state.match.phase === "playing") {
          fighter.respawn -= 1;
          if (fighter.respawn <= 0) respawnFighter(state, fighter);
        }
        continue;
      }
      fighter.prevFacing = fighter.facing;
      var liveGunAim = resolveGunAim(input.aimX, input.aimY, fighter.aimFacing);
      fighter.aimX = input.aimX;
      // Preserve the established grenade/legacy presentation range without
      // distorting the unit vector used by the firearm facing deadzone.
      fighter.aimY = clamp(input.aimY, -0.82, 0.82);
      fighter.aimFacing = liveGunAim.facing;
      fighter.aimStep = liveGunAim.step;
      if (fighter.attack && (fighter.attack.kind === "melee"
        || fighter.attack.kind === "grenade" || fighter.attack.kind === "gun")) {
        fighter.facing = fighter.attack.facing < 0 ? -1
          : fighter.attack.facing > 0 ? 1 : liveGunAim.facing;
      } else {
        fighter.facing = liveGunAim.facing;
      }
      if (input.weaponSlot != null) chooseWeapon(fighter, input.weaponSlot);
      if (edge(input.buttons, fighter.prevButtons, "reload")) startReload(state, fighter);
      var wantsAttack = WEAPONS[fighter.weapon].automatic ? input.buttons.attack : edge(input.buttons, fighter.prevButtons, "attack");
      if (wantsAttack) attackPressed(state, fighter, input, true);
      if (edge(input.buttons, fighter.prevButtons, "pickup")) usePickup(state, fighter);
    }

    if (state.match.phase === "finished" && anyRematch) return resetMatch(state, { seed: state.seed });

    for (var p = 0; p < fighters.length; p += 1) updateFighterPhysics(state, fighters[p], inputs[fighters[p].id]);
    var damageQueue = [];
    if (state.match.phase === "playing") {
      resolveMelee(state, damageQueue);
      resolveBullets(state, damageQueue);
      resolveGrenades(state, damageQueue);
      updateHazards(state, damageQueue);
      flushDamage(state, damageQueue);
    }
    cleanShotGroups(state);
    for (var a = 0; a < fighters.length; a += 1) {
      updateAnimation(fighters[a], inputs[fighters[a].id]);
      fighters[a].prevButtons = copyButtons(inputs[fighters[a].id].buttons);
    }
    updateMatch(state);
    return state;
  }

  function serialize(state) { return JSON.stringify(state); }
  function deserialize(json) {
    var state = typeof json === "string" ? JSON.parse(json) : JSON.parse(JSON.stringify(json));
    if (!state || state.version !== VERSION) throw new Error("StickSim: unsupported serialized state");
    stateMatchDefinition(state);
    return state;
  }

  function snapshot(state) { return deserialize(serialize(state)); }

  return Object.freeze({
    VERSION: VERSION,
    STEP: STEP,
    RULES: RULES,
    DEFAULT_MODE_ID: DEFAULT_MODE_ID,
    DEFAULT_MAP_ID: DEFAULT_MAP_ID,
    MODE_CATALOG: MODE_CATALOG,
    MAP_CATALOG: MAP_CATALOG,
    GUN_AIM: GUN_AIM,
    WEAPONS: WEAPONS,
    WEAPON_SLOTS: SLOT_WEAPONS.slice(),
    createState: createState,
    validateModeMap: validateModeMap,
    createInputFrame: createInputFrame,
    fixedUpdate: fixedUpdate,
    resetMatch: resetMatch,
    fighterById: fighterById,
    grantWeapon: grantWeapon,
    canCollectPickup: canCollectPickup,
    swordSegment: swordSegment,
    unarmedSegment: unarmedSegment,
    gunMuzzle: gunMuzzle,
    gunDirection: gunDirection,
    resolveGunAim: resolveGunAim,
    shotgunImpactAtDistance: shotgunImpactAtDistance,
    grenadeLaunchDirection: grenadeLaunchDirection,
    randomUint: randomUint,
    random: random,
    serialize: serialize,
    deserialize: deserialize,
    snapshot: snapshot
  });
});
