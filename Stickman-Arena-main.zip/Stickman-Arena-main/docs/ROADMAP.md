# Development roadmap

## Purpose and authority

This file records the approved sequence of future work so a contributor can understand the plan without access to earlier conversations. It describes destination and ordering, not current shipped behavior and not permission to start or merge a pass.

- `AGENTS.md` is the Stickman-specific contributor contract.
- `docs/STATUS.md` records what is implemented and what evidence exists now.
- `docs/GAME_DESIGN.md` and `docs/ARCHITECTURE.md` describe the current player experience and runtime.
- This roadmap owns future pass order, pass boundaries, and acceptance gates.
- `docs/MULTIPLAYER_ARCHITECTURE.md` owns the implemented local authority boundary and later dedicated-server direction.

Only one bounded issue or pass is active at a time. Routine work uses a fresh `agent/issue-<number>-<description>` branch from the exact protected, passing Alpha `develop` head and starts as a draft pull request into `develop`. Each issue receives deterministic regression coverage, updates affected documentation and `SHA256SUMS`, and reports automated, rendered, browser, deployed, and physical-device evidence separately. After exact integrated-`develop` Audit and owner Alpha validation, a separate same-repository `develop` → Production `main` release pull request freezes and audits the exact production base and Alpha head, reruns if `main` advances, and promotes with a merge commit rather than squash or rebase. GitHub Pages deploys from `main` only. Emergency production hotfixes require a separately approved protected path and prompt back-integration into `develop`. A roadmap entry does not authorize a merge; the repository merge rules in `AGENTS.md` still apply.

## Finding the current work

Read [`docs/STATUS.md`](STATUS.md) for the implemented checkpoint, active next boundary, and outstanding evidence. Continue with the first uncompleted roadmap entry that Status names; do not infer completion from this future-work document.

## Ordered passes

### Pass 2 — complete timed match

Goal: make the timer, rather than a score threshold, decide the match.

- Regulation lasts the complete `3:00`.
- Reaching five points does not end regulation early.
- The highest score at `0:00` wins.
- A tied highest score produces a clearly presented draw with immediate rematch available.
- Combat from the final simulation tick resolves before winner selection.
- Replace the former first-to-five invariant atomically in simulation, HUD, deterministic tests, `AGENTS.md`, `README.md`, game-design documentation, and status evidence.
- Do not combine animation, aim, combat balance, or multiplayer work with this pass.

### Pass 3A — fighter anatomy and authored animation

Goal: repair the fighter model and the complete existing motion set before changing combat expression.

- Remove the visible neck stroke; terminate the torso behind or at the lower edge of the head without an awkward gap.
- Preserve the large head, short torso, long athletic limbs, matte-black body, colored outline, and current gameplay scale.
- Audit idle, run, jump, fall, land, all existing aim levels, melee, recoil, hit, defeat, and respawn.
- Inspect normal scale, close-up frames, normal speed, and quarter speed.
- Repair foot sliding, detached limbs, elbow and grip errors, intersections, pose pops, weak silhouettes, and scale drift.
- Preserve authoritative melee and muzzle geometry while visual work is in progress.

### Pass 3B — fine ranged aiming

Goal: make direct pointer and touch aim feel effectively continuous without replacing authored animation or adding target selection in Pass 3B itself.

The accepted range is `-51°` through `+51°` in deterministic `3°` steps: 35 elevations for each left/right facing, or 70 facing/elevation combinations. These are local elevations relative to facing; negative is upward and positive is downward. Facing itself remains left or right, with a 0.12 horizontal hysteresis. This local-cone model deliberately leaves a 78° global seam around vertical; a future globally continuous turn requires its own serializable authority design rather than a cosmetic muzzle crossfade.

- Author a small set of strong anchor poses per firearm and interpolate them; do not hand-author 35 poses or use free-form inverse kinematics.
- Use one pure deterministic angle resolver for pose, hand grip, visible barrel, authoritative muzzle, base projectile direction before seeded spread, recoil, muzzle flash, and related effects.
- Preserve a shot's committed aim through recoil so later pointer movement cannot redirect or visually snap it.
- Ensure running and upper-body blends cannot flatten or alter the authoritative barrel angle.
- Derive the same 3° steps in the simulation from existing canonical `aimX`/`aimY` for Hybrid pointer, direct touch drag, and bots; add no device-specific actor fields. Keyboard Only deliberately retains simple level/high/low aiming.
- Keep the grenade's committed continuous input and existing ballistic launch mapping, while bringing its throw pose into honest visual alignment. Sword and unarmed retain their explicitly chosen facing behavior until their own approved command design changes.
- Pass 3B itself adds no aim assist, target selection, auto-targeting, or passive action. The separately approved touch-neutral follow-up below is the only later exception.
- Keep the resolver and authoritative muzzle/socket geometry free of Canvas and DOM dependencies; full browser/headless parity remains a Multiplayer M0 gate. A compact angle-step identifier may be useful for a future protocol, but this pass does not create a wire format or networking code.

Required regression coverage includes every firearm at every step and both facings; all exact half-step boundaries plus just-inside/outside cases; fixed-step hysteresis from both prior facings; committed-facing safety in the direction-only emergency fallback; finite anatomy without elbow-bend reversal; exact projectile-origin/visible-muzzle agreement when the required shared animation geometry is loaded; exact resolved base-aim/barrel agreement; seeded weapon spread measured relative to that base direction; run/fire/recoil continuity; committed gun-aim JSON/replay equality; Keyboard Only level/high/low preservation; shared bot inputs; and the absence of target identity or selection fields. Grenade coverage preserves committed continuous input and exact release-hand/event/projectile alignment, including the facing-hysteresis seam. Rendered review covers normal and close-up scale at normal and quarter speed.

### Pass 4 — melee, effects, and sound

Goal: strengthen readable attack commitment and impact while keeping visible geometry authoritative.

- Reauthor the existing sword action as one decisive approximately 90-degree high-to-low slash while preserving its 44-step duration, active ages 11–16, 58-unit blade, damage, knockback, and recovery.
- Align a cosmetic trail to at most four exact current/prior authored blade segments. Do not extend an endpoint, infer a swept hit volume, or let the trail enter gameplay authority.
- Emit one deterministic swing-geometry cue on the first active melee step, including on a miss. Accepted melee hits may expose their exact contact point and normalized segment tangent to presentation without changing the accepted-hit predicate or outcome.
- Give unarmed, sword, pistol, shotgun, rifle, and grenade explicit bounded impact styles and locally synthesized audio identities. Keep body impact single-sourced, transient collections capped, audio nodes cleaned up, and the stable camera unchanged.
- Add a committed thrust only after defining and approving a clear player command that intentionally selects it. This pass adds no thrust, random variant, invisible attack, attack-state field, or balance change.
- Regression coverage freezes melee tuning, single-command behavior, exact visible/authoritative geometry, trail bounds and purity, event determinism, accepted-contact alignment, presentation caps, six weapon recipes, offline resources, and absence of camera shake or gameplay mutation.

### Pass 5 — weapon differentiation (implemented)

Goal: give every approved weapon a clear tactical identity while keeping an evenly matched fight near 12–25 seconds.

- Sword retains its committed 24 damage, 440 knockback, 44-step action, and authoritative slash geometry as the high-force melee choice.
- Pistol becomes an accurate, deliberate 18-damage shot on a 44-step semiautomatic cadence, retaining its 8 + 32 ammunition and 72-step reload.
- Shotgun uses eight four-damage pellets, a serialized 32-damage same-step aggregation cap, a 78-step semiautomatic cadence, 4 + 16 shells, and a 90-step reload. Pellet damage remains full through 170 units and falls deterministically through 520 units toward a configured 0.35 pre-round scale; rounded accepted damage determines knockback. Exactly eight pellets at no more than four damage guarantee the complete trigger stays at or below 32 even when contacts span different fixed steps.
- Rifle uses the lowest individual damage at three per bullet, a five-step held-fire cadence, 36 + 108 ammunition, and a 96-step reload for sustained automatic identity.
- Grenade uses 48 center damage, 680 knockback, a 120-step fuse, a 190-unit damage radius, three carried throws, and a 60-step cooldown; no single blast defeats a full-health fighter.
- Shotgun pump and rifle magazine details distinguish their pickup and held silhouettes without changing sockets, muzzle authority, collision geometry, or gameplay state.
- `StickSim.VERSION` remains 4 and the canonical actor-input and gameplay-state schemas are unchanged. Bots retain shared inputs without Pass 5 decision adaptation, and no networking work begins here.

The Pass 5 implementation is complete. Its automated, rendered, browser, deployed, and physical-device evidence remains separately reported rather than inferred.

### Pass 6 — deterministic health pickup (implemented)

Goal: add one readable recovery choice without creating a generic power-up system.

- The duplicate lower-center ammunition pickup becomes the sole deterministic health item at authored ID 106 and position `(960, 785)`.
- The existing discrete Pickup command restores at most 30 health and never exceeds 100; full-health fighters cannot consume it.
- The item uses the existing exact 600-step respawn. Its active green medical card, inactive anchored progress ring, pickup/respawn bursts, and local cues remain presentation-only.
- Eligibility is filtered before deterministic distance/ID ordering, and no passive collection, power-up framework, catalog, progression, or equipment is added.
- `bot.js` remains unchanged; health-seeking and broader decision adaptation stay in Pass 7.

The Pass 6 implementation is merged and deployed; automated, rendered, browser, deployed, and physical-device evidence remains separately reported. The touch-neutral follow-up and Pass 7 below are also implemented.

### Touch follow-up — neutral ranged Action aim assist (implemented)

Goal: make an otherwise neutral touch Action press immediately useful without weakening pickup intent, manual aim, or deterministic authority.

- This is touch-only and requires Smart Action On. At Action press, an eligible contextual pickup always has priority; only when none is eligible may pistol, shotgun, rifle, or grenade receive an assisted starting direction.
- Snapshot the closest living opponent once by squared fighter-position distance. Exact ties choose the lower numeric fighter ID. Ignore self, dead, defeated, explicitly non-living, zero-health, malformed-position, nonnumeric-ID, and zero-distance candidates. Preserve the current immediately actionable respawn presentation: a living invulnerable or `respawnVisual` fighter remains eligible.
- Keep the snapshot through subthreshold jitter. The first deliberate drag across the existing aim threshold permanently switches that gesture to direct manual aim, even if the stick recenters. Never track, retarget, predict movement, test line of sight, or claim a hit.
- Preserve the existing weapon phases: pistol, shotgun, and grenade commit on normal release; rifle begins held automatic fire only after its readable delay and stops on release; sword and unarmed remain unchanged and never receive assist.
- With Smart Action Off, keep explicit Pickup and entirely manual ranged aim. All cancellation, capture-loss, pause, transition, resize, rotation, and visibility paths continue to fail closed without a queued attack.
- Emit only the existing finite canonical aim vector and ordinary buttons. Add no target identity, opponent reference, assist flag, claimed outcome, gameplay-state field, schema migration, network request, runtime dependency, or multiplayer behavior.
- Deterministic coverage must freeze pure normalized selection, stable ties and candidate filters, actionable invulnerable respawns, pickup priority, all four assisted weapons, press-time snapshot behavior, subthreshold retention, permanent manual override, Smart Action Off, unchanged melee, cancellation, canonical input shape, and replay equality. Browser and physical-device evidence remain separate.

The follow-up was independently audited, merged, and deployed through [pull request #33 — Add neutral Action aim assist](https://github.com/XenoVoyage/Stickman-Arena/pull/33) at runtime merge `4117f8f3`. Automated, candidate-browser, deployed-browser, and physical-device evidence remains separately reported; post-change physical iPhone/iPad verification is still pending.

### Pass 7 — bots and final evidence (implemented)

Goal: adapt bots only after player controls, timing, animation, balance, and health pickups stabilize, then close the complete evidence matrix.

- Bots continue to read serializable state and act only through shared actor inputs.
- Navigation reaches every authored top objective through stable side-platform waypoints, preserves hazard protection, and emits fresh Jump, Drop, and Pickup edges.
- Weapon selection uses owned supply and the existing Pass 5 identities: semiautomatic presses reset, rifle intent remains held for simulation-owned cadence, grenade count and safe ballistic use are recognized, reloadable reserves reload before a detour, and useful owned ranged alternatives are reselected.
- Bot firearm decisions use the exact shared fine-aim cone. Finished matches emit neutral input; closing regulation suppresses optional detours without preventing final-tick combat.
- Damaged bots can explicitly seek the one authored health pickup, including while opponents respawn, using exact simulation pickup geometry and no direct gameplay mutation.
- Frame assembly resolves the local human identity from authoritative state, is stable under equivalent array ordering, and emits unique canonical actor IDs.
- Complete automated, checksum, real-browser, responsive, animation-sheet, normal-speed, slow-motion, Pages, documentation, and branch-cleanup verification.
- Record physical iPhone/iPad touch, safe-area, orientation, audio, and feel testing only from the user's actual devices.

The controller implementation and deterministic regression matrix are complete. Automated, candidate-browser, deployed-browser, branch-cleanup, and physical-device evidence remain separately reported in Status; no later program becomes active automatically.

### Pass 8 — audio usability (complete)

Goal: make the existing synthesized effects clearly audible without weakening their identities or adding music.

- Audit the complete Web Audio voice, master-gain, and destination path and target approximately twice the prior output.
- Add clearly named Sound On/Off and Master Volume settings. Mute must be truly silent, volume must remain bounded, and unmuting must preserve the chosen level.
- Persist the audio preference through a versioned, safely migrated record. Invalid, unavailable, or unwritable browser storage must fail safely without breaking `file://` play.
- Preserve gesture-safe `AudioContext` creation/resume, deterministic local noise, bounded voices, cleanup, offline packaging, and event-only presentation routing.
- Add peak protection or equivalent bounded headroom so overlapping voices do not introduce harsh clipping while the established weapon recipes remain distinct.
- Add no music. Music and Sound Effects may become separate controls only when music exists.
- Cover preference migration, persistence, mute, gain bounds, context startup/resume, cleanup, and every approved audio-event route deterministically. Browser settings, reload persistence, sound triggers, and console behavior are required; physical MacBook/iPhone/iPad loudness acceptance remains user-owned.

The implementation, automated checks, independent audits, merged-main CI, deployed-browser review, Pages deployment, and runtime-branch cleanup are complete through [pull request #37 — Pass 8: improve audio usability](https://github.com/XenoVoyage/Stickman-Arena/pull/37) at runtime merge `01d04ff74fa4caf1de5ca8eb966e1de5117aab15`. Physical MacBook/iPhone/iPad loudness and compatibility acceptance remains pending and is not inferred from browser evidence.

### Pass 9 — compatibility evidence and targeted fixes (complete)

Goal: prepare repeatable physical-device evidence and close only confirmed bounded compatibility defects without turning the review into an unrelated redesign.

- Prepare explicit MacBook keyboard/audio and iPhone/iPad touch-comfort test matrices.
- Cover safe areas, landscape and portrait transitions, true multi-touch, pointer cancellation, visibility loss, audio startup, and sustained gameplay feel.
- Record browser, responsive/emulated, and physical evidence separately. Browser simulation is never physical-device proof.
- Apply only bounded fixes supported by the user's physical-device feedback. Physical evidence may remain pending while later architecture work proceeds, but it remains required before a production-quality release claim.

The repository-controlled implementation, automated checks, independent audits, merged-main CI, Pages deployment, deployed BFCache/browser/visual review, and branch cleanup are complete through [pull request #39 — Pass 9: prepare compatibility evidence](https://github.com/XenoVoyage/Stickman-Arena/pull/39) at runtime merge `ef365c644669ee225ee36b5566d9ab0a176f7133`. Pull-request Baseline [run #92](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32914140998), merged-main Baseline [run #93](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32914209741), Pages [run #34](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32914209708), and cleanup [run #26](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32914209659) succeeded. Physical MacBook/iPhone/iPad acceptance remains user-owned and pending; it is required before a production-quality compatibility claim but does not prevent the ordered architecture work from continuing.

### Pass 10 — mode and map foundation (complete)

Goal: make match and arena selection explicit before networking without changing current gameplay.

- Preserve the complete three-minute Free-for-All Deathmatch as the default mode and the current arena as the default map.
- Introduce stable serializable `modeId` and `mapId` values, one small explicit authored-map catalog, and one small explicit mode/rules contract.
- Keep simulation independent from UI and networking. Validate every mode/map combination deterministically.
- Add map compatibility metadata so later modes can restrict supported maps.
- Prove the default mode/map remains replay-identical wherever the added identifiers do not intentionally change serialization.
- Do not add a scripting engine, editor, procedural maps, or speculative abstraction.

The bounded implementation was squash-merged through [pull request #41 — Pass 10: add mode and map foundation](https://github.com/XenoVoyage/Stickman-Arena/pull/41) at runtime merge `0130cd08385775fef6d7c5924ab4129bd172b7fc`. It contains exactly one deeply frozen mode contract and one authored map definition, stores their stable IDs in serializable match configuration, advances the simulation schema to version 5, and rejects unknown or incompatible identities. It adds no selection UI, second map/mode, network code, dependency, or gameplay tuning. Pull-request Baseline [run #98](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32917854772), merged-main Baseline [run #99](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32917944285), Pages [run #36](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32917944282), deployed browser/visual/runtime review, and cleanup [run #28](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32917944294) succeeded. Pass 11 then began on its own branch and draft pull request.

### Pass 11 — authoritative multiplayer vertical slice (complete)

Goal: run the current Free-for-All mode and current map in one authoritative dedicated Colyseus Room per match.

- Reverify the current stable Colyseus release, migration guidance, official documentation, SDK packaging, deployment requirements, and security posture immediately before implementation.
- Keep the server simulation at fixed 60 Hz. Clients send validated canonical inputs only; the server owns positions, hits, damage, ammunition, pickups, scores, respawns, randomness, timing, and results.
- Map opaque Colyseus session IDs to stable numeric simulation actor IDs. Add a separate multi-human input aggregator; do not reuse the one-local-human-plus-bots helper.
- Validate input shape, finite values, sequence/tick windows, rate, and actor ownership. Preserve bots through the shared server-owned actor-input path.
- Keep gameplay state deterministic, serializable, and independent from Colyseus types. Add state patches/snapshots, idempotent event delivery, remote interpolation, and carefully bounded local prediction/reconciliation.
- Support join, leave, disconnect cleanup, and reconnection. Preserve the existing offline double-click `index.html` mode with no client runtime CDN.
- Exercise deterministic server replay, multiple local browser clients, artificial latency/jitter/loss, malformed inputs, and headless/offline parity. Do not claim global-network quality from local tests.

The bounded implementation was squash-merged through [pull request #43 — Pass 11: authoritative multiplayer vertical slice](https://github.com/XenoVoyage/Stickman-Arena/pull/43) at runtime commit `897903e3784e9e719c2192f46739d6f54e144976` with reviewed tree `042000594491705c5dfbf530a521e94802cbb6ab`. It exact-pins current Colyseus 0.18 packages inside `server/`, loads the shared simulation/animation/bot boundary headlessly, adds a separate strict multi-human input aggregator, runs a two-human/two-bot Room at fixed 60 Hz, publishes 20 Hz authoritative snapshots/events/hashes, and adds transport-independent prediction, reconciliation, interpolation, and event deduplication. The browser adapter is available only from the local Node service with `?online=1`; ordinary Pages and double-click play stay network-idle. Drop/reconnect reserves the same actor, clears input and SDK queues, resets prediction by epoch, and prevents stale Room callbacks. Finished matches freeze; online rematch remains deliberately disabled until Pass 12 defines authoritative match generations. Pull-request Baseline [run #104](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32950098376), merged-main Baseline [run #105](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32950232790), Pages [run #38](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32950232778), deployed default-route browser/visual review, and cleanup [run #30](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32950232769) succeeded. The connected cloud browser could not reach loopback, so real local two-tab Canvas behavior remains unclaimed; installed official-SDK integration is not relabeled as browser evidence. No service is publicly deployed and no provider or secret is selected. At the Pass 11 closeout, Pass 12 had not started.

### Pass 12 — multiplayer hardening and deployment readiness

Goal: turn the local vertical slice into a bounded, reviewable service candidate without selecting paid infrastructure on the user's behalf.

#### Pass 12A — supported runtime and dependency baseline (complete)

- Keep Node.js 22 as the intentional minimum development/test line with a fail-closed compatibility phase in required CI; select Node.js 24.19.0 LTS for `.nvmrc`, primary CI, and production guidance. As verified on 2026-08-26, Node.js 26 Current is not the production baseline.
- Replace the unused `colyseus` umbrella with the exact-pinned official modular core, WebSocket transport, tools, Schema, SDK, Express, and testing packages. Preserve current APIs and full replay/integration coverage.
- Remove the umbrella plus its unused `@colyseus/auth`, `@colyseus/monitor`, `@colyseus/playground`, `@colyseus/redis-driver`, and `@colyseus/redis-presence` entries and vulnerable Grant/JWT subtree without forced audit fixes, overrides, downgrades, or speculative infrastructure. Record both the prior 13-low/3-moderate state and the resulting zero-advisory point-in-time audit honestly.
- Correct contributor setup guidance, protect `.env*` and `.colyseus-cloud.json`, preserve the dependency-free root client, and leave the local bind, protocol, gameplay, public version, and hosting state unchanged.

The bounded implementation was squash-merged through [pull request #45 — Pass 12A: supported runtime and dependency baseline](https://github.com/XenoVoyage/Stickman-Arena/pull/45) as runtime commit `e8f365e10e64a54a581c058ff3888fbaa3133884` with reviewed tree `546457993ff1149d7e867b36cd650aa23c270e18`. Pull-request Baseline [run #110](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32961702662), merged-main Baseline [run #111](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32961815211), checksum-gated Pages [run #40](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32961815200), deployed default-route browser/visual review, and cleanup [run #32](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32961815157) succeeded. Immediately after cleanup GitHub reported only protected `main` and no open issue or pull request before the short-lived evidence closeout pull request #46. Ordinary Pages remained the same offline game; no public Node service, provider, secret, or later-pass behavior was added. Pass 12B1 began only afterward on a fresh branch and draft pull request.

#### Pass 12B1 — protocol compatibility and loopback admission (complete)

- Define protocol `1`, simulation schema `6`, input contract `1`, client runtime `classic-canvas-v1`, and diagnostic server build identity separately. Use exact prototype-safe records and server-owned canonical values; no client authority, actor, server URL, seed, mode/map override, or downgrade selection is admitted.
- Reject incompatible Quick Match requests before room creation or seat reservation. Require a bounded server hello/acknowledgement before actor binding, assignment, readiness, gameplay, and reconnect rebinding. Keep duplicate protocol/ready messages idempotent and failures fixed and non-sensitive.
- Expose only loopback `joinOrCreate/arena` and exact reconnect requests. Bound HTTP headers/bodies, WebSocket payloads/targets, aggregate admission/upgrade rates, and the negotiation timer. Require exactly one canonical loopback Host; reject forwarding metadata, absolute-form targets, malformed preflight/origin pairs, unused matchmaking methods, unknown data/byte/request-mode messages, queued request bursts, and malformed reconnect bodies before they can reach authority or reflected framework errors.
- Preserve the existing two-human/two-bot Free-for-All, Original Arena, eight-second reservation, finished-match freeze, hidden online Rematch, loopback bind, Pass 11 health/package labels, ordinary Pages network silence, and provider/hosting stop gate.

The bounded implementation was squash-merged through [pull request #47 — Pass 12B1: protocol compatibility and loopback admission](https://github.com/XenoVoyage/Stickman-Arena/pull/47) as runtime commit `ed8e04457dd0ceec4234f838fee80b0e3f245195` with reviewed tree `3341fef34eaad8191d43bf6ad347f73cf87c245a`. Pull-request Baseline [run #116](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32973699456), merged-main Baseline [run #117](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32973886787), checksum-gated Pages [run #42](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32973886882), deployed default-route browser/visual review, and cleanup [run #34](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32973886791) succeeded. GitHub then reported only protected `main` and no open issue or pull request before evidence-closeout [pull request #48](https://github.com/XenoVoyage/Stickman-Arena/pull/48). Raw TCP, official-SDK, and fake-browser evidence remain distinct from real local two-tab Canvas, physical-device, hosted-network, load/soak, operational-security, and production-service evidence. No public Node service was deployed.

#### Pass 12B2 — authoritative match generations (complete)

- Advance the online protocol and input contract to `2`, keep simulation schema `6`, and require one positive server-owned generation on input, readiness, resync, assignments, snapshots, lifecycle, acknowledgements, event identity, and rematch control wherever stale work could cross a reset. Reject stale/future generations before they mutate input, sequence, acknowledgement, readiness, or consent.
- Make the Room the explicit `waiting` → `ready` → `playing` → `finished`/`rematch-vote` → `restarting` → `ready` authority, with bounded `closing` and `disposed` behavior. Publish final-tick combat and the final authoritative snapshot before opening results.
- Accept only an exact one-shot vote/withdrawal control during a 30-second results window. Require unanimous consent from exactly two connected, admitted, ready, bound humans with no pending reservation or negotiation; gameplay `buttons.rematch` remains false and no client may reset state or choose a seed.
- On consent, increment the generation, select a distinct nonzero server seed, preserve server-owned actor seats, recreate all held input/edge, acknowledgement/sequence, prediction/interpolation, event-deduplication, replay/event/result, and timer windows, issue fresh assignments, and require both humans through a 10-second ready barrier.
- Treat the existing eight-second engineering reconnect reservation as one absolute monotonic current-generation deadline including renegotiation and reconnect storms. Drop neutralizes input and withdraws consent; expired, wrong-generation, stale, or terminal protocol/unsupported/oversized sessions receive no usable reservation. Results and post-rematch readiness expiry enter closing, disconnect clients, and dispose through the Room lifecycle.
- Cover deterministic seed/reset behavior, repeated rematches, malformed/stale/future/duplicate/withdrawn votes, wrong-generation controls and snapshots, simultaneous consent, result-screen reconnect, fresh readiness/input, reconnect storms and terminal paths, timeout races, stale callbacks, and bounded cleanup without relabeling SDK/fake-browser evidence as real Canvas evidence.

The bounded implementation was squash-merged through [pull request #49 — Pass 12B2: add authoritative match generations](https://github.com/XenoVoyage/Stickman-Arena/pull/49) as runtime commit `3a81f44f17ff5779601976bad1354a6142b9f309` with exact reviewed tree `6c57b2a0f46ab77d693bb35afb96a6e225e72a2e`. Required pull-request Baseline [run #125](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32989974986), merged-main Baseline [run #126](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32997496646), checksum-gated Pages [run #44](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32997496619), and cleanup [run #36](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/32997496727) succeeded. GitHub then reported only protected `main` and no open issue or pull request before evidence-closeout [pull request #50](https://github.com/XenoVoyage/Stickman-Arena/pull/50). Initial candidate runs #122/#123 were stranded during GitHub's declared Actions incident; restored pull-request head `43be4066282e2d84865d0c6265e50503da19df06` with the reviewed tree passed #125 after queue recovery, so no stale marker check was substituted. Connected cloud Chrome rendered ordinary Pages at `v2026.8.24`, exposed only same-origin repository scripts with no online SDK element/global or game-origin warning/error, and started a four-fighter regulation at `03:00`. The browser surface did not expose a performance-resource ledger, so this is DOM/source/visual network-idle evidence, not packet capture. Real local two-tab Canvas, physical-device, hosted-network, load/soak, operational-security, and production-service evidence remain unclaimed. No public Node service was deployed and no provider was selected.

The completed subpass preserves the two-human/two-bot Free-for-All on Original Arena, full 10,800-step authority, loopback bind, eight-second engineering reconnect value, package/service deployment labels, dependencies, public version, ordinary Pages behavior, and hosting gate.

#### Pass 12A2 — Schema patch maintenance (complete)

The final Pass 12B2 registry query observed that official `@colyseus/schema` `5.0.20` was published on 2026-08-26 after that subpass began. Pass 12B2 history remains frozen at exact `5.0.19`. After evidence-closeout pull request #50 merged and cleaned, draft [pull request #51 — Pass 12A2: update Schema to 5.0.21](https://github.com/XenoVoyage/Stickman-Arena/pull/51) began the separate exact-pin/lock migration. Its initial 5.0.20 install passed the full server suite, then the required outdated gate caught official `5.0.21` after its 18:25 UTC publication. The 5.0.21 release fixes inherited `schema().extend()` initialization, rejects duplicate inherited field declarations before corrupt decoding, and fixes a TypeScript subclass constraint; the registry diff includes built runtime JavaScript. The completed subpass exact-pins `5.0.21` and changes no other direct dependency, gameplay, protocol, simulation schema, input contract, client runtime, public version, service boundary, or hosting decision.

The reviewed runtime tree `f083c58e50ddfbc2703e2595f8f95a97abc887ed` was squash-merged through pull request #51 as `781d1003cb99a6f3d31a905117d20587ab3b6206`. Required pull-request Baseline [run #131](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33001822469), merged-main Baseline [run #132](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33002006032), checksum-gated Pages [run #46](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33002006053), and cleanup [run #38](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33002006017) succeeded. The exact lock passed 122 root tests, 90 installed server tests, complete and production zero-advisory audits, an empty direct-outdated result, and 53 checksum entries. Dependency/security, protocol/test, and documentation audits independently reported no remaining finding; they are evidence, not GitHub approvals. GitHub then reported only protected `main` and no open issue or pull request before evidence-closeout [pull request #52](https://github.com/XenoVoyage/Stickman-Arena/pull/52). Connected cloud Chrome rendered ordinary Pages at `v2026.8.24`, exposed exactly the nine same-origin repository scripts with an empty query and no online SDK global or game-origin warning/error, and started the unchanged four-fighter regulation at `03:00`. The browser surface exposed no performance-resource ledger, so this is DOM/source/visual network-idle evidence rather than packet capture. Real local two-tab Canvas, physical-device, hosted-network, load/soak, operational-security, and production-service evidence remain unclaimed. At that checkpoint, Pass 12B3 remained inactive until the evidence closeout merged and cleaned.

#### Pass 12B3A — local room matchmaking UX (complete)

[Pull request #53 — Pass 12B3A: add local room matchmaking UX](https://github.com/XenoVoyage/Stickman-Arena/pull/53) passed 123 root tests and 110 installed server tests on exact reviewed tree `f7fe6a4ad34a8fdae41f5530d4a5eb5a9a4f5455`, then was squash-merged as `38994e0d632c472d987f45214de7923ee6a00269`. Required pull-request Baseline [run #137](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33009937010), merged-main Baseline [run #138](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33010123572), checksum-gated Pages [run #48](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33010123622), and cleanup [run #40](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33010123652) succeeded. GitHub then reported only protected `main` and no open issue or pull request before evidence-closeout [pull request #54](https://github.com/XenoVoyage/Stickman-Arena/pull/54). Connected cloud Chrome rendered the ordinary empty-query Pages route at `v2026.8.24`, exposed exactly nine same-origin repository scripts and no online SDK script, kept the online menu/status hidden, emitted no game-origin console error, and started the unchanged `YOU`/`RAZOR`/`NOVA`/`HEX` regulation at `03:00`. The browser surface exposed no performance-resource ledger, so this remains DOM/source/visual network-idle evidence rather than packet capture. The exact loopback candidate remained unreachable from cloud Chrome with `net::ERR_BLOCKED_BY_CLIENT`; real local two-tab Canvas, hosted-network, load/soak, operational-security, production-service, and physical-device evidence remain unclaimed.

- Add anonymous Quick Match, Create Match, and Join Code as separate exact SDK operations. Create Match uses a server-generated seven-character uppercase code from an unambiguous alphabet; its Room is private to Quick Match, while Join Code targets only that exact Room ID.
- Keep room configuration fixed and server-frozen at `free-for-all` plus `original-arena`. Preserve exactly two human seats plus two server bots; reject arbitrary configuration, cross-operation envelopes, malformed codes, and authority fields before they can consume a seat.
- Bound the one-process registry to 64 live Rooms and 16 code Rooms, bound code collision retries to 16, keep framework seat reservation at 10 seconds, and apply aggregate and operation-specific matchmaking attempt limits. Redact framework lookup failures so no supplied code is reflected.
- Add an online-only same-origin menu with Quick, Create, Join, and explicit Cancel / Leave controls. Keep ordinary Pages and `file://` play network-idle and unchanged.
- This is a single-process local contract. Codes and Rooms are ephemeral and disappear on process restart; it does not authorize Redis, multi-process matchmaking, accounts, hosting, or a public service.

#### Pass 12A3 — Node 24 LTS maintenance update (complete)

After evidence-closeout pull request #54 merged and cleaned, [pull request #55 — Pass 12A3: update Node 24 LTS maintenance baseline](https://github.com/XenoVoyage/Stickman-Arena/pull/55) moved only `.nvmrc`, primary CI, production guidance, checksums, and invariant declarations from 24.19.0 to official Node.js 24.20.0 Latest LTS. The version change is technically semver-minor rather than a patch: official release notes include new APIs, NSS 3.125 root certificates, and bundled npm 11.19.0. Node.js 26.8.0 remains Current and is scheduled for LTS on 2026-10-28, so it is not selected for production. The intentional Node 22 minimum and fail-closed compatibility phase remain unchanged. Every direct server dependency still matches npm's stable latest tag, the lockfile is unchanged, and no protocol, gameplay, service-topology, public-version, or hosting change is included. Checksum-verified official Node.js 24.20.0 and latest Node.js 22.23.2 binaries each pass the 123-root/110-server matrices locally.

The frozen candidate `b4f960dbf6404e4d427ff8c22f3cf84b58efcd95` had exact reviewed tree `e4d09ea0997f9617136c3ff7da1d49596416add7`; required pull-request Baseline [run #143](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33014162753) succeeded before pull request #55 was squash-merged as `927bf0d689e35db2d37aca2a4b5b9a7ec19d7489` with that same tree. The merged-main Baseline [run #144](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33014278019), checksum-gated Pages [run #50](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33014278013), and cleanup [run #42](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33014277983) then succeeded. GitHub reported only protected `main` and no open issue or pull request before evidence-closeout [pull request #56](https://github.com/XenoVoyage/Stickman-Arena/pull/56). Connected cloud Chrome loaded ordinary Pages at `v2026.8.24`, found the same nine repository scripts plus the stylesheet, no online SDK script, and no visible online controls, then started the unchanged four-fighter regulation at `03:00`. The browser surface exposed no performance-resource ledger, so this is DOM/source/visual offline-default evidence rather than packet capture. No public Node service or provider exists, and real local two-tab Canvas, hosted-network, load/soak, operational-security, production-service, and physical-device evidence remain unclaimed.

#### Pass 12B3B1 — reconnect and abandonment lifecycle (complete)

- [Pull request #57 — Pass 12B3B1: harden reconnect and abandonment cleanup](https://github.com/XenoVoyage/Stickman-Arena/pull/57) adopts one server-owned absolute 30-second current-generation reconnect deadline; repeated reconnects and the application handshake consume the original remainder rather than extending it.
- Permit at most nine automatic browser SDK retries within that server deadline. The pinned SDK delay defaults schedule a nominal 26.2 seconds of waits, leaving 3.8 seconds for the bounded application handshake inside the hard 30-second server window; this deterministic arithmetic is not a network-latency guarantee. Keep the rotated SDK reconnect token in memory only: no Web Storage, reload resume, manual reconnect API, token logging, or client-supplied Room/generation authority is added. Expired, stale, rotated, cross-Room, and wrong-generation attempts fail with fixed non-sensitive behavior.
- Keep Colyseus's default reservation-aware `autoDispose` lifecycle explicit. A Room disposes only when no connected or negotiating human and no framework initial-seat or reconnect reservation remains; one connected human is not abandonment. Pending initial matchmaking seats and reconnect reservations retain their framework-owned bounded lifetimes rather than being bypassed by an application abandonment timer.
- Redact framework matchmaking lookup statuses 521, 522, 523, and 524 to one fixed unavailable response, and give terminal reconnect close code 4003 one fixed client message. The diagnostic build becomes `pass12b3b1-local`; protocol `3`, simulation schema `6`, input contract `2`, client runtime, dependencies, runtime baseline, gameplay, capacity, map/mode, public version, loopback bind, and hosting boundary remain unchanged.
- Add deterministic unit, fake-browser, official-SDK, and real framework-lifecycle regressions for deadline boundaries and storms, late handshake remainder, initial-seat protection, waiting/playing/results expiry, registry release, one-human retention, stale or wrong-generation tokens, token rotation/cross-Room rejection, redaction, retry exhaustion, and cleanup. Local and SDK evidence is not real Canvas, hosted-network, or production-service evidence.

The reviewed candidate `153df65378cbc32005f9e0971a25edbccf718220` had exact tree `57bb877d0bf606e90cdbc6bdbc06da64ea679058`. Required pull-request Baseline [run #149](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33019655764) succeeded before pull request #57 was squash-merged as `2443557c857dd6723dd986b9d8a8396e56c54f92` with that same tree. Merged-main Baseline [run #150](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33019766984), checksum-gated Pages [run #52](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33019766992), and cleanup [run #44](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33019767156) succeeded. GitHub reported only protected `main` immediately after cleanup and before the evidence branch and [pull request #58](https://github.com/XenoVoyage/Stickman-Arena/pull/58) were created; that pull request records these closeout facts.

Direct HTTPS/source verification received deployed `index.html` SHA-256 `12bff602e140eebd46e2e29c5ba35fda090277a94d3edbdfe693e7cc2c4092f1`, byte-identical to the merged file, and deployed `game.js` SHA-256 `270276f6260a9acd5fa6868371b297f1f094ddcda780cc86cdc66c7b05483422`, also matching merged source; `/online-sdk.js` returned 404.

Separately, connected cloud Chrome opened the empty-query Pages URL at 1363 × 936. It visibly rendered `v2026.8.24`, a coherent main menu, and after Play a four-fighter Original Arena Canvas at `03:00` with YOU at 100 health, unarmed, and spawn-shielded. The document and 1363 × 767 Canvas had no horizontal or vertical overflow. DOM inspection found nine same-origin repository script tags, no `/online-sdk.js` tag, and hidden online controls. Byte-identical source and root-test verification establish that the repository-local `window.StickOnline` adapter is loaded but network-idle without the explicit `?online=1` opt-in, and that the ordinary route introduces no `window.Colyseus`. The browser log had no game-origin warning/error, only extension-origin metadata errors. The browser surface exposed no performance resource ledger, so this real-browser/visual/runtime evidence is not a packet or runtime network-ledger capture and does not prove local two-tab Canvas, hosted-service, or physical-device behavior. At that B3B1 checkpoint, Pass 12B3B2 remained inactive until the evidence closeout was merged and cleaned.

#### Pass 12B3B2 — remaining client-control and resource security (complete)

- [Pull request #59 — Pass 12B3B2: harden client-control and resource security](https://github.com/XenoVoyage/Stickman-Arena/pull/59) merged the bounded local runtime as `5b233cb39089a60575d68021cbc6676e84a89157`. Candidate `62fde531886bbd800a5b43b344ff47090fa44318` and the squash merge share exact reviewed tree `0ff371be86b54aacb0f3decc7d9f65b6ddb60d34`. [Evidence-closeout pull request #60](https://github.com/XenoVoyage/Stickman-Arena/pull/60) records the merged facts without changing runtime behavior. The diagnostic build is `pass12b3b2-local`; protocol `3`, simulation schema `6`, input contract `2`, the exact dependencies and catalogs, two human seats plus two server bots, loopback-only service, ordinary network-idle Pages/`file://`, the public identifier, and every hosting stop gate remain unchanged.
- Bound each client to 120 raw frames and 32 KiB of raw payload per one second, 120 input attempts per one second, and 16 aggregate control attempts per ten seconds. Within the aggregate control budget, cap protocol request, hello acknowledgement, ready, and resync at four attempts each and rematch vote at eight attempts per ten seconds. Consume attempt budgets before semantic validation; reject unsupported Colyseus opcodes or modifiers with one fixed terminal close.
- Reject input sequence advancement beyond 120 and neutralize an unrefreshed held input after 60 authoritative ticks. Give the initial waiting generation one absolute 120-second deadline. Do not add a generic active-client idle kick: held intent becomes neutral after one second, initial waiting is bounded, and play/results/readiness already have finite authoritative lifecycle deadlines.
- Cap snapshot JSON at 32 KiB, each server snapshot/event batch at 64 events, client pending presentation events at 256, client deduplication identities at 512, prediction history at 180 inputs, and every application send against each client's 256 KiB outbound WebSocket backlog. Remove a slow client terminally without preserving a reconnect reservation. Preserve the full 10,800-step replay exactly in no-copy chunks whose current-topology retained typed-array backing storage is capped at 1,512,000 bytes per Room and reused after a zeroing generation reset; do not infer process capacity, concurrency, service availability, or load/soak performance from a deterministic per-Room ceiling.
- Fail closed against reconnect into closing/disposed authority, clear terminal Room state and budgets synchronously, return fixed non-reflective static/query/HTTP errors, preserve cache-key asset routing, disable every inherited Colyseus core debug namespace, and replace detail-bearing framework logger calls with fixed local markers. Live malformed-MessagePack regressions must keep decoded canaries and gameplay fields out of the default server console. Add no gameplay-input, direction, token, credential, private-query, analytics, or telemetry logging.
- Cover exact ceilings and relevant one-under/one-over edges, along with stale/future/duplicate/cross-actor/outcome-claiming fields, one-second neutralization, waiting and stale-timer races, aggregate/per-control abuse, unsupported opcodes/modifiers, slow-client backpressure, compact full-regulation byte equality, client/server history caps, canonical static/cache-key routing, and debug redaction. The independently reviewed frozen local candidate passes 125/125 root tests and 138/138 installed server tests on both Node.js 24.20.0 and Node.js 22.23.2. Exact-lock installation succeeds, complete and production audits report zero known vulnerabilities, and direct outdated returns `{}`. Independent reviews are evidence rather than GitHub approvals. Required pull-request Baseline [run #155](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33027598233), merged-main Baseline [run #156](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33027714237), checksum-gated Pages [run #54](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33027714234), and cleanup [run #46](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33027714290) succeeded. GitHub reported the exact reviewed tree, only protected `main`, and no open issue or pull request before closeout #60 opened.
- Connected cloud Chrome rendered the deployed empty-query `v2026.8.24` menu and a coherent four-fighter Original Arena Canvas without overflow or game-origin warning/error. The nine same-origin runtime script hashes matched the merge, online controls stayed hidden, and `/online-sdk.js` remained a Pages 404. The browser exposed no performance resource ledger; loopback was blocked before content. Therefore packet/runtime network-ledger, real local two-tab Canvas, hosted-service, load/soak, public-network, and physical-device evidence remain unclaimed.
- The current source snapshot retains Node.js 24.20.0 Latest LTS for primary CI/production guidance and Node 22 as the tested floor; Node.js 26.8.1 is Current and is not the production selection. Pass 12B4A is merged, repository-closeout complete, and verified through the approved offline deployment extent. Pass 12A4 exact Schema maintenance is also merged and verified through that approved extent, with evidence-closeout pull request #64 recording the repository facts. Pass 12B4B and evidence-closeout pull request #66 are merged and verified through the approved offline deployment extent, and cleanup is complete. Pass 12C1 is implemented on `develop`, and Pass 12C2 issue #79 is current; read `docs/STATUS.md` for its activation state.

#### Pass 12B4A — validated operations and startup baseline (complete)

- Change only the diagnostic build identity to `pass12b4a-ops`; retain online protocol `3`, simulation schema `6`, input contract `2`, current gameplay/catalog/capacity, exact dependencies, public identifier, offline Pages/`file://` behavior, and every hosting stop gate.
- Validate the complete environment record before dynamically importing Colyseus. Keep secure local defaults at `127.0.0.1:2567`. Configuration-only public mode requires production mode, an exact public bind host, canonical HTTPS public origin, and a bounded exact allowed-origin list that includes the public origin. Reject invalid ports, unknown `STICKMAN_*` variables, local/public cross-configuration, and unsupported Cloud, Redis, multi-instance, latency, or topology overrides.
- Keep the service explicitly one-process through `LocalPresence`, `LocalDriver`, local Room lookup, and local process selection. Do not add Redis, shared Presence/Driver, multi-process operation, provider settings, credentials, or public deployment.
- Replace legacy `/health` with fixed, non-sensitive, no-query `GET /livez` and `GET /readyz`; keep `/__healthcheck` unavailable. Readiness requires the ready phase plus a usable listener and local dependencies, and new matchmaking/upgrades fail closed while unready.
- Emit only bounded one-line JSON operational records with fixed build/lifecycle metadata. Discard framework-provided detail, aggregate six fixed security-rejection categories over a bounded window, and never log inputs, directions, Room/session identifiers, reconnect tokens, credentials, private queries, client text, personal data, analytics, or gameplay telemetry.
- Keep `.env*` ignored while committing only the reviewed non-secret `server/.env.example`; the service does not load that file automatically. Give listener startup one ten-second deadline. On configuration/import/create/listen/readiness failure, keep messages fixed; when an application exists, enter failed state, attempt graceful startup cleanup for at most one second, and directly close remaining local resources.
- Independently reviewed candidate `b7dade0500f2890d23e64839666f05078974794b` was squash-merged through pull request #61 as `4c4d82c5b177100bc40aaddc64d7e52734e5b5fb`; both share exact tree `6db593c04875fe8ab7465c5c3f7bd8ba68010679`. The candidate passes 126/126 root tests, 172/172 installed server tests, complete and production zero-advisory audits, all 64 frozen-file checksums, and whitespace. Required pull-request Baseline [run #161](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33033455124), merged-main Baseline [run #162](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33033595987), checksum-gated Pages [run #56](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33033595988), and cleanup [run #48](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33033596005) succeeded. Independent agent audits are evidence, not GitHub approvals.
- Direct post-merge HTTPS verification found the root document and all nine referenced same-origin scripts byte-identical to the reviewed merge, with `v2026.8.24` present and `/online-sdk.js` still a Pages 404. A pre-change connected-browser baseline rendered the offline menu and four-fighter Canvas coherently; a fresh post-merge browser connection was unavailable, so that earlier observation is not relabeled as exact post-merge browser evidence. GitHub reported only protected `main` and no open issue or pull request before evidence-closeout pull request #62 opened. There is no public Node deployment, hosted-network, load/soak, capacity, availability, or production-security claim.

The freeze-day registry check observed stable `@colyseus/schema` `5.0.22`, published on 2026-08-27 after B4A began. The exact `5.0.21` lock remains unchanged in this operations subpass, and the nonempty direct-outdated result is recorded rather than hidden.

#### Pass 12A4 — exact Schema 5.0.22 migration (complete)

- After the B4A evidence closeout merged and cleanup left only protected `main`, [pull request #63 — migrate Schema to 5.0.22](https://github.com/XenoVoyage/Stickman-Arena/pull/63) completed the separate bounded dependency subpass. Candidate `a8a6ece708ec47b2c3969599412475d322ec4e28` was squash-merged as `0b1dda568ae0f2f44eee1ffa2a4b0378ab86c108`; both share exact reviewed tree `c0841d32c6579900327b1d71ddf21e4b9bb60e10`. [Evidence-closeout pull request #64](https://github.com/XenoVoyage/Stickman-Arena/pull/64) records the repository facts without changing runtime behavior. The subpass exact-pins only `@colyseus/schema` `5.0.22` and the matching root dependency plus Schema package lock records; every other package entry remains byte-stable.
- Official npm metadata reports `5.0.22` as stable latest with the same signed 146-file layout as `5.0.21`. The one-commit package delta preserves byte-identical emitted CJS, ESM, browser/UMD, input, codegen, and other runtime JavaScript and changes only the version, TypeScript collection/codec inference sources/declarations, and source maps. Do not add TypeScript or infer project compatibility from the low-risk upstream delta.
- Clean installation resolves the direct pin, Core, and SDK to one deduplicated Schema `5.0.22`. The complete 126-test root and 172-test server suites pass, covering full-regulation replay/hash, served-browser-SDK and official SDK projections across rematch generations, Room lifecycle/reconnect/disposal, snapshots/events/acknowledgements, malformed-wire handling, resource bounds, readiness, and startup cleanup. Complete and production audits report zero vulnerabilities and direct outdated returns `{}`. Required pull-request Baseline [run #167](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33036827490), merged-main Baseline [run #168](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33036951092), checksum-gated Pages [run #58](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33036951128), and cleanup [run #50](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33036951071) succeeded on the exact reviewed tree. Independent reviews are evidence rather than GitHub approvals.
- Direct post-merge HTTPS verification found the root document and all nine same-origin scripts byte-identical to the reviewed merge, with `v2026.8.24` present and `/online-sdk.js` still a Pages 404. A fresh browser backend was unavailable, so this exact HTTP/source result is not relabeled as browser evidence. GitHub reported only protected `main` and no open issue or pull request before closeout #64 opened. SDK/UMD evidence is not real Canvas, hosted-network, load/soak, capacity, availability, production-security, or physical-device evidence.
- Keep gameplay, protocol `3`, simulation schema `6`, input contract `2`, client runtime, capacity, catalogs, service topology, diagnostic build ID, public version, hosting boundary, and every provider stop gate unchanged.

#### Pass 12B4B — graceful shutdown, recovery, and rollback (complete)

- [Pull request #65 — add graceful shutdown and recovery](https://github.com/XenoVoyage/Stickman-Arena/pull/65) squash-merged reviewed candidate `055e9fe3ec029ad5ee8f85544f198b027ec6942c` as `9e2d20013f06a2bcef713483cbddc88201d96605`; both share exact tree `94fc30540b454f6ee573d9422332f22f0efadd6a`. [Evidence-closeout pull request #66](https://github.com/XenoVoyage/Stickman-Arena/pull/66) records the merged facts without changing runtime behavior.
- Change only the diagnostic build identity to `pass12b4b-shutdown`; retain online protocol `3`, simulation schema `6`, input contract `2`, current gameplay/catalog/capacity, exact dependencies, public `v2026.8.24`, ordinary offline Pages/`file://`, and every hosting stop gate.
- Disable Colyseus process-signal ownership. Install persistent application-owned handlers whose first `SIGTERM` or `SIGINT` coalesces every later signal into one drain; route both `uncaughtException` through exclusive capture and `unhandledRejection` through a first-listener barrier into the same controller with one fixed redacted classification, before later framework reporters can inspect either value. The first event synchronously enters `draining`, makes readiness false, rejects new admission, and tracks already-accepted matchmaking until it quiesces.
- Lock and close every current Room with non-reconnectable close code `4001`, presenting only `SERVER RESTARTING — TRY AGAIN`, after synchronously clearing gameplay authority, timers, rematch votes, application seats, and framework initial/reconnect reservations. Give the complete drain one absolute 5,000-millisecond deadline. A clean drain closes transport, HTTP, Presence, and Driver resources, enters `stopped`, and exits `0`.
- On timeout or shutdown error, enter `failed`, exit `1`, and run a separately bounded 1,000-millisecond direct fallback that terminates WebSocket and tracked raw HTTP sockets before closing transport, HTTP, Presence, and Driver resources. Test shutdown before readiness, while waiting, during play, during reconnect, during results/rematch/restart, with no Rooms, under repeated signals, and through timeout/error fallback without relabeling local deterministic/subprocess evidence as public-service or load evidence.
- Restore no Room, code, reconnect token, or match state. Recovery starts a fresh exact process and requires successful `/livez` then `/readyz`. Rollback restores an exact previously reviewed client/server unit through the protected pull-request workflow; there is no hot rollback, history rewrite, cross-contract session migration, provider selection, or public deployment.
- The frozen candidate passes 126/126 root tests and 198/198 installed server tests locally, with zero complete/production advisories, empty direct outdated, 67/67 checksums, clean whitespace, and clean independent runtime/security, test, and documentation audits. Required pull-request Baseline [run #173](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33064782806), merged-main Baseline [run #174](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33064918249), checksum-gated Pages [run #60](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33064918062), and cleanup [run #52](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/33064918050) succeeded. GitHub reported only protected `main` and no open issue or pull request before closeout #66 opened; independent audits are not GitHub approvals.
- Connected cloud Chrome loaded the exact empty-query Pages route with unchanged `v2026.8.24`, nine same-origin scripts whose cache keys match reviewed source, no Colyseus global, no horizontal overflow, and no game-origin warning/error. Play started a coherent four-fighter Original Arena regulation at `03:00`. This is exact post-merge offline browser/visual evidence, not a performance-resource or packet ledger, real local two-tab Canvas, hosted Node service, public-network, load/soak, capacity, production-security, or physical-device evidence.

#### Pass 12A5 — exact Schema 5.0.23 migration (complete)

- After Repository Standard adoption issue #70 and production promotion pull request #73 closed, [issue #74](https://github.com/XenoVoyage/Stickman-Arena/issues/74) completed the separate bounded dependency subpass. Draft pull request #75 squash-merged the pin into `develop`; production promotion pull request #76 published the same tree on `main`. It exact-pins only `@colyseus/schema` `5.0.23` and the matching root dependency plus Schema package lock records; every other package entry remains byte-stable.
- Official npm metadata reports `5.0.23` as stable latest. The signed package adds Swift `schema-codegen` sources and changes only `build/codegen/cli.cjs` among emitted JavaScript; encoder/decoder CJS, ESM, browser/UMD, and input runtime JavaScript remain byte-identical to `5.0.22`. Do not add TypeScript or infer project compatibility from the upstream codegen delta.
- Clean installation must resolve the direct pin, Core, and SDK to one deduplicated Schema `5.0.23`. The complete root and installed server suites must pass, covering full-regulation replay/hash, served-browser-SDK and official SDK projections across rematch generations, Room lifecycle/reconnect/disposal, snapshots/events/acknowledgements, malformed-wire handling, resource bounds, readiness, and shutdown. Complete and production audits must report zero high-or-critical vulnerabilities, and direct outdated should return `{}` unless a newer official Schema appears after freeze.
- Keep gameplay, protocol `3`, simulation schema `6`, input contract `2`, client runtime, capacity, catalogs, service topology, diagnostic build ID, public version, hosting boundary, and every provider stop gate unchanged.
- Do not start Pass 12C1 lifecycle/resource tests, load/soak, proxy/TLS, provider artifacts, or public hosting in this subpass.

#### Pass 12C1 — deterministic lifecycle and resource regressions

- Add fast CI-suitable official-SDK and headless regressions for repeated Room creation/disposal, compact full-regulation finish plus rematch, abandoned Rooms, reconnect expiry races, malformed and oversized messages, rate limits and slow clients, shutdown, and handle/timer/queue/history cleanup.
- Keep each case deterministic and short: compact regulation uses one remaining tick rather than a second 10,800-step wall-clock loop; reconnect expiry uses a shortened test window; leftover process-handle totals from the test runner are not treated as application leaks.
- Prefer tests and owning documentation only. Do not change gameplay, protocol `3`, simulation schema `6`, input contract `2`, capacity, catalogs, Schema pin, diagnostic build, public version, or hosting unless a composed regression proves a leak that an existing owner must fix in this same issue.
- Do not start Pass 12C2 load/soak, adverse-network, cross-browser multi-client, proxy/TLS, provider artifacts, billing, Redis, secrets, or public hosting in this subpass.

#### Pass 12C2 — load, soak, network, browser, and deployment readiness

- Add separate short and operator-soak server profiles that label conditions and measure concurrent Rooms, CPU, memory after warm-up, event-loop delay, fixed-step catch-up, decoded snapshot/event bandwidth, active resources, shutdown, and recovery while exercising valid traffic, room floods, abuse, reconnect, rematch, backpressure, and graceful drain. Defensive runtime ceilings and one-machine samples are not production capacity claims.
- Add deterministic application-level latency, jitter, burst, reorder, loss, disconnect/reconnect, restart-isolation, and backpressure profiles with bounded queues/catch-up and stale-generation failure conditions. Keep synthetic, SDK, real-browser, packet, hosted-network, and physical evidence separate.
- Add the local two-client Canvas and cross-browser evidence checklist. Record Chromium, Firefox, Safari, responsive, adverse-network, console, and cleanup results only when run; physical MacBook/iPhone/iPad acceptance remains separately user-owned.
- Add a secret-free provider-neutral OCI build/start recipe and operations runbook covering exact environment validation, private plain-HTTP listener, external TLS/WebSocket proxy assumptions, probes, structured logs, signal drain, deployment identity, one-process capacity budgeting with headroom, stateless recovery, and protected rollback.
- Keep GitHub Pages as the static client and its Play action offline. The owner has selected Colyseus Cloud app `1868`, Frankfurt, and endpoint `https://de-fra-1131bd95.colyseus.cloud`; Pages Create/Join may use only that server after explicit intent.
- Configure Cloud Root Directory as `server`, use one PM2 fork with explicit LocalPresence/LocalDriver, and preserve local `?online=1`. Wright must set Cloud environment and trigger deployment after review. Do not commit `.colyseus-cloud.json`, tokens, or secrets, and do not add Redis or multiple processes.
- The production rollout hotfix may admit only provider PM2 slots `0`/`1` for transient old/new Unix-socket overlap while keeping one steady worker and process-local Rooms. Selected Cloud listen must bind `/run/colyseus/2567+NODE_APP_INSTANCE.sock` with the pinned tools/Core `listen(socketPath, 0)` contract rather than TCP `port`+`bindHost`. Cloud drain stops accepts and destroys only zero-byte pre-request sockets after admission quiescence; require Wright's successful public probes after redeploy before claiming health.

All Pass 12 subpasses keep the current two-human/two-bot Free-for-All on Original Arena. They do not add accounts, ranked play, progression, purchases, databases, social systems, Redis, multi-region operation, or autoscaling.

### Pass 13 — map selection and authored maps

Goal: add maps one at a time only after multiplayer is stable.

- Add a clear local map selector and a validated online room map option owned by room/host configuration. The authoritative server selects and freezes the map for the match.
- Keep the current arena permanently available.
- Add only one authored map per pass. The first new map must be meaningfully different and support both Free-for-All and the future Team Deathmatch rules.
- Each map defines deterministic platforms, hazards, pickups, spawns, bounds, and supported modes.
- Verify jump/drop reachability, spawn safety, pickup paths, bot navigation, camera stability, responsive rendering, replay behavior, and multiplayer synchronization.
- Do not add procedural generation or a generic map editor without separate approval.

### Pass 14 — Team Deathmatch

Goal: add one deterministic team mode after map selection is stable.

- Default to 2v2, complete three-minute regulation, highest combined team score at `0:00`, and a draw with immediate rematch when team scores tie.
- Keep friendly fire Off. Assign balanced teams deterministically and use team-safe respawns.
- Provide clear team HUD/visual identity. Keep individual statistics visible but never use them to decide the winner.
- Make bots teammate-aware while keeping all decisions in shared actor inputs. Add no target tracking or hidden auto-aim.
- The server owns team assignment, score, winner, disconnect handling, and rematch.
- Cover membership, friendly-fire rules, scoring, final-tick resolution, disconnects, bots, replay equality, and map compatibility deterministically.

### Pass 15 — additional modes

Goal: add and stabilize one fully specified mode at a time.

1. One-versus-one Duel.
2. A bounded Control/King-of-the-Hill prototype only after Duel is stable.
3. Any other mode only after its written rules and acceptance criteria are approved.

Every mode defines player limits, team structure, compatible maps, spawn rules, score/win/draw conditions, regulation timing, disconnect/rematch behavior, bot compatibility, HUD requirements, deterministic server authority, and regression coverage. Multiple modes do not authorize progression, ranked matchmaking, seasonal systems, or accounts.

### Pass 16 — weapon expansion

Goal: add weapons one at a time only after audio, networking, maps, and modes are stable.

- Add one weapon or category per bounded pass with a distinct command, tactical role, readable animation/effects, synthesized sound, damage/knockback identity, ammunition/reload rules, bot policy, and multiplayer replication coverage.
- Never add random or invisible attacks, passive pickup, general auto-targeting, equipment, inventory, rarity, loot, or upgrades without separate approval.
- Avoid full-health one-shot lethality unless separately approved and preserve the approximate 12–25-second evenly matched fight target.
- Audit each weapon at normal and quarter speed, both facings, every supported aim level, local play, bot play, and multiplayer.

## Final release closeout

After the implemented roadmap is stable, complete automated, checksum, replay, browser, responsive, animation, audio, server, latency, security, load, Pages, server-deployment, documentation, and branch-cleanup evidence. Record physical evidence separately, resolve remaining `AGENTS.md` adopting-status gaps where possible, consider required-check enforcement and a release tag, and leave protected `main` and `develop` with no open pull requests or temporary branches.

The detailed authoritative-server trust boundary, staged readiness gates, unresolved hosting choices, and official Colyseus sources remain in [`docs/MULTIPLAYER_ARCHITECTURE.md`](MULTIPLAYER_ARCHITECTURE.md). The roadmap order does not let an earlier pass smuggle in a later pass's dependencies or product scope.

## Scope discipline

Do not start a later pass before the current pass is merged, deployed, verified, and cleaned up. The one approved automatic-direction exception remains the Smart Action On, touch-only, neutral ranged Action snapshot; it must not expand into tracking, retargeting, target identity, or broader auto-targeting. Camera shake, passive auto-pickup, and unrequested accounts, progression, ranking, stores, equipment, telemetry, or monetization remain prohibited throughout the sequence. If a request crosses a pass boundary, split it and complete the active pass first.
