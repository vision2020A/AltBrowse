# Game design

## Player promise

Stickman Arena is a quick, readable 2D action game about movement, spacing, and weapon choice. Small athletic fighters should feel fast, skilled, and dangerous. Matches should be immediately understandable, active without being instantly lethal, and easy to replay.

Controls should make those decisions comfortable rather than mechanically difficult: each key or gesture has one understandable role, touch actions give readable feedback before commitment, pickup intent remains explicit, and a deliberate manual aim gesture always overrides convenience behavior.

## Core loop

1. Move through one platform arena.
2. Claim a useful weapon, ammunition, or the single health pickup.
3. Read opponents' spacing and committed attack recovery.
4. Deal damage, knock enemies away, and score defeats.
5. Respawn quickly and continue until the complete three-minute regulation reaches `0:00`.

Combat on the final fixed step resolves before the result. The unique highest score then wins; if the highest score is tied, the match is a draw. Offline play keeps its immediate rematch. In the local Pass 12B2 online slice, a finished generation freezes before a 30-second unanimous vote/withdrawal window; only the server can start a distinct-seed next generation after both connected players consent and pass a fresh ready barrier. Reaching five points, or any other score, never ends regulation early.

Each match begins with every fighter unarmed. Seeded assignment places distinct fighters across safe low, middle, and high platform starts, so weapon choice is earned through movement rather than granted as a loadout.

The lower center bridge contains the arena's one health pickup, replacing the former duplicate lower ammunition pickup. A damaged fighter must issue the ordinary discrete Pickup command to restore up to 30 health, capped at 100. Full-health fighters are ineligible, so they cannot waste or mask the item. Collection starts its exact 600-step respawn; while inactive, a faint medical cross and progress ring keep the spawn and return readable. Pickup and respawn use bounded green effects and local synthesized cues. There is no passive collection, random placement, second health type, or generic power-up system.

Raised platforms and the center bridge are one-way supports. Pressing S, or deliberately pulling the touch movement stick downward, drops through the current raised support. Solid arena floors never accept this command, and the command must return to neutral before another descent.

Desktop controls have two understandable presets. Hybrid uses A/D to move, W or Space to jump, S to drop, pointer direction to aim, left click or F to attack, right click or E to pick up, R to reload, and Q to select unarmed. Its direct firearm aim resolves to 3° elevations from -51° through +51° on the selected left/right facing. Keyboard Only uses the same A/D, W/Space, S, F, E, R, and Q actions, with the Up and Down arrows deliberately retaining simple high, level, and low aim. Pointer gameplay actions are ignored in Keyboard Only, and W is never both jump and aim.

## Combat language

- Unarmed is the always-available fallback.
- Sword attacks commit through one decisive high-to-low slash with anticipation, active contact, follow-through, and recovery.
- Pistol shots are accurate, deliberate, and meaningfully damaging, but their long cadence punishes a missed trigger.
- Shotgun damage is strongest nearby, falls with projectile travel, and is capped below a full-health defeat.
- Rifle fire deals little damage per bullet but sustains the fastest automatic cadence until its magazine or reload interrupts it.
- Grenades have a readable throw, two-second fuse, bounce, strong area knockback, and non-instant-lethal blast.

All timing values below are authoritative 60 Hz simulation steps. Damage and force are simulation units; firearm capacity is shown as magazine plus reserve.

| Weapon | Damage | Timing and supply | Force and range identity |
| --- | --- | --- | --- |
| Unarmed | 10 | 30-step cooldown and duration; active ages 7–10 | 245 knockback; 7-step hit stun |
| Sword | 24 | 44-step cooldown and duration; active ages 11–16 | 440 knockback; 12-step hit stun; 58-unit blade |
| Pistol | 18 | 44-step cooldown; 72-step reload; 8 + 32 rounds | 1,420 speed; 72-step life; 275 knockback; 7-step hit stun; zero spread |
| Shotgun | 8 pellets × 4, never more than 32 per trigger | 78-step cooldown; 90-step reload; 4 + 16 shells | 1,260 speed; 32-step life; 135 base knockback per pellet; 7-step hit stun; 0.19 spread; distance falloff |
| Rifle | 3 per bullet | 5-step automatic cooldown; 96-step reload; 36 + 108 rounds | 1,550 speed; 68-step life; 115 knockback; 4-step hit stun; 0.032 spread |
| Grenade | 48 at blast center | 60-step cooldown; 3 grenades; 120-step fuse; release age 16 in a 38-step throw | 190 radius; 760 throw speed; 680 knockback; 14-step hit stun |

Shotgun pellets keep full damage through 170 units of travel, then use deterministic linear falloff through 520 units toward a configured 0.35 pre-round scale. Per-pellet damage is rounded to an integer with a minimum of one, and accepted knockback follows the rounded damage ratio—the farthest one-damage pellet therefore uses 0.25 of base knockback. The serialized shot-group cap guards pellets accepted together on one fixed step; independently, exactly eight pellets at no more than four damage guarantee that a trigger cannot exceed 32 when contacts span different fixed steps. Pistol and rifle projectiles do not inherit this falloff. Grenade damage decreases through its 190-unit blast radius, while even a center hit remains below full health.

Visible weapon or projectile geometry is the damage truth. The sword keeps its existing 44-step action, active ages 11–16, and 58-unit authoritative blade while the reauthored pose sweeps that blade through an approximately 90-degree high-to-low arc. Its cosmetic trail contains at most four fading samples of the exact animation-owned blade segment; it never extends either endpoint or creates invisible damage. There is one slash command and no thrust, random variant, or hidden attack selection.

The first active melee step supplies one deterministic swing-geometry event, and an accepted contact supplies its exact point and blade tangent for presentation. Those event values align the effect and synthesized sound with simulation-approved contact; they never decide whether a hit occurred. Each approved weapon has an explicit local Web Audio identity—unarmed impact, sword swing/contact, pistol shot, shotgun blast, rifle cadence, and grenade throw/bounce/explosion—and its own bounded impact treatment. No recorded sound asset, gameplay randomness, camera shake, or presentation-owned damage is involved.

Settings expose a separate Sound On/Off choice and a bounded Master Volume from 0% through 100%. Sound Off is immediate and silent without discarding the selected volume; zero volume is also silent. The louder master path retains the established weapon recipes and uses peak protection only for coincident output. These preferences are local presentation state, never gameplay or replay state. There is no music; Music and Sound Effects become separate controls only if music is deliberately added later.

Once a melee attack commits, its facing remains fixed for that action. Once a grenade throw commits, its selected continuous aim and facing remain fixed through the authoritative release. Each firearm shot similarly commits one of 35 local 3° elevations plus its left/right facing through recoil; rifle may replace that commitment only when another legal shot actually fires. Those choices are ordinary serializable gameplay state rather than presentation state.

## Fighters and presentation

Fighters use matte-black bodies, thin colored outlines, large featureless round heads, short torsos, long rounded limbs, and no visible joint circles, hands, feet, faces, clothing, or armor. There is no visible neck stroke: the torso reaches slightly behind the lower edge of the head, and the head masks that join. Normal scale remains approximately 14–16% of gameplay height. Animation is authored rather than entirely solved by IK.

Locomotion feathers each planted support contact so starts, stops, low analog movement, and direction changes do not replace a leg in one frame. A fighter keeps the committed run support while coasting; when friction crosses into idle, that leg eases into the idle target over six fixed steps. Restarting in either direction enters through a bounded transition instead of reattaching support in one frame. The lower body follows travel direction while the upper body may face the player's aim, so crossing the pointer over a moving fighter does not mirror the legs. Jump launch leaves the current gait, fall begins at the authored jump apex, and walk-off, drop, landing-exit, support-release, or jump interruptions preserve the pose they visibly leave. Ordinary landings use the short settle pose without producing heavy-impact effects. Committed unarmed, sword, and grenade actions keep the live locomotion lower body, reach their exact authoritative contact sockets before activation, retain authored follow-through, and recover to the current ready pose. Firearm handling interpolates five authored anchors into the complete 35-step local elevation range while keeping recoil, grips, forearms, head clearance, visible barrel, and authoritative muzzle coherent.

The sword's single windup and the grenade windup route both the arm and held weapon outside the head before their unchanged contact/release windows. The final visible grenade-hand path, authoritative release socket, event origin, and projectile origin agree with the committed ballistic direction. Once the simulation marks a grenade released, presentation never draws a second held copy—even if hit or defeat presentation takes priority. Hit reactions traverse the same authored presentation across each weapon's actual hit-stun duration, while the current live arm rig, held weapon, or in-progress reload remains connected. A defeat starts at that exact visible source and blends into the authored downed motion without collapsing a limb. Respawn protection uses a readable fade over the live actionable pose; acting during that fade never substitutes a different muzzle or melee segment. The camera stays stable during impacts; force remains readable through body motion, weapon recoil, effects, sound, and knockback.

Shotgun and rifle pickups and held weapons now keep distinct silhouettes at gameplay scale: the shotgun has a broad grooved pump sleeve, while the rifle has a swept magazine. Both details are cosmetic and socket-derived. They do not move the authoritative muzzle, change projectile or collision geometry, or add gameplay state.

The HUD keeps the player's score, health, weapon, and ammunition at top left; regulation timer and pause at top center; and fighter scores at top right. Pickup and temporary state messages appear briefly at bottom center, including the health pickup's exact prospective recovery, leaving both gameplay corners unobstructed. The main menu shows the canonical public version as small subdued text beneath its actions; it is informational rather than interactive.

Landscape touch play uses two independent floating controls. The left stick retains analog horizontal movement. A deliberate upward pull crosses the Jump threshold once, and a deliberate downward pull crosses the Drop threshold once; the stick must return below the neutral reset threshold before another vertical command can fire.

The right Action control reflects the equipped weapon and the player's gesture:

- With Smart Action On, an eligible pickup has first priority at Action press. A non-drag tap then emits one Pickup command; crossing the aim threshold cancels that pickup candidate permanently for the gesture and aims manually instead.
- If no pickup is eligible and pistol, shotgun, rifle, or grenade is equipped, a neutral Action press snapshots one normalized direction toward the closest living opponent. Exact distance ties use stable fighter ID. Dead, defeated, non-living, zero-health, malformed-position, self, and zero-distance candidates are ignored; an immediately actionable fighter under respawn invulnerability remains a living candidate.
- The neutral snapshot is only a starting direction. It never tracks, retargets, predicts movement, checks line of sight, or chooses a claimed hit. Subthreshold jitter retains it, while the first deliberate drag permanently switches the gesture to the player's direct direction.
- Pistol and shotgun fire on normal release after aiming. Grenade commits its throw on normal release after aiming.
- Rifle preserves automatic fire: after a 10-fixed-step aim-and-hold delay, it may fire while held and stops on release.
- Sword and unarmed receive no aim assist and retain their existing behavior: they commit once on press in the fighter's current facing; if a pickup candidate was reserved, dragging through the aim threshold commits once in the selected direction.
- Cancellation, lost pointer capture, pause, dialog or result transitions, resize, rotation, navigation, and visibility loss discard pending actions. They never convert cancellation into an attack.

Reload and Unarmed remain dedicated buttons. With Smart Action Off, Pickup is an explicit button and every ranged direction remains manual. Pickup never happens passively. The bounded Smart Action snapshot emits only the same finite canonical aim vector and ordinary attack/pickup buttons as every other input path; it never adds a target identity or outcome claim.

## Bots

Bots fight every living opponent, seek useful weapons, ammunition, and the single health pickup, navigate the authored platform routes, avoid the central hazard, reload, and approach or retreat around the equipped weapon's useful distance. A critically damaged fighter may prioritize health during pressure; an ordinary optional detour is suppressed near an opponent and during the final 12 seconds of regulation. Bots can still recover while every opponent is respawning, and finished matches produce neutral input.

Weapon decisions preserve the current identities: pistols and shotguns use discrete presses, rifles hold intent so the simulation owns the exact five-step automatic cadence, grenades require a safe distance and use their ballistic path rather than firearm line of sight, and an already owned usable weapon can be reselected as spacing changes. Firearm shots use the same fine-aim cone as players. Pickup presses use the simulation's exact fighter reference point and remain discrete edges; top-platform objectives route through the authored side supports.

Every choice above is a deterministic, read-only derivation of serializable state. Bots may act only through the shared actor input and never write position, health, inventory, damage, score, target identity, or claimed outcomes.

## Scope guardrails

The default player experience remains one three-minute Free-for-All Deathmatch on the Original Arena for one human and one to three bots. The deployed architecture-only Pass 10 foundation gives those existing choices stable serializable IDs and explicit validated definitions, with no selector or second option and no gameplay change. The implemented and merged Pass 11 slice adds a separate local developer route with two humans and two server bots under the same rules/map; it does not change the default, add public hosting, or make GitHub Pages a multiplayer server. Pass 8 audio usability and Pass 9 repository-controlled compatibility work are implemented and deployed; physical MacBook/iPhone/iPad acceptance remains pending. Pass 12A through Pass 12B4B, including the separately bounded dependency maintenance and repository evidence closeouts through pull request #66, are complete without changing gameplay or publicly hosting the Node service. Pass 12B2 adds only server-owned online match generations, unanimous rematch consent, and bounded local lifecycle/reconnect cleanup; later completed subpasses add only the documented room UX, security, operations, dependency maintenance, and graceful-shutdown boundaries. Pass 12C is the next product pass and `docs/STATUS.md` owns its current activation gate. Authored maps, Team Deathmatch, later modes, and new weapons follow the remaining gates in [`docs/ROADMAP.md`](ROADMAP.md). None is permission to cross into a later pass. Progression, equipment systems, accounts, ranking, stores, telemetry, and monetization remain unapproved.

The owner-approved Colyseus Cloud deployment path changes hosting and menu availability only. GitHub Pages Play remains the same offline bot match; Create/Join selects the same two-human/two-bot Free-for-All and Original Arena through server authority. It adds no gameplay rule, mode, map, weapon, progression, account, ranking, store, telemetry, or monetization.
