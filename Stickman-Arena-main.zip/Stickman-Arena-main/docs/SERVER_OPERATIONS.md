# Server operations

This is the durable operations contract for the Stickman Arena Node service. Pass 12C1 retains the CI-fast lifecycle/resource baseline, and Pass 12C2 retains its measured readiness tools. The owner selected Colyseus Cloud application `stickman-arena` (`1868`), space `stickman-arena-ir7f26`, Frankfurt, at `https://de-fra-1131bd95.colyseus.cloud`. GitHub Pages remains the static client host; its Play action remains the offline bot match, while Create/Join may lazily load the SDK and connect to that exact Cloud endpoint after user intent. Local loopback engineering remains supported. Diagnostic build `pass12b4b-shutdown`, two human seats plus two server bots, Free-for-All, Original Arena, protocol `3`, simulation schema `6`, input contract `2`, and public `v2026.9.2` remain unchanged.

## Runtime and installation

Use Node.js 24.20.0 LTS from `.nvmrc` for development, primary CI, and the eventual production artifact. Node.js 22 remains the tested minimum support floor. Install only the exact nested server lock:

```sh
npm ci --prefix server --ignore-scripts
npm --prefix server test
```

The root offline client remains install-free and has no runtime package dependency.

## Configuration contract

Local startup validates `process.env` before importing Colyseus Core/application code and loads no `.env` file. When Cloud has already injected `COLYSEUS_CLOUD`, the entrypoint first imports only pinned `@colyseus/tools/loadenv` with console output suppressed, then validates the provider UI environment before Core/application bootstrap. `server/.env.example` is a non-secret schema; every real `.env*` file remains ignored by Git.

| Variable | Local mode | Public mode |
| --- | --- | --- |
| `STICKMAN_SERVER_MODE` | Optional; defaults to exact `local` | Required as exact `public` |
| `PORT` | Optional; defaults to `2567` | Optional; defaults to `2567` |
| `NODE_ENV` | Not used to widen local behavior | Must be exact `production` |
| `STICKMAN_BIND_HOST` | Rejected if present; bind is fixed to `127.0.0.1` | Must be exact `0.0.0.0` or `::` |
| `STICKMAN_PUBLIC_ORIGIN` | Rejected if present | Required canonical HTTPS origin with no path, query, fragment, credentials, or noncanonical default port |
| `STICKMAN_ALLOWED_ORIGINS` | Rejected if present | Required comma-separated canonical HTTPS origins; 1–16 unique entries and must include the public origin |

`PORT` must be its canonical decimal spelling from `1` through `65535`; signs, whitespace, leading zeroes, fractions, exponents, empty values, and out-of-range values fail closed. Unknown `STICKMAN_*` variables also fail closed. Public Cloud mode alone accepts provider-injected `COLYSEUS_CLOUD` paired with canonical `NODE_APP_INSTANCE=0` or `1`; local mode and ordinary public mode reject them. `REDIS_URI`, slot `2+`, `COLYSEUS_LATENCY`, `COLYSEUS_PRESENCE_SHORT_TIMEOUT`, and `COLYSEUS_MAX_CONCURRENT_CREATE_ROOM_WAIT_TIME` remain rejected. Configuration errors emit one fixed record without the variable name or value and exit nonzero before framework bootstrap.

Public mode remains explicit configuration rather than permission for this agent to deploy. Wright owns Cloud environment entry and deployment after this pull request passes.

## Selected Colyseus Cloud application

In Colyseus Cloud Build settings set **Root Directory** to `server`, not `/`. The server package owns both `package.json` and `ecosystem.config.cjs`; the `.cjs` extension is the official supported alternative required because this package declares ESM. The ecosystem file starts existing `src/index.mjs` as exactly one PM2 fork, waits for the Cloud socket listener, and allows seven seconds for the bounded five-second drain plus one-second fallback. The package `build` command performs a syntax check and creates no second application or generated runtime.

Set these non-secret values in the Cloud environment UI:

```text
NODE_ENV=production
STICKMAN_SERVER_MODE=public
STICKMAN_BIND_HOST=0.0.0.0
STICKMAN_PUBLIC_ORIGIN=https://de-fra-1131bd95.colyseus.cloud
STICKMAN_ALLOWED_ORIGINS=https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io
```

Colyseus Cloud injects `COLYSEUS_CLOUD` and PM2 injects `NODE_APP_INSTANCE`; do not configure either manually. With ecosystem `instances: 1`, steady state has one worker. The pinned rolling deploy temporarily overlaps slots `0` and `1`, exposes only the ready generation through nginx, then drains the old slot. Each worker still passes explicit `LocalPresence` and `LocalDriver`, so Cloud's optional Redis defaults are not selected and Rooms never migrate between generations. `REDIS_URI`, configured multiple instances, slot `2+`, Redis packages, a database, and cross-process Room lookup remain unsupported.

Selected Cloud listen uses the pinned `@colyseus/tools` / Core contract: bind `/run/colyseus/2567+NODE_APP_INSTANCE.sock` with `server.listen(socketPath, 0)`, then `process.send("ready")`. Passing TCP `port`+`bindHost` marks the process ready while nginx still has no upstream socket. Provider proxy metadata is discarded before the strict edge; its values are never trusted or logged. The original Host must remain `de-fra-1131bd95.colyseus.cloud`, and the browser Origin must be exact `https://xenovoyage.github.io`. The Pages repository path is not part of an Origin.

Wright deployed production `7699ec2`; process logs reached ready, but nginx still returned `502` for root and both probes at 17:38 UTC. After hotfix `080f114` / `main` `d1e36f26`, those `502` responses were gone and the application returned HTTP `400` `{"error":"bad request"}` for the same probes because Cloud nginx forwarding headers hit the raw edge. Issue #86 admits those headers in public/Cloud mode without trusting them. After that landing, live probes on 2026-09-02 again returned nginx `502` because listen stayed on TCP; issue #89 binds the official Unix socket. This session does not run `npx @colyseus/cloud deploy`, create `.colyseus-cloud.json`, handle a token, or modify Cloud settings. The origin remains unhealthy until Wright promotes this candidate and receives successful public probes.

### Rolling socket and drain contract

Selected Cloud stores `listenPath` `/run/colyseus/2567+NODE_APP_INSTANCE.sock` for slots `0` and `1`. The application binds that path with the official Core workaround `listen(socketPath, 0)` from pinned `@colyseus/tools`, clears an inactive leftover socket, and sends `process.send("ready")`. Keep `wait_ready: true`. Cloud's one-instance rollout deliberately peaks at two PM2 workers. It starts the replacement in the alternate canonical slot, publishes that socket to nginx only after readiness, then sends `SIGINT` to the outgoing slot. Rejecting slot `1` prevents `2568.sock` from existing and can leave nginx with no reachable upstream. Local and ordinary public listen remain TCP.

Accept only slots `0` and `1`; this is rolling overlap, not configured two-process matchmaking. Every worker remains process-local, and the old generation's Rooms are destroyed during drain. After admission quiesces, Cloud shutdown stops HTTP accepts, closes idle connections, and destroys tracked sockets that have emitted neither request nor upgrade. In-flight HTTP and upgraded Room sockets retain their existing bounded owners. Local and ordinary public operation do not use this Cloud-only prefix.

## Provider-neutral OCI artifact

`server/Containerfile` is a secret-free OCI recipe rooted at the repository top level. It pins the official Node.js `24.20.0-bookworm-slim` multi-platform manifest by digest, installs only the exact production lock with scripts disabled, copies the eleven offline runtime files plus `server/src`, and runs as the image's unprivileged `node` user. `.dockerignore` fails closed from `*` and allowlists only that build input. No `.git`, `.env`, test, documentation, credential, or provider file enters the context.

Build from the repository root with an OCI-compatible builder:

```sh
REVISION="$(git rev-parse --short=12 HEAD)"
docker build --file server/Containerfile \
  --tag "stickman-arena-server:${REVISION}" .
docker image inspect "stickman-arena-server:${REVISION}" \
  --format '{{.Id}}'
```

Record the full commit and tree, local image ID, builder/version/platform, Node base manifest digest, `sha256sum server/package-lock.json`, and build output. A local build normally has no repository manifest digest. After an owner-approved registry push, resolve and record that registry manifest digest before deployment. The pinned base and lock make inputs reviewable; builders can still produce different metadata or platform manifests, so compare resulting image IDs and registry digests instead of claiming reproducibility without those comparisons.

The secure source default still binds loopback. A local image smoke therefore needs no public configuration or host port:

```sh
docker run --detach --name stickman-arena-smoke --rm --init --read-only --tmpfs /tmp \
  "stickman-arena-server:${REVISION}"
docker exec stickman-arena-smoke node --input-type=module -e \
  "const end=Date.now()+10000; for (const path of ['/livez','/readyz']) { for (;;) { try { const response=await fetch('http://127.0.0.1:2567'+path); if (response.ok) break; } catch {} if (Date.now()>=end) process.exit(1); await new Promise(resolve=>setTimeout(resolve,100)); } }"
docker stop --time 6 stickman-arena-smoke
```

`--read-only` and a temporary `/tmp` prove that the application needs no writable persistent volume. The init forwards termination; the application still owns its bounded drain. Do not bake public values or secrets into an image.

## TLS and reverse-proxy contract

The Node listener is plain HTTP/WebSocket inside one private network boundary. A reviewed external proxy terminates TLS and is the only public ingress. It must:

- accept HTTPS/WSS only and redirect or reject public plaintext before it reaches Node;
- preserve an exact `Host` equal to `STICKMAN_PUBLIC_ORIGIN`'s authority, preserve the browser `Origin`, and support WebSocket Upgrade without rewriting the path or query;
- keep proxy metadata non-authoritative. Public and selected Cloud modes strip `Forwarded`, every `X-Forwarded-*`, `X-Real-IP`, `X-Client-IP`, `X-Original-Host`, `X-Original-URL`, and `X-Rewrite-URL` before framework routing and ignore those names if the parsed IncomingMessage copy still carries them; they are never used for Host or Origin identity. Local loopback still rejects them;
- retain the application's 8 KiB header, 1 KiB matchmaking body, 4 KiB WebSocket payload, and bounded URL limits or apply stricter limits, never larger implied guarantees;
- send liveness/readiness requests with the canonical public `Host`; `/readyz` gates admission, while `/livez` only proves the process has not reached a terminal phase;
- stop new traffic before or with `SIGTERM`, allow at least the application's absolute five-second drain plus one-second fallback, and never route to a replacement until its `/livez` and then `/readyz` succeed.

Proxy metadata never enters application logs. Origin enforcement is defense in depth, not authentication. Colyseus Cloud owns TLS termination and certificate renewal for the selected endpoint; DDoS controls, public-network quality, and regional behavior still require hosted evidence after deployment.

## Local start and probes

Start the default loopback service:

```sh
npm --prefix server start
```

Open `http://127.0.0.1:2567/?online=1`. The service exposes two fixed operational probes:

```sh
curl --fail http://127.0.0.1:2567/livez
curl --fail http://127.0.0.1:2567/readyz
```

`GET /livez` returns `200 {"status":"live"}` while the process is starting, ready, or draining. `GET /readyz` returns `200 {"status":"ready"}` only after the listener and explicit local Presence/Driver are usable and the service phase is ready. Otherwise it returns `503 {"status":"unavailable"}`. Both responses are JSON, `no-store`, and `nosniff`. Queries and non-GET methods fail with fixed errors. The obsolete `/health` route and the framework `/__healthcheck` route both return fixed `404` responses.

Matchmaking and WebSocket admission return fixed `503` responses until readiness is true and throughout draining. Only exact Quick/Create/Join/Reconnect matchmaking targets may reach Colyseus's `OPTIONS` shortcut; probe `OPTIONS` requests retain fixed `405` responses, while legacy health and non-allowlisted targets retain fixed `404` responses. The configured origin/authority policy is exact. Local native SDK requests may omit `Origin`; a supplied local browser origin must match the configured loopback authority. Public mode requires one allowlisted origin and the configured public authority. Origin checks are defense in depth, not identity or proof against cheating.

## Topology and logs

The service constructs `LocalPresence` and `LocalDriver` explicitly, selects only its own Colyseus process for room creation, and refuses stale Join Code or reconnect lookups before the framework can attempt remote IPC. There is no Redis, database, shared Presence/Driver, multi-process, autoscaling, multi-region, account, or persistent identity system.

Each application log is one JSON object and one line. The fixed fields are timestamp, level, event, and diagnostic build ID; only allowlisted service phase, Room phase, reason, security category, and bounded count fields may be added. Lifecycle records contain no Room ID, session ID, actor ID, room code, reconnect token, gameplay input, target direction, private query, header value, credential, stack, or free-form error text. Security rejections aggregate into fixed categories in bounded ten-second windows. Framework warnings and errors emit at most one fixed redacted diagnostic per kind per ten-second window while every attempt also increments the bounded protocol-rejection counter. No analytics or gameplay telemetry is collected.

## Load, soak, and one-process budget

Install the exact complete lock before using the measurement tools. The short profile is a CI-safe local sample; the soak profile is operator-run and intentionally absent from the required unit-test command:

```sh
npm ci --prefix server --ignore-scripts
npm --prefix server run load:short
npm --prefix server run network:profiles
npm --prefix server run load:soak
```

`load:short` uses two concurrent Rooms, one second of warm-up, two steady measured seconds, and measured scenario phases. `load:soak` uses eight concurrent Rooms, a 60-second warm-up, a 30-minute steady interval with natural repeated generations, and the same measured scenario phases. Both run valid 20 Hz inputs, compact rematches, simultaneous disconnect/reconnect waves, concurrent Create/Join operations, terminal control abuse, injected output backpressure, and graceful shutdown while traffic continues. Use `LOAD_PORT=<canonical-port>` only to avoid a local collision. Real retry storms under a controlled outage remain an operator adverse-network profile; an immediately successful local reconnect wave is not relabeled as failed-retry evidence.

The JSON report labels the host OS, Node runtime, CPU model/count, host memory, exact profile, Room/client/bot count, and timings. It reports one-core CPU percentage, RSS/heap/external/array-buffer memory after warm-up and at peak across steady plus scenario work, event-loop delay, fixed-step gaps and catch-up bursts, decoded snapshot/event application bytes, active resource types, peak Rooms, shutdown duration/codes, Room-owned cleanup, and post-shutdown registry/resource recovery. It then starts a fresh process on the same port, requires `/livez` followed by `/readyz`, and drains it cleanly. Application bytes are JSON-size estimates after SDK decoding, not Ethernet, TLS, WebSocket, compression, or provider billing bytes. Active-resource totals include the harness and runtime; compare named before/warm/after snapshots rather than treating a Node test-runner total as an application leak.

The short and soak profiles fail on a stale-generation effect, more than 12 same-Room fixed steps without a one-millisecond yield, a snapshot tick jump above 30, event-loop delay above 250 ms, a failed drain, a nonempty post-drain Room registry, or a shutdown close other than `4001`. Those are harness safety thresholds, not latency SLOs or promises that a public service can safely run at the observed count. The deterministic network command separately bounds queued inputs/snapshots and catch-up delivery while exercising latency, jitter, burst, reorder, loss, disconnect/reconnect, generation and process-restart isolation, and backpressure. It is application-level simulation, not packet capture or a real browser/network.

For every candidate host class, record the exact commit/tree and image digest, machine/container CPU and memory limits, runtime, region, profile, start/end time, concurrent Rooms/clients, all report fields, proxy/TLS settings, and repetitions. Run at least three steady samples plus the long soak after other tenants and debug tooling are removed. Increase Rooms only between bounded runs and stop at the first CPU, memory, event-loop, catch-up, bandwidth, error, drain, or recovery knee.

The measured one-process ceiling is the highest repeatedly tested Room count that retains explicit headroom across every measured resource. Keep at least 50% CPU and memory-allocation headroom from the worst accepted repeated sample, require zero stale-generation/catch-up/recovery failures, and include proxy and operating-system overhead. Select and record an operational budget at or below that measured ceiling. The existing 64-live-Room, 16-code-Room, 256-socket, and per-client limits are defensive ceilings, not a capacity budget. Do not raise or reinterpret those runtime ceilings in this issue. One process, LocalPresence, and LocalDriver remain mandatory. Multi-process, Redis, autoscaling, regions, and failover require separate evidence and approval.

## Colyseus Cloud deployment checklist

The provider, Frankfurt region, Cloud endpoint, and Pages client origin are owner-approved. Wright still owns the Cloud settings and deployment trigger. Keep provider credentials outside Stickman Arena's environment schema, source, logs, and image.

1. Freeze one reviewed source commit/tree, lock hash, protocol/schema/input/client/build identities, and eleven-file Pages payload. Keep OCI image identities in the provider-neutral section; Colyseus Cloud uses the selected source Root Directory.
2. Merge the issue PR to protected `develop` only after its Audit and owner review. Perform Alpha validation, then use a separate protected `develop` → `main` promotion; this implementation agent does not open or merge that release.
3. Set Cloud Root Directory to `server`; verify the checked-in one-process ecosystem file and exact public environment values above. Add no unsupported `STICKMAN_*`, Redis, latency, or topology variables.
4. Deploy the exact reviewed production `main` revision through Wright's Cloud UI. Require canonical-host `GET /livez`, then `GET /readyz` before treating Create/Join as available. Verify fixed JSON/no-store responses, expected build ID in structured logs, and no private values in logs.
5. Keep GitHub Pages as the static client and Colyseus Cloud as the server. Confirm the provider exposes only HTTPS/WSS and preserves the exact public Host and Pages Origin while application code discards proxy metadata.
6. Apply a platform memory/CPU allocation and Room admission budget supported by repeated load/soak evidence with headroom. Record conditions and results without turning one machine's sample into a general capacity claim.
7. From the promoted Pages route, confirm Play starts bots without a Cloud request, then exercise Create/Join with two real browsers through HTTPS/WSS. Verify fixed configuration, play, reconnect, rematch, leave, invalid/full/expired code handling, responsive Canvas, and the browser evidence matrix in `tests/README.md`.
8. Send the provider's graceful termination under active load. Require readiness to fail before new admission, client close `4001`, terminal stopped/exit `0`, an empty registry, and replacement readiness. A timeout/error must remain failed/nonzero.
9. Prove a fresh process restores no Room, code, seat, token, vote, result, or generation. Cloud rollback redeploys the prior exact reviewed source revision; if compatibility changed, roll Pages back to its matching reviewed client through the protected workflow. Do not hot-swap or migrate sessions.
10. Retain source/deployment identities, configuration names but not secret values, probe evidence, bounded structured logs, load/network/browser evidence, rollback result, and operator sign-off. Do not claim availability, production security, public-network quality, or physical-device acceptance without that distinct evidence.

## Startup failure

Listener establishment has a ten-second ceiling and observes raw HTTP errors before the pinned framework's listen promise. Failed startup marks readiness false, invokes supported Colyseus cleanup with a one-second ceiling, clears framework stats persistence, closes HTTP/WebSocket resources, shuts down local Presence/Driver, writes a fixed failure record, and exits nonzero. Real subprocess regressions cover invalid configuration, an occupied port, a failure after the socket binds, and starting/ready/draining probe behavior.

Startup failure remains separate from the merged B4B normal-drain contract below. Invalid configuration still fails before framework import, and an import/create/listen/readiness failure never becomes a clean signal exit.

## Graceful shutdown and recovery

The application disables Colyseus's built-in process-signal ownership and installs persistent application-owned handlers for `SIGTERM` and `SIGINT`. The first signal starts one shutdown promise; later `SIGTERM` or `SIGINT` events coalesce into that same work and never extend its deadline. Application-owned exclusive `uncaughtException` capture and a first-listener `unhandledRejection` barrier emit only one fixed redacted classification and invoke the same failed drain; later framework/PM2 reporters never receive the private thrown or rejected value. If the process already has an exception-capture callback, startup emits one fixed `service.failure` record, exits `1`, and stops before configuration or framework bootstrap because Node cannot safely share that hook. No signal name, exception or rejection detail, stack, Room/session/code/token, request value, or client text is added to the operations log schema.

The first event synchronously transitions the service to `draining`, which makes `/readyz` unavailable and makes new matchmaking HTTP requests and WebSocket upgrades return the existing fixed `503`. `/livez` remains live only while the controlled drain still owns an open listener. Matchmaking work accepted before the transition is tracked and allowed to quiesce within the same absolute deadline; any Room it creates is included in shutdown.

Every current Room is locked and removed from new matching. Before transport close, Room shutdown synchronously clears gameplay actor authority and held input, every Room timer, readiness and negotiation state, rematch votes, application reservations, and framework initial-seat/reconnect reservations. Shutdown sends no generic `closing` lifecycle frame and closes the Room with non-reconnectable code `4001`; the browser maps only that code to fixed local copy `SERVER RESTARTING — TRY AGAIN`. The direct-timeout fallback does not claim close-code delivery over a failed connection.

The complete normal drain has one absolute 5,000-millisecond deadline. It quiesces pre-drain matchmaking, closes every Room, and closes transport, HTTP, LocalPresence, and LocalDriver resources. A clean result transitions the service to terminal `stopped` and exits `0`. Timeout or any shutdown error transitions it to terminal `failed`, exits `1`, and invokes a separately bounded 1,000-millisecond direct fallback that terminates remaining WebSocket connections and tracked raw HTTP sockets before closing transport, HTTP, Presence, and Driver resources. Repeated signals do not start a second fallback or change the selected clean/error outcome.

| Trigger/result | Terminal phase | Exit code |
| --- | --- | --- |
| `SIGTERM` or `SIGINT`, complete clean drain | `stopped` | `0` |
| Fixed fatal accepted before drain completion | `failed` | `1` |
| Fixed fatal after terminal clean drain, before process exit | preserves `stopped` | `1` |
| Drain timeout or shutdown/cleanup error | `failed` | `1` |

## Recovery and rollback

Rooms, seven-character codes, reconnect tokens, actor seats, match generations, canonical state, results, and rematch votes are process-local and are not restored. Recovery is a fresh start of the same exact reviewed unit and reviewed environment. Start it with `npm --prefix server start`, require `GET /livez` to succeed, then require `GET /readyz` to succeed before opening matchmaking. A browser must start a new match; reconnecting to a pre-restart Room is not recovery.

Rollback restores one exact previously reviewed client/server unit through a normal protected pull request. Drain the current process, start that prior unit with its matching compatibility dimensions, then repeat the liveness, readiness, and fresh-match checks. Do not force-push or rewrite published history. There is no hot rollback, Room/state transfer, cross-contract session migration, automatic provider restart, or public deployment mechanism.

Reviewed candidate `055e9fe3ec029ad5ee8f85544f198b027ec6942c` was squash-merged through pull request #65 as `9e2d20013f06a2bcef713483cbddc88201d96605`; both share exact tree `94fc30540b454f6ee573d9422332f22f0efadd6a`. Pull-request Baseline #173, merged-main Baseline #174, checksum-gated Pages #60, and cleanup #52 succeeded. Evidence-closeout pull request #66 records those facts without changing this operational contract.

The owner selected the Cloud application and endpoint recorded above, but no deployment from this candidate has occurred. Selection and repository support do not establish public-service availability, capacity, production security, regional latency, or recovery-time guarantees.

## Verification

Before accepting a candidate, run:

```sh
npm test
npm ci --prefix server --ignore-scripts
npm --prefix server test
npm --prefix server run load:short
npm --prefix server run network:profiles
npm audit --prefix server --audit-level=high
npm audit --prefix server --omit=dev --audit-level=high
npm outdated --prefix server --json
sha256sum --check SHA256SUMS
git diff --check
```

Keep deterministic, official-SDK, fake-browser, raw TCP, synthetic-network, real Canvas, load/soak, hosted-network, responsive, and physical-device evidence labeled separately. Local probes and tests are not public-service availability, production security, capacity, DDoS resistance, regional latency, or physical-device evidence.

For B4B specifically, cover shutdown before readiness, while waiting, during play, during reconnect, during results/rematch/restart, with no Rooms, under repeated mixed signals, and through the forced timeout/error fallback. Verify readiness/admission ordering, fixed client copy and close code, synchronous authority/reservation cleanup, terminal phase and exit code, and absence of lingering sockets, listeners, timers, Presence, or Driver resources. These remain local deterministic, official-SDK, raw-socket, and subprocess results; they are not Pass 12C load, soak, hosted-network, availability, or browser evidence.
