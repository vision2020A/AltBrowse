# Asset provenance

Stickman Arena has no third-party runtime assets, fonts, music, sound files, CDN resources, or downloaded libraries.

| Asset | Origin and use | License / boundary |
| --- | --- | --- |
| `docs/assets/stickman-arena-gameplay.webp` | Historical pre-touch gameplay screenshot captured from the approved baseline and supplied by XenoVoyage on 2026-08-24; retained as review evidence but no longer presented as the current README preview | Project-owned documentation evidence; replace only with an exact audited-build capture |
| Canvas fighters, arena, pickups, particles, and HUD | Drawn by project-owned JavaScript and CSS at runtime | Covered by the repository MIT license |
| Sound effects | Six explicit weapon identities and supporting action cues synthesized locally from short oscillator envelopes and a cached deterministic noise buffer with Web Audio at runtime | No recorded or third-party audio assets; no audio download, runtime dependency, or gameplay-randomness input |

Do not add an asset without recording its origin, author, license, permitted use, transformation, runtime reference, and optimization decision here.
