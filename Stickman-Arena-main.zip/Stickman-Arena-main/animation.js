(function (global) {
  "use strict";

  // Authored at 60 Hz. Coordinates are local Canvas coordinates (positive Y is down)
  // with the hip at the origin. Poses are authored facing right and mirrored only
  // after sampling, so renderers never have to guess which hand owns a weapon.
  var TICK_RATE = 60;
  var RUN_CONTACT_TRAVEL = 5;
  var RUN_BLEND_SPEED = 300;
  var DEFEAT_ENTRY_BLEND = 12;
  var RELOAD_DURATIONS = Object.freeze({ pistol: 72, shotgun: 90, rifle: 96 });
  var POINTS = [
    "head", "neck", "shoulder", "spine", "hip",
    "elbowL", "elbowR", "wristL", "wristR",
    "kneeL", "kneeR", "ankleL", "ankleR"
  ];

  var CLIPS = Object.freeze({
    idle: { duration: 48, loop: true },
    run: { duration: 32, loop: true },
    jump: { duration: 15, loop: false },
    fall: { duration: 24, loop: true },
    land: { duration: 7, loop: false },
    unarmed: { duration: 30, loop: false, entryBlendEnd: 7, activeStart: 7, activeEnd: 10, recoveryStart: 16 },
    swordReady: { duration: 36, loop: true },
    swordAttack: { duration: 44, loop: false, entryBlendEnd: 3, activeStart: 11, activeEnd: 16, recoveryStart: 23 },
    gunFire: { duration: 12, loop: false, activeStart: 0, activeEnd: 1 },
    reload: { duration: 96, loop: false },
    grenadeThrow: { duration: 38, loop: false, entryBlendEnd: 0, activeStart: 16, activeEnd: 17, recoveryStart: 27 },
    hit: { duration: 13, loop: false },
    defeat: { duration: 40, loop: false },
    respawn: { duration: 24, loop: false }
  });

  var BASE = Object.freeze({
    head: [0, -68],
    neck: [0, -50],
    shoulder: [1, -42],
    spine: [0, -22],
    hip: [0, 0],
    elbowL: [-14, -20],
    wristL: [-7, 7],
    elbowR: [15, -19],
    wristR: [9, 8],
    kneeL: [-13, 30],
    ankleL: [-17, 61],
    kneeR: [13, 30],
    ankleR: [18, 61]
  });

  function point(value) {
    return { x: value[0], y: value[1] };
  }

  function clamp(value, low, high) {
    return Math.max(low, Math.min(high, value));
  }

  function mix(a, b, t) {
    return a + (b - a) * t;
  }

  function smooth(t) {
    t = clamp(t, 0, 1);
    return t * t * (3 - 2 * t);
  }

  function copyPoint(p) {
    return { x: p.x, y: p.y };
  }

  function makePose(changes) {
    changes = changes || {};
    var pose = {
      headRadius: changes.headRadius == null ? 16 : changes.headRadius,
      alpha: changes.alpha == null ? 1 : changes.alpha,
      scaleX: changes.scaleX == null ? 1 : changes.scaleX,
      scaleY: changes.scaleY == null ? 1 : changes.scaleY,
      rootX: changes.rootX || 0,
      rootY: changes.rootY || 0,
      weaponDir: changes.weaponDir ? point(changes.weaponDir) : { x: 1, y: 0 },
      weaponLift: changes.weaponLift || 0,
      grenadeVisible: changes.grenadeVisible !== false,
      planted: changes.planted || null,
      phase: changes.phase || ""
    };
    for (var i = 0; i < POINTS.length; i += 1) {
      var key = POINTS[i];
      pose[key] = point(changes[key] || BASE[key]);
    }
    return pose;
  }

  function clonePose(source) {
    var pose = {};
    for (var key in source) {
      if (!Object.prototype.hasOwnProperty.call(source, key)) continue;
      var value = source[key];
      pose[key] = value && typeof value.x === "number" && typeof value.y === "number"
        ? copyPoint(value)
        : value;
    }
    return pose;
  }

  function lerpPose(a, b, t) {
    if (t <= 0) return clonePose(a);
    if (t >= 1) return clonePose(b);
    var pose = clonePose(a);
    for (var i = 0; i < POINTS.length; i += 1) {
      var key = POINTS[i];
      pose[key].x = mix(a[key].x, b[key].x, t);
      pose[key].y = mix(a[key].y, b[key].y, t);
    }
    pose.headRadius = mix(a.headRadius, b.headRadius, t);
    pose.alpha = mix(a.alpha, b.alpha, t);
    pose.scaleX = mix(a.scaleX, b.scaleX, t);
    pose.scaleY = mix(a.scaleY, b.scaleY, t);
    pose.rootX = mix(a.rootX, b.rootX, t);
    pose.rootY = mix(a.rootY, b.rootY, t);
    pose.weaponDir = {
      x: mix(a.weaponDir.x, b.weaponDir.x, t),
      y: mix(a.weaponDir.y, b.weaponDir.y, t)
    };
    pose.weaponLift = mix(a.weaponLift, b.weaponLift, t);
    pose.grenadeVisible = t < 0.5 ? a.grenadeVisible : b.grenadeVisible;
    pose.planted = t < 0.5 ? a.planted : b.planted;
    pose.phase = t < 0.5 ? a.phase : b.phase;
    return pose;
  }

  function mixAngle(a, b, t) {
    var delta = ((b - a + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
    return a + delta * t;
  }

  function interpolateChain(pose, a, b, root, joint, end, t) {
    var aUpperX = a[joint].x - a[root].x;
    var aUpperY = a[joint].y - a[root].y;
    var bUpperX = b[joint].x - b[root].x;
    var bUpperY = b[joint].y - b[root].y;
    var upperLength = mix(Math.hypot(aUpperX, aUpperY), Math.hypot(bUpperX, bUpperY), t);
    var upperAngle = mixAngle(Math.atan2(aUpperY, aUpperX), Math.atan2(bUpperY, bUpperX), t);
    pose[joint].x = pose[root].x + Math.cos(upperAngle) * upperLength;
    pose[joint].y = pose[root].y + Math.sin(upperAngle) * upperLength;

    var aLowerX = a[end].x - a[joint].x;
    var aLowerY = a[end].y - a[joint].y;
    var bLowerX = b[end].x - b[joint].x;
    var bLowerY = b[end].y - b[joint].y;
    var lowerLength = mix(Math.hypot(aLowerX, aLowerY), Math.hypot(bLowerX, bLowerY), t);
    var lowerAngle = mixAngle(Math.atan2(aLowerY, aLowerX), Math.atan2(bLowerY, bLowerX), t);
    pose[end].x = pose[joint].x + Math.cos(lowerAngle) * lowerLength;
    pose[end].y = pose[joint].y + Math.sin(lowerAngle) * lowerLength;
  }

  function lerpRiggedPose(a, b, t) {
    if (t <= 0 || t >= 1) return lerpPose(a, b, t);
    var pose = lerpPose(a, b, t);
    interpolateChain(pose, a, b, "shoulder", "elbowL", "wristL", t);
    interpolateChain(pose, a, b, "shoulder", "elbowR", "wristR", t);
    interpolateChain(pose, a, b, "hip", "kneeL", "ankleL", t);
    interpolateChain(pose, a, b, "hip", "kneeR", "ankleR", t);
    return pose;
  }

  function frame(t, changes) {
    return { t: t, pose: makePose(changes) };
  }

  function sampleFrames(frames, time, duration, loop) {
    var t = Number.isFinite(time) ? time : 0;
    if (loop) {
      t = ((t % duration) + duration) % duration;
    } else {
      t = clamp(t, 0, duration);
    }
    var previous = frames[0];
    for (var i = 1; i < frames.length; i += 1) {
      var next = frames[i];
      if (t <= next.t) {
        var span = Math.max(1e-6, next.t - previous.t);
        return lerpPose(previous.pose, next.pose, smooth((t - previous.t) / span));
      }
      previous = next;
    }
    return clonePose(frames[frames.length - 1].pose);
  }

  function sampleRun(time) {
    var pose = sampleFrames(RUN, time, 32, true);
    var phase = ((Number.isFinite(time) ? time : 0) % 32 + 32) % 32;
    var foot = null;
    var supportPhase = 0;
    if (phase < 10) {
      foot = "ankleR";
      supportPhase = phase;
    } else if (phase >= 16 && phase < 26) {
      foot = "ankleL";
      supportPhase = phase - 16;
    }
    pose.planted = foot === "ankleR" ? "R" : foot === "ankleL" ? "L" : null;
    if (foot) {
      // The authored contact window travels backward at the simulation gait
      // cadence. Only the annotated support ankle is stabilized; the rest of
      // the pose remains the authored drawing rather than an IK solution.
      pose[foot].x = 42 - supportPhase * RUN_CONTACT_TRAVEL - (pose.rootX || 0);
      pose[foot].y = 61 - (pose.rootY || 0);
    }
    return pose;
  }

  var IDLE = [
    frame(0, {
      head: [0, -68], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [-14, -20], wristL: [-7, 7], elbowR: [15, -19], wristR: [9, 8],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "settled"
    }),
    frame(12, {
      head: [1, -69], neck: [1, -51], shoulder: [2, -43], spine: [1, -23], hip: [0, 0],
      elbowL: [-13, -21], wristL: [-6, 6], elbowR: [16, -20], wristR: [10, 7],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "inhale"
    }),
    frame(24, {
      head: [0, -68], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [-14, -19], wristL: [-8, 8], elbowR: [15, -18], wristR: [9, 9],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "exhale"
    }),
    frame(36, {
      head: [-1, -69], neck: [0, -51], shoulder: [1, -43], spine: [0, -23], hip: [0, 0],
      elbowL: [-15, -20], wristL: [-8, 7], elbowR: [14, -20], wristR: [8, 7],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "inhale"
    }),
    frame(48, {
      head: [0, -68], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [-14, -20], wristL: [-7, 7], elbowR: [15, -19], wristR: [9, 8],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "settled"
    })
  ];

  // Eight distinct running drawings. The torso drives ahead of the hips, while
  // the contact ankle remains nearly still through each support beat.
  var RUN = [
    frame(0, {
      head: [7, -66], neck: [6, -49], shoulder: [8, -40], spine: [5, -21], hip: [0, 0],
      elbowL: [25, -30], wristL: [34, -8], elbowR: [-12, -17], wristR: [-22, 3],
      kneeL: [-20, 25], ankleL: [-31, 54], kneeR: [22, 28], ankleR: [42, 60],
      rootY: 1, planted: "R", phase: "right-contact"
    }),
    frame(4, {
      head: [8, -67], neck: [7, -50], shoulder: [9, -41], spine: [6, -22], hip: [1, -1],
      elbowL: [20, -28], wristL: [27, -5], elbowR: [-10, -22], wristR: [-18, -2],
      kneeL: [-10, 20], ankleL: [-20, 45], kneeR: [16, 31], ankleR: [22, 61],
      rootY: 0, planted: "R", phase: "right-load"
    }),
    frame(8, {
      head: [8, -68], neck: [7, -51], shoulder: [9, -42], spine: [6, -23], hip: [2, -2],
      elbowL: [12, -25], wristL: [15, -2], elbowR: [-3, -27], wristR: [-8, -6],
      kneeL: [9, 17], ankleL: [19, 38], kneeR: [7, 33], ankleR: [2, 62],
      rootY: -1, planted: "R", phase: "right-drive"
    }),
    frame(12, {
      head: [7, -66], neck: [6, -49], shoulder: [8, -40], spine: [5, -21], hip: [1, 0],
      elbowL: [1, -19], wristL: [-6, 3], elbowR: [14, -29], wristR: [17, -8],
      kneeL: [21, 25], ankleL: [32, 53], kneeR: [-7, 29], ankleR: [-18, 60],
      rootY: 1, planted: null, phase: "flight"
    }),
    frame(16, {
      head: [7, -66], neck: [6, -49], shoulder: [8, -40], spine: [5, -21], hip: [0, 0],
      elbowL: [-12, -17], wristL: [-22, 3], elbowR: [25, -30], wristR: [34, -8],
      kneeL: [22, 28], ankleL: [42, 60], kneeR: [-20, 25], ankleR: [-31, 54],
      rootY: 1, planted: "L", phase: "left-contact"
    }),
    frame(20, {
      head: [8, -67], neck: [7, -50], shoulder: [9, -41], spine: [6, -22], hip: [1, -1],
      elbowL: [-10, -22], wristL: [-18, -2], elbowR: [20, -28], wristR: [27, -5],
      kneeL: [16, 31], ankleL: [22, 61], kneeR: [-10, 20], ankleR: [-20, 45],
      rootY: 0, planted: "L", phase: "left-load"
    }),
    frame(24, {
      head: [8, -68], neck: [7, -51], shoulder: [9, -42], spine: [6, -23], hip: [2, -2],
      elbowL: [-3, -27], wristL: [-8, -6], elbowR: [12, -25], wristR: [15, -2],
      kneeL: [7, 33], ankleL: [2, 62], kneeR: [9, 17], ankleR: [19, 38],
      rootY: -1, planted: "L", phase: "left-drive"
    }),
    frame(28, {
      head: [7, -66], neck: [6, -49], shoulder: [8, -40], spine: [5, -21], hip: [1, 0],
      elbowL: [14, -29], wristL: [17, -8], elbowR: [1, -19], wristR: [-6, 3],
      kneeL: [-7, 29], ankleL: [-18, 60], kneeR: [21, 25], ankleR: [32, 53],
      rootY: 1, planted: null, phase: "flight"
    }),
    frame(32, {
      head: [7, -66], neck: [6, -49], shoulder: [8, -40], spine: [5, -21], hip: [0, 0],
      elbowL: [25, -30], wristL: [34, -8], elbowR: [-12, -17], wristR: [-22, 3],
      kneeL: [-20, 25], ankleL: [-31, 54], kneeR: [22, 28], ankleR: [42, 60],
      rootY: 1, planted: "R", phase: "right-contact"
    })
  ];

  var JUMP = [
    frame(0, {
      head: [3, -66], neck: [2, -49], shoulder: [3, -40], spine: [1, -20], hip: [0, 1],
      elbowL: [-17, -23], wristL: [-24, -3], elbowR: [18, -23], wristR: [26, -4],
      kneeL: [-18, 28], ankleL: [-25, 58], kneeR: [16, 29], ankleR: [23, 59],
      planted: "both", phase: "load"
    }),
    frame(4, {
      head: [6, -69], neck: [5, -52], shoulder: [6, -43], spine: [3, -24], hip: [0, -3],
      elbowL: [-12, -32], wristL: [-20, -14], elbowR: [20, -32], wristR: [28, -14],
      kneeL: [-13, 24], ankleL: [-18, 54], kneeR: [13, 24], ankleR: [19, 54],
      rootY: -2, phase: "launch"
    }),
    frame(9, {
      head: [7, -71], neck: [6, -54], shoulder: [7, -45], spine: [4, -26], hip: [0, -5],
      elbowL: [-8, -38], wristL: [-14, -19], elbowR: [21, -38], wristR: [28, -18],
      kneeL: [-18, 18], ankleL: [-11, 44], kneeR: [19, 19], ankleR: [12, 45],
      rootY: -4, phase: "rise"
    }),
    frame(15, {
      head: [6, -70], neck: [5, -53], shoulder: [6, -44], spine: [3, -25], hip: [0, -4],
      elbowL: [-11, -35], wristL: [-17, -15], elbowR: [19, -35], wristR: [26, -15],
      kneeL: [-20, 17], ankleL: [-14, 43], kneeR: [18, 20], ankleR: [10, 47],
      rootY: -3, phase: "apex"
    })
  ];

  var FALL = [
    frame(0, {
      head: [6, -70], neck: [5, -53], shoulder: [6, -44], spine: [3, -25], hip: [0, -4],
      elbowL: [-11, -35], wristL: [-17, -15], elbowR: [19, -35], wristR: [26, -15],
      kneeL: [-20, 17], ankleL: [-14, 43], kneeR: [18, 20], ankleR: [10, 47],
      rootY: -3, phase: "apex"
    }),
    frame(12, {
      head: [3, -66], neck: [2, -49], shoulder: [3, -40], spine: [1, -21], hip: [0, 0],
      elbowL: [-21, -29], wristL: [-32, -9], elbowR: [23, -28], wristR: [33, -7],
      kneeL: [-19, 24], ankleL: [-12, 52], kneeR: [20, 24], ankleR: [12, 53],
      phase: "drop"
    }),
    frame(24, {
      head: [6, -70], neck: [5, -53], shoulder: [6, -44], spine: [3, -25], hip: [0, -4],
      elbowL: [-11, -35], wristL: [-17, -15], elbowR: [19, -35], wristR: [26, -15],
      kneeL: [-20, 17], ankleL: [-14, 43], kneeR: [18, 20], ankleR: [10, 47],
      rootY: -3, phase: "apex"
    })
  ];

  var LAND = [
    frame(0, {
      head: [6, -65], neck: [5, -48], shoulder: [6, -39], spine: [3, -20], hip: [0, 1],
      elbowL: [-22, -29], wristL: [-31, -8], elbowR: [25, -28], wristR: [34, -6],
      kneeL: [-17, 25], ankleL: [-20, 61], kneeR: [18, 26], ankleR: [22, 61],
      planted: "both", phase: "contact"
    }),
    frame(2, {
      head: [9, -57], neck: [7, -40], shoulder: [8, -32], spine: [4, -15], hip: [0, 6],
      elbowL: [-18, -20], wristL: [-25, 2], elbowR: [24, -19], wristR: [31, 3],
      kneeL: [-23, 29], ankleL: [-21, 58], kneeR: [24, 30], ankleR: [22, 58],
      rootY: 3, planted: "both", phase: "compression"
    }),
    frame(5, {
      head: [4, -64], neck: [3, -47], shoulder: [4, -38], spine: [2, -19], hip: [0, 2],
      elbowL: [-16, -21], wristL: [-21, 4], elbowR: [19, -21], wristR: [24, 4],
      kneeL: [-17, 29], ankleL: [-19, 60], kneeR: [18, 29], ankleR: [20, 60],
      rootY: 1, planted: "both", phase: "recover"
    }),
    frame(7, {
      head: [0, -68], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [-14, -20], wristL: [-7, 7], elbowR: [15, -19], wristR: [9, 8],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      planted: "both", phase: "settled"
    })
  ];

  var UNARMED = [
    frame(0, {
      planted: "both", phase: "ready"
    }),
    frame(4, {
      head: [-3, -67], neck: [-3, -50], shoulder: [-5, -41], spine: [-4, -22], hip: [0, 0],
      elbowL: [-18, -31], wristL: [-29, -17], elbowR: [-10, -29], wristR: [-18, -14],
      kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [13, 30], ankleR: [22, 60],
      planted: "R", phase: "coil"
    }),
    frame(5.5, {
      head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [1, 0],
      elbowL: [-8, -31], wristL: [-3, -17], elbowR: [11, -31], wristR: [15, -17],
      kneeL: [-19, 29], ankleL: [-23, 61], kneeR: [17, 29], ankleR: [25, 60],
      planted: "R", phase: "drive"
    }),
    frame(7, {
      head: [7, -66], neck: [7, -49], shoulder: [10, -40], spine: [6, -21], hip: [1, 0],
      elbowL: [10, -30], wristL: [22, -22], elbowR: [32, -32], wristR: [54, -34],
      kneeL: [-19, 29], ankleL: [-23, 61], kneeR: [20, 28], ankleR: [28, 59],
      planted: "L", phase: "contact"
    }),
    frame(10, {
      head: [10, -65], neck: [10, -48], shoulder: [13, -39], spine: [8, -20], hip: [2, 0],
      elbowL: [15, -28], wristL: [28, -20], elbowR: [37, -31], wristR: [58, -31],
      kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [21, 27], ankleR: [29, 59],
      planted: "L", phase: "extension"
    }),
    frame(16, {
      head: [7, -65], neck: [7, -48], shoulder: [10, -39], spine: [6, -20], hip: [2, 0],
      elbowL: [14, -24], wristL: [28, -15], elbowR: [31, -24], wristR: [47, -13],
      kneeL: [-17, 30], ankleL: [-22, 61], kneeR: [20, 28], ankleR: [28, 59],
      planted: "L", phase: "follow-through"
    }),
    frame(23, {
      head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [0, 0],
      elbowL: [8, -28], wristL: [22, -18], elbowR: [19, -24], wristR: [30, -14],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      planted: "both", phase: "recover"
    }),
    frame(30, {
      planted: "both", phase: "recovered"
    })
  ];

  var SWORD_READY = [
    frame(0, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [-5, -29], wristL: [9, -37], elbowR: [14, -35], wristR: [21, -49],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      weaponDir: [0.7071067811865476, -0.7071067811865476], planted: "both", phase: "ready"
    }),
    frame(18, {
      head: [3, -69], neck: [3, -52], shoulder: [4, -43], spine: [2, -23], hip: [0, 0],
      elbowL: [-4, -30], wristL: [10, -38], elbowR: [15, -36], wristR: [22, -50],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      weaponDir: [0.7071067811865476, -0.7071067811865476], planted: "both", phase: "ready-breathe"
    }),
    frame(36, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [-5, -29], wristL: [9, -37], elbowR: [14, -35], wristR: [21, -49],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      weaponDir: [0.7071067811865476, -0.7071067811865476], planted: "both", phase: "ready"
    })
  ];

  // The wrists intentionally define a straight two-hand hilt axis at every key
  // contact pose. swordBlade() extends that authored axis from wristR.
  var SWORD_ATTACK = [
    frame(0, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [-5, -29], wristL: [9, -37], elbowR: [14, -35], wristR: [21, -49],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      weaponDir: [0.7071067811865476, -0.7071067811865476], planted: "both", phase: "ready"
    }),
    frame(3, {
      head: [0, -68], neck: [0, -51], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [8, -30], wristL: [17, -46], elbowR: [12, -44], wristR: [29, -59],
      kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [14, 30], ankleR: [22, 60],
      weaponDir: [0.6782801027330658, -0.7348034446274879], planted: "both", phase: "lift"
    }),
    frame(5, {
      head: [-4, -67], neck: [-4, -50], shoulder: [-6, -41], spine: [-4, -22], hip: [0, 0],
      elbowL: [8, -34], wristL: [21, -52], elbowR: [11, -47], wristR: [31, -67],
      kneeL: [-18, 29], ankleL: [-24, 61], kneeR: [13, 30], ankleR: [22, 60],
      weaponDir: [0.5547001962252291, -0.8320502943378437], planted: "R", phase: "coil"
    }),
    frame(6, {
      head: [-5, -67], neck: [-5, -50], shoulder: [-6, -41], spine: [-5, -22], hip: [0, 0],
      elbowL: [7, -35], wristL: [21, -53], elbowR: [10, -48], wristR: [30, -68],
      kneeL: [-19, 28], ankleL: [-24, 61], kneeR: [12, 31], ankleR: [21, 60],
      weaponDir: [0.5144957554275265, -0.8574929257125441], planted: "R", phase: "coil"
    }),
    frame(8, {
      head: [-4, -68], neck: [-4, -51], shoulder: [-5, -42], spine: [-3, -22], hip: [0, 0],
      elbowL: [8, -35], wristL: [22, -54], elbowR: [12, -49], wristR: [31, -69],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [13, 31], ankleR: [22, 60],
      weaponDir: [0.5144957554275265, -0.8574929257125441], planted: "R", phase: "overhead-hold"
    }),
    frame(9, {
      head: [-2, -68], neck: [-2, -51], shoulder: [-2, -42], spine: [-1, -22], hip: [0, 0],
      elbowL: [8, -34], wristL: [21, -52], elbowR: [12, -49], wristR: [31, -68],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [14, 31], ankleR: [23, 60],
      weaponDir: [0.5299989400031802, -0.847998304005088], planted: "R", phase: "release-load"
    }),
    frame(10, {
      head: [-10, -68], neck: [-7, -51], shoulder: [2, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [8, -31], wristL: [6, -48], elbowR: [6, -52], wristR: [16, -64],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [15, 30], ankleR: [24, 60],
      weaponDir: [0.5299989400031802, -0.847998304005088], planted: "L", phase: "release"
    }),
    frame(13, {
      head: [9, -65], neck: [9, -48], shoulder: [12, -39], spine: [7, -20], hip: [2, 0],
      elbowL: [4, -15], wristL: [19, -28], elbowR: [24, -43], wristR: [36, -28],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [22, 27], ankleR: [30, 59],
      weaponDir: [1, 0], planted: "L", phase: "contact"
    }),
    frame(16, {
      head: [11, -64], neck: [11, -47], shoulder: [14, -38], spine: [9, -19], hip: [3, 0],
      elbowL: [15, -20], wristL: [33, -16], elbowR: [30, -18], wristR: [46, -3],
      kneeL: [-19, 29], ankleL: [-24, 61], kneeR: [23, 27], ankleR: [31, 59],
      weaponDir: [0.7071067811865476, 0.7071067811865476], planted: "L", phase: "late-contact"
    }),
    frame(23, {
      head: [8, -64], neck: [8, -47], shoulder: [11, -38], spine: [7, -19], hip: [3, 0],
      elbowL: [10, -17], wristL: [25, -6], elbowR: [25, -10], wristR: [34, 7],
      kneeL: [-18, 29], ankleL: [-24, 61], kneeR: [22, 27], ankleR: [30, 59],
      weaponDir: [0.5692099788303083, 0.8221921916437787], planted: "L", phase: "follow-through"
    }),
    frame(27, {
      head: [6, -65], neck: [6, -48], shoulder: [8, -39], spine: [5, -20], hip: [2, 0],
      elbowL: [8, -18], wristL: [20, -5], elbowR: [20, -15], wristR: [34, -10],
      kneeL: [-18, 29], ankleL: [-24, 61], kneeR: [20, 28], ankleR: [28, 59],
      weaponDir: [0.9417419115948374, -0.3363363969981562], planted: "L", phase: "recovery-lift"
    }),
    frame(31, {
      head: [3, -67], neck: [3, -50], shoulder: [4, -41], spine: [2, -21], hip: [1, 0],
      elbowL: [-1, -23], wristL: [12, -25], elbowR: [13, -29], wristR: [24, -38],
      kneeL: [-17, 30], ankleL: [-23, 61], kneeR: [17, 29], ankleR: [24, 60],
      weaponDir: [0.6782801027330658, -0.7348034446274879], planted: "both", phase: "recovery"
    }),
    frame(44, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [-5, -29], wristL: [9, -37], elbowR: [14, -35], wristR: [21, -49],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      weaponDir: [0.7071067811865476, -0.7071067811865476], planted: "both", phase: "ready"
    })
  ];

  var AIM_POSES = {
    pistol: {
      extremeHigh: {
        head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
        elbowL: [23, -47], wristL: [32.08, -57.45], elbowR: [25, -50], wristR: [39, -66],
        kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
        weaponDir: [0.6293203910498375, -0.7771459614569708], planted: "both", phase: "aim--51"
      },
      high: {
        head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
        elbowL: [17, -45], wristL: [31.34, -52], elbowR: [24, -50], wristR: [40, -57],
        kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
        weaponDir: [0.8660254037844387, -0.5], planted: "both", phase: "aim--30"
      },
      level: {
        head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
        elbowL: [18, -36], wristL: [33, -34], elbowR: [25, -37], wristR: [42, -35],
        kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
        weaponDir: [1, 0], planted: "both", phase: "aim-level"
      },
      low: {
        head: [3, -67], neck: [3, -50], shoulder: [4, -41], spine: [2, -22], hip: [0, 0],
        elbowL: [20, -27], wristL: [34.34, -23], elbowR: [27, -27], wristR: [43, -18],
        kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
        weaponDir: [0.8660254037844387, 0.5], planted: "both", phase: "aim-30"
      },
      extremeLow: {
        head: [3, -67], neck: [3, -50], shoulder: [4, -41], spine: [2, -22], hip: [0, 0],
        elbowL: [22, -25], wristL: [32.08, -16.55], elbowR: [26, -19], wristR: [39, -8],
        kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
        weaponDir: [0.6293203910498375, 0.7771459614569708], planted: "both", phase: "aim-51"
      }
    },
    shotgun: {
      extremeHigh: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [27, -55], wristL: [39.70, -72.21], elbowR: [16, -47], wristR: [29, -59],
        kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.6293203910498375, -0.7771459614569708], planted: "both", phase: "aim--51"
      },
      high: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [24, -52], wristL: [39.72, -60.5], elbowR: [15, -46], wristR: [25, -52],
        kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.8660254037844387, -0.5], planted: "both", phase: "aim--30"
      },
      level: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [24, -38], wristL: [42, -36], elbowR: [14, -35], wristR: [26, -35],
        kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [1, 0], planted: "both", phase: "aim-level"
      },
      low: {
        head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [0, 0],
        elbowL: [25, -25], wristL: [41.72, -14.5], elbowR: [15, -27], wristR: [27, -23],
        kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.8660254037844387, 0.5], planted: "both", phase: "aim-30"
      },
      extremeLow: {
        head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [0, 0],
        elbowL: [25, -17], wristL: [38.70, -3.79], elbowR: [16, -28], wristR: [28, -17],
        kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.6293203910498375, 0.7771459614569708], planted: "both", phase: "aim-51"
      }
    },
    rifle: {
      extremeHigh: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [29, -56], wristL: [40.70, -73.21], elbowR: [16, -48], wristR: [30, -60],
        kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.6293203910498375, -0.7771459614569708], planted: "both", phase: "aim--51"
      },
      high: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [26, -53], wristL: [41.72, -61.5], elbowR: [14, -46], wristR: [27, -53],
        kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.8660254037844387, -0.5], planted: "both", phase: "aim--30"
      },
      level: {
        head: [1, -68], neck: [1, -51], shoulder: [2, -42], spine: [0, -22], hip: [0, 0],
        elbowL: [26, -38], wristL: [44, -36], elbowR: [15, -35], wristR: [28, -35],
        kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [1, 0], planted: "both", phase: "aim-level"
      },
      low: {
        head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [0, 0],
        elbowL: [27, -24], wristL: [43.72, -13.5], elbowR: [16, -27], wristR: [29, -22],
        kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.8660254037844387, 0.5], planted: "both", phase: "aim-30"
      },
      extremeLow: {
        head: [2, -67], neck: [2, -50], shoulder: [3, -41], spine: [1, -22], hip: [0, 0],
        elbowL: [25, -17], wristL: [39.70, -2.79], elbowR: [16, -28], wristR: [29, -16],
        kneeL: [-17, 29], ankleL: [-23, 61], kneeR: [16, 30], ankleR: [23, 60],
        weaponDir: [0.6293203910498375, 0.7771459614569708], planted: "both", phase: "aim-51"
      }
    }
  };
  var GUN_AIM_ANCHORS = Object.freeze([
    Object.freeze({ step: -17, key: "extremeHigh" }),
    Object.freeze({ step: -10, key: "high" }),
    Object.freeze({ step: 0, key: "level" }),
    Object.freeze({ step: 10, key: "low" }),
    Object.freeze({ step: 17, key: "extremeLow" })
  ]);

  var RELOAD = {
    pistol: [
      frame(0, AIM_POSES.pistol.level),
      frame(10, {
        head: [1, -68], shoulder: [2, -42], elbowL: [10, -28], wristL: [20, -14],
        elbowR: [20, -26], wristR: [29, -12], weaponDir: [0.78, 0.30], phase: "lower"
      }),
      frame(24, {
        head: [-1, -67], shoulder: [0, -41], elbowL: [3, -17], wristL: [17, -4],
        elbowR: [18, -25], wristR: [28, -12], weaponDir: [0.78, 0.30], phase: "magazine"
      }),
      frame(39, {
        head: [1, -68], shoulder: [2, -42], elbowL: [13, -31], wristL: [27, -24],
        elbowR: [22, -30], wristR: [32, -21], weaponDir: [0.90, 0.16], phase: "rack"
      }),
      frame(54, AIM_POSES.pistol.level)
    ],
    shotgun: [
      frame(0, AIM_POSES.shotgun.level),
      frame(12, {
        head: [1, -67], shoulder: [2, -41], elbowL: [20, -24], wristL: [35, -15],
        elbowR: [13, -27], wristR: [26, -21], weaponDir: [0.92, 0.25], phase: "lower"
      }),
      frame(29, {
        head: [-1, -67], shoulder: [0, -41], elbowL: [9, -15], wristL: [25, -6],
        elbowR: [13, -26], wristR: [26, -20], weaponDir: [0.92, 0.25], phase: "load"
      }),
      frame(42, {
        head: [1, -67], shoulder: [2, -41], elbowL: [22, -29], wristL: [37, -23],
        elbowR: [14, -30], wristR: [27, -27], weaponDir: [0.98, 0.10], phase: "pump"
      }),
      frame(54, AIM_POSES.shotgun.level)
    ],
    rifle: [
      frame(0, AIM_POSES.rifle.level),
      frame(10, {
        head: [1, -67], shoulder: [2, -41], elbowL: [21, -25], wristL: [37, -17],
        elbowR: [14, -28], wristR: [28, -23], weaponDir: [0.94, 0.22], phase: "lower"
      }),
      frame(28, {
        head: [-1, -67], shoulder: [0, -41], elbowL: [5, -14], wristL: [22, -5],
        elbowR: [14, -28], wristR: [28, -23], weaponDir: [0.94, 0.22], phase: "magazine"
      }),
      frame(43, {
        head: [1, -68], shoulder: [2, -42], elbowL: [27, -36], wristL: [42, -32],
        elbowR: [15, -33], wristR: [29, -31], weaponDir: [1, 0], phase: "charge"
      }),
      frame(54, AIM_POSES.rifle.level)
    ]
  };

  var GRENADE = [
    frame(0, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [10, -29], wristL: [23, -22], elbowR: [19, -36], wristR: [29, -48],
      kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      planted: "both", phase: "ready"
    }),
    frame(4, {
      head: [-1, -68], neck: [-1, -51], shoulder: [-2, -42], spine: [-1, -22], hip: [0, 0],
      elbowL: [-20, -30], wristL: [-12, -14], elbowR: [25, -48], wristR: [35, -65],
      kneeL: [-18, 29], ankleL: [-23, 61], kneeR: [14, 30], ankleR: [22, 60],
      planted: "R", phase: "lift"
    }),
    frame(7, {
      head: [-4, -67], neck: [-4, -50], shoulder: [-6, -41], spine: [-4, -22], hip: [0, 0],
      elbowL: [-13, -27], wristL: [-21, -9], elbowR: [25, -52], wristR: [36, -76],
      kneeL: [-19, 29], ankleL: [-24, 61], kneeR: [13, 31], ankleR: [22, 60],
      planted: "R", phase: "windup"
    }),
    frame(13, {
      head: [2, -68], neck: [2, -51], shoulder: [4, -42], spine: [2, -22], hip: [0, 0],
      elbowL: [4, -27], wristL: [15, -15], elbowR: [28, -54], wristR: [40, -73],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [17, 29], ankleR: [25, 60],
      planted: "L", phase: "whip"
    }),
    frame(16, {
      head: [9, -65], neck: [9, -48], shoulder: [12, -39], spine: [7, -20], hip: [2, 0],
      elbowL: [10, -25], wristL: [22, -14], elbowR: [34, -51], wristR: [54, -58],
      kneeL: [-20, 28], ankleL: [-24, 61], kneeR: [22, 27], ankleR: [30, 59],
      grenadeVisible: true, planted: "L", phase: "release"
    }),
    frame(18, {
      head: [10, -64], neck: [10, -47], shoulder: [13, -38], spine: [8, -19], hip: [3, 0],
      elbowL: [12, -22], wristL: [25, -10], elbowR: [37, -43], wristR: [57, -43],
      grenadeVisible: false, kneeL: [-19, 29], ankleL: [-24, 61], kneeR: [23, 27], ankleR: [31, 59],
      planted: "L", phase: "released"
    }),
    frame(27, {
      head: [7, -65], neck: [7, -48], shoulder: [10, -39], spine: [6, -20], hip: [2, 0],
      elbowL: [11, -20], wristL: [24, -8], elbowR: [30, -24], wristR: [46, -13],
      grenadeVisible: false, kneeL: [-18, 29], ankleL: [-24, 61], kneeR: [21, 28], ankleR: [29, 59],
      planted: "L", phase: "follow-through"
    }),
    frame(38, {
      head: [2, -68], neck: [2, -51], shoulder: [3, -42], spine: [1, -22], hip: [0, 0],
      elbowL: [10, -29], wristL: [23, -22], elbowR: [19, -36], wristR: [29, -48],
      grenadeVisible: true, kneeL: [-16, 30], ankleL: [-22, 61], kneeR: [15, 29], ankleR: [22, 60],
      planted: "both", phase: "ready"
    })
  ];
  var GRENADE_RELEASE_ARMS = Object.freeze([
    Object.freeze({
      degrees: -90,
      preElbow: [33, -53], preWrist: [38, -76], releaseElbow: [38.5, -55]
    }),
    Object.freeze({
      degrees: -45,
      preElbow: [29, -51], preWrist: [43.5, -63.5], releaseElbow: [35, -52]
    }),
    Object.freeze({
      degrees: 0,
      preElbow: [28, -43], preWrist: [46, -43], releaseElbow: [35, -43]
    }),
    Object.freeze({
      degrees: 45,
      preElbow: [28, -32], preWrist: [43.5, -20.5], releaseElbow: [34, -27]
    }),
    Object.freeze({
      degrees: 90,
      preElbow: [17, -29], preWrist: [22, -15], releaseElbow: [23, -20]
    })
  ]);

  var HIT = [
    frame(0, { phase: "impact" }),
    frame(3, {
      head: [-8, -65], neck: [-7, -48], shoulder: [-10, -39], spine: [-6, -20], hip: [0, 0],
      elbowL: [-25, -28], wristL: [-36, -8], elbowR: [4, -32], wristR: [11, -12],
      kneeL: [-20, 29], ankleL: [-24, 61], kneeR: [12, 31], ankleR: [21, 60],
      phase: "recoil"
    }),
    frame(7, {
      head: [-4, -66], neck: [-4, -49], shoulder: [-5, -40], spine: [-3, -21], hip: [0, 0],
      elbowL: [-20, -25], wristL: [-29, -3], elbowR: [10, -26], wristR: [15, -4],
      kneeL: [-18, 30], ankleL: [-23, 61], kneeR: [13, 30], ankleR: [22, 60],
      phase: "brace"
    }),
    frame(13, { phase: "recover" })
  ];

  var DEFEAT = [
    frame(0, { phase: "stagger" }),
    frame(6, {
      head: [-12, -62], neck: [-10, -46], shoulder: [-13, -37], spine: [-8, -19], hip: [0, 0],
      elbowL: [-30, -28], wristL: [-42, -8], elbowR: [1, -31], wristR: [8, -10],
      kneeL: [-22, 29], ankleL: [-25, 61], kneeR: [10, 32], ankleR: [20, 60],
      phase: "stagger"
    }),
    frame(14, {
      head: [-29, -47], neck: [-22, -34], shoulder: [-23, -26], spine: [-12, -12], hip: [0, 2],
      elbowL: [-38, -16], wristL: [-47, 4], elbowR: [-7, -24], wristR: [3, -5],
      kneeL: [-25, 30], ankleL: [-27, 61], kneeR: [11, 34], ankleR: [21, 61],
      rootY: 2, phase: "collapse"
    }),
    frame(24, {
      head: [-43, -24], neck: [-31, -20], shoulder: [-28, -14], spine: [-14, -6], hip: [0, 5],
      elbowL: [-42, -4], wristL: [-49, 16], elbowR: [-13, -13], wristR: [2, 0],
      kneeL: [-24, 30], ankleL: [-29, 59], kneeR: [16, 29], ankleR: [28, 57],
      rootY: 6, phase: "fall"
    }),
    frame(34, {
      head: [-49, -13], neck: [-32, -10], shoulder: [-27, -6], spine: [-13, -1], hip: [2, 5],
      elbowL: [-40, 2], wristL: [-51, 12], elbowR: [-12, -5], wristR: [5, 2],
      kneeL: [-13, 10], ankleL: [-31, 14], kneeR: [18, 9], ankleR: [39, 12],
      rootY: 47, phase: "grounded"
    }),
    frame(40, {
      head: [-49, -13], neck: [-32, -10], shoulder: [-27, -6], spine: [-13, -1], hip: [2, 5],
      elbowL: [-40, 2], wristL: [-51, 12], elbowR: [-12, -5], wristR: [5, 2],
      kneeL: [-13, 10], ankleL: [-31, 14], kneeR: [18, 9], ankleR: [39, 12],
      rootY: 47, phase: "grounded"
    })
  ];

  var RESPAWN = [
    frame(0, {
      head: [0, -58], neck: [0, -42], shoulder: [1, -34], spine: [0, -17], hip: [0, 5],
      elbowL: [-12, -14], wristL: [-6, 8], elbowR: [13, -13], wristR: [7, 9],
      kneeL: [-18, 31], ankleL: [-20, 58], kneeR: [18, 31], ankleR: [20, 58],
      alpha: 0.7, rootY: 5, planted: "both", phase: "materialize"
    }),
    frame(8, {
      head: [0, -61], neck: [0, -44], shoulder: [1, -36], spine: [0, -18], hip: [0, 4],
      elbowL: [-13, -16], wristL: [-7, 7], elbowR: [14, -15], wristR: [8, 8],
      kneeL: [-17, 31], ankleL: [-19, 59], kneeR: [17, 31], ankleR: [19, 59],
      alpha: 0.82, rootY: 4, planted: "both", phase: "materialize"
    }),
    frame(16, {
      head: [0, -66], neck: [0, -49], shoulder: [1, -40], spine: [0, -21], hip: [0, 1],
      elbowL: [-14, -19], wristL: [-7, 7], elbowR: [15, -18], wristR: [9, 8],
      kneeL: [-14, 30], ankleL: [-18, 61], kneeR: [14, 30], ankleR: [19, 61],
      alpha: 0.92, rootY: 1, planted: "both", phase: "form"
    }),
    frame(24, {
      head: [0, -68], shoulder: [1, -42], spine: [0, -22], hip: [0, 0],
      elbowL: [-14, -20], wristL: [-7, 7], elbowR: [15, -19], wristR: [9, 8],
      kneeL: [-13, 30], ankleL: [-17, 61], kneeR: [13, 30], ankleR: [18, 61],
      alpha: 1, scaleY: 1, planted: "both", phase: "ready"
    })
  ];

  function aimBand(value, aimY) {
    if (value === "high" || value === "level" || value === "low") return value;
    var y = Number.isFinite(aimY) ? aimY : 0;
    if (y < -0.28) return "high";
    if (y > 0.28) return "low";
    return "level";
  }

  function legacyAimStep(value) {
    if (value === "high") return -10;
    if (value === "low") return 10;
    if (value === "level") return 0;
    return null;
  }

  function resolveGunAimStep(value, aimX, aimY, facing) {
    var sim = global.StickSim;
    if (!sim || typeof sim.resolveGunAim !== "function") {
      throw new Error("StickAnim: StickSim.resolveGunAim is required");
    }
    var legacy = legacyAimStep(value);
    var committed = Number.isFinite(value) ? value : legacy;
    return sim.resolveGunAim(
      Number.isFinite(aimX) ? aimX : (facing < 0 ? -1 : 1),
      Number.isFinite(aimY) ? aimY : 0,
      facing,
      committed
    );
  }

  function grenadeLaunchLocal(aimX, aimY, facing) {
    var sim = global.StickSim;
    if (!sim || typeof sim.grenadeLaunchDirection !== "function") {
      throw new Error("StickAnim: StickSim.grenadeLaunchDirection is required");
    }
    var face = facing < 0 ? -1 : 1;
    var launch = sim.grenadeLaunchDirection(
      Number.isFinite(aimX) ? aimX : face,
      Number.isFinite(aimY) ? aimY : 0,
      face
    );
    return { x: launch.x * face, y: launch.y };
  }

  function sampleGrenadeReleaseArm(degrees, key) {
    var previous = GRENADE_RELEASE_ARMS[0];
    for (var i = 1; i < GRENADE_RELEASE_ARMS.length; i += 1) {
      var next = GRENADE_RELEASE_ARMS[i];
      if (degrees <= next.degrees) {
        var amount = (degrees - previous.degrees) / (next.degrees - previous.degrees);
        return {
          x: mix(previous[key][0], next[key][0], amount),
          y: mix(previous[key][1], next[key][1], amount)
        };
      }
      previous = next;
    }
    return point(previous[key]);
  }

  function grenadeThrowPose(age, aimX, aimY, facing) {
    var t = clamp(Number.isFinite(age) ? age : 0, 0, CLIPS.grenadeThrow.duration);
    var pose = sampleFrames(GRENADE, t, CLIPS.grenadeThrow.duration, false);
    var launch = grenadeLaunchLocal(aimX, aimY, facing);
    var degrees = clamp(Math.atan2(launch.y, Math.max(0, launch.x)) * 180 / Math.PI, -90, 90);
    var preElbow = sampleGrenadeReleaseArm(degrees, "preElbow");
    var preWrist = sampleGrenadeReleaseArm(degrees, "preWrist");
    var releaseElbow = sampleGrenadeReleaseArm(degrees, "releaseElbow");
    var releaseWrist = {
      x: preWrist.x + launch.x * 12,
      y: preWrist.y + launch.y * 12
    };

    if (t > 13 && t <= 15) {
      var prepare = smooth((t - 13) / 2);
      var preparedPose = clonePose(pose);
      preparedPose.elbowR = copyPoint(preElbow);
      preparedPose.wristR = copyPoint(preWrist);
      pose = lerpRiggedPose(pose, preparedPose, prepare);
    } else if (t > 15 && t <= 16) {
      var release = t - 15;
      pose.elbowR.x = mix(preElbow.x, releaseElbow.x, release);
      pose.elbowR.y = mix(preElbow.y, releaseElbow.y, release);
      pose.wristR.x = mix(preWrist.x, releaseWrist.x, release);
      pose.wristR.y = mix(preWrist.y, releaseWrist.y, release);
    } else if (t > 16 && t < 18) {
      var follow = smooth((t - 16) / 2);
      var releasePose = clonePose(pose);
      releasePose.elbowR = copyPoint(releaseElbow);
      releasePose.wristR = copyPoint(releaseWrist);
      pose = lerpRiggedPose(releasePose, pose, follow);
    }
    if (t > 13 && t < 18) pose.weaponDir = copyPoint(launch);
    pose.grenadeLaunchDir = copyPoint(launch);
    return retainElbowBends(pose, pose);
  }

  function normalizeWeapon(weapon) {
    if (!weapon) return "unarmed";
    var value = typeof weapon === "string" ? weapon : (weapon.kind || weapon.id || weapon.type);
    value = String(value || "unarmed").toLowerCase();
    if (value === "automatic" || value === "automatic-rifle" || value === "assault-rifle") return "rifle";
    if (value === "longsword" || value === "long-sword") return "sword";
    if (value === "fists" || value === "none") return "unarmed";
    return value;
  }

  function elbowBendSign(pose, side) {
    var elbow = pose["elbow" + side];
    var wrist = pose["wrist" + side];
    var shoulder = pose.shoulder;
    var cross = (wrist.x - shoulder.x) * (elbow.y - shoulder.y)
      - (wrist.y - shoulder.y) * (elbow.x - shoulder.x);
    return cross < 0 ? -1 : 1;
  }

  function retainElbowBends(pose, reference) {
    pose.elbowBendL = elbowBendSign(reference, "L");
    pose.elbowBendR = elbowBendSign(reference, "R");
    return pose;
  }

  function gunAimPose(weapon, aimValue) {
    weapon = normalizeWeapon(weapon);
    if (!AIM_POSES[weapon]) weapon = "pistol";
    var resolved = resolveGunAimStep(aimValue, 1, 0, 1);
    var previous = GUN_AIM_ANCHORS[0];
    var pose = makePose(AIM_POSES[weapon][previous.key]);
    for (var i = 1; i < GUN_AIM_ANCHORS.length; i += 1) {
      var next = GUN_AIM_ANCHORS[i];
      if (resolved.step <= next.step) {
        var span = next.step - previous.step;
        var amount = span ? (resolved.step - previous.step) / span : 0;
        pose = lerpRiggedPose(
          makePose(AIM_POSES[weapon][previous.key]),
          makePose(AIM_POSES[weapon][next.key]),
          amount
        );
        break;
      }
      previous = next;
      pose = makePose(AIM_POSES[weapon][previous.key]);
    }
    pose.weaponDir = { x: resolved.x, y: resolved.y };
    pose.aimStep = resolved.step;
    pose.aimDegrees = resolved.degrees;
    pose.phase = "aim-" + resolved.degrees;
    return retainElbowBends(pose, pose);
  }

  function gunFirePose(weapon, aimValue, age) {
    var base = gunAimPose(weapon, aimValue);
    var timings = [0, 2, 5, 8, 12];
    var amounts = [0, 1, 0.55, 0.16, 0];
    var t = clamp(age || 0, 0, 12);
    var recoil = 0;
    for (var i = 1; i < timings.length; i += 1) {
      if (t <= timings[i]) {
        recoil = mix(amounts[i - 1], amounts[i], smooth((t - timings[i - 1]) / (timings[i] - timings[i - 1])));
        break;
      }
    }
    var strength = weapon === "shotgun" ? 8 : weapon === "rifle" ? 3.2 : 5;
    var kick = strength * recoil;
    var direction = base.weaponDir;
    var normal = { x: -direction.y, y: direction.x };
    function recoilPoint(key, along, side) {
      base[key].x -= direction.x * kick * along;
      base[key].y -= direction.y * kick * along;
      base[key].x += normal.x * kick * side;
      base[key].y += normal.y * kick * side;
    }
    // Recoil remains authored, but its beats are expressed in barrel space so
    // high and low shots recover along their committed direction.
    recoilPoint("head", 0.18, 0);
    recoilPoint("neck", 0.28, 0);
    recoilPoint("shoulder", 0.42, 0);
    recoilPoint("spine", 0.24, 0);
    recoilPoint("elbowL", 0.75, 0.06);
    recoilPoint("elbowR", 0.88, 0.06);
    recoilPoint("wristL", 1, 0.08);
    recoilPoint("wristR", 1, 0.08);
    base.phase = t <= 2 ? "fire" : t <= 8 ? "recoil" : "recover";
    base.recoil = recoil;
    return base;
  }

  function reloadDuration(weapon) {
    weapon = normalizeWeapon(weapon);
    return RELOAD_DURATIONS[weapon] || 54;
  }

  function sampleReload(weapon, aimValue, age) {
    weapon = normalizeWeapon(weapon);
    var resolved = resolveGunAimStep(aimValue, 1, 0, 1);
    var band = resolved.step < 0 ? "high" : resolved.step > 0 ? "low" : "level";
    var frames = RELOAD[weapon] || RELOAD.pistol;
    var duration = reloadDuration(weapon);
    var progress = clamp((Number.isFinite(age) ? age : 0) / Math.max(1, duration - 1), 0, 1);
    var pose = sampleFrames(frames, progress * 54, 54, false);
    if (resolved.step !== 0) {
      // Reloads pass through the authored level handling pose, but enter and exit
      // from the selected high/low band so an animation never teleports to level.
      var seamWeight = 0;
      if (progress < 0.22) seamWeight = 1 - smooth(progress / 0.22);
      else if (progress > 0.78) seamWeight = smooth((progress - 0.78) / 0.22);
      if (seamWeight > 0) {
        var level = gunAimPose(weapon, 0);
        var target = gunAimPose(weapon, resolved.step);
        var seam = lerpRiggedPose(level, target, seamWeight);
        var upperPoints = ["head", "neck", "shoulder", "spine", "elbowL", "elbowR", "wristL", "wristR"];
        for (var i = 0; i < upperPoints.length; i += 1) {
          var key = upperPoints[i];
          if (seamWeight === 1) {
            pose[key] = copyPoint(target[key]);
          } else {
            pose[key].x += seam[key].x - level[key].x;
            pose[key].y += seam[key].y - level[key].y;
          }
        }
        pose.weaponDir = copyPoint(seamWeight === 1 ? target.weaponDir : seam.weaponDir);
      }
    }
    pose.upperPhase = pose.phase;
    pose.phase = "reload-" + band + (progress === 0 ? "-enter" : progress === 1 ? "-exit" : "-handle");
    pose.aimStep = resolved.step;
    pose.aimDegrees = resolved.degrees;
    retainElbowBends(pose, gunAimPose(weapon, resolved.step));
    return pose;
  }

  function sampleClip(name, time, options) {
    options = options || {};
    var pose;
    var resolvedAim;
    switch (name) {
      case "idle": pose = sampleFrames(IDLE, time, 48, true); break;
      case "run": pose = sampleRun(time); break;
      case "jump": pose = sampleFrames(JUMP, time, 15, false); break;
      case "fall": pose = sampleFrames(FALL, time, 24, true); break;
      case "land": pose = sampleFrames(LAND, time, 7, false); break;
      case "unarmed": pose = sampleFrames(UNARMED, time, 30, false); break;
      case "swordReady": pose = sampleFrames(SWORD_READY, time, 36, true); break;
      case "swordAttack": pose = sampleFrames(SWORD_ATTACK, time, 44, false); break;
      case "gunAim":
        resolvedAim = resolveGunAimStep(options.aimStep == null ? options.aimBand : options.aimStep,
          options.aimX, options.aimY, options.facing);
        pose = gunAimPose(options.weapon, resolvedAim.step);
        break;
      case "gunFire":
        resolvedAim = resolveGunAimStep(options.aimStep == null ? options.aimBand : options.aimStep,
          options.aimX, options.aimY, options.facing);
        pose = gunFirePose(options.weapon, resolvedAim.step, time);
        break;
      case "reload":
        resolvedAim = resolveGunAimStep(options.aimStep == null ? options.aimBand : options.aimStep,
          options.aimX, options.aimY, options.facing);
        pose = sampleReload(options.weapon, resolvedAim.step, time);
        break;
      case "grenadeThrow":
        pose = grenadeThrowPose(time, options.aimX, options.aimY, options.facing);
        break;
      case "hit": pose = sampleFrames(HIT, time, 13, false); break;
      case "defeat": pose = sampleFrames(DEFEAT, time, 40, false); break;
      case "respawn": pose = sampleFrames(RESPAWN, time, 24, false); break;
      default: pose = sampleFrames(IDLE, time, 48, true); name = "idle"; break;
    }
    pose.clip = name;
    pose.clipTime = Number.isFinite(time) ? time : 0;
    pose.weapon = normalizeWeapon(options.weapon);
    pose.aimStep = resolvedAim ? resolvedAim.step : (Number.isFinite(pose.aimStep) ? pose.aimStep : 0);
    pose.aimDegrees = resolvedAim ? resolvedAim.degrees : (Number.isFinite(pose.aimDegrees) ? pose.aimDegrees : 0);
    pose.aimBand = pose.aimStep < 0 ? "high" : pose.aimStep > 0 ? "low" : "level";
    return finalizePose(pose, options.facing == null ? 1 : options.facing, pose.weapon);
  }

  function attachWeaponUpper(lower, upper) {
    var pose = clonePose(lower);
    var lowerRootX = lower.rootX || 0;
    var lowerRootY = lower.rootY || 0;
    var upperRootX = upper.rootX || 0;
    var upperRootY = upper.rootY || 0;
    // Weapon stances own the complete upper-body silhouette. Converting their
    // authored world-local points into the locomotion root keeps every joint and
    // authority-sensitive wrist exact while the live lower body keeps moving.
    var upperPoints = ["head", "neck", "shoulder", "spine", "elbowL", "elbowR", "wristL", "wristR"];
    for (var i = 0; i < upperPoints.length; i += 1) {
      var key = upperPoints[i];
      pose[key].x = upper[key].x + upperRootX - lowerRootX;
      pose[key].y = upper[key].y + upperRootY - lowerRootY;
    }
    pose.weaponDir = copyPoint(upper.weaponDir);
    pose.grenadeLaunchDir = upper.grenadeLaunchDir ? copyPoint(upper.grenadeLaunchDir) : null;
    pose.weaponLift = upper.weaponLift || 0;
    pose.grenadeVisible = upper.grenadeVisible;
    pose.upperPhase = upper.phase || "ready";
    return pose;
  }

  function readyWeaponPose(weapon, band, age) {
    if (weapon === "sword") {
      return retainElbowBends(
        sampleFrames(SWORD_READY, age, 36, true),
        sampleFrames(SWORD_READY, 0, 36, true)
      );
    }
    if (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle") return gunAimPose(weapon, band);
    if (weapon === "grenade") {
      var grenadeReady = sampleFrames(GRENADE, 0, 38, false);
      return retainElbowBends(grenadeReady, grenadeReady);
    }
    return null;
  }

  function actionInfo(fighter) {
    var action = fighter && fighter.action;
    if (!action) return { kind: "", age: fighter && Number.isFinite(fighter.actionAge) ? fighter.actionAge : 0 };
    if (typeof action === "string") {
      return { kind: action.toLowerCase(), age: fighter && Number.isFinite(fighter.actionAge) ? fighter.actionAge : 0 };
    }
    return {
      kind: String(action.kind || action.type || action.name || "").toLowerCase(),
      age: Number.isFinite(action.age) ? action.age : (Number.isFinite(action.t) ? action.t : 0)
    };
  }

  function lifeInfo(fighter) {
    var life = fighter && fighter.life;
    if (!life) {
      return {
        kind: fighter && (fighter.defeated || fighter.dead) ? "defeated" : "alive",
        age: fighter && Number.isFinite(fighter.lifeAge)
          ? fighter.lifeAge
          : fighter && Number.isFinite(fighter.animTick)
            ? fighter.animTick
            : 0
      };
    }
    if (typeof life === "string") return { kind: life.toLowerCase(), age: 0 };
    return {
      kind: String(life.kind || life.state || "alive").toLowerCase(),
      age: Number.isFinite(life.age) ? life.age : 0,
      source: life.source || null
    };
  }

  function locomotionInfo(fighter) {
    var locomotion = fighter && fighter.locomotion;
    if (!locomotion) return {
      kind: "", age: 0, gaitPhase: 0,
      previousKind: "", previousAge: 0, previousGaitPhase: 0,
      previousVx: 0, previousTravelSign: 0, previousMoveIntent: false,
      previousEntryKind: "", previousEntryAge: 0,
      previousTurn: null, previousLandExit: null, previousRunExit: null,
      travelSign: 0, moveIntent: false,
      turn: null, landExit: null, runExit: null
    };
    if (typeof locomotion === "string") {
      return {
        kind: locomotion.toLowerCase(), age: 0, gaitPhase: 0,
        previousKind: locomotion.toLowerCase(), previousAge: 0, previousGaitPhase: 0,
        previousVx: 0, previousTravelSign: 0,
        previousMoveIntent: locomotion.toLowerCase() === "run",
        previousEntryKind: locomotion.toLowerCase(), previousEntryAge: 0,
        previousTurn: null, previousLandExit: null, previousRunExit: null,
        travelSign: 0, moveIntent: locomotion.toLowerCase() === "run",
        turn: null, landExit: null, runExit: null
      };
    }
    var kind = String(locomotion.kind || locomotion.state || "").toLowerCase();
    return {
      kind: kind,
      age: Number.isFinite(locomotion.age) ? locomotion.age : 0,
      gaitPhase: Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0,
      previousKind: String(locomotion.previousKind || kind).toLowerCase(),
      previousAge: Number.isFinite(locomotion.previousAge) ? locomotion.previousAge : 0,
      previousGaitPhase: Number.isFinite(locomotion.previousGaitPhase)
        ? locomotion.previousGaitPhase
        : (Number.isFinite(locomotion.gaitPhase) ? locomotion.gaitPhase : 0),
      previousVx: Number.isFinite(locomotion.previousVx)
        ? locomotion.previousVx
        : (fighter && Number.isFinite(fighter.prevVx) ? fighter.prevVx : 0),
      previousTravelSign: locomotion.previousTravelSign < 0
        ? -1
        : locomotion.previousTravelSign > 0
          ? 1
          : (locomotion.travelSign < 0 ? -1 : locomotion.travelSign > 0 ? 1 : 0),
      previousMoveIntent: locomotion.previousMoveIntent == null
        ? !!locomotion.moveIntent
        : !!locomotion.previousMoveIntent,
      previousEntryKind: String(locomotion.previousEntryKind || locomotion.previousKind || kind).toLowerCase(),
      previousEntryAge: Number.isFinite(locomotion.previousEntryAge) ? locomotion.previousEntryAge : 0,
      previousTurn: locomotion.previousTurn && typeof locomotion.previousTurn === "object"
        ? locomotion.previousTurn
        : null,
      previousLandExit: locomotion.previousLandExit && typeof locomotion.previousLandExit === "object"
        ? locomotion.previousLandExit
        : null,
      previousRunExit: locomotion.previousRunExit && typeof locomotion.previousRunExit === "object"
        ? locomotion.previousRunExit
        : null,
      travelSign: locomotion.travelSign < 0 ? -1 : locomotion.travelSign > 0 ? 1 : 0,
      moveIntent: locomotion.moveIntent == null
        ? (kind === "run" || kind === "running")
        : !!locomotion.moveIntent,
      turn: locomotion.turn && typeof locomotion.turn === "object" ? locomotion.turn : null,
      landExit: locomotion.landExit && typeof locomotion.landExit === "object"
        ? locomotion.landExit
        : null,
      runExit: locomotion.runExit && typeof locomotion.runExit === "object"
        ? locomotion.runExit
        : null
    };
  }

  function orientLowerToTravel(pose, facing, lowerFacing) {
    if (lowerFacing !== facing) {
      var lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];
      for (var i = 0; i < lowerPoints.length; i += 1) pose[lowerPoints[i]].x *= -1;
    }
    pose.lowerFacing = lowerFacing;
    return pose;
  }

  function stabilizeChain(pose, root, joint, end, minimum, maximum) {
    var dx = pose[joint].x - pose[root].x;
    var dy = pose[joint].y - pose[root].y;
    var length = Math.hypot(dx, dy) || 1;
    var target = clamp(length, minimum, maximum);
    if (target !== length) {
      var jointX = pose[root].x + dx / length * target;
      var jointY = pose[root].y + dy / length * target;
      var shiftX = jointX - pose[joint].x;
      var shiftY = jointY - pose[joint].y;
      pose[joint].x = jointX;
      pose[joint].y = jointY;
      pose[end].x += shiftX;
      pose[end].y += shiftY;
    }
    dx = pose[end].x - pose[joint].x;
    dy = pose[end].y - pose[joint].y;
    length = Math.hypot(dx, dy) || 1;
    target = clamp(length, minimum, maximum);
    if (target !== length) {
      pose[end].x = pose[joint].x + dx / length * target;
      pose[end].y = pose[joint].y + dy / length * target;
    }
  }

  function stabilizeTransitionLimbs(pose) {
    stabilizeChain(pose, "shoulder", "elbowL", "wristL", 10, 36);
    stabilizeChain(pose, "shoulder", "elbowR", "wristR", 10, 36);
    stabilizeChain(pose, "hip", "kneeL", "ankleL", 15, 40);
    stabilizeChain(pose, "hip", "kneeR", "ankleR", 15, 40);
    return pose;
  }

  function supportBlendAtPhase(phase) {
    var start = phase < 10 ? 0 : 16;
    var end = start + 10;
    var edge = 2;
    return smooth(clamp(Math.min((phase - start) / edge, (end - phase) / edge), 0, 1));
  }

  function sampleGroundedMotion(fighter, facing, locomotion, renderAlpha, previous) {
    var kind = previous ? locomotion.previousKind : locomotion.kind;
    var idleAge = previous ? locomotion.previousAge : locomotion.age;
    var velocityX = previous
      ? locomotion.previousVx
      : (Number.isFinite(fighter.vx) ? fighter.vx : 0);
    var speed = Math.abs(velocityX);
    var age = previous ? locomotion.previousGaitPhase : locomotion.gaitPhase;
    var travelSign = previous ? locomotion.previousTravelSign : locomotion.travelSign;
    if (!previous && Number.isFinite(renderAlpha) && Number.isFinite(fighter.renderStepX) && Number.isFinite(fighter.prevX)) {
      var scale = Number.isFinite(fighter.drawScale) ? fighter.drawScale : 1;
      var stepDistance = Math.abs(fighter.renderStepX - fighter.prevX);
      var stepPhase = stepDistance / Math.max(0.000001, RUN_CONTACT_TRAVEL * scale);
      age -= stepPhase * (1 - clamp(renderAlpha, 0, 1));
    }
    var idlePose = sampleFrames(IDLE, idleAge, 48, true);
    var runPose = sampleRun(age);
    var lowerFacing = travelSign || (speed > 1 ? (velocityX < 0 ? -1 : 1) : facing);
    orientLowerToTravel(idlePose, facing, lowerFacing);
    orientLowerToTravel(runPose, facing, lowerFacing);
    var hasRunSource = kind === "run" || kind === "running"
      || (!previous && (locomotion.previousKind === "run" || locomotion.previousKind === "running"));
    var runWeight = hasRunSource ? smooth(clamp(speed / RUN_BLEND_SPEED, 0, 1)) : 0;
    var runEntryWeight = 1;
    if (!previous && (kind === "run" || kind === "running")
      && locomotion.previousKind !== "run" && locomotion.previousKind !== "running") {
      runEntryWeight = smooth(clamp(locomotion.age / 4, 0, 1));
    } else if (previous && (kind === "run" || kind === "running") && locomotion.previousAge < 4) {
      runEntryWeight = smooth(clamp(locomotion.previousAge / 4, 0, 1));
    }
    runWeight *= runEntryWeight;
    var pose = lerpPose(idlePose, runPose, runWeight);
    if (runPose.planted && (kind === "run" || kind === "running")) {
      var foot = runPose.planted === "R" ? "ankleR" : "ankleL";
      var supportKnee = runPose.planted === "R" ? "kneeR" : "kneeL";
      var supportPoints = ["hip", supportKnee, foot];
      var runPhase = ((age % 32) + 32) % 32;
      var supportBlend = supportBlendAtPhase(runPhase) * runEntryWeight;
      for (var supportIndex = 0; supportIndex < supportPoints.length; supportIndex += 1) {
        var supportKey = supportPoints[supportIndex];
        var supportX = runPose[supportKey].x + (runPose.rootX || 0) - (pose.rootX || 0);
        var supportY = runPose[supportKey].y + (runPose.rootY || 0) - (pose.rootY || 0);
        pose[supportKey].x = mix(pose[supportKey].x, supportX, supportBlend);
        pose[supportKey].y = mix(pose[supportKey].y, supportY, supportBlend);
      }
      stabilizeTransitionLimbs(pose);
      pose.planted = supportBlend >= 0.999999 ? runPose.planted : null;
    } else {
      pose.planted = null;
    }
    pose.phase = runWeight >= 1 ? runPose.phase : runWeight <= 0 ? idlePose.phase : "run-blend";
    if (!previous && locomotion.turn) {
      var turn = locomotion.turn;
      var turnDuration = Number.isFinite(turn.duration) ? Math.max(1, turn.duration) : 8;
      var turnAge = Number.isFinite(turn.age) ? turn.age : turnDuration;
      if (turnAge < turnDuration) {
        var turnLocomotion = {
          kind: String(turn.sourceKind || "run").toLowerCase(),
          age: Number.isFinite(turn.sourceAge) ? turn.sourceAge : 0,
          gaitPhase: Number.isFinite(turn.sourceGaitPhase) ? turn.sourceGaitPhase : 0,
          previousKind: String(turn.sourcePreviousKind || turn.sourceKind || "run").toLowerCase(),
          previousAge: Number.isFinite(turn.sourcePreviousAge) ? turn.sourcePreviousAge : 0,
          previousGaitPhase: 0,
          previousVx: 0,
          previousTravelSign: turn.sourceTravelSign < 0 ? -1 : 1,
          previousMoveIntent: !!turn.sourceMoveIntent,
          travelSign: turn.sourceTravelSign < 0 ? -1 : 1,
          moveIntent: !!turn.sourceMoveIntent,
          turn: null,
          landExit: null
        };
        var turnFighter = Object.assign({}, fighter, {
          vx: Number.isFinite(turn.sourceVx) ? turn.sourceVx : 0
        });
        var turnSource = sampleGroundedMotion(
          turnFighter, facing, turnLocomotion, 1, false
        ).pose;
        pose = lerpPose(turnSource, pose, smooth(clamp(turnAge / turnDuration, 0, 1)));
        stabilizeTransitionLimbs(pose);
        pose.planted = turnAge === 0 ? turnSource.planted : null;
        pose.phase = turnAge === 0 ? "turn-seam" : "turn";
      }
    }
    if (!previous && locomotion.landExit) {
      var landExit = locomotion.landExit;
      var landExitDuration = Number.isFinite(landExit.duration) ? Math.max(1, landExit.duration) : 6;
      var landExitAge = Number.isFinite(landExit.age) ? landExit.age : landExitDuration;
      if (landExitAge < landExitDuration) {
        var landExitFacing = landExit.sourceTravelSign < 0 ? -1 : 1;
        var landSource = orientLowerToTravel(
          sampleFrames(LAND, Number.isFinite(landExit.sourceAge) ? landExit.sourceAge : 7, 7, false),
          facing,
          landExitFacing
        );
        var landPreviousKind = String(landExit.sourcePreviousKind || "").toLowerCase();
        if ((landPreviousKind === "fall" || landPreviousKind === "falling")
          && landExit.sourceAge < 2) {
          var landFallSource = orientLowerToTravel(
            sampleFrames(FALL, Number.isFinite(landExit.sourcePreviousAge) ? landExit.sourcePreviousAge : 0, 24, true),
            facing,
            landExitFacing
          );
          landSource = lerpPose(
            landFallSource,
            landSource,
            smooth(clamp(landExit.sourceAge / 2, 0, 1))
          );
          stabilizeTransitionLimbs(landSource);
        }
        pose = lerpRiggedPose(
          landSource,
          pose,
          smooth(clamp(landExitAge / landExitDuration, 0, 1))
        );
        pose.planted = landExitAge === 0 ? landSource.planted : null;
        pose.phase = landExitAge === 0 ? "land-exit-seam" : "land-exit";
      }
    }
    if (!previous && locomotion.runExit) {
      var runExit = locomotion.runExit;
      var runExitDuration = Number.isFinite(runExit.duration) ? Math.max(1, runExit.duration) : 6;
      var runExitAge = Number.isFinite(runExit.age) ? runExit.age : runExitDuration;
      if (runExitAge < runExitDuration) {
        var runExitTravelSign = runExit.sourceTravelSign < 0 ? -1 : 1;
        var runExitLocomotion = {
          kind: String(runExit.sourceKind || "run").toLowerCase(),
          age: Number.isFinite(runExit.sourceAge) ? runExit.sourceAge : 0,
          gaitPhase: Number.isFinite(runExit.sourceGaitPhase) ? runExit.sourceGaitPhase : 0,
          previousKind: String(runExit.sourcePreviousKind || runExit.sourceKind || "run").toLowerCase(),
          previousAge: Number.isFinite(runExit.sourcePreviousAge) ? runExit.sourcePreviousAge : 0,
          previousGaitPhase: Number.isFinite(runExit.sourcePreviousGaitPhase)
            ? runExit.sourcePreviousGaitPhase
            : 0,
          previousVx: Number.isFinite(runExit.sourcePreviousVx) ? runExit.sourcePreviousVx : 0,
          previousTravelSign: runExit.sourcePreviousTravelSign < 0
            ? -1
            : runExit.sourcePreviousTravelSign > 0
              ? 1
              : runExitTravelSign,
          previousMoveIntent: !!runExit.sourcePreviousMoveIntent,
          previousEntryKind: String(
            runExit.sourcePreviousEntryKind || runExit.sourcePreviousKind || runExit.sourceKind || "run"
          ).toLowerCase(),
          previousEntryAge: Number.isFinite(runExit.sourcePreviousEntryAge)
            ? runExit.sourcePreviousEntryAge
            : 0,
          previousTurn: null,
          previousLandExit: null,
          previousRunExit: null,
          travelSign: runExitTravelSign,
          moveIntent: runExit.sourceMoveIntent !== false,
          turn: runExit.sourceTurn && typeof runExit.sourceTurn === "object"
            ? runExit.sourceTurn
            : null,
          landExit: runExit.sourceLandExit && typeof runExit.sourceLandExit === "object"
            ? runExit.sourceLandExit
            : null,
          runExit: null
        };
        var runExitFighter = Object.assign({}, fighter, {
          vx: Number.isFinite(runExit.sourceVx) ? runExit.sourceVx : 0
        });
        var runExitSource = sampleGroundedMotion(
          runExitFighter, facing, runExitLocomotion, 1, false
        ).pose;
        pose = lerpRiggedPose(
          runExitSource,
          pose,
          smooth(clamp(runExitAge / runExitDuration, 0, 1))
        );
        pose.planted = runExitAge === 0 ? runExitSource.planted : null;
        pose.phase = runExitAge === 0 ? "run-exit-seam" : "run-exit";
      }
    }
    pose.lowerFacing = lowerFacing;
    return { pose: pose, clip: runWeight > 0 ? "run" : "idle", age: runWeight > 0 ? age : idleAge };
  }

  function samplePreviousLocomotion(fighter, facing, locomotion, renderAlpha) {
    var kind = locomotion.previousKind;
    var age = locomotion.previousAge;
    var lowerFacing = locomotion.previousTravelSign || locomotion.travelSign || facing;
    if (kind === "land" || kind === "landing") {
      var previousLand = orientLowerToTravel(sampleFrames(LAND, age, 7, false), facing, lowerFacing);
      if ((locomotion.previousEntryKind === "fall" || locomotion.previousEntryKind === "falling") && age < 2) {
        var previousFall = orientLowerToTravel(
          sampleFrames(FALL, locomotion.previousEntryAge, 24, true), facing, lowerFacing
        );
        previousLand = lerpPose(previousFall, previousLand, smooth(clamp(age / 2, 0, 1)));
        stabilizeTransitionLimbs(previousLand);
      }
      return previousLand;
    }
    if (kind === "fall" || kind === "falling") {
      return orientLowerToTravel(sampleFrames(FALL, age, 24, true), facing, lowerFacing);
    }
    if (kind === "jump" || kind === "jumping") {
      return orientLowerToTravel(sampleFrames(JUMP, age, 15, false), facing, lowerFacing);
    }
    var previousLocomotion = {
      kind: kind,
      age: age,
      gaitPhase: locomotion.previousGaitPhase,
      previousKind: locomotion.previousEntryKind || kind,
      previousAge: locomotion.previousEntryAge,
      previousGaitPhase: locomotion.previousGaitPhase,
      previousVx: locomotion.previousVx,
      previousTravelSign: locomotion.previousTravelSign,
      previousMoveIntent: locomotion.previousMoveIntent,
      previousTurn: null,
      previousLandExit: null,
      previousRunExit: null,
      travelSign: locomotion.previousTravelSign,
      moveIntent: locomotion.previousMoveIntent,
      turn: locomotion.previousTurn,
      landExit: locomotion.previousLandExit,
      runExit: locomotion.previousRunExit
    };
    var previousFighter = Object.assign({}, fighter, { vx: locomotion.previousVx });
    return sampleGroundedMotion(
      previousFighter, facing, previousLocomotion, 1, false
    ).pose;
  }

  function sampleLocomotion(fighter, facing, renderAlpha) {
    var locomotion = locomotionInfo(fighter);
    var grounded = fighter.grounded !== false;
    var velocityX = Number.isFinite(fighter.vx) ? fighter.vx : 0;
    var velocityY = Number.isFinite(fighter.vy) ? fighter.vy : 0;
    var committedAirTravel = !grounded || locomotion.kind === "land" || locomotion.kind === "landing";
    var lowerFacing = committedAirTravel
      ? (locomotion.travelSign || facing)
      : (Math.abs(velocityX) > 1 ? (velocityX < 0 ? -1 : 1) : (locomotion.travelSign || facing));
    var age;
    var clip;
    var pose;
    if (!grounded) {
      age = locomotion.age;
      if (velocityY < -25 || locomotion.kind === "jump" || locomotion.kind === "jumping") {
        clip = "jump";
        pose = orientLowerToTravel(sampleFrames(JUMP, age, 15, false), facing, lowerFacing);
        if (age < 4) {
          var launchSource = samplePreviousLocomotion(fighter, facing, locomotion, renderAlpha);
          pose = lerpPose(launchSource, pose, smooth(clamp(age / 4, 0, 1)));
          stabilizeTransitionLimbs(pose);
          pose.phase = age === 0 ? "launch-seam" : "launch";
        }
      } else {
        clip = "fall";
        pose = orientLowerToTravel(sampleFrames(FALL, age, 24, true), facing, lowerFacing);
        var fellFromGround = locomotion.previousKind === "idle" || locomotion.previousKind === "run"
          || locomotion.previousKind === "running" || locomotion.previousKind === "land"
          || locomotion.previousKind === "landing";
        if (fellFromGround && age < 4) {
          var fallSource = samplePreviousLocomotion(fighter, facing, locomotion, renderAlpha);
          pose = lerpPose(fallSource, pose, smooth(clamp(age / 4, 0, 1)));
          stabilizeTransitionLimbs(pose);
          pose.phase = age === 0 ? "fall-seam" : "fall-enter";
        }
      }
    } else if (locomotion.kind === "land" || locomotion.kind === "landing") {
      age = locomotion.age;
      clip = "land";
      pose = orientLowerToTravel(sampleFrames(LAND, age, 7, false), facing, lowerFacing);
      if ((locomotion.previousKind === "fall" || locomotion.previousKind === "falling") && age < 2) {
        var landSource = orientLowerToTravel(
          sampleFrames(FALL, locomotion.previousAge, 24, true), facing, lowerFacing
        );
        pose = lerpPose(landSource, pose, smooth(clamp(age / 2, 0, 1)));
        stabilizeTransitionLimbs(pose);
        pose.phase = age === 0 ? "land-seam" : "land-enter";
      }
    } else {
      return sampleGroundedMotion(fighter, facing, locomotion, renderAlpha, false);
    }
    pose.lowerFacing = lowerFacing;
    return { pose: pose, clip: clip, age: age };
  }

  function attachLocomotionLower(upper, lower) {
    var pose = clonePose(upper);
    var upperRootX = upper.rootX || 0;
    var upperRootY = upper.rootY || 0;
    var lowerRootX = lower.rootX || 0;
    var lowerRootY = lower.rootY || 0;
    var lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];
    for (var i = 0; i < lowerPoints.length; i += 1) {
      var key = lowerPoints[i];
      pose[key].x = lower[key].x + lowerRootX - upperRootX;
      pose[key].y = lower[key].y + lowerRootY - upperRootY;
    }
    pose.planted = lower.planted;
    pose.lowerPhase = lower.phase;
    return pose;
  }

  function composeHitReaction(motion, authoredHit, handlingUpper) {
    var target = handlingUpper
      ? attachWeaponUpper(motion.pose, handlingUpper)
      : motion.pose;
    var pose = clonePose(target);
    var neutral = HIT[0].pose;
    var torsoPoints = ["head", "neck", "shoulder", "spine"];
    var i;
    for (i = 0; i < torsoPoints.length; i += 1) {
      var torsoKey = torsoPoints[i];
      pose[torsoKey].x += authoredHit[torsoKey].x - neutral[torsoKey].x;
      pose[torsoKey].y += authoredHit[torsoKey].y - neutral[torsoKey].y;
    }

    // Both arms move with the recoiling shoulder as one live rig. This retains
    // the current locomotion or handling silhouette without additive joint
    // paths collapsing a limb; independently authored head/torso motion still
    // gives every hit duration the complete impact, brace, and recovery read.
    var armPoints = ["elbowL", "elbowR", "wristL", "wristR"];
    var shoulderDx = authoredHit.shoulder.x - neutral.shoulder.x;
    var shoulderDy = authoredHit.shoulder.y - neutral.shoulder.y;
    for (i = 0; i < armPoints.length; i += 1) {
      var armKey = armPoints[i];
      pose[armKey].x += shoulderDx;
      pose[armKey].y += shoulderDy;
    }
    pose.phase = authoredHit.phase === "recover" ? target.phase : "hit-recover";
    pose.upperPhase = "hit";
    return pose;
  }

  function normalizedHitAge(action, hitStun) {
    var actionAge = Number.isFinite(action.age) ? Math.max(0, action.age) : 0;
    var remaining = Number.isFinite(hitStun) ? Math.max(0, hitStun) : 0;
    if ((action.kind === "hit" || action.kind === "hurt") && remaining > 0) {
      var visibleDuration = Math.max(1, actionAge + remaining - 2);
      return 13 * clamp((actionAge - 1) / visibleDuration, 0, 1);
    }
    return clamp(actionAge, 0, 13);
  }

  function actionBlendWeight(age, entryBlendEnd, recoveryStart, duration) {
    var t = Number.isFinite(age) ? age : 0;
    if (entryBlendEnd > 0 && t < entryBlendEnd) {
      return smooth(clamp(t / entryBlendEnd, 0, 1));
    }
    if (t <= recoveryStart) return 1;
    return 1 - smooth(clamp((t - recoveryStart) / Math.max(1, duration - 1 - recoveryStart), 0, 1));
  }

  function composeCommittedAction(motion, actionPose, weapon, band, age, entryBlendEnd, recoveryStart, duration) {
    var ready = motion.pose;
    var readyUpper = readyWeaponPose(weapon, band, motion.age);
    if (readyUpper) ready = attachWeaponUpper(ready, readyUpper);
    // Unarmed transitions from unconstrained locomotion arms. Sword needs only
    // a short blend from its breathing ready loop; grenade already begins on
    // its exact static ready upper pose.
    var weight = actionBlendWeight(age, entryBlendEnd, recoveryStart, duration);
    var pose = lerpPose(ready, actionPose, weight);
    // Movement remains live for the whole action. Authority-sensitive melee
    // shoulders/wrists and grenade handling still become the exact authored
    // pose throughout their active windows, while planted feet never inherit
    // the attack clip's stationary lower body.
    pose = attachLocomotionLower(pose, motion.pose);
    pose.actionWeight = weight;
    pose.lowerPhase = motion.pose.phase;
    pose.phase = weight >= 1 ? actionPose.phase : weight <= 0 ? ready.phase : "action-blend";
    return pose;
  }

  function authoredFromFinalPose(finalPose, facing) {
    var pose = clonePose(finalPose);
    var face = facing < 0 ? -1 : 1;
    for (var i = 0; i < POINTS.length; i += 1) {
      var key = POINTS[i];
      pose[key].x = finalPose[key].x * face;
      pose[key].y = finalPose[key].y;
    }
    pose.rootX = 0;
    pose.rootY = 0;
    pose.weaponDir = {
      x: finalPose.weaponDir.x * face,
      y: finalPose.weaponDir.y
    };
    return pose;
  }

  function poseForFighter(fighter, renderAlpha) {
    fighter = fighter || {};
    var facing = fighter.facing < 0 ? -1 : 1;
    var weapon = normalizeWeapon(fighter.weapon);
    var action = actionInfo(fighter);
    var life = lifeInfo(fighter);
    var locomotion = locomotionInfo(fighter);
    var gunAttack = fighter.attack && fighter.attack.kind === "gun" ? fighter.attack : null;
    if (gunAttack && Number.isFinite(gunAttack.facing)) facing = gunAttack.facing < 0 ? -1 : 1;
    var liveAimValue = Number.isFinite(fighter.aimStep) ? fighter.aimStep : fighter.aimBand;
    var liveAim = resolveGunAimStep(liveAimValue, fighter.aimX, fighter.aimY,
      Number.isFinite(fighter.aimFacing) ? fighter.aimFacing : facing);
    var resolvedAim = gunAttack && Number.isFinite(gunAttack.aimStep)
      ? resolveGunAimStep(gunAttack.aimStep, 0, 0, facing)
      : liveAim;
    var aimStep = resolvedAim.step;
    var band = aimStep < 0 ? "high" : aimStep > 0 ? "low" : "level";
    var grenadeAttack = fighter.attack && fighter.attack.kind === "grenade" ? fighter.attack : null;
    var grenadeAimX = grenadeAttack && Number.isFinite(grenadeAttack.aimX) ? grenadeAttack.aimX : fighter.aimX;
    var grenadeAimY = grenadeAttack && Number.isFinite(grenadeAttack.aimY) ? grenadeAttack.aimY : fighter.aimY;
    var grenadeFacing = grenadeAttack && Number.isFinite(grenadeAttack.facing) ? grenadeAttack.facing : facing;
    var age;
    var pose;
    var clip;
    var attachReady = false;

    if (life.kind === "defeated" || life.kind === "dead" || life.kind === "down") {
      age = life.age;
      clip = "defeat";
      pose = sampleFrames(DEFEAT, age, 40, false);
      if (life.source && age < DEFEAT_ENTRY_BLEND) {
        var sourceFighter = Object.assign({}, fighter, life.source, {
          dead: false,
          defeated: false,
          life: { kind: "alive", age: 0 },
          respawnVisual: 0
        });
        var finalSourcePose = poseForFighter(sourceFighter, renderAlpha);
        var sourcePose = authoredFromFinalPose(finalSourcePose, finalSourcePose.facing);
        var defeatEntryTarget = sampleFrames(
          DEFEAT,
          DEFEAT_ENTRY_BLEND,
          CLIPS.defeat.duration,
          false
        );
        pose = lerpRiggedPose(
          sourcePose,
          defeatEntryTarget,
          smooth(clamp(age / DEFEAT_ENTRY_BLEND, 0, 1))
        );
        pose.phase = age === 0 ? "defeat-seam" : "defeat-enter";
      }
    } else if ((life.kind === "respawning" || life.kind === "respawn") && !fighter.attack && !fighter.reload) {
      // Respawn is intentionally an alpha overlay on the live pose: protection
      // is simulation-owned and the fighter can act immediately, so returning
      // to a separate materialize silhouette after an action would visibly pop.
      var respawnMotion = sampleLocomotion(fighter, facing, renderAlpha);
      age = respawnMotion.age;
      clip = respawnMotion.clip + "+respawn";
      pose = respawnMotion.pose;
      attachReady = true;
    } else if ((fighter.hitstun || fighter.hitStun || 0) > 0 || action.kind === "hit" || action.kind === "hurt") {
      // Concurrent melee retains the established shared geometry until a later
      // combat pass explicitly changes interruption rules. Otherwise every real
      // simulation hit-stun duration traverses the complete authored reaction.
      var concurrentMelee = fighter.attack && fighter.attack.kind === "melee";
      age = concurrentMelee
        ? clamp(action.age, 0, 13)
        : normalizedHitAge(action, fighter.hitstun == null ? fighter.hitStun : fighter.hitstun);
      clip = "hit";
      var hitMotion = sampleLocomotion(fighter, facing, renderAlpha);
      var authoredHit = sampleFrames(HIT, age, 13, false);
      if (concurrentMelee) {
        pose = attachLocomotionLower(authoredHit, hitMotion.pose);
      } else {
        var handlingUpper;
        if (fighter.attack && fighter.attack.kind === "gun"
          && (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle")) {
          handlingUpper = gunFirePose(weapon, aimStep, fighter.attack.age);
        } else if (fighter.attack && fighter.attack.kind === "grenade") {
          handlingUpper = grenadeThrowPose(fighter.attack.age, grenadeAimX, grenadeAimY, grenadeFacing);
        } else if (fighter.reload > 0 && (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle")) {
          var reloadLength = reloadDuration(weapon);
          handlingUpper = sampleReload(weapon, aimStep, clamp(reloadLength - fighter.reload, 0, reloadLength - 1));
        } else {
          handlingUpper = readyWeaponPose(weapon, aimStep, hitMotion.age);
        }
        pose = composeHitReaction(hitMotion, authoredHit, handlingUpper);
      }
      attachReady = false;
    } else if (action.kind === "sword" || action.kind === "swordattack" || action.kind === "sword_attack" || (action.kind === "attack" && weapon === "sword")) {
      age = action.age;
      clip = "swordAttack";
      var swordMotion = sampleLocomotion(fighter, facing, renderAlpha);
      pose = composeCommittedAction(
        swordMotion,
        sampleFrames(SWORD_ATTACK, age, 44, false),
        weapon,
        aimStep,
        age,
        CLIPS.swordAttack.entryBlendEnd,
        CLIPS.swordAttack.recoveryStart,
        CLIPS.swordAttack.duration
      );
    } else if (action.kind === "unarmed" || action.kind === "punch" || action.kind === "melee" || (action.kind === "attack" && weapon === "unarmed")) {
      age = action.age;
      clip = "unarmed";
      var unarmedMotion = sampleLocomotion(fighter, facing, renderAlpha);
      pose = composeCommittedAction(
        unarmedMotion,
        sampleFrames(UNARMED, age, 30, false),
        weapon,
        aimStep,
        age,
        CLIPS.unarmed.entryBlendEnd,
        CLIPS.unarmed.recoveryStart,
        CLIPS.unarmed.duration
      );
    } else if (action.kind === "grenade" || action.kind === "throw" || action.kind === "grenadethrow" || action.kind === "grenade_throw") {
      age = action.age;
      clip = "grenadeThrow";
      var grenadeMotion = sampleLocomotion(fighter, facing, renderAlpha);
      pose = composeCommittedAction(
        grenadeMotion,
        grenadeThrowPose(age, grenadeAimX, grenadeAimY, grenadeFacing),
        weapon,
        aimStep,
        age,
        CLIPS.grenadeThrow.entryBlendEnd,
        CLIPS.grenadeThrow.recoveryStart,
        CLIPS.grenadeThrow.duration
      );
    } else if (action.kind === "reload" || action.kind.indexOf("reload") >= 0) {
      age = action.age;
      var reloadMotion = sampleLocomotion(fighter, facing, renderAlpha);
      clip = reloadMotion.clip + "+reload";
      pose = attachWeaponUpper(reloadMotion.pose, sampleReload(weapon, aimStep, age));
    } else if (action.kind === "fire" || action.kind === "shoot" || action.kind.indexOf("fire") >= 0) {
      age = action.age;
      var fireMotion = sampleLocomotion(fighter, facing, renderAlpha);
      clip = fireMotion.clip + "+gunFire";
      pose = attachWeaponUpper(fireMotion.pose, gunFirePose(weapon, aimStep, age));
    } else {
      attachReady = true;
      var motion = sampleLocomotion(fighter, facing, renderAlpha);
      age = motion.age;
      clip = motion.clip;
      pose = motion.pose;
    }

    if (attachReady) {
      var readyUpper = readyWeaponPose(weapon, aimStep, age);
      if (readyUpper) {
        var readyLabel = weapon === "sword" ? "swordReady" : weapon === "grenade" ? "grenadeReady" : "gunAim";
        pose = attachWeaponUpper(pose, readyUpper);
        clip = clip === "idle" ? readyLabel : clip + "+" + readyLabel;
      }
    }

    if (life.kind === "respawning" || life.kind === "respawn") {
      var respawnOverlay = sampleFrames(RESPAWN, life.age, 24, false);
      pose.alpha *= respawnOverlay.alpha;
      pose.lifePhase = respawnOverlay.phase;
    }
    // The simulation owns grenade release. Once its serializable attack state
    // says the projectile exists, presentation must never draw a second copy in
    // the hand—even if hitstun or another visual layer owns the sampled clip.
    var sourceAttack = life.source && life.source.attack;
    var grenadeAmmoEmpty = weapon === "grenade"
      && fighter.ammo && fighter.ammo.grenade
      && Number.isFinite(fighter.ammo.grenade.count)
      && fighter.ammo.grenade.count <= 0;
    if ((fighter.attack && fighter.attack.kind === "grenade" && fighter.attack.released)
      || (sourceAttack && sourceAttack.kind === "grenade" && sourceAttack.released)
      || grenadeAmmoEmpty) {
      pose.grenadeVisible = false;
    }

    pose.clip = clip;
    pose.clipTime = Number.isFinite(age) ? age : 0;
    pose.weapon = weapon;
    pose.aimStep = aimStep;
    pose.aimDegrees = aimStep * 3;
    pose.aimBand = band;
    pose.renderAlpha = Number.isFinite(renderAlpha) ? renderAlpha : 0;
    return finalizePose(pose, facing, weapon);
  }

  function torsoTop(pose) {
    if (!pose || !pose.head || !pose.shoulder) return null;
    var dx = pose.shoulder.x - pose.head.x;
    var dy = pose.shoulder.y - pose.head.y;
    var length = Math.hypot(dx, dy) || 1;
    var insetRadius = Math.max(1, (pose.headRadius || 16) - 1.5);
    return {
      x: pose.head.x + dx / length * insetRadius,
      y: pose.head.y + dy / length * insetRadius
    };
  }

  function finalizePose(source, facing, weapon) {
    var pose = clonePose(source);
    var face = facing < 0 ? -1 : 1;
    pose.facing = face;
    pose.weapon = normalizeWeapon(weapon || source.weapon);
    pose.headRadius = source.headRadius == null ? 16 : source.headRadius;
    for (var i = 0; i < POINTS.length; i += 1) {
      var key = POINTS[i];
      pose[key].x *= face;
      pose[key].x += (source.rootX || 0) * face;
      pose[key].y += source.rootY || 0;
    }
    pose.weaponDir = {
      x: source.weaponDir.x * face,
      y: source.weaponDir.y
    };
    var length = Math.hypot(pose.weaponDir.x, pose.weaponDir.y) || 1;
    pose.weaponDir.x /= length;
    pose.weaponDir.y /= length;
    // Aliases are deliberate: both arms connect to the same rounded shoulder,
    // avoiding visible joint disks or gaps while allowing back/front draw order.
    pose.shoulderL = copyPoint(pose.shoulder);
    pose.shoulderR = copyPoint(pose.shoulder);
    pose.torsoTop = torsoTop(pose);
    pose.worldOffset = { x: 0, y: 0 };
    return pose;
  }

  function add(a, direction, distance) {
    return { x: a.x + direction.x * distance, y: a.y + direction.y * distance };
  }

  function perpendicular(direction) {
    return { x: -direction.y, y: direction.x };
  }

  function swordBlade(pose) {
    if (!pose) return null;
    var rear = copyPoint(pose.wristL);
    var front = copyPoint(pose.wristR);
    var dx = front.x - rear.x;
    var dy = front.y - rear.y;
    var length = Math.hypot(dx, dy);
    var direction = length > 2
      ? { x: dx / length, y: dy / length }
      : copyPoint(pose.weaponDir || { x: pose.facing || 1, y: 0 });
    // Respect the authored swing direction if interpolating wrists briefly flips
    // the handle around zero length.
    if (pose.weaponDir && direction.x * pose.weaponDir.x + direction.y * pose.weaponDir.y < 0.35) {
      direction = copyPoint(pose.weaponDir);
    }
    var normal = perpendicular(direction);
    var handleStart = add(rear, direction, -7);
    var handleEnd = add(front, direction, 4);
    var bladeStart = add(front, direction, 5);
    var bladeEnd = add(bladeStart, direction, 58);
    return {
      kind: "sword",
      rearGrip: rear,
      frontGrip: front,
      handleStart: handleStart,
      handleEnd: handleEnd,
      guardA: add(front, normal, -8),
      guardB: add(front, normal, 8),
      start: bladeStart,
      end: bladeEnd,
      bladeStart: bladeStart,
      bladeEnd: bladeEnd,
      tip: copyPoint(bladeEnd),
      direction: direction,
      width: 5,
      active: pose.clip === "swordAttack" && pose.clipTime >= CLIPS.swordAttack.activeStart && pose.clipTime <= CLIPS.swordAttack.activeEnd
    };
  }

  function swordTrailSamples(pose) {
    if (!pose || pose.weapon !== "sword" || pose.clip !== "swordAttack"
      || !Number.isFinite(pose.clipTime) || pose.clipTime < 10 || pose.clipTime >= 23) return [];
    var facing = pose.facing < 0 ? -1 : 1;
    var ages = [pose.clipTime, pose.clipTime - 1, pose.clipTime - 2, pose.clipTime - 3];
    var alphas = [0.52, 0.34, 0.19, 0.08];
    // Fade through the authored follow-through instead of dropping a fully
    // visible trail on one slow-motion tick. At 23 the recovery owns the pose
    // alone, so the helper returns no samples.
    var exitAlpha = pose.clipTime <= 18 ? 1 : (23 - pose.clipTime) / 5;
    var samples = [];
    for (var i = 0; i < ages.length; i += 1) {
      if (ages[i] < 10) continue;
      var blade = i === 0
        ? swordBlade(pose)
        : swordBlade(sampleClip("swordAttack", ages[i], { weapon: "sword", facing: facing }));
      if (!blade) continue;
      samples.push({
        age: ages[i],
        bladeStart: copyPoint(blade.bladeStart),
        bladeEnd: copyPoint(blade.bladeEnd),
        tip: copyPoint(blade.tip),
        alpha: alphas[i] * exitAlpha
      });
    }
    return samples;
  }

  function gunSockets(pose, weapon) {
    weapon = normalizeWeapon(weapon || (pose && pose.weapon));
    if (!pose || (weapon !== "pistol" && weapon !== "shotgun" && weapon !== "rifle")) return null;
    var direction = copyPoint(pose.weaponDir || { x: pose.facing || 1, y: 0 });
    var mag = Math.hypot(direction.x, direction.y) || 1;
    direction.x /= mag;
    direction.y /= mag;
    var normal = perpendicular(direction);
    if (normal.y < 0) normal = { x: -normal.x, y: -normal.y };
    var triggerGrip = copyPoint(pose.wristR);
    var supportGrip = copyPoint(pose.wristL);
    var barrelLength = weapon === "pistol" ? 31 : weapon === "shotgun" ? 59 : 55;
    var stockLength = weapon === "pistol" ? 3 : weapon === "shotgun" ? 20 : 22;
    var barrelStart = add(triggerGrip, direction, weapon === "pistol" ? 1 : 5);
    var muzzle = add(triggerGrip, direction, barrelLength);
    muzzle = add(muzzle, normal, weapon === "pistol" ? -2.5 : -1.5);
    return {
      kind: weapon,
      grip: triggerGrip,
      triggerGrip: triggerGrip,
      supportGrip: supportGrip,
      stock: add(triggerGrip, direction, -stockLength),
      barrelStart: barrelStart,
      muzzle: muzzle,
      direction: direction,
      normal: normal,
      angle: Math.atan2(direction.y, direction.x),
      recoil: pose.recoil || 0
    };
  }

  function gunMuzzle(pose, weapon) {
    var sockets = gunSockets(pose, weapon);
    if (!sockets) return null;
    return {
      x: sockets.muzzle.x,
      y: sockets.muzzle.y,
      point: copyPoint(sockets.muzzle),
      direction: copyPoint(sockets.direction),
      angle: sockets.angle
    };
  }

  function grenadeSocket(pose) {
    if (!pose || pose.grenadeVisible === false) return null;
    return {
      kind: "grenade",
      center: copyPoint(pose.wristR),
      grip: copyPoint(pose.wristR),
      radius: 6,
      released: pose.phase === "released" || pose.phase === "follow-through"
    };
  }

  function grenadeReleaseSocket(pose) {
    if (!pose || !pose.wristR) return null;
    return {
      kind: "grenade-release",
      center: copyPoint(pose.wristR),
      grip: copyPoint(pose.wristR),
      direction: copyPoint(pose.weaponDir || { x: pose.facing || 1, y: 0 })
    };
  }

  function unarmedStrike(pose) {
    if (!pose) return null;
    return {
      kind: "unarmed",
      start: copyPoint(pose.shoulder),
      end: copyPoint(pose.wristR),
      radius: 7,
      active: pose.clip === "unarmed" && pose.clipTime >= CLIPS.unarmed.activeStart && pose.clipTime <= CLIPS.unarmed.activeEnd
    };
  }

  function weaponSockets(pose, weapon) {
    weapon = normalizeWeapon(weapon || (pose && pose.weapon));
    if (weapon === "sword") return swordBlade(pose);
    if (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle") return gunSockets(pose, weapon);
    if (weapon === "grenade") return grenadeSocket(pose);
    return null;
  }

  function localToWorld(pose, fighter, localPoint) {
    var scale = fighter && Number.isFinite(fighter.drawScale) ? fighter.drawScale : 1;
    return {
      x: (fighter && Number.isFinite(fighter.x) ? fighter.x : 0) + localPoint.x * scale,
      y: (fighter && Number.isFinite(fighter.y) ? fighter.y : 0) + localPoint.y * scale
    };
  }

  global.StickAnim = Object.freeze({
    TICK_RATE: TICK_RATE,
    POINTS: POINTS.slice(),
    CLIPS: CLIPS,
    poseForFighter: poseForFighter,
    poseForState: sampleClip,
    sampleClip: sampleClip,
    finalizePose: finalizePose,
    torsoTop: torsoTop,
    reloadDuration: reloadDuration,
    weaponSockets: weaponSockets,
    swordBlade: swordBlade,
    swordTrailSamples: swordTrailSamples,
    gunSockets: gunSockets,
    gunMuzzle: gunMuzzle,
    grenadeSocket: grenadeSocket,
    grenadeReleaseSocket: grenadeReleaseSocket,
    unarmedStrike: unarmedStrike,
    localToWorld: localToWorld,
    normalizeWeapon: normalizeWeapon,
    aimBand: aimBand
  });
}(typeof window !== "undefined" ? window : globalThis));
