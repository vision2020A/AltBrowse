(function attachStickBots(global) {
  "use strict";

  const ZERO_BUTTONS = Object.freeze({
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false,
  });

  const BOT_RULES = Object.freeze({
    criticalHealth: 40,
    closingTicks: 12 * 60,
    pickupTravelLimit: 900,
    pickupCombatGuard: 165,
  });

  const WEAPON_ORDER = Object.freeze([
    "unarmed", "sword", "shotgun", "pistol", "rifle", "grenade",
  ]);

  const WEAPON_PLAN = Object.freeze({
    unarmed: Object.freeze({ min: 0, ideal: 55, max: 82, lead: 0, ranged: false, wobble: 5, bias: 0.48 }),
    longsword: Object.freeze({ min: 0, ideal: 86, max: 128, lead: 0, ranged: false, wobble: 5, bias: 0.05 }),
    sword: Object.freeze({ min: 0, ideal: 86, max: 128, lead: 0, ranged: false, wobble: 5, bias: 0.05 }),
    pistol: Object.freeze({ min: 145, ideal: 330, max: 520, lead: 7, ranged: true, wobble: 7, bias: 0.12, reloadAt: 2 }),
    shotgun: Object.freeze({ min: 80, ideal: 165, max: 325, lead: 4, ranged: true, wobble: 17, bias: 0.03, reloadAt: 1 }),
    rifle: Object.freeze({ min: 175, ideal: 385, max: 590, lead: 8, ranged: true, wobble: 11, bias: 0.08, reloadAt: 8 }),
    grenade: Object.freeze({ min: 225, ideal: 350, max: 500, lead: 18, ranged: true, wobble: 8, bias: 0, reloadAt: 0 }),
  });

  function number(value, fallback) {
    return Number.isFinite(value) ? value : fallback;
  }

  function clamp(value, low, high) {
    return Math.max(low, Math.min(high, value));
  }

  function sign(value, deadZone) {
    if (value > deadZone) return 1;
    if (value < -deadZone) return -1;
    return 0;
  }

  function fighterId(fighter, fallback) {
    return fighter.id !== undefined ? fighter.id : fallback;
  }

  function stableIdValue(id) {
    if (typeof id === "number" && Number.isFinite(id)) return id | 0;
    const text = String(id);
    let value = 2166136261;
    for (let index = 0; index < text.length; index += 1) {
      value ^= text.charCodeAt(index);
      value = Math.imul(value, 16777619);
    }
    return value | 0;
  }

  function hash32(seed) {
    let value = seed | 0;
    value ^= value >>> 16;
    value = Math.imul(value, 0x7feb352d);
    value ^= value >>> 15;
    value = Math.imul(value, 0x846ca68b);
    value ^= value >>> 16;
    return value >>> 0;
  }

  function noise01(seed, tick, id, channel) {
    const mixed =
      (seed | 0) ^
      Math.imul((tick | 0) + 1, 0x9e3779b1) ^
      Math.imul(stableIdValue(id) + 11, 0x85ebca6b) ^
      Math.imul(channel + 19, 0xc2b2ae35);
    return hash32(mixed) / 4294967296;
  }

  function readFighters(state) {
    if (Array.isArray(state.fighters)) return state.fighters;
    if (Array.isArray(state.actors)) return state.actors;
    if (state.fighters && typeof state.fighters === "object") {
      return Object.keys(state.fighters).map(function mapFighter(key) {
        return state.fighters[key];
      });
    }
    return [];
  }

  function readPickups(state) {
    if (Array.isArray(state.pickups)) return state.pickups;
    if (state.arena && Array.isArray(state.arena.pickups)) return state.arena.pickups;
    return [];
  }

  function readPlatforms(state) {
    if (state.arena && Array.isArray(state.arena.platforms)) return state.arena.platforms;
    if (Array.isArray(state.platforms)) return state.platforms;
    return [];
  }

  function readHazards(state) {
    if (state.arena && Array.isArray(state.arena.hazards)) return state.arena.hazards;
    if (Array.isArray(state.hazards)) return state.hazards;
    return [];
  }

  function isAlive(fighter) {
    if (fighter.alive === false || fighter.defeated === true) return false;
    if (fighter.dead === true || number(fighter.respawn, 0) > 0) return false;
    return number(fighter.health, 1) > 0;
  }

  function weaponName(fighter) {
    const held = fighter.weapon !== undefined ? fighter.weapon : fighter.weaponType;
    if (typeof held === "string") return held.toLowerCase();
    if (held && typeof held.name === "string") return held.name.toLowerCase();
    if (held && typeof held.type === "string") return held.type.toLowerCase();
    return "unarmed";
  }

  function weaponPlan(value) {
    const name = typeof value === "string" ? value : weaponName(value);
    return WEAPON_PLAN[name] || WEAPON_PLAN.unarmed;
  }

  function weaponData(weapon) {
    const sim = global.StickSim;
    return sim && sim.WEAPONS && sim.WEAPONS[weapon] ? sim.WEAPONS[weapon] : null;
  }

  function readAmmo(fighter, selectedWeapon) {
    const held = selectedWeapon || weaponName(fighter);
    if (!weaponPlan(held).ranged) return { clip: Infinity, reserve: Infinity, total: Infinity };
    const ammo = fighter.ammo;
    const reserve = fighter.reserveAmmo !== undefined ? fighter.reserveAmmo : fighter.reserve;
    if (held === "grenade") {
      const entry = ammo && typeof ammo === "object" ? ammo.grenade : null;
      const count = entry && typeof entry === "object"
        ? number(entry.count, 0)
        : typeof entry === "number" ? entry : 0;
      return { clip: count, reserve: 0, total: count };
    }
    if (typeof ammo === "number") {
      const stock = number(reserve, 0);
      return { clip: ammo, reserve: stock, total: ammo + stock };
    }
    if (ammo && typeof ammo === "object") {
      const entry = ammo[held] !== undefined ? ammo[held] : ammo;
      if (typeof entry === "number") {
        const stock = number(reserve, 0);
        return { clip: entry, reserve: stock, total: entry + stock };
      }
      if (entry && typeof entry === "object") {
        const clip = number(entry.clip, number(entry.mag, number(entry.loaded, 0)));
        const stock = number(entry.reserve, number(entry.stock, number(reserve, 0)));
        return {
          clip: clip,
          reserve: stock,
          total: clip + stock,
        };
      }
    }
    return { clip: 0, reserve: 0, total: 0 };
  }

  function ownsWeapon(fighter, weapon) {
    if (weapon === "unarmed") return true;
    return weaponName(fighter) === weapon || !!(fighter.inventory && fighter.inventory[weapon]);
  }

  function weaponHasSupply(fighter, weapon) {
    return ownsWeapon(fighter, weapon) && readAmmo(fighter, weapon).total > 0;
  }

  function isGrounded(fighter) {
    return fighter.grounded === true || fighter.onGround === true || fighter.platformId != null;
  }

  function centerOf(entity) {
    const width = number(entity.w, number(entity.width, 0));
    const height = number(entity.h, number(entity.height, 0));
    return {
      x: number(entity.x, 0) + width * 0.5,
      y: number(entity.y, 0) + height * 0.5,
    };
  }

  function rectOf(entity) {
    return {
      id: entity.id,
      x: number(entity.x, 0),
      y: number(entity.y, 0),
      w: number(entity.w, number(entity.width, 0)),
      h: number(entity.h, number(entity.height, 0)),
      ground: entity.ground === true,
      bridge: entity.bridge === true,
    };
  }

  function containsExpanded(rect, x, y, padding) {
    return (
      x >= rect.x - padding &&
      x <= rect.x + rect.w + padding &&
      y >= rect.y - padding &&
      y <= rect.y + rect.h + padding
    );
  }

  function platformBelow(entity, platforms) {
    const x = number(entity.x, 0);
    const y = number(entity.y, 0);
    let best = null;
    let bestGap = Infinity;
    for (let index = 0; index < platforms.length; index += 1) {
      const platform = rectOf(platforms[index]);
      const inset = Math.min(22, platform.w * 0.12);
      if (x < platform.x - inset || x > platform.x + platform.w + inset) continue;
      const gap = platform.y - y;
      if (gap >= -18 && gap < bestGap) {
        best = platform;
        bestGap = gap;
      }
    }
    return best;
  }

  function segmentIntersectsRect(x1, y1, x2, y2, rect, margin) {
    const left = rect.x - margin;
    const right = rect.x + rect.w + margin;
    const top = rect.y - margin;
    const bottom = rect.y + rect.h + margin;
    let t0 = 0;
    let t1 = 1;
    const dx = x2 - x1;
    const dy = y2 - y1;
    const p = [-dx, dx, -dy, dy];
    const q = [x1 - left, right - x1, y1 - top, bottom - y1];
    for (let index = 0; index < 4; index += 1) {
      if (p[index] === 0) {
        if (q[index] < 0) return false;
      } else {
        const ratio = q[index] / p[index];
        if (p[index] < 0) {
          if (ratio > t1) return false;
          if (ratio > t0) t0 = ratio;
        } else {
          if (ratio < t0) return false;
          if (ratio < t1) t1 = ratio;
        }
      }
    }
    return t1 > t0 && t0 < 0.94 && t1 > 0.06;
  }

  function hasClearShot(from, target, platforms) {
    const x1 = number(from.x, 0);
    const y1 = number(from.y, 0) - 42;
    const x2 = number(target.x, 0);
    const y2 = number(target.y, 0) - 42;
    for (let index = 0; index < platforms.length; index += 1) {
      const platform = rectOf(platforms[index]);
      if (platform.h <= 0 || platform.w <= 0) continue;
      if (segmentIntersectsRect(x1, y1, x2, y2, platform, 2)) return false;
    }
    return true;
  }

  function ticksRemaining(state) {
    if (state.match && Number.isFinite(state.match.ticksRemaining)) return Math.max(0, state.match.ticksRemaining);
    if (state.config && Number.isFinite(state.config.timeLimitTicks)) {
      return Math.max(0, state.config.timeLimitTicks - number(state.tick, 0));
    }
    return Infinity;
  }

  function chooseTarget(self, fighters, tick, seed, remainingTicks) {
    const selfId = fighterId(self, -1);
    const selfPoint = centerOf(self);
    const closingPressure = Number.isFinite(remainingTicks)
      ? clamp(1 - remainingTicks / (BOT_RULES.closingTicks * 2), 0, 1)
      : 0;
    let chosen = null;
    let chosenCost = Infinity;
    let chosenId = Infinity;
    for (let index = 0; index < fighters.length; index += 1) {
      const candidate = fighters[index];
      const candidateId = fighterId(candidate || {}, index);
      if (!candidate || !isAlive(candidate) || candidateId === selfId) continue;
      const point = centerOf(candidate);
      const dx = point.x - selfPoint.x;
      const dy = point.y - selfPoint.y;
      const distance = Math.hypot(dx, dy);
      const lowHealthBonus = (100 - clamp(number(candidate.health, 100), 0, 100))
        * (0.52 + closingPressure * 0.22);
      const scoreThreat = number(candidate.score, 0) * (13 + closingPressure * 22);
      const spawnShieldPenalty = Math.min(42, Math.max(0, number(candidate.invuln, 0))) * 2.5;
      const variety = noise01(seed, Math.floor(tick / 90), selfId, stableIdValue(candidateId))
        * 35 * (1 - closingPressure * 0.55);
      const cost = distance + Math.abs(dy) * 0.16 - lowHealthBonus - scoreThreat
        + spawnShieldPenalty + variety;
      const stableCandidateId = stableIdValue(candidateId);
      if (cost < chosenCost || (cost === chosenCost && stableCandidateId < chosenId)) {
        chosen = candidate;
        chosenCost = cost;
        chosenId = stableCandidateId;
      }
    }
    return chosen;
  }

  function pickupKind(pickup) {
    if (typeof pickup.type === "string") return pickup.type.toLowerCase();
    if (typeof pickup.weapon === "string") return pickup.weapon.toLowerCase();
    if (typeof pickup.kind === "string") return pickup.kind.toLowerCase();
    return "";
  }

  function pickupIsAvailable(pickup) {
    return pickup.active !== false && pickup.collected !== true
      && number(pickup.respawn, number(pickup.respawnTimer, 0)) <= 0;
  }

  function pickupIsEligible(self, pickup) {
    if (!pickupIsAvailable(pickup)) return false;
    const sim = global.StickSim;
    if (sim && typeof sim.canCollectPickup === "function") return sim.canCollectPickup(self, pickup);
    return pickup.kind !== "health" || number(self.health, 100) < number(self.maxHealth, 100);
  }

  function choosePickup(self, pickups, targetDistance, remainingTicks) {
    const currentWeapon = weaponName(self);
    const hasUsefulWeapon = WEAPON_ORDER.some(function hasUseful(candidate) {
      return candidate !== "unarmed" && weaponHasSupply(self, candidate);
    });
    const hasUsefulRanged = WEAPON_ORDER.some(function hasUsefulRanged(candidate) {
      return weaponPlan(candidate).ranged && weaponHasSupply(self, candidate);
    });
    const shouldSeekWeapon = !hasUsefulWeapon
      || (!hasUsefulRanged && targetDistance > 260);
    function needsAmmo(candidate) {
      if (!weaponPlan(candidate).ranged || !ownsWeapon(self, candidate)) return false;
      const supply = readAmmo(self, candidate);
      const lowSupplyLimit = candidate === "grenade"
        ? 1
        : number(weaponData(candidate) && weaponData(candidate).mag, 0);
      return supply.total <= lowSupplyLimit;
    }
    const currentSupply = readAmmo(self, currentWeapon);
    const currentCanReload = currentSupply.clip <= 0 && currentSupply.reserve > 0;
    const hasAlternateRanged = WEAPON_ORDER.some(function hasAlternate(candidate) {
      return candidate !== currentWeapon && weaponPlan(candidate).ranged
        && weaponHasSupply(self, candidate);
    });
    const currentNeedsAmmo = !currentCanReload && !hasAlternateRanged
      && needsAmmo(currentWeapon);
    const dormantRecovery = !hasUsefulRanged && WEAPON_ORDER.some(function recoverDormant(candidate) {
      return candidate !== currentWeapon && needsAmmo(candidate);
    });
    const shouldSeekAmmo = currentNeedsAmmo || dormantRecovery;
    const maxHealth = number(self.maxHealth, 100);
    const health = clamp(number(self.health, maxHealth), 0, maxHealth);
    const simRules = global.StickSim && global.StickSim.RULES;
    const healAmount = number(simRules && simRules.healthPickupAmount, 30);
    const shouldSeekHealth = health <= maxHealth - healAmount;
    const criticalHealth = health <= Math.min(BOT_RULES.criticalHealth, maxHealth - healAmount);
    const defenseless = !hasUsefulWeapon;
    if ((!shouldSeekWeapon && !shouldSeekAmmo && !shouldSeekHealth)
      || (targetDistance < BOT_RULES.pickupCombatGuard && !criticalHealth && !defenseless)) return null;

    const selfPoint = { x: number(self.x, 0), y: number(self.y, 0) - 35 };
    let chosen = null;
    let chosenCost = Infinity;
    let chosenId = Infinity;
    for (let index = 0; index < pickups.length; index += 1) {
      const pickup = pickups[index];
      if (!pickup || !pickupIsEligible(self, pickup)) continue;
      const kind = pickupKind(pickup);
      const isAmmo = kind.indexOf("ammo") !== -1;
      const isWeapon = WEAPON_PLAN[kind] !== undefined;
      const isHealth = pickup.kind === "health" || kind === "health";
      const usefulHealth = isHealth && shouldSeekHealth;
      const usefulWeapon = isWeapon && shouldSeekWeapon
        && (!ownsWeapon(self, kind) || readAmmo(self, kind).total <= 0);
      const usefulAmmo = isAmmo && shouldSeekAmmo;
      if (!usefulHealth && !usefulWeapon && !usefulAmmo) continue;
      const point = { x: number(pickup.x, 0), y: number(pickup.y, 0) };
      const dx = point.x - selfPoint.x;
      const dy = point.y - selfPoint.y;
      const distance = Math.hypot(dx, dy);
      const closingOptionalDetour = remainingTicks <= BOT_RULES.closingTicks
        && distance > 96 && !criticalHealth && !defenseless;
      if (closingOptionalDetour) continue;
      const priority = usefulHealth
        ? (criticalHealth ? 520 : 220)
        : usefulWeapon ? 120 : 80;
      const cost = distance + Math.abs(dy) * 0.34 - priority;
      const stablePickupId = stableIdValue(fighterId(pickup, index));
      const travelLimit = criticalHealth ? BOT_RULES.pickupTravelLimit + 300 : BOT_RULES.pickupTravelLimit;
      if (distance <= travelLimit
        && (cost < chosenCost || (cost === chosenCost && stablePickupId < chosenId))) {
        chosen = pickup;
        chosenCost = cost;
        chosenId = stablePickupId;
      }
    }
    return chosen;
  }

  function engagementCost(plan, distance) {
    if (distance < plan.min) {
      return 1 + (plan.min - distance) / Math.max(60, plan.min) + plan.bias;
    }
    if (distance > plan.max) {
      return 1 + (distance - plan.max) / Math.max(80, plan.max - plan.ideal) + plan.bias;
    }
    const range = Math.max(1, plan.ideal - plan.min, plan.max - plan.ideal);
    return Math.abs(distance - plan.ideal) / range + plan.bias;
  }

  function chooseCombatWeapon(self, distance) {
    const current = weaponName(self);
    const currentPlan = weaponPlan(current);
    if (weaponHasSupply(self, current)
      && distance >= currentPlan.min && distance <= currentPlan.max) return current;

    let chosen = "unarmed";
    let chosenCost = Infinity;
    for (let index = 0; index < WEAPON_ORDER.length; index += 1) {
      const candidate = WEAPON_ORDER[index];
      if (!weaponHasSupply(self, candidate)) continue;
      const cost = engagementCost(weaponPlan(candidate), distance)
        - (candidate === current ? 0.18 : 0);
      if (cost < chosenCost) {
        chosen = candidate;
        chosenCost = cost;
      }
    }
    return chosen;
  }

  function routeTopObjective(state, selfPoint, currentPlatform, objectivePlatform, platforms) {
    const sim = global.StickSim;
    const mapId = state && state.config && state.config.mapId;
    const map = sim && sim.MAP_CATALOG && typeof mapId === "string"
      && Object.prototype.hasOwnProperty.call(sim.MAP_CATALOG, mapId)
      ? sim.MAP_CATALOG[mapId] : null;
    const routeDefinition = map && map.botRoutes && map.botRoutes.topObjective;
    if (!routeDefinition || !currentPlatform || !objectivePlatform
      || currentPlatform.id !== routeDefinition.fromPlatformId
      || objectivePlatform.id !== routeDefinition.toPlatformId) return null;
    const routes = [];
    for (let index = 0; index < platforms.length; index += 1) {
      const platform = rectOf(platforms[index]);
      if (routeDefinition.viaPlatformIds.indexOf(platform.id) >= 0) routes.push(platform);
    }
    routes.sort(function sortRoutes(left, right) {
      const leftDistance = Math.abs(left.x + left.w * 0.5 - selfPoint.x);
      const rightDistance = Math.abs(right.x + right.w * 0.5 - selfPoint.x);
      return leftDistance - rightDistance || number(left.id, 0) - number(right.id, 0);
    });
    if (!routes.length) return null;
    return {
      point: { x: routes[0].x + routes[0].w * 0.5, y: routes[0].y },
      platform: routes[0],
    };
  }

  function hazardResponse(self, intendedMove, hazards) {
    if (!hazards.length) return null;
    const x = number(self.x, 0);
    const y = number(self.y, 0);
    const vx = number(self.vx, 0);
    const projectedX = x + intendedMove * 38 + vx * 0.08;
    for (let index = 0; index < hazards.length; index += 1) {
      const hazard = rectOf(hazards[index]);
      if (!containsExpanded(hazard, projectedX, y, 34) && !containsExpanded(hazard, x, y, 18)) continue;
      const middle = hazard.x + hazard.w * 0.5;
      return {
        moveX: x < middle ? -1 : 1,
        jump: true,
      };
    }
    return null;
  }

  function normalizeVector(x, y) {
    const length = Math.hypot(x, y);
    if (length < 0.0001) return { x: 1, y: 0 };
    return { x: x / length, y: y / length };
  }

  function neutralInput(id, facing) {
    return {
      id: id,
      moveX: 0,
      moveY: 0,
      aimX: facing < 0 ? -1 : 1,
      aimY: 0,
      buttons: {
        jump: false,
        attack: false,
        pickup: false,
        reload: false,
        drop: false,
        rematch: false,
      },
      weaponSlot: null,
    };
  }

  function normalizeHumanInput(input, id) {
    const source = input && Array.isArray(input.actors) ? input.actors[0] : input;
    if (!source) return neutralInput(id);
    const buttons = source.buttons || ZERO_BUTTONS;
    const aim = normalizeVector(number(source.aimX, 1), number(source.aimY, 0));
    return {
      id: id,
      moveX: clamp(number(source.moveX, 0), -1, 1),
      moveY: clamp(number(source.moveY, 0), -1, 1),
      aimX: aim.x,
      aimY: aim.y,
      buttons: {
        jump: buttons.jump === true,
        attack: buttons.attack === true,
        pickup: buttons.pickup === true,
        reload: buttons.reload === true,
        drop: buttons.drop === true,
        rematch: buttons.rematch === true,
      },
      weaponSlot: Number.isInteger(source.weaponSlot) ? source.weaponSlot : null,
    };
  }

  function makeBotInput(state, self, fighters, ordinal) {
    const id = fighterId(self, ordinal + 1);
    const facing = number(self.facing, number(self.aimFacing, 1));
    if (!isAlive(self)) return neutralInput(id, facing);
    if (state.match && state.match.phase && state.match.phase !== "playing") {
      return neutralInput(id, facing);
    }

    const tick = number(state.tick, number(state.frame, 0)) | 0;
    const seed = number(state.seed, number(state.randomSeed, 1)) | 0;
    const platforms = readPlatforms(state);
    const hazards = readHazards(state);
    const selfPoint = centerOf(self);
    const remainingTicks = ticksRemaining(state);
    const target = chooseTarget(self, fighters, tick, seed, remainingTicks);
    const targetPoint = target ? centerOf(target) : null;
    const dx = targetPoint ? targetPoint.x - selfPoint.x : 0;
    const dy = targetPoint ? targetPoint.y - selfPoint.y : 0;
    const distance = targetPoint ? Math.hypot(dx, dy) : Infinity;
    const pickup = choosePickup(self, readPickups(state), distance, remainingTicks);

    const currentWeapon = weaponName(self);
    const desiredWeapon = target && !pickup
      ? chooseCombatWeapon(self, distance)
      : currentWeapon;
    const plan = weaponPlan(desiredWeapon);
    const switching = desiredWeapon !== currentWeapon;
    const desiredData = weaponData(desiredWeapon) || {};
    const ammo = readAmmo(self, desiredWeapon);

    let objective = pickup ? centerOf(pickup) : targetPoint || selfPoint;
    const currentPlatform = platformBelow(self, platforms);
    let objectivePlatform = platformBelow(pickup || target || objective, platforms);
    const route = routeTopObjective(state, selfPoint, currentPlatform, objectivePlatform, platforms);
    if (route) {
      objective = route.point;
      objectivePlatform = route.platform;
    }
    const objectiveDx = objective.x - selfPoint.x;
    const objectiveDy = objective.y - selfPoint.y;

    let moveX = sign(objectiveDx, 18);
    let jump = false;
    let drop = false;
    const weaponSlot = switching && Number.isInteger(desiredData.slot) ? desiredData.slot : null;

    if (!pickup && target && !route) {
      if (distance < plan.min) {
        moveX = dx < 0 ? 1 : -1;
      } else if (distance >= plan.ideal * 0.78 && distance <= plan.ideal * 1.16) {
        if (remainingTicks <= BOT_RULES.closingTicks) {
          moveX = distance > plan.ideal * 0.9 ? sign(dx, 10) : 0;
        } else {
          const strafe = noise01(seed, Math.floor(tick / 48), id, 31) < 0.5 ? -1 : 1;
          moveX = tick % 48 < 20 ? strafe : 0;
        }
      } else if (distance > plan.max) {
        moveX = sign(dx, 14);
      }
    }

    const verticalGap = objective.y - selfPoint.y;
    if (isGrounded(self)) {
      if (verticalGap < -58) jump = true;
      if (currentPlatform && objectivePlatform && objectivePlatform.y + 26 < currentPlatform.y) jump = true;
      if (currentPlatform && objectivePlatform && objectivePlatform.y > currentPlatform.y + 76) drop = true;
      if (!pickup && target && !route && plan.ranged && desiredWeapon !== "grenade"
        && !hasClearShot(selfPoint, targetPoint, platforms) && Math.abs(dx) < 390) {
        jump = noise01(seed, Math.floor(tick / 24), id, 43) > 0.34;
        moveX = sign(dx, 8) || moveX;
      }
    }

    const hazard = hazardResponse(self, moveX, hazards);
    if (hazard) {
      moveX = hazard.moveX;
      jump = jump || hazard.jump;
      drop = false;
    }

    if (currentPlatform && isGrounded(self) && moveX !== 0) {
      const nextX = selfPoint.x + moveX * 45;
      const nearEdge = nextX < currentPlatform.x + 18 || nextX > currentPlatform.x + currentPlatform.w - 18;
      if (nearEdge && objective.y < selfPoint.y - 18) jump = true;
    }

    const skill = 0.58 + noise01(seed, id, id, 51) * 0.25;
    const idPhase = Math.abs(stableIdValue(id) % 17);
    const wobblePhase = tick * (0.041 + idPhase * 0.00037) + stableIdValue(id) * 0.71;
    const wobbleScale = plan.wobble * (plan.ranged ? 1.18 - skill : 1);
    const leadTicks = plan.lead * skill;
    const aimDx = target
      ? dx + number(target.vx, 0) * leadTicks / 60
      : facing < 0 ? -1 : 1;
    const aimDy = target
      ? dy + number(target.vy, 0) * leadTicks / 60 - 34
        + Math.sin(wobblePhase) * wobbleScale
      : 0;
    const aim = normalizeVector(aimDx, aimDy);

    const hitstun = number(self.hitstun, number(self.hitStun, 0));
    const reloadTimer = number(self.reload, number(self.reloadTimer, 0));
    const cooldown = number(self.cooldown, number(self.attackTimer, 0));
    const hardLocked = hitstun > 0 || reloadTimer > 0;
    const edgeBusy = !!self.attack || cooldown > 0
      || number(self.recoveryTimer, 0) > 0 || hardLocked;
    const empty = plan.ranged && ammo.clip <= 0;
    const firearm = desiredWeapon === "pistol" || desiredWeapon === "shotgun"
      || desiredWeapon === "rifle";
    const lineClear = !target || !firearm || hasClearShot(selfPoint, targetPoint, platforms);
    const grenadeRadius = number(weaponData("grenade") && weaponData("grenade").radius, 190);
    const grenadeSafe = desiredWeapon !== "grenade"
      || distance >= Math.max(plan.min, grenadeRadius + 35);
    const inAttackRange = target && distance <= plan.max
      && (distance >= plan.min || !plan.ranged);
    const localDegrees = Math.abs(Math.atan2(aimDy, Math.abs(aimDx)) * 180 / Math.PI);
    const aimReachable = !firearm || localDegrees <= number(
      global.StickSim && global.StickSim.GUN_AIM && global.StickSim.GUN_AIM.maxDegrees,
      51
    );
    const cadence = remainingTicks <= BOT_RULES.closingTicks
      ? 0.98
      : desiredWeapon === "rifle" ? 0.91 : 0.75 + skill * 0.2;
    const triggerWindow = noise01(seed, tick, id, 67) < cadence;
    const combatIntent = !!target && !pickup && !switching && !empty
      && inAttackRange && lineClear && grenadeSafe && aimReachable;
    const attack = desiredWeapon === "rifle"
      ? combatIntent && !hardLocked
      : combatIntent && !edgeBusy && triggerWindow;

    const magazineSize = number(desiredData.mag, 0);
    const lowMagazine = firearm && ammo.clip <= number(plan.reloadAt, 0);
    const tacticalWindow = !target || !lineClear || distance > plan.ideal * 1.15;
    const canReload = !switching && firearm && ammo.reserve > 0
      && ammo.clip < magazineSize && !self.attack && cooldown <= 0 && !hardLocked
      && (empty || (lowMagazine && tacticalWindow));

    const pickupPoint = pickup
      ? { x: number(pickup.x, 0), y: number(pickup.y, 0) }
      : null;
    const pickupDistance = pickupPoint
      ? Math.hypot(pickupPoint.x - number(self.x, 0), pickupPoint.y - (number(self.y, 0) - 35))
      : Infinity;
    const pickupRadius = number(
      global.StickSim && global.StickSim.RULES && global.StickSim.RULES.pickupRadius,
      62
    );
    const pickupButton = !!pickup && pickupDistance < Math.min(58, pickupRadius)
      && !(self.prevButtons && self.prevButtons.pickup);

    return {
      id: id,
      moveX: clamp(moveX, -1, 1),
      moveY: 0,
      aimX: aim.x,
      aimY: aim.y,
      buttons: {
        jump: jump && !drop && hitstun <= 0,
        attack: attack && !canReload,
        pickup: pickupButton,
        reload: canReload && !pickupButton,
        drop: drop,
        rematch: false,
      },
      weaponSlot: weaponSlot,
    };
  }

  function compareIds(left, right) {
    const a = stableIdValue(left.id);
    const b = stableIdValue(right.id);
    return a === b ? String(left.id).localeCompare(String(right.id)) : a - b;
  }

  function inferHumanId(state, fighters) {
    if (state.humanId !== undefined) return state.humanId;
    if (state.playerId !== undefined) return state.playerId;
    for (let index = 0; index < fighters.length; index += 1) {
      const fighter = fighters[index];
      if (fighter && (fighter.isHuman === true || fighter.human === true
        || fighter.control === "human" || fighter.isBot === false)) {
        return fighterId(fighter, index);
      }
    }
    return fighters.length ? fighterId(fighters[0], 0) : 0;
  }

  function makeInputs(state, humanInput) {
    const safeState = state || {};
    const fighters = readFighters(safeState);
    const humanId = inferHumanId(safeState, fighters);
    const actors = [normalizeHumanInput(humanInput, humanId)];

    for (let index = 0; index < fighters.length; index += 1) {
      const fighter = fighters[index];
      if (!fighter) continue;
      const id = fighterId(fighter, index);
      const explicitlyHuman = fighter.isHuman === true || fighter.human === true;
      if (id === humanId || explicitlyHuman) continue;
      actors.push(makeBotInput(safeState, fighter, fighters, index));
    }

    actors.sort(compareIds);
    return {
      tick: number(safeState.tick, number(safeState.frame, 0)) | 0,
      actors: actors,
    };
  }

  const api = Object.freeze({
    makeInputs: makeInputs,
    makeBotInput: function exposedMakeBotInput(state, fighter) {
      const fighters = readFighters(state || {});
      return makeBotInput(state || {}, fighter, fighters, fighters.indexOf(fighter));
    },
  });

  Object.defineProperty(global, "StickBots", {
    configurable: true,
    enumerable: true,
    writable: false,
    value: api,
  });
})(typeof window !== "undefined" ? window : globalThis);
