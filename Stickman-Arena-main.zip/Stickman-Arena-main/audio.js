(function (root) {
  "use strict";

  var PREFERENCE_KEY = "stickman-arena.audio";
  var PREFERENCE_VERSION = 1;
  var DEFAULT_VOLUME = 70;
  var MAX_MASTER_GAIN = 0.44;
  var MAX_ACTIVE_VOICES = 64;
  var COMPRESSOR = Object.freeze({
    threshold: -3,
    knee: 0,
    ratio: 20,
    attack: 0.003,
    release: 0.12
  });

  function clamp(value, low, high) {
    return Math.max(low, Math.min(high, value));
  }

  function finitePercent(value, fallback) {
    var number = Number(value);
    return Number.isFinite(number) ? Math.round(clamp(number, 0, 100)) : fallback;
  }

  function legacyPercent(value, fallback) {
    var number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    if (number >= 0 && number <= 1) number *= 100;
    return Math.round(clamp(number, 0, 100));
  }

  function preferenceRecord(soundEnabled, masterVolume) {
    return {
      version: PREFERENCE_VERSION,
      soundEnabled: !!soundEnabled,
      masterVolume: finitePercent(masterVolume, DEFAULT_VOLUME)
    };
  }

  function normalizePreferences(value, initialVolume) {
    var fallbackVolume = finitePercent(initialVolume, DEFAULT_VOLUME);
    var fallback = preferenceRecord(fallbackVolume > 0, fallbackVolume);
    var candidate = value;

    if (typeof candidate === "string") {
      try {
        candidate = JSON.parse(candidate);
      } catch (error) {
        var scalar = Number(candidate);
        candidate = Number.isFinite(scalar) ? scalar : null;
      }
    }

    if (typeof candidate === "number") {
      var scalarVolume = legacyPercent(candidate, fallbackVolume);
      return preferenceRecord(scalarVolume > 0, scalarVolume);
    }

    if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)) return fallback;

    if (candidate.version != null && Number(candidate.version) !== PREFERENCE_VERSION) return fallback;
    var current = Number(candidate.version) === PREFERENCE_VERSION;
    var volume = fallbackVolume;
    if (candidate.masterVolume != null) {
      volume = current
        ? finitePercent(candidate.masterVolume, fallbackVolume)
        : legacyPercent(candidate.masterVolume, fallbackVolume);
    } else if (candidate.volume != null) {
      volume = legacyPercent(candidate.volume, fallbackVolume);
    }

    var enabled = volume > 0;
    if (typeof candidate.soundEnabled === "boolean") enabled = candidate.soundEnabled;
    else if (typeof candidate.soundOn === "boolean") enabled = candidate.soundOn;
    else if (typeof candidate.muted === "boolean") enabled = !candidate.muted;
    return preferenceRecord(enabled, volume);
  }

  function loadPreferences(storage, initialVolume) {
    var stored = null;
    if (storage && typeof storage.getItem === "function") {
      try { stored = storage.getItem(PREFERENCE_KEY); } catch (error) { stored = null; }
    }
    var parsed = stored;
    if (typeof parsed === "string") {
      try { parsed = JSON.parse(parsed); } catch (error) { parsed = null; }
    }
    var preserveStored = !!(parsed && typeof parsed === "object" && !Array.isArray(parsed) &&
      parsed.version != null && Number(parsed.version) !== PREFERENCE_VERSION);
    return {
      preferences: normalizePreferences(stored, initialVolume),
      preserveStored: preserveStored
    };
  }

  function savePreferences(storage, preferences) {
    if (!storage || typeof storage.setItem !== "function") return false;
    try {
      storage.setItem(PREFERENCE_KEY, JSON.stringify(preferences));
      return true;
    } catch (error) {
      return false;
    }
  }

  function effectiveMasterGain(preferences) {
    if (!preferences || !preferences.soundEnabled) return 0;
    return finitePercent(preferences.masterVolume, 0) / 100 * MAX_MASTER_GAIN;
  }

  function setParam(param, value, time) {
    if (!param) return;
    if (typeof param.cancelScheduledValues === "function") param.cancelScheduledValues(time);
    if (typeof param.setValueAtTime === "function") param.setValueAtTime(value, time);
    else param.value = value;
  }

  function configureCompressor(compressor) {
    if (!compressor) return;
    compressor.threshold.value = COMPRESSOR.threshold;
    compressor.knee.value = COMPRESSOR.knee;
    compressor.ratio.value = COMPRESSOR.ratio;
    compressor.attack.value = COMPRESSOR.attack;
    compressor.release.value = COMPRESSOR.release;
  }

  function routeEvent(event, voices) {
    if (!event || !voices) return 0;
    var weapon = event.weapon || "";
    var calls = 0;
    function tone(frequency, duration, type, gain, slide) {
      calls += 1;
      voices.tone(frequency, duration, type, gain, slide);
    }
    function noise(duration, gain, filterType, frequency, slide) {
      calls += 1;
      voices.noise(duration, gain, filterType, frequency, slide, event.id);
    }

    if (event.type === "attack") {
      if (weapon === "sword") {
        tone(590, 0.055, "triangle", 0.07, 360);
        tone(145, 0.05, "sine", 0.05, 92);
      } else if (weapon === "unarmed") {
        noise(0.038, 0.035, "bandpass", 310, 190);
      } else if (weapon === "grenade") {
        tone(810, 0.045, "square", 0.045, 520);
        tone(240, 0.04, "triangle", 0.035, 175);
      }
    } else if (event.type === "meleeSwing") {
      if (weapon === "sword") {
        noise(0.15, 0.18, "bandpass", 1120, 330);
        tone(310, 0.11, "sine", 0.1, 105);
      } else if (weapon === "unarmed") {
        noise(0.07, 0.085, "bandpass", 520, 180);
        tone(125, 0.055, "triangle", 0.07, 72);
      }
    } else if (event.type === "fire") {
      if (weapon === "shotgun") {
        noise(0.17, 0.31, "lowpass", 920, 180);
        tone(118, 0.18, "sawtooth", 0.38, 45);
      } else if (weapon === "rifle") {
        noise(0.045, 0.11, "bandpass", 1450, 520);
        tone(235, 0.052, "square", 0.15, 92);
      } else if (weapon === "pistol") {
        noise(0.065, 0.14, "highpass", 1350, 620);
        tone(345, 0.085, "square", 0.21, 118);
      }
    } else if (event.type === "hit") {
      if (weapon === "sword") {
        tone(940, 0.085, "triangle", 0.16, 430);
        tone(112, 0.095, "sine", 0.16, 55);
      } else if (weapon === "unarmed") {
        noise(0.055, 0.085, "lowpass", 520, 150);
        tone(102, 0.08, "triangle", 0.16, 50);
      } else if (weapon === "shotgun") {
        noise(0.075, 0.12, "lowpass", 720, 170);
        tone(82, 0.09, "triangle", 0.18, 42);
      } else if (weapon === "rifle") {
        noise(0.035, 0.05, "bandpass", 920, 410);
        tone(116, 0.05, "triangle", 0.08, 62);
      } else if (weapon === "grenade") {
        noise(0.07, 0.08, "lowpass", 480, 110);
        tone(76, 0.08, "sine", 0.12, 40);
      } else if (weapon === "pistol") {
        noise(0.045, 0.06, "bandpass", 780, 310);
        tone(98, 0.065, "triangle", 0.11, 52);
      } else {
        tone(90, 0.055, "triangle", 0.07, 48);
      }
    } else if (event.type === "spark") {
      tone(840, 0.035, "triangle", weapon === "rifle" ? 0.025 : 0.04, 510);
    } else if (event.type === "grenadeThrow") {
      noise(0.13, 0.1, "bandpass", 720, 210);
      tone(190, 0.08, "triangle", 0.055, 105);
    } else if (event.type === "grenadeBounce") {
      tone(360, 0.045, "triangle", 0.045, 190);
    } else if (event.type === "explosion") {
      noise(0.3, 0.38, "lowpass", 820, 95);
      tone(92, 0.34, "sawtooth", 0.46, 36);
    } else if (event.type === "dryFire") {
      tone(720, 0.032, "square", 0.035, 430);
      tone(210, 0.04, "triangle", 0.025, 145);
    } else if (event.type === "reloadStart") {
      if (weapon === "shotgun") tone(255, 0.055, "square", 0.04, 150);
      else if (weapon === "rifle") tone(390, 0.045, "square", 0.035, 225);
      else if (weapon === "pistol") tone(520, 0.04, "square", 0.035, 310);
    } else if (event.type === "reload") {
      if (weapon === "shotgun") {
        tone(170, 0.06, "triangle", 0.045, 270);
        noise(0.035, 0.025, "bandpass", 680, 420);
      } else if (weapon === "rifle") {
        tone(285, 0.045, "square", 0.04, 470);
      } else if (weapon === "pistol") {
        tone(430, 0.04, "square", 0.035, 650);
      }
    } else if (event.type === "pickup") {
      if (event.kind === "health") {
        tone(510, 0.1, "sine", 0.11, 760);
        tone(760, 0.12, "triangle", 0.075, 980);
      } else {
        tone(420, 0.09, "sine", 0.12, 720);
      }
    } else if (event.type === "pickupRespawn" && event.kind === "health") {
      tone(360, 0.07, "sine", 0.05, 540);
      tone(540, 0.08, "triangle", 0.04, 720);
    } else if (event.type === "jump") {
      tone(150, 0.06, "triangle", 0.07, 230);
    } else if (event.type === "defeat") {
      tone(120, 0.22, "sawtooth", 0.25, 48);
    }
    return calls;
  }

  function create(options) {
    options = options || {};
    var storage = options.storage || null;
    var AudioCtor = options.AudioContext || root.AudioContext || root.webkitAudioContext || null;
    var loaded = loadPreferences(storage, options.initialVolume);
    var preferences = loaded.preferences;
    var audioContext = null;
    var masterGain = null;
    var compressor = null;
    var noiseBuffer = null;
    var activeVoices = 0;
    var activeVoiceRecords = [];
    if (!loaded.preserveStored) savePreferences(storage, preferences);

    function snapshot() {
      return {
        version: preferences.version,
        soundEnabled: preferences.soundEnabled,
        masterVolume: preferences.masterVolume,
        effectiveGain: effectiveMasterGain(preferences),
        hasContext: !!audioContext,
        contextState: audioContext ? audioContext.state : "unavailable",
        activeVoices: activeVoices
      };
    }

    function applyMasterGain() {
      if (!masterGain) return true;
      try {
        setParam(masterGain.gain, effectiveMasterGain(preferences), audioContext.currentTime);
        return true;
      } catch (error) {
        return false;
      }
    }

    function persist() {
      savePreferences(storage, preferences);
    }

    function setSoundEnabled(enabled) {
      preferences = preferenceRecord(!!enabled, preferences.masterVolume);
      var applied = applyMasterGain();
      if (!preferences.soundEnabled) stopActiveVoices();
      if (!applied) releaseAudioGraph(true);
      persist();
      return snapshot();
    }

    function setMasterVolume(percent) {
      preferences = preferenceRecord(preferences.soundEnabled,
        finitePercent(percent, preferences.masterVolume));
      var applied = applyMasterGain();
      if (preferences.masterVolume <= 0) stopActiveVoices();
      if (!applied) releaseAudioGraph(true);
      persist();
      return snapshot();
    }

    function safelyResumeContext() {
      if (!audioContext || audioContext.state === "running" || audioContext.state === "closed" ||
        typeof audioContext.resume !== "function") return;
      try {
        var resumed = audioContext.resume();
        if (resumed && typeof resumed.catch === "function") resumed.catch(function () { /* A later gesture may retry. */ });
      } catch (error) { /* A later gesture may retry. */ }
    }

    function resume() {
      if (!preferences.soundEnabled || preferences.masterVolume <= 0 || !AudioCtor) {
        if (!applyMasterGain()) releaseAudioGraph(true);
        return false;
      }
      if (audioContext && audioContext.state === "closed") releaseAudioGraph(false);
      if (!audioContext) {
        try {
          audioContext = new AudioCtor();
          masterGain = audioContext.createGain();
          compressor = audioContext.createDynamicsCompressor();
          configureCompressor(compressor);
          masterGain.connect(compressor);
          compressor.connect(audioContext.destination);
          if (!applyMasterGain()) throw new Error("master gain unavailable");
        } catch (error) {
          releaseAudioGraph(true);
          return false;
        }
      }
      safelyResumeContext();
      return true;
    }

    function disconnectAudioNodes(nodes) {
      for (var i = 0; i < nodes.length; i += 1) {
        try { nodes[i].disconnect(); } catch (error) { /* A completed voice may already be disconnected. */ }
      }
    }

    function releaseAudioGraph(closeContext) {
      var context = audioContext;
      var graphNodes = [masterGain, compressor];
      stopActiveVoices();
      disconnectAudioNodes(graphNodes);
      audioContext = null;
      masterGain = null;
      compressor = null;
      noiseBuffer = null;
      if (!closeContext || !context || typeof context.close !== "function") return;
      try {
        var closed = context.close();
        if (closed && typeof closed.catch === "function") {
          closed.catch(function () { /* The failed graph is already isolated. */ });
        }
      } catch (error) { /* The failed graph is already isolated. */ }
    }

    function finishAudioVoice(source, nodes) {
      var record = { source: source, nodes: nodes, finished: false, cleanup: null };
      activeVoiceRecords.push(record);
      activeVoices += 1;
      record.cleanup = function () {
        if (record.finished) return;
        record.finished = true;
        activeVoices = Math.max(0, activeVoices - 1);
        var index = activeVoiceRecords.indexOf(record);
        if (index >= 0) activeVoiceRecords.splice(index, 1);
        disconnectAudioNodes(record.nodes);
      };
      try {
        source.onended = record.cleanup;
      } catch (error) {
        record.cleanup();
        throw error;
      }
      return record.cleanup;
    }

    function stopActiveVoices() {
      var records = activeVoiceRecords.slice();
      for (var i = 0; i < records.length; i += 1) {
        try { records[i].source.stop(); } catch (error) { /* A completed source may already be stopped. */ }
        records[i].cleanup();
      }
    }

    function canPlayVoice() {
      return !!(audioContext && masterGain && preferences.soundEnabled &&
        preferences.masterVolume > 0 && audioContext.state === "running" &&
        activeVoices < MAX_ACTIVE_VOICES);
    }

    function playTone(frequency, duration, type, gain, slide) {
      if (!canPlayVoice()) return false;
      var osc = null;
      var amp = null;
      var cleanup = null;
      var started = false;
      try {
        var now = audioContext.currentTime;
        var finish = now + Math.max(0.015, duration);
        var peak = Math.max(0.0001, Number.isFinite(gain) ? gain : 0.15);
        var attack = Math.min(0.006, Math.max(0.002, duration * 0.16));
        osc = audioContext.createOscillator();
        amp = audioContext.createGain();
        osc.type = type || "square";
        osc.frequency.setValueAtTime(Math.max(35, frequency), now);
        if (slide) osc.frequency.exponentialRampToValueAtTime(Math.max(35, slide), finish);
        amp.gain.setValueAtTime(0.0001, now);
        amp.gain.exponentialRampToValueAtTime(peak, now + attack);
        amp.gain.exponentialRampToValueAtTime(0.0001, finish);
        osc.connect(amp);
        amp.connect(masterGain);
        cleanup = finishAudioVoice(osc, [osc, amp]);
        osc.start(now);
        started = true;
        osc.stop(finish + 0.01);
      } catch (error) {
        if (started && osc) {
          try { osc.stop(); } catch (stopError) { /* Disconnection still makes the failed voice silent. */ }
        }
        if (cleanup) cleanup();
        else disconnectAudioNodes([osc, amp]);
        return false;
      }
      return true;
    }

    function deterministicNoiseBuffer() {
      if (!audioContext) return null;
      if (noiseBuffer && noiseBuffer.sampleRate === audioContext.sampleRate) return noiseBuffer;
      var sampleCount = Math.max(1, Math.floor(audioContext.sampleRate * 0.5));
      var buffer = audioContext.createBuffer(1, sampleCount, audioContext.sampleRate);
      var samples = buffer.getChannelData(0);
      var seed = 0x7f4a7c15;
      for (var i = 0; i < samples.length; i += 1) {
        seed ^= seed << 13;
        seed ^= seed >>> 17;
        seed ^= seed << 5;
        samples[i] = ((seed >>> 0) / 2147483648) - 1;
      }
      noiseBuffer = buffer;
      return noiseBuffer;
    }

    function playNoise(duration, gain, filterType, frequency, slide, eventId) {
      if (!canPlayVoice()) return false;
      var source = null;
      var filter = null;
      var amp = null;
      var cleanup = null;
      var started = false;
      try {
        var buffer = deterministicNoiseBuffer();
        if (!buffer) return false;
        var now = audioContext.currentTime;
        var voiceDuration = Math.min(buffer.duration, Math.max(0.015, duration));
        var finish = now + voiceDuration;
        var peak = Math.max(0.0001, Number.isFinite(gain) ? gain : 0.1);
        var attack = Math.min(0.006, Math.max(0.002, voiceDuration * 0.12));
        source = audioContext.createBufferSource();
        filter = audioContext.createBiquadFilter();
        amp = audioContext.createGain();
        var availableOffset = Math.max(0, buffer.duration - voiceDuration);
        var normalizedId = Math.abs(Number(eventId) || 0) % 97;
        var offset = availableOffset * normalizedId / 97;
        source.buffer = buffer;
        filter.type = filterType || "bandpass";
        filter.frequency.setValueAtTime(Math.max(35, frequency || 620), now);
        if (slide) filter.frequency.exponentialRampToValueAtTime(Math.max(35, slide), finish);
        filter.Q.setValueAtTime(filter.type === "bandpass" ? 0.8 : 0.45, now);
        amp.gain.setValueAtTime(0.0001, now);
        amp.gain.exponentialRampToValueAtTime(peak, now + attack);
        amp.gain.exponentialRampToValueAtTime(0.0001, finish);
        source.connect(filter);
        filter.connect(amp);
        amp.connect(masterGain);
        cleanup = finishAudioVoice(source, [source, filter, amp]);
        source.start(now, offset, voiceDuration);
        started = true;
        source.stop(finish + 0.01);
      } catch (error) {
        if (started && source) {
          try { source.stop(); } catch (stopError) { /* Disconnection still makes the failed voice silent. */ }
        }
        if (cleanup) cleanup();
        else disconnectAudioNodes([source, filter, amp]);
        return false;
      }
      return true;
    }

    function route(event) {
      if (!canPlayVoice()) return 0;
      try {
        return routeEvent(event, { tone: playTone, noise: playNoise });
      } catch (error) {
        return 0;
      }
    }

    return Object.freeze({
      snapshot: snapshot,
      setSoundEnabled: setSoundEnabled,
      setMasterVolume: setMasterVolume,
      resume: resume,
      route: route
    });
  }

  root.StickAudio = Object.freeze({
    PREFERENCE_KEY: PREFERENCE_KEY,
    PREFERENCE_VERSION: PREFERENCE_VERSION,
    DEFAULT_VOLUME: DEFAULT_VOLUME,
    MAX_MASTER_GAIN: MAX_MASTER_GAIN,
    MAX_ACTIVE_VOICES: MAX_ACTIVE_VOICES,
    COMPRESSOR: COMPRESSOR,
    normalizePreferences: normalizePreferences,
    routeEvent: routeEvent,
    create: create
  });
}(typeof window !== "undefined" ? window : globalThis));
