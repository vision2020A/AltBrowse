# Stickman Arena

**[Play on GitHub Pages](https://xenovoyage.github.io/Stickman-Arena/)** · Version [v2026.9.2](VERSION.txt) · [MIT License](LICENSE)

[![Baseline checks](https://github.com/XenoVoyage/Stickman-Arena/actions/workflows/ci.yml/badge.svg)](https://github.com/XenoVoyage/Stickman-Arena/actions/workflows/ci.yml)

A fast, deterministic 2D stickman free-for-all with authored animation, responsive movement, six distinct weapons, and bots that use the same inputs as the player.

## At a glance

| Detail | Summary |
| --- | --- |
| Match | One player versus one to three bots; full 3:00 regulation; highest score wins; a tied lead draws |
| Weapons | Unarmed, sword, pistol, shotgun, rifle, and grenade |
| Built with | HTML, CSS, JavaScript, Canvas 2D, and Web Audio |
| Runtime | Dependency-free offline client; fixed deterministic 60 Hz simulation |
| Play with | Keyboard and mouse, or landscape touch controls |
| Multiplayer | Pages Create/Join client plus selected Frankfurt Colyseus Cloud server; two humans plus two server bots; deployment pending |

## Play locally

Download or clone the repository, then double-click `index.html`. No server, installation, account, or internet connection is required.

Double-click `index.html` for completely offline play. On GitHub Pages, **Play** also remains the ordinary bot match. **Create Match** and **Join Match** are separate online actions: after one is chosen, the static Pages client lazily loads the SDK from and connects to the owner-selected Frankfurt Colyseus Cloud endpoint at `https://de-fra-1131bd95.colyseus.cloud`. Production `main` still serves the menu as `v2026.8.24` until this `v2026.9.2` Cloud proxy-header fix is separately promoted; online health remains unclaimed until Wright deploys the reviewed `develop` head and probes `/livez`, `/readyz`, and Pages Create/Join.

Local multiplayer engineering remains available. Use the Node.js 24.20.0 LTS version declared in `.nvmrc` (Node.js 22 remains the tested minimum), run `npm ci --prefix server --ignore-scripts`, `npm --prefix server test`, and `npm --prefix server start`, then open two `http://127.0.0.1:2567/?online=1` tabs. Pair through Quick Match or Create/Join Code. Both local and Cloud paths keep the fixed two-human/two-bot Free-for-All on Original Arena; the server owns actors, seed, results, and rematch generations. See the [server operations guide](docs/SERVER_OPERATIONS.md) for exact Cloud root/environment settings, probes, bounded shutdown/recovery, and rollback.

## Controls

Choose one desktop control preset in Settings:

| Action | Hybrid | Keyboard Only |
| --- | --- | --- |
| Move | `A` / `D` | `A` / `D` |
| Jump | `W` or `Space` | `W` or `Space` |
| Drop through a raised platform | `S` | `S` |
| Aim | Direct pointer aim (3° firearm steps) | Up / Down arrows aim high / low |
| Attack, fire, or throw | Left click or `F` | `F` |
| Pick up an eligible item | Right click or `E` | `E` |
| Reload | `R` | `R` |
| Use unarmed fallback | `Q` | `Q` |

`Esc` pauses or closes the active menu/dialog; `T` enables quarter-speed review. The Keyboard Only preset ignores pointer gameplay actions, so `W` is never both jump and aim.

Settings provides Sound On/Off and a 0–100% Master Volume. Muting keeps the chosen level for later, and the preference persists locally when browser storage is available. The game contains synthesized effects only—no music or downloaded audio.

On touch screens, play in landscape. The left floating stick moves horizontally; a deliberate upward pull emits one Jump command, while a deliberate downward pull emits one Drop command. Return the stick below its vertical reset threshold before either command can repeat.

The right Action control follows the equipped weapon. With Smart Action On and no eligible pickup nearby, a neutral press with pistol, shotgun, rifle, or grenade snapshots aim toward the closest living opponent. This is a one-time starting direction, not tracking: deliberate drag permanently takes manual control for that gesture. Pistol, shotgun, and grenade commit on release after aiming. Rifle begins automatic fire after a short readable aim-and-hold delay and stops on release. Sword and unarmed attacks remain unchanged and commit on press in the current facing or selected direction. Reload and Unarmed remain dedicated buttons.

With Smart Action On, a non-drag Action tap near the visible pickup prompt picks up that item before aim assist is considered. With Smart Action Off, Pickup remains an explicit button and ranged aim is entirely manual. No mode passively picks up items. The assist never tracks or predicts an opponent, checks line of sight, or sends a target identity or hit claim into gameplay. Cancellation, lost pointer capture, pause, rotation, and visibility loss discard pending touch actions instead of firing them. Touch Controls can be Auto, On, or Off.

One spring-green health pickup occupies the lower center bridge. When damaged, use the same explicit Pickup action to restore up to 30 health, capped at 100. A full-health fighter cannot waste it; after collection its anchored progress ring counts through the deterministic 10-second respawn before the item returns.

## Weapon identities

All timing is resolved by the deterministic 60 Hz simulation.

| Weapon | Player-facing identity |
| --- | --- |
| Unarmed | Quick unlimited fallback: 10 damage every 30 steps |
| Sword | Committed close-range hit: 24 damage, strong 440 knockback, 44-step recovery |
| Pistol | Accurate zero-spread single shot: 18 damage, 44-step cadence, 8-round magazine |
| Shotgun | Eight-pellet close-range burst capped at 32 damage per trigger; damage and knockback fall between 170 and 520 world units; 4-shell magazine |
| Rifle | Sustained automatic fire: 3 damage every 5 steps while held, 36-round magazine |
| Grenade | Readable area attack: up to 48 damage inside a 190-unit radius after a 120-step fuse; three carried throws |

Pistol and shotgun require a new press for every shot; the rifle continues only while attack is held. The shotgun's grooved pump and the rifle's swept magazine keep the two long guns readable without changing their animation-owned muzzle or collision geometry.

## Current status

The long checkpoint paragraph below preserves historical merge evidence; its earlier “current/next” wording is superseded by the hosting note that follows it.

The current build preserves the manually approved arena and fighter direction, starts every fighter unarmed on distinct seeded low, middle, or high positions, keeps the camera stable during impacts, grounds defeated fighters on their supporting surface, and uses a minimal menu with dedicated Controls and Settings panels. Fighters use connected neck-free silhouettes, planted travel-oriented legs, coherent weapon grips, and authored action transitions while retaining exact visible melee and muzzle authority. The sword reads as one decisive high-to-low slash with an exact cosmetic blade trail, the pistol is deliberate and accurate, the shotgun rewards close range, the rifle sustains automatic fire, and the grenade applies bounded area pressure. Bounded impact effects, six locally synthesized weapon identities, and distinct shotgun/rifle silhouettes reinforce those roles without moving gameplay authority into presentation. Hybrid pointer, manual touch drag, and bots resolve firearm aim through 35 deterministic 3° elevations per facing; Smart Action's bounded neutral-touch snapshot feeds that same aim path and manual drag always wins. Each shot keeps its chosen direction through recoil, while Keyboard Only intentionally remains simple high/level/low. Grenade hand motion and projectile release share the same continuous committed direction. Bots navigate every authored pickup route, use weapon supply and cadence coherently, seek health through explicit Pickup input, and close regulation without direct gameplay mutation. The complete three-minute regulation, compact top HUD, shared command path, subtle canonical version label, explicit health recovery, and bounded Sound/Volume controls keep gameplay readable without changing deterministic authority. Passes 1–11, Pass 12A, Pass 12B1, Pass 12B2, the dependency-only Pass 12A2, Pass 12B3A, Pass 12A3, Pass 12B3B1, Pass 12B3B2, Pass 12B4A, and dependency-only Pass 12A4 are merged and deployed to their approved extents. Pass 12B3A adds the local anonymous Quick/Create/Join Code room UX, exact protocol-3 admission, fixed approved configuration, bounded process-local codes/rooms/attempts, redacted lookup failures, and an explicit waiting-room leave path without changing gameplay, capacity, the public Pages route, or hosting. Pass 12B3B1 adds the bounded reconnect, memory-only token, lookup-redaction, and framework-reservation-aware abandoned-room contract described above without changing protocol, gameplay, dependencies, public version, or hosting. Its repository evidence is recorded through closeout pull request #58. Pass 12B3B2 adds bounded control traffic, initial waiting, held input, snapshots, client histories, compact replay storage, outbound backlog, unsupported-wire handling, and fixed static errors while keeping protocol `3`, simulation schema `6`, input contract `2`, gameplay, dependencies, public version, loopback binding, and hosting unchanged. Pull request #59 merged exact reviewed tree `0ff371be86b54aacb0f3decc7d9f65b6ddb60d34`; closeout pull request #60 records its repository evidence. Pass 12B4A adds the bounded operations baseline without changing gameplay, wire versions, dependencies, public version, or Pages behavior; pull request #61 merged exact reviewed tree `6db593c04875fe8ab7465c5c3f7bd8ba68010679`, and closeout pull request #62 records its repository evidence. Pass 12A4 exact Schema `5.0.22` maintenance is merged through pull request #63 without gameplay or player-facing changes, and evidence-closeout pull request #64 records its CI, Pages, and cleanup facts. Pass 12B4B candidate `055e9fe3ec029ad5ee8f85544f198b027ec6942c` was squash-merged through pull request #65 as `9e2d20013f06a2bcef713483cbddc88201d96605` with exact reviewed tree `94fc30540b454f6ee573d9422332f22f0efadd6a`; evidence-closeout pull request #66 records required CI, approved offline Pages, cleanup, and bounded browser facts. It leaves gameplay, protocol `3`, simulation schema `6`, input contract `2`, capacity, public `v2026.8.24`, Pages behavior, and hosting unchanged. Pass 12A5 exact-pins Schema `5.0.23` through issue #74 without a player-facing change. No hosted Node service, public-network, load/soak, production-security, or physical-device result is claimed. Pass 12C1 is the current product issue and Pass 12C2 remains the next load/soak/deployment-readiness work; activation state is recorded in the current status; all authored maps, teams/modes, and weapons remain gated. Play the deployed offline checkpoint on [GitHub Pages](https://xenovoyage.github.io/Stickman-Arena/) or double-click `index.html`. See [current status](docs/STATUS.md).

Current hosting note: after the rolling-socket hotfix, nginx `502` is gone, but Cloud nginx `X-Forwarded-*` / `Forwarded` / `X-Real-IP` still produced application HTTP `400` `{"error":"bad request"}` and Pages Create Match showed `CONNECTION FAILED — TRY AGAIN`. This `v2026.9.2` landing admits those proxy headers in public/Cloud mode without trusting them. Public health is not claimed until Wright promotes to `main` and probes. Production Pages still shows `v2026.8.24` until that separate owner yes.

## Project documentation

- [Game design](docs/GAME_DESIGN.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Current status](docs/STATUS.md)
- [Development roadmap](docs/ROADMAP.md)
- [Multiplayer architecture](docs/MULTIPLAYER_ARCHITECTURE.md)
- [Server operations](docs/SERVER_OPERATIONS.md)
- [Asset provenance](docs/ASSETS.md)
- [Contributing](CONTRIBUTING.md)
- [Security](SECURITY.md)
- [Changelog](CHANGELOG.md)

Designed and implemented with **OpenAI Codex**, with gameplay direction and review from **XenoVoyage**. Released under the [MIT License](LICENSE).
