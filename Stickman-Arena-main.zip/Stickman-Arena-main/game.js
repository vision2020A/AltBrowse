(function () {
  "use strict";

  var Sim = window.StickSim;
  var Anim = window.StickAnim;
  var Bots = window.StickBots;
  var Touch = window.StickTouch;
  var Input = window.StickInput;
  var Audio = window.StickAudio;
  var Online = window.StickOnline;
  var gameShell = document.getElementById("gameShell");
  var canvas = document.getElementById("game");
  var ctx = canvas.getContext("2d", { alpha: false });
  if (!Sim || !Anim || !Bots || !Touch || !Input || !Audio || !Online || !gameShell || !ctx) return;

  var ui = {};
  [
    "hud", "matchTimer", "speedBadge", "onlineStatusBadge", "pauseButton", "scoreboard",
    "prompt", "promptKey", "promptText", "stateLabel", "healthFill",
    "healthText", "weaponText", "weaponGlyph", "ammoText", "playerScore",
    "killFeed", "startOverlay", "startButton", "onlineMatchPanel", "onlineAdmissionPanel",
    "createMatchButton", "joinMatchForm", "roomCodeInput", "joinMatchButton",
    "onlineWaitingPanel", "roomCodeDisplay", "roomCodeOutput", "cancelOnlineButton",
    "networkStatus", "pauseOverlay", "pauseTitle", "resumeButton",
    "restartButton", "mainMenuButton", "mainControlsButton", "mainSettingsButton",
    "pauseControlsButton", "pauseSettingsButton", "soundControl", "volumeControl", "soundValue",
    "controlPresetControl", "smartActionControl", "botCountControl", "botCountLabel", "botCountHint",
    "controlsDialog", "controlsCloseButton",
    "settingsDialog", "settingsCloseButton",
    "resultOverlay", "resultEyebrow", "resultTitle", "resultCopy",
    "finalScores", "rematchButton", "resultMainMenuButton", "touchControl",
    "touchControls", "touchLeftStick", "touchRightStick", "touchRightLabel",
    "touchPickupButton", "touchReloadButton", "touchUnarmedButton", "rotateDevice"
  ].forEach(function (id) { ui[id] = document.getElementById(id); });

  var state = null;
  var onlineAvailable = Online.requested();
  var onlineMode = false;
  var localActorId = 0;
  var onlineEpoch = null;
  var onlineGeneration = null;
  var onlineTransition = false;
  var onlineTerminalPresented = false;
  var onlineMenuPending = false;
  var roomCodeValidationDismissed = false;
  var started = false;
  var paused = false;
  var slowMotion = false;
  var accumulator = 0;
  var lastTime = 0;
  var particles = [];
  var flashes = [];
  var MAX_PARTICLES = 360;
  var MAX_FLASHES = 72;
  var resultShown = false;
  var keys = Object.create(null);
  var pointerController = Input.createPointerController();
  var touchController = Touch.createController();
  var touchMode = "auto";
  var touchSeen = false;
  var touchPortraitBlocked = false;
  var coarsePointerQuery = window.matchMedia ? window.matchMedia("(pointer: coarse)") : { matches: false };
  var portraitQuery = window.matchMedia ? window.matchMedia("(orientation: portrait)") : { matches: false };
  var controlPreset = Input.CONTROL_PRESETS.hybrid;
  var smartAction = true;
  var botCount = 3;
  var offlineBotCountValue = null;
  var dialogOpener = null;
  var dialogRestoresKeyboardFocus = false;
  var inputModality = "pointer";
  var matchSeedCounter = 0;
  var weaponGlyphs = {
    unarmed: "◇", sword: "╱", pistol: "⌐", shotgun: "═", rifle: "≡", grenade: "●"
  };
  var impactStyles = Object.freeze({
    unarmed: Object.freeze({ color: "#ffe2bd", core: "#fff5e6", count: 7, power: 112, radius: 15, size: 3, kind: "dot" }),
    sword: Object.freeze({ color: "#9ff6ff", core: "#ecfdff", count: 14, power: 210, radius: 24, size: 2, kind: "spark" }),
    pistol: Object.freeze({ color: "#dffaff", core: "#ffffff", count: 6, power: 145, radius: 13, size: 2, kind: "spark" }),
    shotgun: Object.freeze({ color: "#ffd294", core: "#fff2d2", count: 13, power: 205, radius: 21, size: 3, kind: "spark" }),
    rifle: Object.freeze({ color: "#b8f4ff", core: "#effdff", count: 4, power: 125, radius: 10, size: 2, kind: "spark" }),
    grenade: Object.freeze({ color: "#ffb353", core: "#fff2c6", count: 8, power: 170, radius: 18, size: 3, kind: "dot" })
  });
  var audioStorage = null;
  try { audioStorage = window.localStorage; } catch (error) { /* Preferences remain in memory. */ }
  var audio = Audio.create({
    storage: audioStorage,
    AudioContext: window.AudioContext || window.webkitAudioContext,
    initialVolume: ui.volumeControl.value
  });

  function clamp(value, low, high) { return Math.max(low, Math.min(high, value)); }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function length(x, y) { return Math.sqrt(x * x + y * y); }

  function show(element, visible) {
    if (!element) return;
    element.hidden = !visible;
  }

  function updateStatusSurface(element, text, state, visible) {
    if (!element) return;
    if (element.hidden === visible) element.hidden = !visible;
    if (!visible) return;
    if (element.textContent !== text) element.textContent = text;
    if (element.getAttribute("data-state") !== state) element.setAttribute("data-state", state);
  }

  function onlineRequestPending(connection) {
    return connection.state === "connecting" || connection.state === "reconnecting"
      || (connection.connected && !connection.started);
  }

  function updateOnlineMenu(connection) {
    if (!onlineAvailable || !ui.onlineMatchPanel) return;
    var pending = onlineRequestPending(connection);
    var pendingBecameActive = pending && !onlineMenuPending;
    ui.startButton.hidden = pending;
    ui.onlineAdmissionPanel.hidden = pending;
    ui.onlineWaitingPanel.hidden = !pending;
    ui.createMatchButton.disabled = pending;
    ui.joinMatchButton.disabled = pending;
    ui.roomCodeInput.disabled = pending;
    ui.mainControlsButton.disabled = pending;
    ui.mainSettingsButton.disabled = pending;
    var busyValue = connection.state === "connecting" || connection.state === "reconnecting"
      ? "true" : "false";
    if (ui.onlineMatchPanel.getAttribute("aria-busy") !== busyValue) {
      ui.onlineMatchPanel.setAttribute("aria-busy", busyValue);
    }
    var codeVisible = pending && typeof connection.roomCode === "string";
    ui.roomCodeDisplay.hidden = !codeVisible;
    if (codeVisible && ui.roomCodeOutput.textContent !== connection.roomCode) {
      ui.roomCodeOutput.textContent = connection.roomCode;
    } else if (!codeVisible && ui.roomCodeOutput.textContent !== "") {
      ui.roomCodeOutput.textContent = "";
    }
    var invalidCode = connection.state === "error"
      && connection.matchmakingOperation === "join-code"
      && connection.detail === "ENTER A VALID 7-CHARACTER MATCH CODE"
      && !roomCodeValidationDismissed;
    var invalidValue = invalidCode ? "true" : "false";
    if (ui.roomCodeInput.getAttribute("aria-invalid") !== invalidValue) {
      ui.roomCodeInput.setAttribute("aria-invalid", invalidValue);
    }
    if (pendingBecameActive && !started && !ui.startOverlay.hidden) {
      ui.cancelOnlineButton.focus();
    }
    onlineMenuPending = pending;
  }

  function clearTouchInput() {
    touchController.clear();
    if (ui.touchControls) {
      var pressed = ui.touchControls.querySelectorAll(".is-pressed");
      for (var i = 0; i < pressed.length; i += 1) pressed[i].classList.remove("is-pressed");
    }
    updateTouchVisuals();
  }

  function clearPlayerInput() {
    keys = Object.create(null);
    pointerController.clear();
    clearTouchInput();
  }

  function anyDialogOpen() {
    return !!(ui.controlsDialog.open || ui.settingsDialog.open);
  }

  function openMenuDialog(dialog, opener) {
    if (!dialog || anyDialogOpen()) return;
    clearPlayerInput();
    dialogOpener = opener;
    dialogRestoresKeyboardFocus = inputModality === "keyboard";
    dialog.showModal();
    if (dialogRestoresKeyboardFocus) {
      var firstControl = dialog.querySelector("button, select, input");
      if (firstControl) firstControl.focus();
    }
    updateTouchVisibility();
  }

  function closeMenuDialog(dialog) {
    if (dialog && dialog.open) dialog.close();
  }

  function restoreDialogFocus() {
    if (dialogRestoresKeyboardFocus && dialogOpener && !dialogOpener.hidden) dialogOpener.focus();
    else if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    dialogOpener = null;
    dialogRestoresKeyboardFocus = false;
    updateTouchVisibility();
  }

  function touchPreferenceEnabled() {
    if (touchMode === "off") return false;
    return touchMode === "on" || touchSeen || coarsePointerQuery.matches;
  }

  function touchPointerAccepted(event) {
    return (event.pointerType === "touch" && touchMode !== "off") ||
      (touchMode === "on" && event.pointerType === "mouse" && controlPreset === Input.CONTROL_PRESETS.hybrid);
  }

  function updateTouchStick(element, visual, defaultX, defaultY) {
    if (!element || !ui.touchControls) return;
    var rect = gameShell.getBoundingClientRect();
    var originX = visual && visual.active ? visual.originX : rect.width * defaultX;
    var originY = visual && visual.active ? visual.originY : rect.height * defaultY;
    var offsetX = visual && visual.active ? visual.knobX - visual.originX : 0;
    var offsetY = visual && visual.active ? visual.knobY - visual.originY : 0;
    if (!visual || !visual.active) {
      var radius = touchController.config.radius;
      originX = clamp(originX, radius, Math.max(radius, rect.width - radius));
      originY = clamp(originY, radius, Math.max(radius, rect.height - radius));
    }
    element.style.left = originX + "px";
    element.style.top = originY + "px";
    element.classList.toggle("is-active", !!(visual && visual.active));
    var knob = element.querySelector(".touch-stick-knob");
    if (knob) {
      knob.style.left = "calc(50% + " + offsetX + "px)";
      knob.style.top = "calc(50% + " + offsetY + "px)";
    }
  }

  function updateTouchVisuals() {
    var action = touchController.actionVisual();
    updateTouchStick(ui.touchLeftStick, touchController.visual("left"), 0.18, 0.69);
    updateTouchStick(ui.touchRightStick, action, 0.81, 0.61);
    if (!ui.touchControls) return;
    ui.touchRightStick.classList.toggle("is-aimed", !!(action && action.aimed));
    ui.touchRightStick.setAttribute("data-phase", action && action.phase ? action.phase : "idle");
    ui.touchRightStick.style.setProperty("--hold-progress", Math.round((action ? action.holdProgress : 0) * 360) + "deg");
    if (ui.touchRightLabel) {
      var actionLabel = "ACTION";
      if (action && action.pickupCandidate) actionLabel = "TAP · PICKUP";
      else if (action && action.weapon === "rifle" && action.phase === "firing") actionLabel = "AUTO FIRE";
      else if (action && action.assisted && action.weapon === "rifle") actionLabel = "ASSIST · HOLD";
      else if (action && action.assisted) actionLabel = "ASSIST · RELEASE";
      else if (action && action.phase === "committed" && (action.weapon === "sword" || action.weapon === "unarmed")) actionLabel = "ATTACK";
      else if (action && action.weapon === "rifle" && action.aimed) actionLabel = "HOLD · AUTO";
      else if (action && action.aimed) actionLabel = "AIM · RELEASE";
      ui.touchRightLabel.textContent = actionLabel;
    }
    var buttons = ui.touchControls.querySelectorAll("[data-touch-button]");
    for (var i = 0; i < buttons.length; i += 1) {
      var visual = touchController.buttonVisual(buttons[i].getAttribute("data-touch-button"));
      buttons[i].classList.toggle("is-pressed", !!(visual && visual.held));
    }
  }

  function updateTouchVisibility() {
    var eligible = touchPreferenceEnabled();
    var playing = !!(started && state && state.match.phase === "playing" && !paused && !anyDialogOpen());
    var nextPortraitBlocked = !!(playing && eligible && portraitQuery.matches);
    if (nextPortraitBlocked !== touchPortraitBlocked) {
      clearPlayerInput();
      if (onlineMode && nextPortraitBlocked && started) Online.sendNeutral();
    }
    touchPortraitBlocked = nextPortraitBlocked;
    var visible = playing && eligible && !touchPortraitBlocked;
    if (!visible && ui.touchControls && !ui.touchControls.hidden) clearTouchInput();
    var shellWasBlocked = gameShell.classList.contains("is-portrait-blocked");
    gameShell.classList.toggle("is-portrait-blocked", touchPortraitBlocked);
    var shellChanged = shellWasBlocked !== touchPortraitBlocked;
    ui.hud.inert = touchPortraitBlocked;
    if (touchPortraitBlocked) {
      ui.hud.setAttribute("aria-hidden", "true");
      if (ui.hud.contains(document.activeElement) && document.activeElement.blur) document.activeElement.blur();
    } else {
      ui.hud.removeAttribute("aria-hidden");
    }
    show(ui.touchControls, visible);
    show(ui.rotateDevice, touchPortraitBlocked);
    updateTouchVisuals();
    if (shellChanged) window.requestAnimationFrame(resize);
  }

  function capturePointer(element, pointerId) {
    if (!element || !element.setPointerCapture) return;
    try { element.setPointerCapture(pointerId); } catch (error) { /* Global terminal handlers remain the fallback. */ }
  }

  function shellPoint(event) {
    var rect = gameShell.getBoundingClientRect();
    return {
      x: clamp(event.clientX - rect.left, 0, rect.width),
      y: clamp(event.clientY - rect.top, 0, rect.height),
      width: rect.width,
      height: rect.height
    };
  }

  function nextMatchSeed() {
    matchSeedCounter += 1;
    var fallback = (0x51a7f00d ^ Math.imul(matchSeedCounter, 0x9e3779b9)) >>> 0;
    if (window.crypto && window.crypto.getRandomValues) {
      var values = new Uint32Array(1);
      window.crypto.getRandomValues(values);
      return values[0] || fallback;
    }
    return fallback;
  }

  function makeState(seed) {
    state = Sim.createState({
      seed: seed == null ? 0x51a7f00d : seed,
      botCount: botCount,
      modeId: Sim.DEFAULT_MODE_ID,
      mapId: Sim.DEFAULT_MAP_ID
    });
    particles.length = 0;
    flashes.length = 0;
    accumulator = 0;
    resultShown = false;
    if (ui.killFeed) ui.killFeed.textContent = "";
    show(ui.resultOverlay, false);
    updateHud();
  }

  function localFighter() {
    return fighterById(localActorId) || (state && state.fighters ? state.fighters[0] : null);
  }

  function ensureAudio() {
    audio.resume();
  }

  function pushBounded(list, value, limit) {
    if (list.length >= limit) list.splice(0, list.length - limit + 1);
    list.push(value);
  }

  function pushParticle(particle) {
    pushBounded(particles, particle, MAX_PARTICLES);
  }

  function pushFlash(flash) {
    pushBounded(flashes, flash, MAX_FLASHES);
  }

  function burst(x, y, color, count, power, options) {
    options = options || {};
    count = clamp(count | 0, 0, 32);
    for (var i = 0; i < count; i += 1) {
      var angle = (i / count) * Math.PI * 2 + ((i * 1.618) % 1) * 0.7;
      var speed = power * (0.45 + ((i * 37) % 11) / 15);
      var life = (options.life || 0.22) + (i % 5) * (options.lifeStep == null ? 0.025 : options.lifeStep);
      pushParticle({
        x: x, y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: life,
        maxLife: life,
        color: color,
        size: (options.size || 3) + (i % (options.sizeVariance == null ? 3 : Math.max(1, options.sizeVariance))),
        gravity: options.gravity == null ? 460 : options.gravity,
        drag: options.drag == null ? 0.04 : options.drag,
        kind: options.kind || "dot"
      });
    }
  }

  function bodyImpact(event) {
    var style = impactStyles[event.weapon] || impactStyles.pistol;
    var tangentX = Number.isFinite(event.tangentX) ? event.tangentX : 1;
    var tangentY = Number.isFinite(event.tangentY) ? event.tangentY : 0;
    var tangentLength = Math.hypot(tangentX, tangentY) || 1;
    tangentX /= tangentLength;
    tangentY /= tangentLength;
    pushFlash({
      kind: "impact", x: event.x, y: event.y,
      life: 0.12, maxLife: 0.12, radius: style.radius,
      color: style.color, core: style.core, weapon: event.weapon,
      tangentX: tangentX, tangentY: tangentY
    });
    burst(event.x, event.y, style.color, style.count, style.power, {
      kind: style.kind,
      size: style.size,
      sizeVariance: 2,
      gravity: style.kind === "spark" ? 260 : 420,
      drag: style.kind === "spark" ? 0.09 : 0.04,
      life: style.kind === "spark" ? 0.16 : 0.2,
      lifeStep: 0.018
    });
  }

  function fighterById(id) {
    if (!state) return null;
    for (var i = 0; i < state.fighters.length; i += 1) {
      if (state.fighters[i].id === id) return state.fighters[i];
    }
    return null;
  }

  function fighterLabel(fighter) {
    if (!fighter) return "FIGHTER";
    if (!fighter.isBot) return fighter.id === localActorId ? "YOU" : "PLAYER " + (fighter.id + 1);
    return fighter.name || "BOT " + (fighter.id + 1);
  }

  function addKillFeed(event) {
    if (!ui.killFeed) return;
    var victim = fighterById(event.fighterId);
    var attacker = fighterById(event.attackerId);
    var row = document.createElement("div");
    row.className = "kill-row";
    row.textContent = (attacker ? fighterLabel(attacker) : "ARENA") + "  ›  " + fighterLabel(victim);
    ui.killFeed.prepend(row);
    while (ui.killFeed.children.length > 4) ui.killFeed.lastElementChild.remove();
    window.setTimeout(function () { if (row.parentNode) row.remove(); }, 3200);
  }

  function processEvents(events) {
    if (!events) return;
    for (var i = 0; i < events.length; i += 1) {
      var event = events[i];
      audio.route(event);
      if (event.type === "fire") {
        pushFlash({
          kind: "muzzle", x: event.x, y: event.y,
          life: 0.075, maxLife: 0.075,
          radius: event.weapon === "shotgun" ? 28 : event.weapon === "rifle" ? 13 : 17
        });
      } else if (event.type === "hit") {
        // bulletHit reports projectile contact before the damage queue is
        // grouped. The accepted hit event is the one body-impact cue, avoiding
        // duplicate pistol/rifle effects and eight extra shotgun pellet cues.
        bodyImpact(event);
      } else if (event.type === "spark") {
        burst(event.x, event.y, "#dffaff", 5, 112, {
          kind: "spark", size: 2, sizeVariance: 2,
          gravity: 310, drag: 0.08, life: 0.14, lifeStep: 0.015
        });
      } else if (event.type === "explosion") {
        pushFlash({
          kind: "explosion", x: event.x, y: event.y,
          life: 0.28, maxLife: 0.28, radius: event.radius || 190
        });
        burst(event.x, event.y, "#ffb353", 28, 330, {
          size: 4, sizeVariance: 3, gravity: 390,
          drag: 0.055, life: 0.24, lifeStep: 0.02
        });
      } else if (event.type === "grenadeBounce") {
        burst(event.x, event.y, "#b7c8b8", 3, 54, {
          size: 2, sizeVariance: 2, gravity: 360,
          drag: 0.05, life: 0.12, lifeStep: 0.015
        });
      } else if (event.type === "land") {
        burst(event.x, event.y, "#86a6b4", 5, 65, {
          size: 3, sizeVariance: 2, gravity: 380,
          drag: 0.045, life: 0.18, lifeStep: 0.02
        });
      } else if (event.type === "pickup") {
        var pickupColor = event.kind === "health" ? "#69ff9d" : "#55eaff";
        burst(event.x, event.y, pickupColor, event.kind === "health" ? 18 : 12, event.kind === "health" ? 135 : 105, {
          size: 3, sizeVariance: 3, gravity: 230,
          drag: 0.08, life: 0.22, lifeStep: 0.022
        });
        if (event.kind === "health") {
          pushFlash({
            kind: "pickup", x: event.x, y: event.y,
            life: 0.22, maxLife: 0.22, radius: 58,
            color: "#69ff9d", core: "#effff4"
          });
        }
      } else if (event.type === "pickupRespawn" && event.kind === "health") {
        pushFlash({
          kind: "pickup", x: event.x, y: event.y,
          life: 0.32, maxLife: 0.32, radius: 48,
          color: "#69ff9d", core: "#effff4"
        });
        burst(event.x, event.y, "#69ff9d", 10, 82, {
          size: 2, sizeVariance: 3, gravity: 170,
          drag: 0.08, life: 0.2, lifeStep: 0.02
        });
      } else if (event.type === "defeat") {
        addKillFeed(event);
        if (event.fighterId === localActorId) clearPlayerInput();
      }
    }
  }

  function updatePresentation(dt) {
    for (var i = particles.length - 1; i >= 0; i -= 1) {
      var p = particles[i];
      p.life -= dt;
      if (p.life <= 0) { particles.splice(i, 1); continue; }
      p.vy += p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      var damping = Math.pow(p.drag, dt);
      p.vx *= damping;
      p.vy *= damping;
    }
    for (var j = flashes.length - 1; j >= 0; j -= 1) {
      flashes[j].life -= dt;
      if (flashes[j].life <= 0) flashes.splice(j, 1);
    }
  }

  function canvasPoint(event) {
    var rect = canvas.getBoundingClientRect();
    var px = (event.clientX - rect.left) / Math.max(1, rect.width) * state.arena.width;
    var py = (event.clientY - rect.top) / Math.max(1, rect.height) * state.arena.height;
    return { x: px, y: py };
  }

  function humanInput() {
    var player = localFighter();
    var pointer = pointerController.read();
    var pointerAimX = player.facing || 1;
    var pointerAimY = 0;
    if (pointer.inside) {
      pointerAimX = pointer.x - player.x;
      pointerAimY = pointer.y - (player.y - 90);
    }
    var touch = touchController.read(player.facing);
    return Input.mapActor({
      fighter: player,
      preset: controlPreset,
      keys: keys,
      pointer: {
        inside: pointer.inside,
        aimX: pointerAimX,
        aimY: pointerAimY,
        attack: pointer.attack,
        pickup: pointer.pickup
      },
      touch: touch
    });
  }

  function simulationStep() {
    if (onlineMode) {
      Online.sendInput(humanInput());
      var onlineState = Online.renderState();
      if (onlineState) state = onlineState;
      processEvents(Online.drainEvents());
      if (state.match.phase === "finished" && !resultShown) showResult();
      return;
    }
    var frame = Bots.makeInputs(state, humanInput());
    frame.tick = state.tick;
    Sim.fixedUpdate(state, frame, Sim.STEP);
    processEvents(state.events);
    if (state.match.phase === "finished" && !resultShown) showResult();
  }

  function resize() {
    var rect = canvas.getBoundingClientRect();
    var dpr = Math.min(2, window.devicePixelRatio || 1);
    var width = Math.max(2, Math.round(rect.width * dpr));
    var height = Math.max(2, Math.round(rect.height * dpr));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
  }

  function beginWorld() {
    resize();
    var w = canvas.width;
    var h = canvas.height;
    var scale = Math.min(w / state.arena.width, h / state.arena.height);
    var ox = (w - state.arena.width * scale) * 0.5;
    var oy = (h - state.arena.height * scale) * 0.5;
    ctx.setTransform(scale, 0, 0, scale, ox, oy);
  }

  function drawBackground() {
    var arena = state.arena;
    var sky = ctx.createLinearGradient(0, 0, 0, arena.height);
    sky.addColorStop(0, "#7894a0");
    sky.addColorStop(0.48, "#294351");
    sky.addColorStop(1, "#0a1822");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, arena.width, arena.height);

    var halo = ctx.createRadialGradient(1500, 160, 18, 1500, 160, 155);
    halo.addColorStop(0, "rgba(244,247,218,.9)");
    halo.addColorStop(0.43, "rgba(234,239,212,.32)");
    halo.addColorStop(1, "rgba(224,237,219,0)");
    ctx.fillStyle = halo;
    ctx.beginPath(); ctx.arc(1500, 160, 155, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = "#e4e8d1";
    ctx.beginPath(); ctx.arc(1500, 160, 76, 0, Math.PI * 2); ctx.fill();

    drawMountain([[0,620],[220,380],[430,610],[710,290],[980,625]], "#223a48", 0.9);
    drawMountain([[370,680],[650,485],[930,660],[1250,335],[1580,650],[1920,430],[1920,760],[0,760]], "#172d3a", 0.86);
    drawMountain([[0,760],[410,545],[760,780],[1290,470],[1710,705],[1920,585],[1920,900],[0,900]], "#102733", 0.9);

    ctx.fillStyle = "#0b1a23";
    ctx.fillRect(0, 815, arena.width, 265);
    ctx.strokeStyle = "rgba(94,138,153,.14)";
    ctx.lineWidth = 1;
    for (var x = 0; x <= arena.width; x += 96) {
      ctx.beginPath(); ctx.moveTo(x, 760); ctx.lineTo(x, 1080); ctx.stroke();
    }
    for (var y = 760; y <= 1080; y += 46) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(arena.width, y); ctx.stroke();
    }
  }

  function drawMountain(points, color, alpha) {
    ctx.save();
    ctx.globalAlpha = alpha;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(points[0][0], points[0][1]);
    for (var i = 1; i < points.length; i += 1) ctx.lineTo(points[i][0], points[i][1]);
    ctx.lineTo(1920, 900); ctx.lineTo(0, 900); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  function roundRect(x, y, w, h, radius) {
    var r = Math.min(radius, w * 0.5, h * 0.5);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  function drawArena() {
    var hazards = state.arena.hazards;
    for (var hazardIndex = 0; hazardIndex < hazards.length; hazardIndex += 1) {
      var hazard = hazards[hazardIndex];
      var pulse = 0.5 + Math.sin(state.tick * 0.11) * 0.15;
      ctx.fillStyle = "#050b10";
      ctx.fillRect(hazard.x, state.arena.groundY, hazard.w, Math.max(0, hazard.y - state.arena.groundY));
      var glow = ctx.createLinearGradient(0, hazard.y, 0, hazard.y + hazard.h);
      glow.addColorStop(0, "rgba(255,105,78," + pulse + ")");
      glow.addColorStop(1, "rgba(151,42,38,.2)");
      ctx.fillStyle = glow; ctx.fillRect(hazard.x, hazard.y, hazard.w, hazard.h);
      ctx.strokeStyle = "#ff7b64"; ctx.lineWidth = 4;
      ctx.beginPath();
      for (var hx = hazard.x; hx <= hazard.x + hazard.w; hx += 18) {
        var hy = hazard.y + 5 + Math.sin(hx * 0.043 + state.tick * 0.13) * 3;
        if (hx === hazard.x) ctx.moveTo(hx, hy); else ctx.lineTo(hx, hy);
      }
      ctx.stroke();
    }
    var platforms = state.arena.platforms;
    for (var i = 0; i < platforms.length; i += 1) {
      var p = platforms[i];
      var height = p.ground ? Math.max(26, p.h) : p.h;
      var fill = ctx.createLinearGradient(0, p.y, 0, p.y + Math.min(height, 90));
      fill.addColorStop(0, "#172732"); fill.addColorStop(1, "#08131b");
      ctx.fillStyle = fill;
      roundRect(p.x, p.y, p.w, height, p.ground ? 5 : 10); ctx.fill();
      ctx.strokeStyle = p.bridge ? "#d8715d" : "#9cb6c0";
      ctx.lineWidth = p.bridge ? 5 : 2.2;
      ctx.beginPath(); ctx.moveTo(p.x + 8, p.y + 1); ctx.lineTo(p.x + p.w - 8, p.y + 1); ctx.stroke();
      if (!p.ground) {
        ctx.strokeStyle = "rgba(92,133,148,.16)"; ctx.lineWidth = 1;
        for (var d = p.x + 24; d < p.x + p.w - 10; d += 42) {
          ctx.beginPath(); ctx.moveTo(d, p.y + 8); ctx.lineTo(d - 12, p.y + p.h - 5); ctx.stroke();
        }
      }
    }
  }

  function drawPickup(pickup) {
    var isHealth = pickup.kind === "health";
    if (!pickup.active && !isHealth) return;
    var pulse = 0.75 + Math.sin(state.tick * 0.08 + pickup.id) * 0.12;
    ctx.save();
    ctx.translate(pickup.x, pickup.y);
    if (!pickup.active) {
      var progress = clamp(1 - pickup.respawn / Sim.RULES.pickupRespawnTicks, 0, 1);
      ctx.globalAlpha = 0.62;
      ctx.fillStyle = "rgba(10,31,25,.76)";
      ctx.strokeStyle = "rgba(105,255,157,.55)";
      ctx.lineWidth = 2;
      roundRect(-20, -18, 40, 36, 10); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = "rgba(105,255,157,.95)";
      ctx.lineWidth = 4.5;
      ctx.beginPath(); ctx.arc(0, 0, 27, -Math.PI * 0.5, -Math.PI * 0.5 + Math.PI * 2 * progress); ctx.stroke();
      ctx.strokeStyle = "rgba(239,255,244,.82)";
      ctx.lineWidth = 4.5;
      ctx.beginPath(); ctx.moveTo(-8, 0); ctx.lineTo(8, 0); ctx.moveTo(0, -8); ctx.lineTo(0, 8); ctx.stroke();
      ctx.restore();
      return;
    }
    ctx.shadowColor = isHealth ? "#45f58c" : "#36e4ff"; ctx.shadowBlur = 22 * pulse;
    ctx.fillStyle = isHealth ? "rgba(8,35,26,.94)" : "rgba(8,28,38,.92)";
    ctx.strokeStyle = isHealth ? "#69ff9d" : "#59eaff"; ctx.lineWidth = 2.3;
    roundRect(-27, -24, 54, 48, 12); ctx.fill(); ctx.stroke();
    ctx.shadowBlur = 0; ctx.strokeStyle = "#eafcff"; ctx.fillStyle = "#eafcff"; ctx.lineWidth = 4; ctx.lineCap = "round";
    var weapon = pickup.kind === "ammo" ? "ammo" : pickup.weapon;
    if (isHealth) {
      ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(-11, 0); ctx.lineTo(11, 0); ctx.moveTo(0, -11); ctx.lineTo(0, 11); ctx.stroke();
    } else if (weapon === "sword") {
      ctx.beginPath(); ctx.moveTo(-13, 12); ctx.lineTo(14, -14); ctx.stroke();
      ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(-3, 5); ctx.lineTo(5, 13); ctx.stroke();
    } else if (weapon === "grenade") {
      ctx.beginPath(); ctx.arc(0, 4, 8, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(1, -5); ctx.lineTo(7, -12); ctx.stroke();
    } else if (weapon === "ammo") {
      ctx.strokeRect(-10, -13, 20, 26); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-5, -7); ctx.lineTo(5, -7); ctx.moveTo(-5, 0); ctx.lineTo(5, 0); ctx.moveTo(-5, 7); ctx.lineTo(5, 7); ctx.stroke();
    } else {
      var gunLength = weapon === "pistol" ? 20 : 31;
      ctx.beginPath(); ctx.moveTo(-gunLength * 0.55, -3); ctx.lineTo(gunLength * 0.55, -3); ctx.stroke();
      ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-2, -1); ctx.lineTo(2, 11); ctx.stroke();
      if (weapon === "shotgun") {
        // The broad, grooved fore-end keeps the shotgun readable at pickup scale.
        ctx.strokeStyle = "#8ba2aa"; ctx.lineWidth = 7;
        ctx.beginPath(); ctx.moveTo(4, -2); ctx.lineTo(14, -2); ctx.stroke();
        ctx.strokeStyle = "#eafcff"; ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(7, -6); ctx.lineTo(7, 2);
        ctx.moveTo(11, -6); ctx.lineTo(11, 2);
        ctx.stroke();
      } else if (weapon === "rifle") {
        // A separate swept magazine distinguishes the rifle from the long gun.
        ctx.fillStyle = "#8ba2aa"; ctx.strokeStyle = "#eafcff"; ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.moveTo(4, -1); ctx.lineTo(10, -1); ctx.lineTo(7, 12); ctx.lineTo(1, 10);
        ctx.closePath(); ctx.fill(); ctx.stroke();
      }
    }
    ctx.restore();
  }

  function worldPosePoint(fighter, point) {
    var scale = Number.isFinite(fighter.drawScale) ? fighter.drawScale : 1;
    return {
      x: fighter.x + point.x * scale,
      y: fighter.y - 61 * scale + point.y * scale
    };
  }

  function strokeLimb(fighter, pose, names, color) {
    ctx.lineCap = "round"; ctx.lineJoin = "round";
    ctx.strokeStyle = color; ctx.lineWidth = 10;
    ctx.beginPath();
    for (var pass = 0; pass < 2; pass += 1) {
      ctx.beginPath();
      for (var i = 0; i < names.length; i += 1) {
        var p = worldPosePoint(fighter, pose[names[i]]);
        if (i === 0) ctx.moveTo(p.x, p.y); else ctx.lineTo(p.x, p.y);
      }
      ctx.stroke();
      ctx.strokeStyle = "#080b0d"; ctx.lineWidth = 6;
    }
  }

  function drawSwordTrail(fighter, pose) {
    if (!Anim || typeof Anim.swordTrailSamples !== "function") return;
    var samples = Anim.swordTrailSamples(pose);
    if (!Array.isArray(samples) || !samples.length) return;
    var count = Math.min(4, samples.length);
    var baseAlpha = ctx.globalAlpha;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    // Butt caps preserve the animation-owned start/end points. These are only
    // fading prior blade segments; the ordinary authoritative blade is drawn
    // unchanged afterward and remains the clear leading edge.
    ctx.lineCap = "butt";
    ctx.lineJoin = "round";
    for (var i = count - 1; i >= 0; i -= 1) {
      var sample = samples[i];
      if (!sample || !sample.bladeStart || !sample.bladeEnd
        || !Number.isFinite(sample.bladeStart.x) || !Number.isFinite(sample.bladeStart.y)
        || !Number.isFinite(sample.bladeEnd.x) || !Number.isFinite(sample.bladeEnd.y)) continue;
      var start = worldPosePoint(fighter, sample.bladeStart);
      var end = worldPosePoint(fighter, sample.bladeEnd);
      var alpha = clamp(Number(sample.alpha) || 0, 0, 1);
      ctx.globalAlpha = baseAlpha * alpha * 0.34;
      ctx.strokeStyle = "#32e6ff";
      ctx.lineWidth = 16;
      ctx.beginPath(); ctx.moveTo(start.x, start.y); ctx.lineTo(end.x, end.y); ctx.stroke();
      ctx.globalAlpha = baseAlpha * alpha * 0.46;
      ctx.strokeStyle = "#effeff";
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(start.x, start.y); ctx.lineTo(end.x, end.y); ctx.stroke();
    }
    ctx.restore();
  }

  function drawWeapon(fighter, pose) {
    var weapon = fighter.weapon;
    var sockets = Anim.weaponSockets(pose, weapon);
    if (!sockets) return;
    function wp(point) { return worldPosePoint(fighter, point); }
    ctx.save(); ctx.lineCap = "round"; ctx.lineJoin = "round";
    if (weapon === "sword") {
      var bladeStart = wp(sockets.bladeStart || sockets.start);
      var bladeEnd = wp(sockets.bladeEnd || sockets.end);
      var handleStart = wp(sockets.handleStart);
      var handleEnd = wp(sockets.handleEnd);
      var guardA = wp(sockets.guardA); var guardB = wp(sockets.guardB);
      ctx.strokeStyle = "rgba(77,230,255,.32)"; ctx.lineWidth = 13;
      ctx.beginPath(); ctx.moveTo(bladeStart.x, bladeStart.y); ctx.lineTo(bladeEnd.x, bladeEnd.y); ctx.stroke();
      ctx.strokeStyle = "#d9e8ea"; ctx.lineWidth = 5;
      ctx.beginPath(); ctx.moveTo(bladeStart.x, bladeStart.y); ctx.lineTo(bladeEnd.x, bladeEnd.y); ctx.stroke();
      ctx.strokeStyle = "#070a0c"; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(handleStart.x, handleStart.y); ctx.lineTo(handleEnd.x, handleEnd.y); ctx.stroke();
      ctx.strokeStyle = "#a8c8d0"; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(guardA.x, guardA.y); ctx.lineTo(guardB.x, guardB.y); ctx.stroke();
    } else if (weapon === "pistol" || weapon === "shotgun" || weapon === "rifle") {
      var stock = wp(sockets.stock); var muzzle = wp(sockets.muzzle); var grip = wp(sockets.triggerGrip);
      var weaponAlpha = ctx.globalAlpha;
      var gripNormal = sockets.normal.y >= 0
        ? sockets.normal
        : { x: -sockets.normal.x, y: -sockets.normal.y };
      var gripEnd = wp({
        x: sockets.triggerGrip.x + gripNormal.x * 18,
        y: sockets.triggerGrip.y + gripNormal.y * 18
      });
      ctx.strokeStyle = fighter.color; ctx.globalAlpha = weaponAlpha * 0.28; ctx.lineWidth = 11;
      ctx.beginPath(); ctx.moveTo(stock.x, stock.y); ctx.lineTo(muzzle.x, muzzle.y); ctx.stroke();
      ctx.globalAlpha = weaponAlpha; ctx.strokeStyle = "#05080a"; ctx.lineWidth = weapon === "pistol" ? 8 : 10;
      ctx.beginPath(); ctx.moveTo(stock.x, stock.y); ctx.lineTo(muzzle.x, muzzle.y); ctx.stroke();
      ctx.strokeStyle = "#8ba2aa"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(stock.x, stock.y - 1); ctx.lineTo(muzzle.x, muzzle.y - 1); ctx.stroke();
      ctx.strokeStyle = "#05080a"; ctx.lineWidth = 7;
      ctx.beginPath(); ctx.moveTo(grip.x, grip.y); ctx.lineTo(gripEnd.x, gripEnd.y); ctx.stroke();
      if (weapon === "shotgun") {
        // Cosmetic pump sleeve: it follows the socket direction without moving
        // the authoritative muzzle or changing the collision barrel geometry.
        var pumpStart = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 25 + gripNormal.x * 1.5,
          y: sockets.triggerGrip.y + sockets.direction.y * 25 + gripNormal.y * 1.5
        });
        var pumpEnd = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 42 + gripNormal.x * 1.5,
          y: sockets.triggerGrip.y + sockets.direction.y * 42 + gripNormal.y * 1.5
        });
        ctx.strokeStyle = "#34434a"; ctx.lineWidth = 9;
        ctx.beginPath(); ctx.moveTo(pumpStart.x, pumpStart.y); ctx.lineTo(pumpEnd.x, pumpEnd.y); ctx.stroke();
        ctx.strokeStyle = "#9eb3ba"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(pumpStart.x, pumpStart.y); ctx.lineTo(pumpEnd.x, pumpEnd.y); ctx.stroke();
      } else if (weapon === "rifle") {
        // Cosmetic swept magazine; all points are derived from animation-owned
        // sockets so it follows every continuous aim angle and recoil pose.
        var magazineA = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 7 + gripNormal.x * 3,
          y: sockets.triggerGrip.y + sockets.direction.y * 7 + gripNormal.y * 3
        });
        var magazineB = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 14 + gripNormal.x * 3,
          y: sockets.triggerGrip.y + sockets.direction.y * 14 + gripNormal.y * 3
        });
        var magazineC = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 8 + gripNormal.x * 21,
          y: sockets.triggerGrip.y + sockets.direction.y * 8 + gripNormal.y * 21
        });
        var magazineD = wp({
          x: sockets.triggerGrip.x + sockets.direction.x * 1 + gripNormal.x * 19,
          y: sockets.triggerGrip.y + sockets.direction.y * 1 + gripNormal.y * 19
        });
        ctx.fillStyle = "#11191d"; ctx.strokeStyle = "#8ba2aa"; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(magazineA.x, magazineA.y); ctx.lineTo(magazineB.x, magazineB.y);
        ctx.lineTo(magazineC.x, magazineC.y); ctx.lineTo(magazineD.x, magazineD.y);
        ctx.closePath(); ctx.fill(); ctx.stroke();
      }
    } else if (weapon === "grenade") {
      var center = wp(sockets.center);
      ctx.fillStyle = "#17241c"; ctx.strokeStyle = "#87a38e"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(center.x, center.y, sockets.radius || 7, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    }
    ctx.restore();
  }

  function drawFighter(fighter, alpha) {
    var x = lerp(fighter.prevX, fighter.x, alpha);
    var y = lerp(fighter.prevY, fighter.y, alpha);
    var renderFighter = Object.assign({}, fighter, {
      x: x,
      y: y,
      renderStepX: fighter.x,
      renderStepY: fighter.y
    });
    var pose = Anim.poseForFighter(renderFighter, alpha);
    ctx.save();
    ctx.globalAlpha *= clamp(pose.alpha == null ? 1 : pose.alpha, 0, 1);
    var presentingRespawn = fighter.respawnVisual > 0
      || fighter.life && (fighter.life.kind === "respawn" || fighter.life.kind === "respawning");
    if (!presentingRespawn && fighter.invuln && Math.floor(fighter.invuln / 4) % 2) ctx.globalAlpha *= 0.48;
    if (fighter.dead) ctx.globalAlpha *= 0.72;
    drawSwordTrail(renderFighter, pose);
    strokeLimb(renderFighter, pose, ["hip", "kneeL", "ankleL"], fighter.color);
    strokeLimb(renderFighter, pose, ["shoulder", "elbowL", "wristL"], fighter.color);
    strokeLimb(renderFighter, pose, ["hip", "spine", "torsoTop"], fighter.color);
    strokeLimb(renderFighter, pose, ["hip", "kneeR", "ankleR"], fighter.color);
    strokeLimb(renderFighter, pose, ["shoulder", "elbowR", "wristR"], fighter.color);
    drawWeapon(renderFighter, pose);
    var head = worldPosePoint(renderFighter, pose.head);
    ctx.fillStyle = "#080b0d"; ctx.strokeStyle = fighter.color; ctx.lineWidth = 3.5;
    var drawScale = Number.isFinite(fighter.drawScale) ? fighter.drawScale : 1;
    ctx.beginPath(); ctx.arc(head.x, head.y, (pose.headRadius || 16) * drawScale, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.restore();

    if (!fighter.dead) {
      var width = 70;
      ctx.fillStyle = "rgba(3,9,13,.8)"; roundRect(x - width / 2, y - 190, width, 7, 4); ctx.fill();
      ctx.fillStyle = fighter.color; roundRect(x - width / 2, y - 190, width * clamp(fighter.health / fighter.maxHealth, 0, 1), 7, 4); ctx.fill();
    }
  }

  function drawProjectiles() {
    ctx.save(); ctx.lineCap = "round";
    for (var i = 0; i < state.projectiles.length; i += 1) {
      var b = state.projectiles[i];
      ctx.strokeStyle = b.weapon === "shotgun" ? "#ffd99d" : "#e7fbff";
      ctx.lineWidth = b.weapon === "rifle" ? 2.4 : 3.2;
      ctx.beginPath(); ctx.moveTo(b.prevX, b.prevY); ctx.lineTo(b.x, b.y); ctx.stroke();
    }
    for (var j = 0; j < state.grenades.length; j += 1) {
      var g = state.grenades[j];
      ctx.fillStyle = "#18251b"; ctx.strokeStyle = "#adbea9"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(g.x, g.y, g.radius || 10, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
      ctx.fillStyle = g.fuse < 45 && g.fuse % 8 < 4 ? "#fff" : "#ff765f";
      ctx.beginPath(); ctx.arc(g.x + 5, g.y - 9, 2.5, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }

  function drawEffects() {
    ctx.save();
    for (var i = 0; i < flashes.length; i += 1) {
      var f = flashes[i]; var t = clamp(f.life / f.maxLife, 0, 1);
      ctx.globalAlpha = 1;
      if (f.kind === "explosion") {
        var glow = ctx.createRadialGradient(f.x, f.y, 3, f.x, f.y, f.radius * (1 - t * 0.35));
        glow.addColorStop(0, "rgba(255,250,205," + (0.9 * t) + ")");
        glow.addColorStop(0.32, "rgba(255,153,71," + (0.7 * t) + ")");
        glow.addColorStop(1, "rgba(255,70,45,0)");
        ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(f.x, f.y, f.radius, 0, Math.PI * 2); ctx.fill();
      } else if (f.kind === "impact") {
        var progress = 1 - t;
        if (f.weapon === "sword") {
          var slashHalfLength = f.radius * (0.46 + progress * 0.18);
          ctx.lineCap = "butt";
          ctx.globalAlpha = t * 0.46;
          ctx.strokeStyle = f.color;
          ctx.lineWidth = 9;
          ctx.beginPath();
          ctx.moveTo(f.x - f.tangentX * slashHalfLength, f.y - f.tangentY * slashHalfLength);
          ctx.lineTo(f.x + f.tangentX * slashHalfLength, f.y + f.tangentY * slashHalfLength);
          ctx.stroke();
          ctx.globalAlpha = t * 0.84;
          ctx.strokeStyle = f.core;
          ctx.lineWidth = 2.5;
          ctx.beginPath();
          ctx.moveTo(f.x - f.tangentX * slashHalfLength, f.y - f.tangentY * slashHalfLength);
          ctx.lineTo(f.x + f.tangentX * slashHalfLength, f.y + f.tangentY * slashHalfLength);
          ctx.stroke();
        } else {
          ctx.globalAlpha = t * 0.72;
          ctx.strokeStyle = f.color;
          ctx.lineWidth = 2.5 * t + 0.8;
          ctx.beginPath(); ctx.arc(f.x, f.y, f.radius * (0.34 + progress * 0.66), 0, Math.PI * 2); ctx.stroke();
        }
        ctx.globalAlpha = t * 0.82;
        ctx.fillStyle = f.core;
        ctx.beginPath(); ctx.arc(f.x, f.y, Math.max(1, f.radius * 0.28 * t), 0, Math.PI * 2); ctx.fill();
      } else if (f.kind === "pickup") {
        var pickupProgress = 1 - t;
        ctx.globalAlpha = t * 0.82;
        ctx.strokeStyle = f.color;
        ctx.lineWidth = 2 + t * 3;
        ctx.beginPath();
        ctx.arc(f.x, f.y, f.radius * (0.32 + pickupProgress * 0.68), 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = t * 0.7;
        ctx.fillStyle = f.core;
        ctx.beginPath(); ctx.arc(f.x, f.y, Math.max(1, 5 * t), 0, Math.PI * 2); ctx.fill();
      } else {
        ctx.fillStyle = "rgba(255,244,194," + t + ")";
        ctx.beginPath(); ctx.arc(f.x, f.y, f.radius * (1.4 - t * 0.4), 0, Math.PI * 2); ctx.fill();
      }
    }
    for (var j = 0; j < particles.length; j += 1) {
      var p = particles[j]; var a = clamp(p.life / p.maxLife, 0, 1);
      ctx.globalAlpha = a;
      if (p.kind === "spark") {
        var speed = Math.hypot(p.vx, p.vy) || 1;
        var streak = Math.min(18, speed * 0.045) * a;
        ctx.strokeStyle = p.color;
        ctx.lineWidth = Math.max(0.8, p.size * a);
        ctx.lineCap = "round";
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p.x - p.vx / speed * streak, p.y - p.vy / speed * streak);
        ctx.stroke();
      } else {
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * a, 0, Math.PI * 2); ctx.fill();
      }
    }
    ctx.restore();
  }

  function render(alpha) {
    if (!state) return;
    beginWorld();
    drawBackground();
    drawArena();
    for (var i = 0; i < state.pickups.length; i += 1) drawPickup(state.pickups[i]);
    if (started) {
      drawProjectiles();
      var fighters = state.fighters.slice().sort(function (a, b) { return a.y - b.y || a.id - b.id; });
      for (var j = 0; j < fighters.length; j += 1) drawFighter(fighters[j], alpha);
      drawEffects();
    }
  }

  function nearbyPickup(player) {
    var best = null; var bestDistance2 = Infinity;
    for (var i = 0; i < state.pickups.length; i += 1) {
      var p = state.pickups[i];
      if (!Sim.canCollectPickup(player, p)) continue;
      var dx = p.x - player.x;
      var dy = p.y - (player.y - 35);
      var distance2 = dx * dx + dy * dy;
      if (distance2 <= Sim.RULES.pickupRadius * Sim.RULES.pickupRadius
        && (distance2 < bestDistance2 || (distance2 === bestDistance2 && p.id < best.id))) {
        best = p;
        bestDistance2 = distance2;
      }
    }
    return best;
  }

  function updateHud() {
    if (!state) return;
    var player = localFighter();
    if (!player) return;
    var seconds = Math.ceil(state.match.ticksRemaining / 60);
    ui.matchTimer.textContent = String(Math.floor(seconds / 60)).padStart(2, "0") + ":" + String(seconds % 60).padStart(2, "0");
    var chips = ui.scoreboard ? ui.scoreboard.querySelectorAll("[data-score-id]") : [];
    for (var i = 0; i < chips.length; i += 1) {
      var fighter = fighterById(Number(chips[i].getAttribute("data-score-id")));
      chips[i].hidden = !fighter;
      if (fighter) {
        var name = chips[i].querySelector("b"); var score = chips[i].querySelector("strong");
        if (name) name.textContent = fighterLabel(fighter);
        if (score) score.textContent = fighter.score;
      }
    }
    ui.playerScore.textContent = player.score;
    ui.healthText.textContent = Math.ceil(player.health);
    ui.healthFill.style.width = clamp(player.health / player.maxHealth * 100, 0, 100) + "%";
    ui.healthFill.parentElement.setAttribute("aria-valuenow", String(Math.ceil(player.health)));
    ui.weaponText.textContent = player.weapon.toUpperCase();
    ui.weaponGlyph.textContent = weaponGlyphs[player.weapon] || "◇";
    var ammo = player.ammo[player.weapon];
    ui.ammoText.textContent = ammo && ammo.mag != null ? ammo.mag + " / " + ammo.reserve : ammo && ammo.count != null ? String(ammo.count) : "∞";
    var status = "";
    if (player.dead) status = "RESPAWNING";
    else if (player.reload) status = "RELOADING";
    else if (player.hitstun) status = "HIT";
    else if (player.invuln) status = "SPAWN SHIELD";
    ui.stateLabel.textContent = status;
    var pickup = nearbyPickup(player);
    if (ui.touchPickupButton) ui.touchPickupButton.hidden = smartAction || !pickup;
    if (ui.touchReloadButton) {
      var weaponRules = Sim.WEAPONS[player.weapon];
      var canReload = !!(ammo && ammo.mag != null && weaponRules && weaponRules.mag != null && ammo.mag < weaponRules.mag && ammo.reserve > 0 && !player.reload);
      ui.touchReloadButton.hidden = !canReload;
    }
    if (ui.prompt) {
      ui.prompt.hidden = !pickup;
      if (pickup) {
        if (ui.touchControls && !ui.touchControls.hidden) ui.promptKey.textContent = smartAction ? "TAP ACTION" : "PICK";
        else ui.promptKey.textContent = controlPreset === Input.CONTROL_PRESETS.hybrid ? "E / RIGHT CLICK" : "E";
        if (pickup.kind === "health") {
          var healthAmount = Math.min(Sim.RULES.healthPickupAmount, player.maxHealth - player.health);
          ui.promptText.textContent = "HEALTH +" + Math.ceil(healthAmount);
        } else {
          ui.promptText.textContent = pickup.kind === "ammo" ? "AMMUNITION" : pickup.weapon.toUpperCase();
        }
      }
    }
  }

  function showResult() {
    resultShown = true;
    var winner = fighterById(state.match.winnerId);
    var won = winner && winner.id === localActorId;
    ui.resultEyebrow.textContent = "REGULATION COMPLETE";
    ui.resultTitle.textContent = winner ? (won ? "VICTORY" : fighterLabel(winner) + " WINS") : "DRAW";
    ui.resultCopy.textContent = onlineMode
      ? (won ? "You held the highest score at 0:00." : winner ? fighterLabel(winner) + " led at 0:00." : "The highest score was tied at 0:00.")
        + " Both players can vote for an immediate server-owned rematch."
      : won ? "You held the highest score at 0:00." : winner ? fighterLabel(winner) + " led at 0:00. Rematch and take back the arena." : "The highest score was tied at 0:00. Rematch to break it.";
    ui.finalScores.innerHTML = "";
    state.fighters.slice().sort(function (a, b) { return b.score - a.score || a.id - b.id; }).forEach(function (fighter) {
      var row = document.createElement("div"); row.textContent = fighterLabel(fighter) + "  " + fighter.score; ui.finalScores.appendChild(row);
    });
    show(ui.resultOverlay, true);
    ui.rematchButton.hidden = onlineMode;
    ui.rematchButton.disabled = onlineMode;
    ui.pauseButton.hidden = true;
    clearPlayerInput();
    updateTouchVisibility();
    ui.resultOverlay.focus({ preventScroll: true });
  }

  function showOnlineGenerationTransition(connection) {
    var firstTransitionFrame = !onlineTransition;
    if (firstTransitionFrame) {
      onlineTransition = true;
      clearPlayerInput();
      particles.length = 0;
      flashes.length = 0;
      if (ui.killFeed) ui.killFeed.textContent = "";
      accumulator = 0;
      paused = false;
      started = false;
      resultShown = false;
      state = null;
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = "#03080e";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.restore();
      show(ui.startOverlay, false);
      show(ui.pauseOverlay, false);
      ui.hud.hidden = true;
      ui.pauseButton.hidden = true;
      ui.rematchButton.hidden = true;
      ui.rematchButton.disabled = true;
      ui.finalScores.innerHTML = "";
      updateTouchVisibility();
    }
    ui.resultEyebrow.textContent = "SERVER-OWNED REMATCH";
    ui.resultTitle.textContent = connection.state === "reconnecting"
      ? "RECONNECTING"
      : connection.lifecycle === "restarting"
      ? "STARTING NEW MATCH"
      : connection.lifecycle === "waiting"
        ? "WAITING FOR OTHER PLAYER"
        : "READYING AUTHORITATIVE MATCH";
    ui.resultCopy.textContent = connection.state === "reconnecting"
      ? "Restoring your reserved seat within the bounded reconnect window."
      : "The next generation starts only after both players are ready.";
    show(ui.resultOverlay, true);
    if (firstTransitionFrame) ui.resultMainMenuButton.focus({ preventScroll: true });
  }

  function prepareOnlineRequest() {
    onlineMode = true;
    ensureAudio();
    botCount = onlineMode ? 2 : Number(ui.botCountControl.value) || 3;
    if (!Online.quickMatchAvailable() && offlineBotCountValue === null) {
      offlineBotCountValue = ui.botCountControl.value;
    }
    ui.botCountControl.value = "2";
    ui.botCountControl.disabled = true;
    ui.botCountLabel.textContent = "SERVER BOTS";
    ui.botCountHint.textContent = "FIXED ONLINE TOPOLOGY";
    controlPreset = ui.controlPresetControl.value === Input.CONTROL_PRESETS.keyboard ? Input.CONTROL_PRESETS.keyboard : Input.CONTROL_PRESETS.hybrid;
    smartAction = ui.smartActionControl.value !== "off";
    onlineTerminalPresented = false;
    roomCodeValidationDismissed = false;
    ui.startButton.disabled = true;
    ui.createMatchButton.disabled = true;
    ui.joinMatchButton.disabled = true;
    ui.roomCodeInput.disabled = true;
    ui.restartButton.hidden = true;
    ui.pauseTitle.textContent = "MATCH MENU";
  }

  function restoreOfflineBotSettings() {
    if (!onlineAvailable || Online.quickMatchAvailable()) return;
    ui.botCountControl.disabled = false;
    if (offlineBotCountValue !== null) ui.botCountControl.value = offlineBotCountValue;
    offlineBotCountValue = null;
    ui.botCountLabel.textContent = "OPPONENTS";
    ui.botCountHint.textContent = "APPLIES NEXT MATCH";
  }

  function ignoreOnlineFailure() {
    // The adapter exposes only fixed redacted status; the animation loop renders it.
  }

  function startQuickMatch() {
    prepareOnlineRequest();
    Online.quickMatch().catch(ignoreOnlineFailure);
  }

  function startCreatedMatch() {
    prepareOnlineRequest();
    Online.createMatch().catch(ignoreOnlineFailure);
  }

  function startJoinedMatch() {
    prepareOnlineRequest();
    Online.joinMatch(ui.roomCodeInput.value).catch(ignoreOnlineFailure);
  }

  function startMatch() {
    if (onlineAvailable && Online.quickMatchAvailable()) {
      startQuickMatch();
      return;
    }
    onlineMode = false;
    restoreOfflineBotSettings();
    ensureAudio();
    botCount = Number(ui.botCountControl.value) || 3;
    controlPreset = ui.controlPresetControl.value === Input.CONTROL_PRESETS.keyboard ? Input.CONTROL_PRESETS.keyboard : Input.CONTROL_PRESETS.hybrid;
    smartAction = ui.smartActionControl.value !== "off";
    makeState(nextMatchSeed());
    ui.restartButton.hidden = false;
    ui.pauseTitle.textContent = "PAUSED";
    started = true; paused = false; lastTime = performance.now();
    show(ui.startOverlay, false); show(ui.pauseOverlay, false); show(ui.resultOverlay, false);
    ui.hud.hidden = false; ui.pauseButton.hidden = false; canvas.focus();
    updateTouchVisibility();
  }

  function pause(value) {
    if (!started || state.match.phase === "finished") return;
    if (onlineMode) {
      paused = !!value;
      if (paused) {
        clearPlayerInput();
        Online.sendNeutral();
      }
      show(ui.pauseOverlay, paused);
      ui.pauseButton.hidden = paused;
      ui.restartButton.hidden = true;
      ui.pauseTitle.textContent = "MATCH MENU";
      updateTouchVisibility();
      if (paused) ui.pauseOverlay.focus({ preventScroll: true });
      else canvas.focus();
      return;
    }
    paused = value;
    if (paused) {
      clearPlayerInput();
    }
    show(ui.pauseOverlay, paused);
    ui.pauseButton.hidden = paused;
    lastTime = performance.now();
    updateTouchVisibility();
    if (paused) ui.pauseOverlay.focus({ preventScroll: true });
    else canvas.focus();
  }

  function restartMatch() {
    botCount = Number(ui.botCountControl.value) || 3;
    controlPreset = ui.controlPresetControl.value === Input.CONTROL_PRESETS.keyboard ? Input.CONTROL_PRESETS.keyboard : Input.CONTROL_PRESETS.hybrid;
    smartAction = ui.smartActionControl.value !== "off";
    if (onlineMode) {
      var connection = Online.getStatus();
      if (connection.rematchVotePending === null
          && Online.setRematchVote(!connection.rematchVoted)) {
        ui.rematchButton.disabled = true;
      }
      return;
    }
    ensureAudio(); makeState(nextMatchSeed()); paused = false; started = true; lastTime = performance.now();
    show(ui.pauseOverlay, false); show(ui.resultOverlay, false);
    ui.hud.hidden = false; ui.pauseButton.hidden = false; canvas.focus();
    updateTouchVisibility();
  }

  function returnToMainMenu() {
    if (onlineMode) Online.disconnect();
    onlineMode = false;
    onlineEpoch = null;
    onlineGeneration = null;
    onlineTransition = false;
    onlineTerminalPresented = false;
    started = false;
    paused = false;
    slowMotion = false;
    clearPlayerInput();
    ui.speedBadge.hidden = true;
    ui.pauseButton.hidden = true;
    makeState();
    show(ui.pauseOverlay, false);
    show(ui.resultOverlay, false);
    show(ui.startOverlay, true);
    ui.hud.hidden = true;
    if (onlineAvailable) {
      ui.startButton.disabled = false;
      ui.createMatchButton.disabled = false;
      ui.joinMatchButton.disabled = false;
      ui.roomCodeInput.disabled = false;
      ui.mainControlsButton.disabled = false;
      ui.mainSettingsButton.disabled = false;
      ui.roomCodeInput.value = "";
      ui.roomCodeInput.setAttribute("aria-invalid", "false");
      updateOnlineMenu(Online.getStatus());
    }
    restoreOfflineBotSettings();
    if (onlineAvailable && Online.quickMatchAvailable()) {
      ui.botCountControl.disabled = true;
      ui.botCountLabel.textContent = "SERVER BOTS";
      ui.botCountHint.textContent = "FIXED ONLINE TOPOLOGY";
    }
    lastTime = performance.now();
    updateTouchVisibility();
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
  }

  function syncOnlineStatus() {
    if (!onlineMode) return;
    var connection = Online.getStatus();
    updateOnlineMenu(connection);
    if (Number.isInteger(connection.actorId)) localActorId = connection.actorId;
    if (Number.isSafeInteger(connection.generation) && connection.generation !== onlineGeneration) {
      onlineGeneration = connection.generation;
      clearPlayerInput();
      particles.length = 0;
      flashes.length = 0;
      if (ui.killFeed) ui.killFeed.textContent = "";
      accumulator = 0;
      paused = false;
      started = false;
      resultShown = false;
      show(ui.pauseOverlay, false);
      if (!onlineTransition) show(ui.resultOverlay, false);
      ui.rematchButton.disabled = false;
    }
    var generationTransition = !connection.started
      && (connection.lifecycle === "restarting"
        || (connection.generation > 1
          && (connection.lifecycle === "waiting" || connection.lifecycle === "ready")));
    if (generationTransition) showOnlineGenerationTransition(connection);
    if (Number.isInteger(connection.epoch) && connection.epoch !== onlineEpoch) {
      onlineEpoch = connection.epoch;
      clearPlayerInput();
    }
    updateStatusSurface(ui.networkStatus, connection.detail || "ONLINE · TWO PLAYERS",
      connection.state, true);
    updateStatusSurface(ui.onlineStatusBadge, connection.detail || "AUTHORITATIVE MATCH",
      connection.state, started || connection.started);
    var onlineState = Online.renderState();
    if (onlineState && !onlineTransition) state = onlineState;
    processEvents(Online.drainEvents());
    if (connection.started && onlineState && !started) {
      onlineTransition = false;
      state = onlineState;
      started = true;
      paused = false;
      accumulator = 0;
      lastTime = performance.now();
      show(ui.startOverlay, false);
      show(ui.pauseOverlay, false);
      show(ui.resultOverlay, false);
      ui.hud.hidden = false;
      ui.pauseButton.hidden = false;
      canvas.focus();
      updateTouchVisibility();
    }
    if (resultShown && onlineMode) {
      ui.rematchButton.hidden = !connection.rematchOpen;
      ui.rematchButton.disabled = !connection.rematchOpen
        || connection.rematchVotePending !== null || !connection.connected;
      ui.rematchButton.textContent = connection.rematchVoted ? "WITHDRAW REMATCH" : "REMATCH";
      if (connection.rematchOpen) {
        ui.resultCopy.setAttribute("data-rematch-state", connection.rematchVoted ? "voted" : "open");
      } else {
        ui.resultCopy.setAttribute("data-rematch-state", "closed");
      }
    }
    var terminalConnection = connection.state === "error" || connection.state === "closed";
    if (!terminalConnection) onlineTerminalPresented = false;
    if (terminalConnection && !onlineTerminalPresented) {
      onlineTerminalPresented = true;
      onlineTransition = false;
      clearPlayerInput();
      started = false;
      paused = false;
      resultShown = false;
      show(ui.pauseOverlay, false);
      show(ui.resultOverlay, false);
      show(ui.startOverlay, true);
      ui.hud.hidden = true;
      ui.pauseButton.hidden = true;
      ui.startButton.disabled = false;
      ui.createMatchButton.disabled = false;
      ui.joinMatchButton.disabled = false;
      ui.roomCodeInput.disabled = false;
      ui.mainControlsButton.disabled = false;
      ui.mainSettingsButton.disabled = false;
      restoreOfflineBotSettings();
      updateTouchVisibility();
      var retryControl = connection.matchmakingOperation === "join-code"
        ? ui.roomCodeInput
        : connection.matchmakingOperation === "create-match" ? ui.createMatchButton : ui.startButton;
      retryControl.focus();
    }
    if (started && connection.started && state && state.match.phase === "finished" && !resultShown) showResult();
  }

  function frame(time) {
    if (!lastTime) lastTime = time;
    var realDt = clamp((time - lastTime) / 1000, 0, 0.1);
    lastTime = time;
    syncOnlineStatus();
    if (started && !paused && !touchPortraitBlocked && state.match.phase === "playing") {
      accumulator += realDt * (onlineMode ? 1 : (slowMotion ? 0.25 : 1));
      var steps = 0;
      while (accumulator >= Sim.STEP && steps < 8) {
        simulationStep(); accumulator -= Sim.STEP; steps += 1;
      }
      if (steps === 8) accumulator = 0;
    }
    updatePresentation(realDt);
    updateHud();
    if (ui.touchControls && !ui.touchControls.hidden) updateTouchVisuals();
    render(clamp(accumulator / Sim.STEP, 0, 1));
    requestAnimationFrame(frame);
  }

  function syncAudioControls(preferences) {
    ui.soundControl.value = preferences.soundEnabled ? "on" : "off";
    ui.volumeControl.value = String(Math.round(preferences.masterVolume));
    if (ui.soundValue) ui.soundValue.value = Math.round(preferences.masterVolume) + "%";
    ui.volumeControl.setAttribute("aria-valuetext", Math.round(preferences.masterVolume) + " percent");
  }

  function setVolume(value) {
    syncAudioControls(audio.setMasterVolume(value));
  }

  function setSoundEnabled(value) {
    var preferences = audio.setSoundEnabled(value === "on");
    syncAudioControls(preferences);
    if (preferences.soundEnabled && preferences.masterVolume > 0) ensureAudio();
  }

  document.addEventListener("pointerdown", function (event) {
    inputModality = event.pointerType === "touch" ? "touch" : "pointer";
    document.documentElement.classList.remove("using-keyboard");
    document.documentElement.classList.toggle("using-pointer", event.pointerType !== "touch");
    if (event.pointerType === "touch") {
      touchSeen = true;
      updateTouchVisibility();
    }
  }, true);
  document.addEventListener("pointermove", function (event) {
    if (event.pointerType === "mouse") {
      document.documentElement.classList.remove("using-keyboard");
      document.documentElement.classList.add("using-pointer");
    }
  }, true);

  window.addEventListener("keydown", function (event) {
    inputModality = "keyboard";
    document.documentElement.classList.remove("using-pointer");
    document.documentElement.classList.add("using-keyboard");
    if (event.code === "Escape" && !event.repeat) {
      if (anyDialogOpen()) return;
      if (paused) ensureAudio();
      pause(!paused);
      return;
    }
    if (touchPortraitBlocked) {
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].indexOf(event.code) !== -1) event.preventDefault();
      return;
    }
    if (anyDialogOpen()) return;
    var tagName = event.target && event.target.tagName;
    if (tagName === "INPUT" || tagName === "SELECT" || tagName === "BUTTON") return;
    if (event.code === "Enter" && !event.repeat) {
      if (!started) startMatch(); else if (state.match.phase === "finished") restartMatch();
      return;
    }
    if (!started || paused) return;
    ensureAudio();
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].indexOf(event.code) !== -1) event.preventDefault();
    if (event.code === "KeyT" && !event.repeat) {
      if (onlineMode) return;
      slowMotion = !slowMotion; ui.speedBadge.hidden = !slowMotion; return;
    }
    keys[event.code] = true;
  });
  window.addEventListener("keyup", function (event) { keys[event.code] = false; });
  window.addEventListener("blur", function () { clearPlayerInput(); if (started) pause(true); });
  window.addEventListener("pagehide", function () { clearPlayerInput(); if (started) pause(true); });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      clearPlayerInput();
      if (started) pause(true);
    }
  });

  canvas.addEventListener("pointermove", function (event) {
    if (!state || touchPortraitBlocked) return;
    var local = shellPoint(event);
    if (touchController.movePointer(event.pointerId, local.x, local.y)) {
      event.preventDefault();
      updateTouchVisuals();
      return;
    }
    if (event.pointerType === "touch") return;
    var p = canvasPoint(event);
    pointerController.setPosition(p.x, p.y, true);
  });
  canvas.addEventListener("pointerenter", function (event) {
    if (state && !touchPortraitBlocked && event.pointerType !== "touch") {
      var point = canvasPoint(event);
      pointerController.setPosition(point.x, point.y, true);
    }
  });
  canvas.addEventListener("pointerleave", function (event) {
    if (event.pointerType !== "touch") pointerController.setInside(false);
  });
  canvas.addEventListener("pointerdown", function (event) {
    if (!started || !state || paused || anyDialogOpen() || state.match.phase !== "playing" || touchPortraitBlocked) return;
    if (event.button === 0 && touchPointerAccepted(event)) {
      touchSeen = touchSeen || event.pointerType === "touch";
      updateTouchVisibility();
      if (ui.touchControls.hidden || touchPortraitBlocked) return;
      var local = shellPoint(event);
      var side = local.x < local.width * 0.5 ? "left" : "right";
      var player = localFighter();
      var pickup = side === "right" && player && smartAction ? nearbyPickup(player) : null;
      var assistAim = side === "right" && player && smartAction && !pickup
        ? Touch.closestLiveEnemyAim(state.fighters, player)
        : null;
      var startedTouch = side === "left"
        ? touchController.startStick("left", event.pointerId, local.x, local.y)
        : player && touchController.startAction(event.pointerId, local.x, local.y, {
          weapon: player.weapon,
          smartAction: smartAction,
          pickupEligible: !!pickup,
          assistAimX: assistAim ? assistAim.x : null,
          assistAimY: assistAim ? assistAim.y : null,
          facing: player.facing
        });
      if (startedTouch) {
        touchController.movePointer(event.pointerId, local.x, local.y);
        event.preventDefault();
        ensureAudio();
        capturePointer(canvas, event.pointerId);
        updateTouchVisuals();
      }
      return;
    }
    if (event.pointerType === "touch") return;
    if (event.button !== 0 && event.button !== 2) return;
    ensureAudio();
    var point = canvasPoint(event);
    pointerController.setPosition(point.x, point.y, true);
    if (controlPreset === Input.CONTROL_PRESETS.hybrid && pointerController.press(event.button, event.pointerId)) {
      event.preventDefault();
      capturePointer(canvas, event.pointerId);
    }
    canvas.focus();
  });

  function endCanvasPointer(event) {
    var normalRelease = event.type === "pointerup";
    var endedTouch = normalRelease ? touchController.endPointer(event.pointerId) : touchController.cancelPointer(event.pointerId);
    var endedPointer = normalRelease
      ? pointerController.releasePointer(event.pointerId, event.button)
      : pointerController.cancelPointer(event.pointerId);
    if (endedTouch || endedPointer) {
      event.preventDefault();
      updateTouchVisuals();
    }
  }

  canvas.addEventListener("pointerup", endCanvasPointer);
  canvas.addEventListener("pointercancel", endCanvasPointer);
  canvas.addEventListener("lostpointercapture", endCanvasPointer);
  canvas.addEventListener("contextmenu", function (event) { event.preventDefault(); });

  function beginTouchButton(event) {
    if (!touchPointerAccepted(event) || ui.touchControls.hidden || touchPortraitBlocked) return;
    var name = event.currentTarget.getAttribute("data-touch-button");
    if (!touchController.startButton(name, event.pointerId)) return;
    event.preventDefault();
    event.stopPropagation();
    ensureAudio();
    updateTouchVisuals();
    capturePointer(event.currentTarget, event.pointerId);
  }

  function endTouchButton(event) {
    var ended = event.type === "pointerup" ? touchController.endPointer(event.pointerId) : touchController.cancelPointer(event.pointerId);
    if (!ended) return;
    event.preventDefault();
    event.stopPropagation();
    updateTouchVisuals();
  }

  var touchButtons = ui.touchControls.querySelectorAll("[data-touch-button]");
  for (var touchButtonIndex = 0; touchButtonIndex < touchButtons.length; touchButtonIndex += 1) {
    touchButtons[touchButtonIndex].addEventListener("pointerdown", beginTouchButton);
    touchButtons[touchButtonIndex].addEventListener("pointerup", endTouchButton);
    touchButtons[touchButtonIndex].addEventListener("pointercancel", endTouchButton);
    touchButtons[touchButtonIndex].addEventListener("lostpointercapture", endTouchButton);
    touchButtons[touchButtonIndex].addEventListener("click", function (event) {
      if (event.detail !== 0 || ui.touchControls.hidden || touchPortraitBlocked) return;
      var name = event.currentTarget.getAttribute("data-touch-button");
      var keyboardPointerId = "keyboard:" + name;
      if (touchController.startButton(name, keyboardPointerId)) touchController.endPointer(keyboardPointerId);
      updateTouchVisuals();
    });
  }

  function releaseTerminalPointer(event) {
    var normalRelease = event.type === "pointerup";
    var endedTouch = normalRelease ? touchController.endPointer(event.pointerId) : touchController.cancelPointer(event.pointerId);
    var endedPointer = normalRelease
      ? pointerController.releasePointer(event.pointerId, event.button)
      : pointerController.cancelPointer(event.pointerId);
    if (endedTouch || endedPointer) updateTouchVisuals();
  }
  window.addEventListener("pointerup", releaseTerminalPointer, true);
  window.addEventListener("pointercancel", releaseTerminalPointer, true);

  ui.startButton.addEventListener("click", startMatch);
  ui.createMatchButton.addEventListener("click", startCreatedMatch);
  ui.joinMatchForm.addEventListener("submit", function (event) {
    event.preventDefault();
    startJoinedMatch();
  });
  ui.roomCodeInput.addEventListener("input", function () {
    var canonical = ui.roomCodeInput.value.slice(0, 7).toUpperCase();
    if (ui.roomCodeInput.value !== canonical) ui.roomCodeInput.value = canonical;
    roomCodeValidationDismissed = true;
    if (ui.roomCodeInput.getAttribute("aria-invalid") !== "false") {
      ui.roomCodeInput.setAttribute("aria-invalid", "false");
    }
  });
  ui.cancelOnlineButton.addEventListener("click", returnToMainMenu);
  ui.pauseButton.addEventListener("click", function () { pause(true); });
  ui.resumeButton.addEventListener("click", function () { ensureAudio(); pause(false); });
  ui.restartButton.addEventListener("click", restartMatch);
  ui.mainMenuButton.addEventListener("click", returnToMainMenu);
  ui.rematchButton.addEventListener("click", restartMatch);
  ui.resultMainMenuButton.addEventListener("click", returnToMainMenu);
  ui.mainControlsButton.addEventListener("click", function () { openMenuDialog(ui.controlsDialog, ui.mainControlsButton); });
  ui.mainSettingsButton.addEventListener("click", function () { openMenuDialog(ui.settingsDialog, ui.mainSettingsButton); });
  ui.pauseControlsButton.addEventListener("click", function () { openMenuDialog(ui.controlsDialog, ui.pauseControlsButton); });
  ui.pauseSettingsButton.addEventListener("click", function () { openMenuDialog(ui.settingsDialog, ui.pauseSettingsButton); });
  ui.controlsCloseButton.addEventListener("click", function () { closeMenuDialog(ui.controlsDialog); });
  ui.settingsCloseButton.addEventListener("click", function () { closeMenuDialog(ui.settingsDialog); });
  ui.controlsDialog.addEventListener("close", restoreDialogFocus);
  ui.settingsDialog.addEventListener("close", restoreDialogFocus);
  ui.soundControl.addEventListener("change", function () { setSoundEnabled(ui.soundControl.value); });
  ui.volumeControl.addEventListener("input", function () {
    setVolume(ui.volumeControl.value);
    var preferences = audio.snapshot();
    if (preferences.soundEnabled && preferences.masterVolume > 0) ensureAudio();
  });
  ui.controlPresetControl.addEventListener("change", function () {
    controlPreset = ui.controlPresetControl.value === Input.CONTROL_PRESETS.keyboard ? Input.CONTROL_PRESETS.keyboard : Input.CONTROL_PRESETS.hybrid;
    clearPlayerInput();
  });
  ui.smartActionControl.addEventListener("change", function () {
    smartAction = ui.smartActionControl.value !== "off";
    clearPlayerInput();
    updateHud();
  });
  ui.touchControl.addEventListener("change", function () {
    touchMode = ["auto", "on", "off"].indexOf(ui.touchControl.value) === -1 ? "auto" : ui.touchControl.value;
    clearTouchInput();
    updateTouchVisibility();
  });
  window.addEventListener("resize", function () { resize(); clearPlayerInput(); updateTouchVisibility(); });
  window.addEventListener("orientationchange", function () { clearPlayerInput(); updateTouchVisibility(); });
  if (coarsePointerQuery.addEventListener) coarsePointerQuery.addEventListener("change", updateTouchVisibility);
  if (portraitQuery.addEventListener) portraitQuery.addEventListener("change", function () { clearPlayerInput(); updateTouchVisibility(); });

  syncAudioControls(audio.snapshot());
  touchMode = ui.touchControl.value;
  controlPreset = ui.controlPresetControl.value === Input.CONTROL_PRESETS.keyboard ? Input.CONTROL_PRESETS.keyboard : Input.CONTROL_PRESETS.hybrid;
  smartAction = ui.smartActionControl.value !== "off";
  if (onlineAvailable && Online.quickMatchAvailable()) {
    onlineMode = true;
    botCount = 2;
    ui.botCountControl.value = "2";
    ui.botCountLabel.textContent = "SERVER BOTS";
    ui.botCountHint.textContent = "FIXED ONLINE TOPOLOGY";
  }
  makeState();
  if (onlineAvailable) {
    ui.startOverlay.classList.add("is-online");
    if (Online.quickMatchAvailable()) ui.startButton.textContent = "QUICK MATCH";
    ui.onlineMatchPanel.hidden = false;
    if (Online.quickMatchAvailable()) ui.botCountControl.disabled = true;
    if (ui.networkStatus) {
      ui.networkStatus.hidden = false;
      ui.networkStatus.textContent = "ONLINE · TWO PLAYERS";
    }
    updateOnlineMenu(Online.getStatus());
  }
  ui.hud.hidden = true;
  updateTouchVisibility();
  requestAnimationFrame(frame);
}());
