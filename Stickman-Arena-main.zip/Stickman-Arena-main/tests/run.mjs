import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { pathToFileURL } from "node:url";

const root = path.resolve(import.meta.dirname, "..");
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");
const runtimeHashes = {
  "animation.js": "77d9ff11fb112c2b61c886aff8227f1ff2dfd36717f2eb524cc747c431bad539",
  "audio.js": "2290fb3409dad3bc2341582d0860cf90513fca4c800d33df0185023d63f572e3",
  "bot.js": "0d05a6274023b1e103f48c7bd56352eee416eb74b5097527e26b9e2c3c7c8763",
  "game.js": "aaa23e2fff96987054efe0a390bb6a984165dc8209082a96cef64d9b499948d9",
  "index.html": "5b281030ba586ca94a7d1187059b97633357b4de61b7fbe2efd2be0b38fc4ce9",
  "input.js": "87849c7dba2571d17e23951206861839aa3a1309cee36dfcb6eeab50fc1ea9f3",
  "multiplayer.js": "294f150deca1a5857dddecad573bb4c94fbf1638463438e75cf479714115495f",
  "online-client.js": "cfc6497aa228a7393030cb87f98b0e15bca359d3d75646a879ff3bd6fefb508d",
  "sim.js": "dfb849055ec7c697284afb4443744899205c2af47f076fbe259cc33bdf4bf918",
  "styles.css": "51570c46a508a05f1a9d74884924e2bf8e54ca6f0806430791277b4d89c85944",
  "touch.js": "dcbfbb76f83720478bf691b9d1a49b5edd7876955d7ccc3b619ea79ea2e415d5"
};

globalThis.window = globalThis;
await import(pathToFileURL(path.join(root, "sim.js")));
await import(pathToFileURL(path.join(root, "animation.js")));
await import(pathToFileURL(path.join(root, "bot.js")));
await import(pathToFileURL(path.join(root, "multiplayer.js")));
await import(pathToFileURL(path.join(root, "touch.js")));
await import(pathToFileURL(path.join(root, "input.js")));
await import(pathToFileURL(path.join(root, "audio.js")));

const Sim = globalThis.StickSim;
const Anim = globalThis.StickAnim;
const Bots = globalThis.StickBots;
const Multiplayer = globalThis.StickMultiplayer;
const Touch = globalThis.StickTouch;
const Input = globalThis.StickInput;
const Audio = globalThis.StickAudio;
const ARM_SEGMENTS = [
  ["shoulder", "elbowL"], ["elbowL", "wristL"],
  ["shoulder", "elbowR"], ["elbowR", "wristR"]
];
const LEG_SEGMENTS = [
  ["hip", "kneeL"], ["kneeL", "ankleL"],
  ["hip", "kneeR"], ["kneeR", "ankleR"]
];
const LIMB_SEGMENTS = [...ARM_SEGMENTS, ...LEG_SEGMENTS];

function poseGeometry(pose) {
  const geometry = {};
  for (const key of [...Anim.POINTS, "torsoTop"]) {
    geometry[key] = { x: pose[key].x, y: pose[key].y };
  }
  geometry.headRadius = pose.headRadius;
  geometry.weaponDir = { x: pose.weaponDir.x, y: pose.weaponDir.y };
  return geometry;
}

function worldPosePoint(fighter, point) {
  const scale = fighter.drawScale;
  return {
    x: fighter.x + point.x * scale,
    y: fighter.y - 61 * scale + point.y * scale
  };
}

function pointSegmentDistance(point, start, end) {
  const dx = end.x - start.x;
  const dy = end.y - start.y;
  const lengthSquared = dx * dx + dy * dy;
  const amount = Math.max(0, Math.min(1, lengthSquared
    ? ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared
    : 0));
  return Math.hypot(
    point.x - (start.x + dx * amount),
    point.y - (start.y + dy * amount)
  );
}

function elbowBendCross(pose, side) {
  const elbow = pose[`elbow${side}`];
  const wrist = pose[`wrist${side}`];
  return (wrist.x - pose.shoulder.x) * (elbow.y - pose.shoulder.y)
    - (wrist.y - pose.shoulder.y) * (elbow.x - pose.shoulder.x);
}

function assertPointNear(actual, expected, label, epsilon = 1e-9) {
  assert.ok(Math.abs(actual.x - expected.x) <= epsilon && Math.abs(actual.y - expected.y) <= epsilon,
    `${label}: (${actual.x}, ${actual.y}) != (${expected.x}, ${expected.y})`);
}

function assertPoseGeometryNear(actual, expected, label, epsilon = 1e-9) {
  for (const key of [...Anim.POINTS, "torsoTop"]) {
    assertPointNear(actual[key], expected[key], `${label}.${key}`, epsilon);
  }
  assert.ok(Math.abs(actual.headRadius - expected.headRadius) <= epsilon, `${label}.headRadius changed`);
  assertPointNear(actual.weaponDir, expected.weaponDir, `${label}.weaponDir`, epsilon);
}

function makeStorage(initialValue, options = {}) {
  const values = new Map();
  if (initialValue !== undefined) values.set(Audio.PREFERENCE_KEY, initialValue);
  return {
    values,
    reads: 0,
    writes: 0,
    readKeys: [],
    writeKeys: [],
    getItem(key) {
      this.reads += 1;
      this.readKeys.push(key);
      if (options.throwGet) throw new Error("storage read blocked");
      return values.has(key) ? values.get(key) : null;
    },
    setItem(key, value) {
      this.writes += 1;
      this.writeKeys.push(key);
      if (options.throwSet) throw new Error("storage write blocked");
      values.set(key, value);
    }
  };
}

class FakeAudioParam {
  constructor(value = 0) {
    this.value = value;
    this.calls = [];
  }

  cancelScheduledValues(time) {
    this.calls.push(["cancel", time]);
  }

  setValueAtTime(value, time) {
    this.value = value;
    this.calls.push(["set", value, time]);
  }

  exponentialRampToValueAtTime(value, time) {
    this.value = value;
    this.calls.push(["ramp", value, time]);
  }
}

class FakeAudioNode {
  constructor(kind) {
    this.kind = kind;
    this.connections = [];
    this.disconnects = 0;
  }

  connect(target) {
    this.connections.push(target);
    return target;
  }

  disconnect() {
    this.disconnects += 1;
  }
}

function makeAudioContextHarness(options = {}) {
  const contexts = [];
  class FakeAudioContext {
    constructor() {
      this.state = options.initialState || "suspended";
      this.currentTime = 4.25;
      this.sampleRate = 48000;
      this.destination = new FakeAudioNode("destination");
      this.gains = [];
      this.compressors = [];
      this.oscillators = [];
      this.sources = [];
      this.filters = [];
      this.buffers = [];
      this.resumeCalls = 0;
      this.resumeCatches = 0;
      this.closeCalls = 0;
      this.closeCatches = 0;
      contexts.push(this);
    }

    createGain() {
      const node = new FakeAudioNode("gain");
      node.gain = new FakeAudioParam(1);
      this.gains.push(node);
      return node;
    }

    createDynamicsCompressor() {
      const node = new FakeAudioNode("compressor");
      for (const name of ["threshold", "knee", "ratio", "attack", "release"]) {
        node[name] = new FakeAudioParam();
      }
      this.compressors.push(node);
      return node;
    }

    createOscillator() {
      const node = new FakeAudioNode("oscillator");
      node.frequency = new FakeAudioParam();
      node.startCalls = [];
      node.stopCalls = [];
      node.start = (...args) => {
        node.startCalls.push(args);
        if (options.startThrows) throw new Error("oscillator start blocked");
      };
      node.stop = (...args) => {
        node.stopCalls.push(args);
        if (options.stopThrows && node.stopCalls.length > (options.stopThrowsAfter || 0)) {
          throw new Error("oscillator stop blocked");
        }
      };
      node.onended = null;
      this.oscillators.push(node);
      return node;
    }

    createBufferSource() {
      const node = new FakeAudioNode("bufferSource");
      node.startCalls = [];
      node.stopCalls = [];
      node.start = (...args) => {
        node.startCalls.push(args);
        if (options.startThrows) throw new Error("source start blocked");
      };
      node.stop = (...args) => {
        node.stopCalls.push(args);
        if (options.stopThrows && node.stopCalls.length > (options.stopThrowsAfter || 0)) {
          throw new Error("source stop blocked");
        }
      };
      node.onended = null;
      node.buffer = null;
      this.sources.push(node);
      return node;
    }

    createBiquadFilter() {
      const node = new FakeAudioNode("filter");
      node.frequency = new FakeAudioParam();
      node.Q = new FakeAudioParam();
      node.type = "lowpass";
      this.filters.push(node);
      return node;
    }

    createBuffer(channels, sampleCount, sampleRate) {
      const samples = new Float32Array(sampleCount);
      const buffer = {
        channels,
        sampleRate,
        duration: sampleCount / sampleRate,
        getChannelData(channel) {
          assert.equal(channel, 0);
          return samples;
        }
      };
      this.buffers.push(buffer);
      return buffer;
    }

    resume() {
      this.resumeCalls += 1;
      if (options.resumeThrows) throw new Error("resume blocked");
      if (options.resumeRejects) {
        return { catch: (callback) => { this.resumeCatches += 1; callback(new Error("resume rejected")); } };
      }
      this.state = "running";
      return Promise.resolve();
    }

    close() {
      this.closeCalls += 1;
      if (options.closeThrows) throw new Error("close blocked");
      if (options.closeRejects) {
        return { catch: (callback) => { this.closeCatches += 1; callback(new Error("close rejected")); } };
      }
      this.state = "closed";
      return Promise.resolve();
    }
  }
  return { AudioContext: FakeAudioContext, contexts };
}

function maxPosePointDelta(actual, expected, points = Anim.POINTS) {
  return Math.max(...points.map((key) =>
    Math.hypot(actual[key].x - expected[key].x, actual[key].y - expected[key].y)));
}

function neutralActor(fighter) {
  return {
    id: fighter.id,
    moveX: 0,
    moveY: 0,
    aimX: fighter.facing,
    aimY: 0,
    weaponSlot: null,
    buttons: { jump: false, attack: false, pickup: false, reload: false, drop: false }
  };
}

function neutralHuman(state) {
  return neutralActor(state.fighters[0]);
}

function placeAtPickup(fighter, pickup, platformId = 8) {
  Object.assign(fighter, {
    x: pickup.x,
    y: pickup.y + 35,
    prevX: pickup.x,
    prevY: pickup.y + 35,
    vx: 0,
    vy: 0,
    prevVx: 0,
    prevVy: 0,
    grounded: true,
    prevGrounded: true,
    platformId,
    dropThrough: 0,
    dead: false,
    hitstun: 0
  });
}

function stepPickup(state, held) {
  const actor = neutralHuman(state);
  actor.buttons.pickup = held;
  Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
}

function allBots(state) {
  return {
    tick: state.tick,
    actors: state.fighters.map((fighter) => Bots.makeBotInput(state, fighter))
  };
}

function legacyPass10Projection(state) {
  const projected = JSON.parse(Sim.serialize(state));
  projected.version = 4;
  delete projected.config.humanCount;
  delete projected.config.modeId;
  delete projected.config.mapId;
  return JSON.stringify(projected);
}

function placeBotFixtureFighter(fighter, x, y, platformId = null) {
  Object.assign(fighter, {
    x,
    y,
    prevX: x,
    prevY: y,
    vx: 0,
    vy: 0,
    prevVx: 0,
    prevVy: 0,
    grounded: platformId !== null,
    prevGrounded: platformId !== null,
    platformId,
    dropThrough: 0,
    health: fighter.maxHealth,
    dead: false,
    respawn: 0,
    invuln: 0,
    hitstun: 0,
    cooldown: 0,
    reload: 0,
    attack: null,
    prevButtons: {
      jump: false, attack: false, pickup: false,
      reload: false, drop: false, rematch: false
    }
  });
}

function equipBotFixtureWeapon(fighter, weapon) {
  Sim.grantWeapon(fighter, weapon, true);
  fighter.weapon = weapon;
}

function keepOnlyPickup(state, id) {
  for (const pickup of state.pickups) pickup.active = pickup.id === id;
}

function spawnTier(fighter) {
  if ([0, 7].includes(fighter.platformId)) return "low";
  if ([1, 2, 3].includes(fighter.platformId)) return "middle";
  if ([4, 5, 6].includes(fighter.platformId)) return "high";
  return "invalid";
}

function assertSafeSpawn(state, fighter, checkSeparation = true) {
  const platform = state.arena.platforms.find((candidate) => candidate.id === fighter.platformId);
  assert.ok(platform, `fighter ${fighter.id} has no supporting platform`);
  assert.equal(fighter.y, platform.y);
  const edgeMargin = Sim.RULES.fighterRadius + 20;
  assert.ok(fighter.x >= platform.x + edgeMargin, `fighter ${fighter.id} is too close to the left edge`);
  assert.ok(fighter.x <= platform.x + platform.w - edgeMargin, `fighter ${fighter.id} is too close to the right edge`);
  assert.notEqual(spawnTier(fighter), "invalid");
  for (const pickup of state.pickups) {
    const distance = Math.hypot(pickup.x - fighter.x, pickup.y - (fighter.y - 35));
    assert.ok(distance > Sim.RULES.pickupRadius,
      `fighter ${fighter.id} spawned ${distance}px from pickup ${pickup.id}`);
  }
  for (const hazard of state.arena.hazards) {
    const insideHazard = fighter.x > hazard.x && fighter.x < hazard.x + hazard.w && fighter.y > hazard.y;
    assert.equal(insideHazard, false, `fighter ${fighter.id} spawned in hazard ${hazard.id}`);
  }
  if (checkSeparation) {
    for (const other of state.fighters) {
      if (other.id === fighter.id) continue;
      const distance = Math.hypot(other.x - fighter.x, other.y - fighter.y);
      assert.ok(distance >= Sim.RULES.fighterHeight,
        `fighters ${fighter.id} and ${other.id} spawned only ${distance}px apart`);
    }
  }
}

function walkFiles(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    if (entry.name === ".git" || entry.name === "node_modules") return [];
    const absolute = path.join(directory, entry.name);
    return entry.isDirectory() ? walkFiles(absolute) : [absolute];
  });
}

test("repository contract and public version are consistent", () => {
  const agents = read("AGENTS.md");
  const contributing = read("CONTRIBUTING.md");
  const roadmap = read("docs/ROADMAP.md");
  const status = read("docs/STATUS.md");
  const pullRequestTemplate = read(".github/pull_request_template.md");
  const version = read("VERSION.txt").trim();
  const readme = read("README.md");
  const html = read("index.html");
  const packageJson = JSON.parse(read("package.json"));
  const canonicalStandard = "**Repository Standard:** [Canonical Repository Standard]" +
    "(https://github.com/XenoVoyage/Helios/blob/main/REPOSITORY_STANDARD.md)";
  assert.ok(agents.slice(0, 500).includes(canonicalStandard),
    "AGENTS.md must link the canonical Repository Standard near the top");
  assert.equal(agents.split(canonicalStandard).length - 1, 1,
    "AGENTS.md must declare the canonical Repository Standard exactly once");
  assert.equal((agents.match(/^\*\*Standard Status:\*\* adopting$/gm) || []).length, 1,
    "AGENTS.md must have one exact adopting status");
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CONTRIBUTING.md", contributing],
    ["docs/ROADMAP.md", roadmap],
    ["docs/STATUS.md", status],
    [".github/pull_request_template.md", pullRequestTemplate]
  ]) {
    assert.doesNotMatch(document,
      /(?:Project\s+)?Engineering Standard[^\n]*(?:v(?:ersion)?\s*\d+(?:\.\d+)+|edition\s+\d+)/i,
      `${file} retained the obsolete numbered engineering-standard marker`);
  }
  assert.deepEqual(walkFiles(root).filter((file) =>
    /(?:repository|engineering)[._ -]*standard.*\.(?:md|txt)$/i.test(path.basename(file))), [],
  "the canonical generic standard or a numbered derivative must not be copied into this repository");
  assert.ok(status.includes(canonicalStandard),
    "Status must point to the same canonical Repository Standard");
  assert.equal((status.match(/^\*\*Standard Status:\*\* adopting$/gm) || []).length, 1,
    "Status must record one exact adopting marker");
  for (const provenance of [
    "24342310785a8254fcf3f079bdfea2f7d7cde1a2",
    "e9f1498c12f6f3ad51bb3d7ec53c83b993a54f71",
    "10ad6f8aa5cf2a572acb87f4801997af7cc7ec1c",
    "18d9372e277df046561f3ee00fed5fa792ef077d",
    "cbec0d19d852b9d5e14f04f92263f8267d6f0c34",
    "21294292",
    "21563361",
    "do_not_enforce_on_create=true",
    "@colyseus/schema` `5.0.22` behind current stable `5.0.23",
    "No Git tag or GitHub Release exists",
    "https://github.com/XenoVoyage/Stickman-Arena/issues/70"
  ]) assert.ok(status.includes(provenance), `Status is missing adoption provenance ${provenance}`);
  for (const protectionException of [
    "owner-approved local exception",
    "waives the required-status-check rule only when the `develop` ref is created",
    "does not satisfy full canonical protection"
  ]) assert.ok(status.includes(protectionException),
    `Status is missing the scoped owner-approved protection exception: ${protectionException}`);
  assert.doesNotMatch(status,
    /(?:remove|disable|removing)[^\n]{0,120}do_not_enforce_on_create|owner settings gate/i,
    "Status must not describe the owner-retained creation exception as a pending settings action");
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CONTRIBUTING.md", contributing],
    ["docs/ROADMAP.md", roadmap]
  ]) {
    assert.ok(document.includes("agent/issue-<number>-<description>"),
      `${file} must name the routine issue-branch pattern`);
    assert.match(document, /(?:draft )?pull request[\s\S]{0,240}(?:target(?:ing|s)?|into) `develop`/i,
      `${file} must route routine issue pull requests into develop`);
    assert.match(document, /`develop`[\s\S]{0,180}(?:→|into|to)[\s\S]{0,80}(?:Production )?`main`/i,
      `${file} must preserve the develop-to-main release route`);
    assert.match(document, /merge commit/i,
      `${file} must require merge-commit promotion on the release route`);
  }
  assert.ok(pullRequestTemplate.includes(
    "agent/issue-<number>-<description> -> develop / develop -> main / exact approved emergency route"),
    "the pull-request template must distinguish issue, release, and emergency routes");
  assert.match(pullRequestTemplate, /\| Production `main` \| \| \|[\s\S]*\| Alpha `develop` \| \| \|/);
  assert.match(pullRequestTemplate,
    /Canonical-standard provenance when applicable:[^\n]*exact production commit, tree, and standard-file blob/);
  assert.match(pullRequestTemplate, /asset, license, source\/provenance, and deployment non-change evidence/);
  assert.equal(version, "v2026.9.2");
  assert.equal(`v${packageJson.version}`, version);
  assert.equal(packageJson.dependencies, undefined);
  assert.equal(packageJson.devDependencies, undefined);
  assert.ok(readme.includes(version));
  const menuVersions = [...html.matchAll(/<small class="menu-version">([^<]+)<\/small>/g)];
  assert.equal(menuVersions.length, 1, "main menu must show exactly one public version label");
  assert.equal(menuVersions[0][1].trim(), version, "main-menu version drifted from VERSION.txt");
  for (const file of [
    "README.md", "LICENSE", "AGENTS.md", "VERSION.txt", "CHANGELOG.md",
    "CONTRIBUTING.md", "SECURITY.md", "docs/ARCHITECTURE.md",
    "docs/GAME_DESIGN.md", "docs/STATUS.md", "docs/ROADMAP.md",
    "docs/MULTIPLAYER_ARCHITECTURE.md", "docs/ASSETS.md"
  ]) assert.ok(fs.statSync(path.join(root, file)).size > 0, `${file} is required`);
});

test("approved roadmap stays ordered, gated, and offline-safe", () => {
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const readme = read("README.md");
  const roadmap = read("docs/ROADMAP.md");
  const gameDesign = read("docs/GAME_DESIGN.md");
  const multiplayer = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const status = read("docs/STATUS.md");
  const boundedSection = (document, start, end, label) => {
    const startIndex = document.indexOf(start);
    const endIndex = document.indexOf(end, startIndex + start.length);
    assert.ok(startIndex >= 0 && endIndex > startIndex, `${label} section boundaries must remain present and ordered`);
    return document.slice(startIndex, endIndex);
  };
  const roadmapA3 = boundedSection(roadmap,
    "#### Pass 12A3 — Node 24 LTS maintenance update",
    "#### Pass 12B3B1",
    "Pass 12A3 roadmap");
  const statusA3 = boundedSection(status,
    "## Pass 12A3 Node 24 LTS maintenance update",
    "## Earlier Pass 7 evidence",
    "Pass 12A3 status");
  const changelogA3 = boundedSection(changelog,
    "## Pass 12A3 Node 24 LTS maintenance update",
    "## Pass 12B3A local room matchmaking",
    "Pass 12A3 changelog");
  const multiplayerContinuation = boundedSection(multiplayer,
    "## Ordered continuation",
    "Pass 13 may then",
    "multiplayer ordered continuation");
  const orderedHeadings = [
    "### Pass 2", "### Pass 3A", "### Pass 3B", "### Pass 4",
    "### Pass 5", "### Pass 6", "### Pass 7", "### Pass 8",
    "### Pass 9", "### Pass 10", "### Pass 11", "### Pass 12",
    "### Pass 13", "### Pass 14", "### Pass 15", "### Pass 16",
    "## Final release closeout"
  ];
  const orderedIndexes = orderedHeadings.map((heading) => roadmap.indexOf(heading));

  assert.match(roadmap, /not permission to start or merge a pass/i);
  assert.ok(orderedIndexes.every((index, position) =>
    index >= 0 && (position === 0 || orderedIndexes[position - 1] < index)),
  "approved passes must remain in dependency order");
  assert.match(roadmap, /### Pass 8 — audio usability \(complete\)/);
  assert.match(roadmap, /### Pass 9 — compatibility evidence and targeted fixes \(complete\)/);
  assert.match(roadmap, /### Pass 10 — mode and map foundation \(complete\)/);
  assert.match(roadmap, /### Pass 11 — authoritative multiplayer vertical slice \(complete\)/);
  assert.match(agents, /Passes 7–11[^\n]+implemented, merged, and deployed[^\n]+Pass 12A establishes[^\n]+repository-closeout complete through pull request #46/);
  assert.match(changelog, /## Pass 8 audio usability — deployed 2026-08-25/);
  assert.match(changelog, /## Pass 9 compatibility — deployed 2026-08-26/);
  assert.match(changelog, /## Pass 10 mode\/map foundation — deployed 2026-08-26/);
  assert.match(changelog, /## Pass 11 authoritative multiplayer vertical slice — deployed 2026-08-26/);
  assert.match(readme, /Passes 1–11, Pass 12A, Pass 12B1, Pass 12B2, the dependency-only Pass 12A2, Pass 12B3A, Pass 12A3, Pass 12B3B1, Pass 12B3B2, Pass 12B4A, and dependency-only Pass 12A4 are merged and deployed to their approved extents[\s\S]*Pass 12B3A adds the local anonymous Quick\/Create\/Join Code room UX[\s\S]*remain gated/);
  assert.match(gameDesign, /implemented and merged Pass 11 slice adds a separate local developer route/);
  assert.match(gameDesign, /Pass 12A through Pass 12B4B[\s\S]*repository evidence closeouts through pull request #66[\s\S]*Pass 12B2 adds only server-owned online match generations/);
  assert.match(multiplayer, /Pass 12A replaced the umbrella package with the official modular surface/);
  assert.match(status, /Passes 1–11[^\n]+repository-closeout complete through pull request #56/);
  assert.match(status, /Pass 12A[^\n]+Node\.js 24\.19\.0 LTS/);
  for (const runId of ["32950098376", "32950232790", "32950232778", "32950232769"]) {
    assert.ok(roadmap.includes(runId) && status.includes(runId), `Pass 11 run ${runId} must remain recorded`);
  }
  for (const runId of ["32961702662", "32961815211", "32961815200", "32961815157"]) {
    assert.ok(roadmap.includes(runId) && status.includes(runId), `Pass 12A run ${runId} must remain recorded`);
  }
  for (const runId of ["32973699456", "32973886787", "32973886882", "32973886791"]) {
    assert.ok(roadmap.includes(runId) && status.includes(runId), `Pass 12B1 run ${runId} must remain recorded`);
  }
  for (const runId of ["32989974986", "32997496646", "32997496619", "32997496727"]) {
    assert.ok(roadmap.includes(runId) && status.includes(runId), `Pass 12B2 run ${runId} must remain recorded`);
  }
  for (const runId of ["33001822469", "33002006032", "33002006053", "33002006017"]) {
    assert.ok(roadmap.includes(runId) && status.includes(runId), `Pass 12A2 run ${runId} must remain recorded`);
  }
  for (const [label, number, runId] of [
    ["pull-request Baseline", 137, "33009937010"],
    ["merged-main Baseline", 138, "33010123572"],
    ["checksum-gated Pages", 48, "33010123622"],
    ["cleanup", 40, "33010123652"]
  ]) {
    const evidence = new RegExp(`${label} \\[run #${number}\\]\\(https:\\/\\/github\\.com\\/XenoVoyage\\/Stickman-Arena\\/actions\\/runs\\/${runId}\\)`);
    assert.match(roadmap, evidence, `Pass 12B3A ${label} #${number} must remain associated with ${runId}`);
    assert.match(status, evidence, `Pass 12B3A status must associate ${label} #${number} with ${runId}`);
  }
  for (const [label, number, runId] of [
    ["pull-request Baseline", 143, "33014162753"],
    ["merged-main Baseline", 144, "33014278019"],
    ["checksum-gated Pages", 50, "33014278013"],
    ["cleanup", 42, "33014277983"]
  ]) {
    const evidence = new RegExp(`${label} \\[run #${number}\\]\\(https:\\/\\/github\\.com\\/XenoVoyage\\/Stickman-Arena\\/actions\\/runs\\/${runId}\\)`);
    assert.match(roadmapA3, evidence, `Pass 12A3 ${label} #${number} must remain associated with ${runId}`);
    assert.match(statusA3, evidence, `Pass 12A3 status must associate ${label} #${number} with ${runId}`);
  }
  assert.match(roadmap, /#### Pass 12A — supported runtime and dependency baseline \(complete\)/);
  assert.match(roadmap, /#### Pass 12B1 — protocol compatibility and loopback admission \(complete\)/);
  assert.match(roadmap, /#### Pass 12B2 — authoritative match generations \(complete\)/);
  assert.match(roadmap, /#### Pass 12A2 — Schema patch maintenance \(complete\)/);
  assert.match(roadmap, /#### Pass 12B3A — local room matchmaking UX \(complete\)/);
  assert.match(roadmap, /#### Pass 12A3 — Node 24 LTS maintenance update \(complete\)/);
  const roadmapB3B1Index = roadmap.indexOf("#### Pass 12B3B1");
  const roadmapB3B2Index = roadmap.indexOf("#### Pass 12B3B2");
  assert.ok(roadmap.indexOf("#### Pass 12A3 — Node 24 LTS maintenance update (complete)") <
    roadmapB3B1Index && roadmapB3B1Index < roadmapB3B2Index,
  "Pass 12A3, Pass 12B3B1, and Pass 12B3B2 must remain ordered");
  assert.match(status, /Passes 1–11, Pass 12A, Pass 12B1, Pass 12B2, Pass 12A2, Pass 12B3A, and Pass 12A3 are repository-closeout complete through pull request #56; Pass 12B3B1 evidence is recorded through closeout pull request #58, Pass 12B3B2 evidence through closeout pull request #60, Pass 12B4A evidence through closeout pull request #62, Pass 12A4 evidence through closeout pull request #64, and Pass 12B4B evidence through closeout pull request #66/);
  assert.match(status, /## Pass 12A2 Schema patch maintenance — complete[\s\S]*stable latest tag[\s\S]*5\.0\.21/);
  assert.match(status, /registry diff includes built runtime JavaScript[\s\S]*@colyseus\/schema` `5\.0\.21`/);
  assert.ok(status.includes("781d1003cb99a6f3d31a905117d20587ab3b6206") &&
    status.includes("f083c58e50ddfbc2703e2595f8f95a97abc887ed"),
  "Pass 12A2 merge and reviewed tree must remain recorded");
  assert.ok(status.includes("38994e0d632c472d987f45214de7923ee6a00269") &&
    status.includes("f7fe6a4ad34a8fdae41f5530d4a5eb5a9a4f5455"),
  "Pass 12B3A merge and reviewed tree must remain recorded");
  assert.match(changelog, /## Pass 12A2 Schema patch maintenance — deployed 2026-08-26/);
  assert.match(changelog, /## Pass 12B3A local room matchmaking — deployed 2026-08-26/);
  assert.match(statusA3, /Node\.js 24\.20\.0 Latest LTS[\s\S]*Node\.js 26\.8\.0 remains Current/);
  assert.match(statusA3, /## Pass 12A3 Node 24 LTS maintenance update — complete[\s\S]*semver-minor[\s\S]*2026-10-28/);
  assert.match(statusA3, /Checksum-verified official Linux binaries reproduced 123\/123 root and 110\/110 server tests[\s\S]*Node\.js 22\.23\.2/);
  assert.match(roadmapA3, /24\.19\.0 to official Node\.js 24\.20\.0 Latest LTS[\s\S]*semver-minor[\s\S]*npm 11\.19\.0/);
  assert.match(changelogA3, /## Pass 12A3 Node 24 LTS maintenance update — deployed 2026-08-26[\s\S]*Node\.js 24\.20\.0 Latest LTS[\s\S]*semver-minor/);
  assert.ok(statusA3.includes("b4f960dbf6404e4d427ff8c22f3cf84b58efcd95") &&
    statusA3.includes("927bf0d689e35db2d37aca2a4b5b9a7ec19d7489") &&
    statusA3.includes("e4d09ea0997f9617136c3ff7da1d49596416add7"),
  "Pass 12A3 candidate, merge, and reviewed tree must remain recorded");
  assert.match(statusA3, /evidence-closeout pull request #56/);
  assert.match(agents, /Pass 12A3 updates only[^\n]+e4d09ea0997f9617136c3ff7da1d49596416add7[^\n]+927bf0d689e35db2d37aca2a4b5b9a7ec19d7489[^\n]+evidence-closeout pull request #56/);
  assert.match(multiplayerContinuation, /Pass 12A3 maintenance update are merged, verified, deployed to their approved offline extent[\s\S]*pull request #56/);
  assert.match(status, /Pass 12B2 authoritative match generations — deployed/);
  assert.match(status, /ed8e04457dd0ceec4234f838fee80b0e3f245195[\s\S]*3341fef34eaad8191d43bf6ad347f73cf87c245a/);
  assert.ok(roadmap.includes("43be4066282e2d84865d0c6265e50503da19df06") && status.includes("43be4066282e2d84865d0c6265e50503da19df06"), "Pass 12B2 restored PR head must remain recorded");
  assert.match(status, /3a81f44f17ff5779601976bad1354a6142b9f309[\s\S]*6c57b2a0f46ab77d693bb35afb96a6e225e72a2e/);
  assert.match(status, /real local two-tab Canvas audit[^|]+remains unclaimed/);
  assert.match(roadmap, /Do not start a later pass before the current pass is merged, deployed, verified, and cleaned up\./);
  assert.match(multiplayer, /Online support does not remove or weaken `file:\/\/` play\./);
  assert.match(multiplayer, /Room's call to `fixedUpdate\(state, inputs, 1 \/ 60\)` is the only canonical online result/);
  assert.match(multiplayer, /No public Node service, provider, region, billing, domain, secret, account, database/);
  assert.match(multiplayerContinuation, /Pass 12B1, Pass 12B2, the separately bounded Pass 12A2 Schema patch maintenance, Pass 12B3A, and the exact Node 24\.20\.0 semver-minor Pass 12A3 maintenance update are merged, verified, deployed to their approved offline extent[\s\S]*evidence closeouts through pull request #56/);
});

test("Pass 12A server baseline stays supported, exact, and offline-isolated", () => {
  const rootPackage = JSON.parse(read("package.json"));
  const serverPackage = JSON.parse(read("server/package.json"));
  const lock = JSON.parse(read("server/package-lock.json"));
  const ci = read(".github/workflows/ci.yml");
  const pages = read(".github/workflows/pages.yml");
  const nodeVersion = read(".nvmrc").trim();
  const gitignore = read(".gitignore");
  const sim = read("sim.js");
  const sharedRuntime = read("server/src/shared-runtime.mjs");
  const serverEntry = read("server/src/index.mjs");
  const startup = read("server/src/startup.mjs");
  const appConfig = read("server/src/app.config.mjs");
  const room = read("server/src/arena-room.mjs");
  const aggregator = read("server/src/input-aggregator.mjs");
  const online = read("online-client.js");
  const game = read("game.js");
  const agents = read("AGENTS.md");
  const readme = read("README.md");
  const contributing = read("CONTRIBUTING.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayerArchitecture = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const testGuide = read("tests/README.md");

  assert.equal(rootPackage.dependencies, undefined);
  assert.equal(rootPackage.devDependencies, undefined);
  assert.equal(rootPackage.engines.node, ">=22");
  assert.equal(serverPackage.engines.node, ">=22");
  assert.deepEqual(serverPackage.dependencies, {
    "@colyseus/core": "0.18.8",
    "@colyseus/schema": "5.0.23",
    "@colyseus/sdk": "0.18.2",
    "@colyseus/tools": "0.18.3",
    "@colyseus/ws-transport": "0.18.2",
    express: "5.2.1"
  });
  assert.deepEqual(serverPackage.devDependencies, { "@colyseus/testing": "0.18.5" });
  assert.deepEqual(lock.packages[""].dependencies, serverPackage.dependencies);
  assert.deepEqual(lock.packages[""].devDependencies, serverPackage.devDependencies);
  assert.equal(lock.packages["node_modules/@colyseus/schema"].version, "5.0.23");
  assert.equal(lock.packages["node_modules/@colyseus/schema"].resolved, "https://registry.npmjs.org/@colyseus/schema/-/schema-5.0.23.tgz");
  assert.equal(lock.packages["node_modules/@colyseus/schema"].integrity, "sha512-6fXSIjqBoEYw4PBs4vvzpFL0vGRAQ9ezwxILpazb+Uw2/qsbgUt+F4DGNYzecsdTogsrpHETqHYDlkI783RUig==");
  for (const unused of [
    "@colyseus/auth", "@colyseus/monitor", "@colyseus/playground",
    "@colyseus/redis-driver", "@colyseus/redis-presence", "colyseus"
  ]) assert.equal(lock.packages[`node_modules/${unused}`], undefined, `${unused} remained in the lock`);
  assert.equal(nodeVersion, "24.20.0");
  assert.match(ci, /audit:[\s\S]*Use Node\.js 24\.20\.0[\s\S]*node-version: 24\.20\.0/);
  assert.match(ci, /audit:[\s\S]*node-version: 24\.20\.0[\s\S]*name: Run deterministic baseline tests\s+run: npm test[\s\S]*name: Install pinned multiplayer server dependencies\s+run: npm ci --prefix server --ignore-scripts[\s\S]*name: Run authoritative multiplayer tests\s+run: npm --prefix server test[\s\S]*name: Audit production dependencies for high severity\s+run: npm audit --prefix server --omit=dev --audit-level=high[\s\S]*name: Verify frozen source checksums\s+run: sha256sum --check SHA256SUMS[\s\S]*name: Check whitespace errors\s+run: git diff --check HEAD\^[\s\S]*node-version: 22[\s\S]*name: Run dependency-free root compatibility tests\s+run: npm test[\s\S]*name: Install pinned multiplayer server dependencies for compatibility\s+run: npm ci --prefix server --ignore-scripts[\s\S]*name: Run authoritative multiplayer compatibility tests\s+run: npm --prefix server test/);
  assert.doesNotMatch(ci, /^\s{2}node-22-compatibility:/m,
    "the supported Node 22 phase must not sit outside the only required audit check");
  assert.match(ci, /npm ci --prefix server --ignore-scripts/);
  assert.match(ci, /npm --prefix server test/);
  assert.match(ci, /npm audit --prefix server --omit=dev --audit-level=high/);
  assert.match(agents, /\.nvmrc`, primary CI, and production guidance use Node\.js 24\.20\.0 LTS/);
  assert.match(readme, /Use the Node\.js 24\.20\.0 LTS version declared in `\.nvmrc`/);
  assert.match(contributing, /Node\.js 24\.20\.0 LTS in `\.nvmrc` is the default development, primary-CI, and production baseline/);
  assert.match(architecture, /\.nvmrc` and the primary phase of that job use Node\.js 24\.20\.0 LTS/);
  assert.match(multiplayerArchitecture, /Use Node\.js 24\.20\.0 from `\.nvmrc` for the default development path/);
  assert.match(testGuide, /Node\.js 24\.20\.0 from `\.nvmrc` is the default and primary-CI runtime/);
  assert.match(pages, /cp -- index\.html styles\.css sim\.js animation\.js bot\.js touch\.js input\.js audio\.js multiplayer\.js online-client\.js game\.js _site\//);
  assert.doesNotMatch(pages, /\bserver\//);
  assert.match(gitignore, /^\.env\*$/m);
  assert.match(gitignore, /^\.colyseus-cloud\.json$/m);

  assert.doesNotMatch(sim, /^\s*(?:import|export)[^\n]*colyseus/im);
  assert.doesNotMatch(sim, /sessionId|WebSocket/);
  assert.match(sharedRuntime, /import\("\.\.\/\.\.\/sim\.js"\)[\s\S]*import\("\.\.\/\.\.\/animation\.js"\)[\s\S]*import\("\.\.\/\.\.\/bot\.js"\)/);
  assert.match(appConfig, /from "@colyseus\/core"/);
  assert.match(room, /from "@colyseus\/core"/);
  assert.doesNotMatch(appConfig, /from "colyseus"/);
  assert.doesNotMatch(room, /from "colyseus"/);
  const configIndex = serverEntry.indexOf("runtimeConfig = createRuntimeConfig(process.env)");
  const startupIndex = serverEntry.indexOf("startConfiguredApplication(runtimeConfig");
  assert.ok(configIndex >= 0 && startupIndex > configIndex,
    "validated runtime configuration must precede every Colyseus application import");
  assert.doesNotMatch(serverEntry, /from "\.\/app\.config\.mjs"/,
    "invalid configuration must fail before framework initialization");
  assert.match(startup, /import\("\.\/app\.config\.mjs"\)/);
  assert.match(startup, /application\.listen\(\)/);
  assert.match(appConfig, /export function createApplication\(runtimeConfig, options = \{\}\)/);
  assert.match(room, /setFixedTimestep\(\(context\) => this\.fixedStep\(context\), 60\)/);
  assert.match(room, /ready: \(client, payload\) => this\.receiveReady\(client, payload\)/);
  assert.match(room, /receiveHelloAck\(client, payload\)[\s\S]*this\.completeAdmission\(client\)/);
  assert.match(room, /completeAdmission\(client\)[\s\S]*this\.match\.bind[\s\S]*this\.sendAssignment\(client\)/,
    "the exact protocol acknowledgement must precede actor binding and assignment");
  assert.match(room, /receiveReady\(client, payload\)[\s\S]*this\.sendBootstrap\(client\)[\s\S]*this\.startIfReady\(\)/,
    "the assigned client must explicitly become ready before snapshot bootstrap and start");
  assert.match(room, /this\.readySessions\.size !== ONLINE_HUMAN_COUNT/,
    "the match must wait until both bound clients registered handlers and declared ready");
  assert.match(room, /onDrop\(client, code\)[\s\S]*this\.readySessions\.delete\(client\.sessionId\)/,
    "a dropped client must become unready before it can reconnect");
  assert.match(room, /this\.lifecycle !== "playing"/);
  assert.match(aggregator, /if \(buttons\.rematch\) return null/);
  assert.doesNotMatch(aggregator, /Bots\.makeInputs|makeInputs\(/);

  assert.match(online, /root\.location\.protocol === "file:"/);
  assert.match(online,
    /PAGES_ORIGIN = "https:\/\/xenovoyage\.github\.io"[\s\S]*CLOUD_SERVER_ORIGIN = "https:\/\/de-fra-1131bd95\.colyseus\.cloud"/);
  assert.match(online, /get\("online"\) === "1"/);
  assert.match(online, /script\.src = serverOrigin\(\) \+ "\/online-sdk\.js"/);
  assert.match(online, /new Colyseus\.Client\(serverOrigin\(\)\)/);
  assert.match(online, /room\.reconnection\.maxEnqueuedMessages = 0/);
  assert.match(online, /status !== "playing"/);
  assert.equal((online.match(/https:\/\/de-fra-1131bd95\.colyseus\.cloud/g) || []).length, 1);
  assert.match(game, /onlineMode && nextPortraitBlocked && started\) Online\.sendNeutral\(\)/);
  assert.match(game, /var onlineAvailable = Online\.requested\(\);[\s\S]*var onlineMode = false/);
  assert.match(game,
    /function startMatch\(\)[\s\S]*onlineAvailable && Online\.quickMatchAvailable\(\)[\s\S]*onlineMode = false[\s\S]*makeState\(nextMatchSeed\(\)\)/);
  assert.match(game,
    /function restoreOfflineBotSettings\(\)[\s\S]*offlineBotCountValue[\s\S]*OPPONENTS[\s\S]*APPLIES NEXT MATCH/);
  assert.match(game, /function fighterLabel\(fighter\)[\s\S]*!fighter\.isBot[\s\S]*localActorId/);
  assert.match(game, /Online\.setRematchVote\(!connection\.rematchVoted\)/);
  assert.match(game, /terminalConnection = connection\.state === "error" \|\| connection\.state === "closed"[\s\S]*terminalConnection && !onlineTerminalPresented[\s\S]*show\(ui\.startOverlay, true\)[\s\S]*ui\.hud\.hidden = true/,
    "a pre-start or fresh-generation close must restore the retryable Play overlay");
  assert.match(game, /if \(!terminalConnection\) onlineTerminalPresented = false[\s\S]*if \(terminalConnection && !onlineTerminalPresented\)[\s\S]*onlineTerminalPresented = true[\s\S]*var retryControl =[\s\S]*retryControl\.focus/,
    "terminal transition recovery must move focus once to the relevant retry control");
  assert.match(game, /function showOnlineGenerationTransition\(connection\)[\s\S]*state = null[\s\S]*ctx\.setTransform\(1, 0, 0, 1, 0, 0\)[\s\S]*ctx\.fillRect\(0, 0, canvas\.width, canvas\.height\)[\s\S]*ui\.hud\.hidden = true[\s\S]*ui\.rematchButton\.hidden = true[\s\S]*show\(ui\.resultOverlay, true\)[\s\S]*ui\.resultMainMenuButton\.focus/,
    "a fresh-generation ready barrier must cover and discard prior-generation presentation");
  assert.match(game, /generationTransition = !connection\.started[\s\S]*connection\.lifecycle === "restarting"[\s\S]*connection\.generation > 1[\s\S]*connection\.lifecycle === "waiting"[\s\S]*connection\.lifecycle === "ready"[\s\S]*showOnlineGenerationTransition\(connection\)/,
    "every bounded rematch transition phase must keep a visible surface");
  assert.match(game, /connection\.generation !== onlineGeneration[\s\S]*if \(!onlineTransition\) show\(ui\.resultOverlay, false\)/,
    "a generation assignment must not hide and blur an already-active transition dialog");
  assert.match(game, /showOnlineGenerationTransition\(connection\)[\s\S]*connection\.state === "reconnecting"[\s\S]*"RECONNECTING"[\s\S]*"Restoring your reserved seat within the bounded reconnect window\."/,
    "a dropped fresh-generation client must see reconnecting rather than stale readiness copy");
  assert.match(game, /var onlineState = Online\.renderState\(\)[\s\S]*if \(onlineState && !onlineTransition\) state = onlineState[\s\S]*connection\.started && onlineState && !started[\s\S]*onlineTransition = false[\s\S]*state = onlineState/,
    "fresh authoritative state must remain behind the transition surface until match-start");
  assert.match(game, /canvas\.addEventListener\("pointerenter"[\s\S]*if \(state && !touchPortraitBlocked/,
    "the generation transition's null render state must reject pointer entry");
  assert.match(game, /ui\.pauseTitle\.textContent = "MATCH MENU"/);
});

test("Pass 12B compatibility, admission, and generation contracts cannot drift into gameplay authority", () => {
  const aggregator = read("server/src/input-aggregator.mjs");
  const authoritative = read("server/src/authoritative-match.mjs");
  const room = read("server/src/arena-room.mjs");
  const boundary = read("server/src/protocol-boundary.mjs");
  const appConfig = read("server/src/app.config.mjs");
  const stateSchema = read("server/src/state-schema.mjs");
  const online = read("online-client.js");
  const rootKeysBlock = aggregator.match(
    /export const INPUT_ROOT_KEYS = Object\.freeze\(\[([\s\S]*?)\]\);/
  );
  const buttonKeysBlock = aggregator.match(
    /export const INPUT_BUTTON_KEYS = Object\.freeze\(\[([\s\S]*?)\]\);/
  );
  assert.ok(rootKeysBlock && buttonKeysBlock);
  const quotedValues = (block) => [...block.matchAll(/"([^"]+)"/g)].map((match) => match[1]);

  assert.equal(Multiplayer.ONLINE_PROTOCOL_VERSION, 3);
  assert.equal(Multiplayer.SERVER_BUILD_ID, "pass12b4b-shutdown");
  assert.equal(Multiplayer.SIMULATION_SCHEMA_VERSION, Sim.VERSION);
  assert.equal(Multiplayer.INPUT_CONTRACT_VERSION, 2);
  assert.equal(Multiplayer.CLIENT_RUNTIME_ID, "classic-canvas-v1");
  assert.deepEqual(Multiplayer.SUPPORTED_MODE_IDS, [Sim.DEFAULT_MODE_ID]);
  assert.deepEqual(Multiplayer.SUPPORTED_MAP_IDS, [Sim.DEFAULT_MAP_ID]);
  assert.deepEqual(Multiplayer.WIRE_KEYS, quotedValues(rootKeysBlock[1]));
  assert.deepEqual(Multiplayer.BUTTON_KEYS, quotedValues(buttonKeysBlock[1]));

  const offer = Multiplayer.createCompatibilityOffer();
  assert.equal(Multiplayer.validateCompatibilityOffer(offer).accepted, true);
  assert.equal(Object.prototype.hasOwnProperty.call(offer, "serverBuildId"), false);
  assert.equal(Multiplayer.validateCompatibilityOffer({ ...offer, actorId: 0 }).accepted, false);
  assert.equal(Multiplayer.validateCompatibilityOffer({ ...offer, serverUrl: "wss://invalid" }).accepted, false);
  const rollbackHello = {
    ...Multiplayer.createServerHello(),
    serverBuildId: "pass12b1-rollback.1"
  };
  assert.equal(Multiplayer.validateServerHello(rollbackHello).accepted, true);
  assert.equal(Multiplayer.validateCurrentServerHello(rollbackHello).accepted, false);

  let getterCalls = 0;
  const accessor = Multiplayer.createCompatibilityOffer();
  Object.defineProperty(accessor, "protocolVersion", {
    enumerable: true,
    get() {
      getterCalls += 1;
      return Multiplayer.ONLINE_PROTOCOL_VERSION;
    }
  });
  assert.equal(Multiplayer.validateCompatibilityOffer(accessor).accepted, false);
  assert.equal(getterCalls, 0);
  let hostileResult;
  assert.doesNotThrow(() => {
    hostileResult = Multiplayer.validateCompatibilityOffer(new Proxy(offer, {
      ownKeys() { throw new Error("hostile ownKeys"); }
    }));
  });
  assert.equal(hostileResult.accepted, false);

  assert.match(room, /static onAuth\(token, options, context\)/);
  for (const messageType of ["protocol-request", "server-hello", "hello-ack"]) {
    assert.ok(room.includes(messageType), `${messageType} protocol message is missing`);
  }
  assert.match(room, /beginNegotiation\(client\)[\s\S]*HANDSHAKE_TIMEOUT_MS/);
  assert.match(room, /messages = \{[\s\S]*_: \(client\) => this\.rejectUnsupportedMessage\(client\)/);
  assert.match(room, /_onMessage\(client, buffer\)[\s\S]*consumeInboundFrame\(client, buffer\)[\s\S]*COLYSEUS_PROTOCOL_CODE_MASK[\s\S]*ALLOWED_CLIENT_PROTOCOL_CODES\.has\(code\)[\s\S]*rejectUnsupportedMessage/);
  assert.match(room, /terminateClient\(client, reason\)[\s\S]*rejectingClients\.has\(client\)[\s\S]*removeAllListeners\("message"\)[\s\S]*client\.leave/);
  assert.match(room, /rejectUnsupportedMessage\(client\)[\s\S]*terminateClient\(client, UNSUPPORTED_MESSAGE_REASON\)/);
  assert.match(room, /fixedStep\(context\)[\s\S]*this\.admittedSessions\.has\(client\.sessionId\)[\s\S]*this\.readySessions\.has\(client\.sessionId\)[\s\S]*this\.sendSnapshot\(client, events\)/);
  assert.match(room, /"rematch-vote": \(client, payload\) => this\.receiveRematchVote\(client, payload\)/);
  assert.match(room, /readExactDataRecord\(payload, \["generation", "vote"\]\)/);
  assert.match(room, /const REMATCH_WINDOW_MS = 30_000/);
  assert.match(room, /const GENERATION_READY_TIMEOUT_MS = 10_000/);
  assert.match(room, /restartIfUnanimous\(\)[\s\S]*this\.match\.restartGeneration\(\)/);
  assert.match(room, /connected\.length !== ONLINE_HUMAN_COUNT[\s\S]*this\.reservations\.size !== 0[\s\S]*this\.negotiatingSessions\.size !== 0/);
  assert.match(room, /generation: this\.match\.generation[\s\S]*phase: this\.lifecycle[\s\S]*rematchRemainingMs/);
  assert.match(room, /expiresAt: this\.monotonicNow\(\) \+ this\.reconnectWindowSeconds\(\) \* 1000/);
  assert.match(room, /reservation\.expiresAt - this\.monotonicNow\(\)/);
  assert.match(room, /this\.terminalSessions\.has\(client\.sessionId\)/);
  assert.match(room, /onDispose\(\)[\s\S]*clearResultsTimer\(\)[\s\S]*clearGenerationReadyTimer\(\)/);
  assert.match(room, /PASS12B2_REMATCH_WINDOW_MS = REMATCH_WINDOW_MS/);
  assert.match(authoritative, /this\.generation \+= 1[\s\S]*Sim\.resetMatch\(this\.state, \{ seed \}\)[\s\S]*this\.inputs = this\.createInputs\(\)/);
  assert.match(authoritative, /if \(candidate !== this\.state\.seed\) return candidate/);
  assert.match(aggregator, /"generation"/);
  assert.match(aggregator, /input\.generation < this\.#generation[\s\S]*input\.generation > this\.#generation[\s\S]*authoritativeTick/);
  assert.match(online, /setRematchVote: setRematchVote/);
  assert.match(online, /var matchGeneration = null/);
  assert.match(online, /var connectionGeneration = 0/);
  assert.match(online, /resetModel\(matchGeneration\)/);
  assert.match(boundary, /PASS12B1_MAX_HTTP_BODY_BYTES = 1024/);
  assert.match(boundary, /PASS12B1_MAX_WS_PAYLOAD_BYTES = 4096/);
  assert.match(boundary, /if \(url\.search \|\| url\.hash/);
  assert.match(boundary,
    /isAllowedConfiguredHost\(request\.headers\.get\("host"\), request\.url, requestPolicy\)[\s\S]*isAllowedConfiguredRequest\(origin, request\.url, requestPolicy\)/);
  assert.match(boundary, /return typeof token === "string" && RECONNECTION_TOKEN\.test\(token\)/);
  assert.match(appConfig, /new WebSocketTransport\([\s\S]*maxPayload:[\s\S]*beforeUpgrade:/);
  assert.match(appConfig,
    /replaceWithFixedEdgeRejection\(request, rejection\)[\s\S]*request\.method = "GET"[\s\S]*PASS12B1_RAW_REJECTION_PATH[\s\S]*createRawRequestGuard\([\s\S]*requestPolicy = DEFAULT_LOCAL_REQUEST_POLICY,[\s\S]*cloudProxy = false[\s\S]*replaceWithFixedEdgeRejection\(request, EDGE_REJECTION_BAD_REQUEST\)/);
  assert.match(appConfig,
    /prependWithRawGuard[\s\S]*nodePrependListener\.call\(this, "request", rawRequestGuard\)/);
  for (const gameplayField of ["seed", "tick", "snapshotJson", "stateHash"]) {
    assert.doesNotMatch(stateSchema, new RegExp(`\\b${gameplayField}\\b`),
      `${gameplayField} must not enter the global pre-admission Schema projection`);
  }
  assert.match(online, /joinOrCreate\("arena", \{[\s\S]*createCompatibilityOffer\(\)/);
  assert.match(online, /onMessage\("server-hello"[\s\S]*send\("hello-ack"[\s\S]*onMessage\("assignment"[\s\S]*send\("ready"/);
  assert.doesNotMatch(online, /joinOrCreate\("arena"\s*,\s*\{[^}]*serverUrl/);
});

test("Pass 12B3B1 reconnect and abandonment boundaries cannot drift", () => {
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const contributing = read("CONTRIBUTING.md");
  const readme = read("README.md");
  const security = read("SECURITY.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayerArchitecture = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const room = read("server/src/arena-room.mjs");
  const boundary = read("server/src/protocol-boundary.mjs");
  const online = read("online-client.js");
  const roadmap = read("docs/ROADMAP.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");
  const sourceSection = (source, start, end, label) => {
    const startIndex = source.indexOf(start);
    const endIndex = source.indexOf(end, startIndex + start.length);
    assert.ok(startIndex >= 0 && endIndex > startIndex,
      `${label} boundaries must remain present and ordered`);
    return source.slice(startIndex, endIndex);
  };
  const reconnectAdmission = sourceSection(room,
    "  onReconnect(client) {", "  beginNegotiation(client) {", "onReconnect");
  const reconnectNegotiation = sourceSection(room,
    "  beginNegotiation(client) {", "  clearNegotiation(sessionId) {", "beginNegotiation");
  const completeAdmission = sourceSection(room,
    "  completeAdmission(client) {", "  updatePrestartLifecycle() {", "completeAdmission");
  const safeFailure = sourceSection(online,
    "  function safeFailureDetail(error, operation) {",
    "  function canonicalRoomCode(value) {", "safeFailureDetail");
  const responseBoundary = sourceSection(boundary,
    "  function onResponse(response) {", "  function beforeUpgrade(request) {", "onResponse");
  const apiStart = online.indexOf("root.StickOnline = Object.freeze");
  assert.ok(apiStart >= 0, "the frozen public online API must remain present");
  const apiBlock = online.slice(apiStart);

  assert.equal(Multiplayer.ONLINE_PROTOCOL_VERSION, 3);
  assert.equal(Sim.VERSION, 6);
  assert.equal(Multiplayer.SIMULATION_SCHEMA_VERSION, 6);
  assert.equal(Multiplayer.INPUT_CONTRACT_VERSION, 2);
  assert.equal(Multiplayer.SERVER_BUILD_ID, "pass12b4b-shutdown");

  assert.match(room, /const RECONNECT_SECONDS = 30;/);
  assert.match(room, /^  autoDispose = true;$/m,
    "ArenaRoom must explicitly retain the framework's reservation-aware disposal lifecycle");
  assert.match(room, /reconnectWindowSeconds\(\) \{\s*return RECONNECT_SECONDS;\s*\}/);
  assert.match(room,
    /expiresAt: this\.monotonicNow\(\) \+ this\.reconnectWindowSeconds\(\) \* 1000/);
  assert.match(room, /PASS12B3B1_RECONNECT_SECONDS = RECONNECT_SECONDS/);
  for (const [label, section] of [
    ["onReconnect", reconnectAdmission],
    ["beginNegotiation", reconnectNegotiation],
    ["completeAdmission", completeAdmission],
  ]) {
    assert.match(section, /const reservation = this\.reservations\.get\(client\.sessionId\);/,
      `${label} must consult the application reservation map`);
  }
  assert.doesNotMatch(room,
    /this\.reservations\.get\(client\.sessionId\)\s*(?:\|\||\?\?)\s*client\.userData/,
    "transport userData must not resurrect an absent application reservation");

  assert.match(online, /var MAX_RECONNECT_RETRIES = 9;/);
  assert.match(online, /room\.reconnection\.minUptime = 0/);
  assert.match(online, /room\.reconnection\.maxEnqueuedMessages = 0/);
  assert.match(online, /room\.reconnection\.maxRetries = MAX_RECONNECT_RETRIES/);
  assert.match(online, /var FAILED_TO_RECONNECT_CODE = 4003;/);
  assert.match(online,
    /var RECONNECT_FAILED_DETAIL = "RECONNECT FAILED — START A NEW MATCH";/);
  assert.match(safeFailure,
    /if \(code === FAILED_TO_RECONNECT_CODE\) return RECONNECT_FAILED_DETAIL;/);
  assert.doesNotMatch(safeFailure, /\.message\b|\.reason\b|JSON\.stringify|String\(/,
    "public reconnect failure text must not reflect a supplied reason");
  assert.match(online,
    /room\.onLeave\(function \(code\) \{[\s\S]*safeFailureDetail\(\{ code: code \}, matchmakingOperation\)/);

  assert.match(online, /new Colyseus\.Client\(serverOrigin\(\)\)/);
  assert.match(online,
    /function serverOrigin\(\)[\s\S]*isPagesClient\(\) \? CLOUD_SERVER_ORIGIN : root\.location\.origin/);
  assert.doesNotMatch(online,
    /\breconnectionToken\b|\bsessionStorage\b|\blocalStorage\b|\bclient\.reconnect\s*\(/,
    "the browser adapter must not persist or expose manual reconnect credentials");
  assert.doesNotMatch(online, /\bserverUrl\b|wss?:\/\//,
    "the browser adapter must not accept or embed an arbitrary service URL");
  assert.doesNotMatch(apiBlock, /\n\s+(?:connect|reconnect):/,
    "the public adapter must not expose general or manual reconnect entrypoints");

  for (const errorCode of [
    "MATCHMAKE_INVALID_CRITERIA", "MATCHMAKE_INVALID_ROOM_ID",
    "MATCHMAKE_UNHANDLED", "MATCHMAKE_EXPIRED",
  ]) assert.ok(responseBoundary.includes(`ErrorCode.${errorCode}`),
    `${errorCode} must remain in the fixed matchmaking redaction boundary`);
  assert.match(responseBoundary,
    /safeJsonResponse\(response\.status, MATCH_UNAVAILABLE_MESSAGE\)/);
  assert.match(boundary,
    /MATCH_UNAVAILABLE_MESSAGE = "Match unavailable or expired\."/);
  assert.match(online,
    /operation === "join-code" && \[521, 522, 523, 524\]\.indexOf\(code\) >= 0/);

  const b3b1Index = roadmap.indexOf("#### Pass 12B3B1");
  const b3b2Index = roadmap.indexOf("#### Pass 12B3B2");
  assert.match(roadmap,
    /^#### Pass 12B3B1 — reconnect and abandonment lifecycle \(complete\)$/m);
  assert.match(roadmap,
    /^#### Pass 12B3B2 — remaining client-control and resource security \(complete\)$/m);
  assert.ok(b3b1Index >= 0 && b3b2Index > b3b1Index,
    "Pass 12B3B1 must remain before Pass 12B3B2");

  const candidate = "153df65378cbc32005f9e0971a25edbccf718220";
  const merge = "2443557c857dd6723dd986b9d8a8396e56c54f92";
  const tree = "57bb877d0bf606e90cdbc6bdbc06da64ea679058";
  for (const document of [roadmap, status]) {
    assert.ok(document.includes(candidate) && document.includes(merge) && document.includes(tree),
      "Pass 12B3B1 candidate, squash merge, and identical reviewed tree must remain recorded");
    assert.match(document, /pull request #57/i);
    assert.match(document, /pull request #58/i);
  }
  for (const [label, number, runId] of [
    ["pull-request Baseline", 149, "33019655764"],
    ["merged-main Baseline", 150, "33019766984"],
    ["checksum-gated Pages", 52, "33019766992"],
    ["cleanup", 44, "33019767156"],
  ]) {
    const evidence = new RegExp(`${label} \\[run #${number}\\]\\(https:\\/\\/github\\.com\\/XenoVoyage\\/Stickman-Arena\\/actions\\/runs\\/${runId}\\)`, "i");
    assert.match(roadmap, evidence,
      `Pass 12B3B1 ${label} #${number} must remain associated with ${runId}`);
    assert.match(status, evidence,
      `Pass 12B3B1 status must associate ${label} #${number} with ${runId}`);
  }
  assert.match(changelog,
    /## Pass 12B3B1 reconnect and abandonment lifecycle — deployed 2026-08-26/);
  assert.match(status,
    /12bff602e140eebd46e2e29c5ba35fda090277a94d3edbdfe693e7cc2c4092f1[\s\S]*270276f6260a9acd5fa6868371b297f1f094ddcda780cc86cdc66c7b05483422/,
    "deployed index and game source hashes must remain exact and ordered");
  assert.match(status,
    /1363\s*[×x]\s*936[\s\S]*four-fighter[\s\S]*Original Arena[\s\S]*03:00/i,
    "the deployed real-browser Canvas observation must remain recorded separately");
  assert.match(status,
    /performance-resource ledger|runtime resource ledger/i,
    "the unavailable browser resource-ledger boundary must remain explicit");
  assert.match(status, /not (?:a )?(?:packet|network)[ -]?(?:capture|ledger)|no packet/i,
    "browser DOM and visual evidence must not be relabeled as packet capture");
  assert.match(status,
    /Byte-identical source and root-test verification[\s\S]{0,160}`window\.StickOnline` adapter is loaded but network-idle[\s\S]{0,120}`\?online=1`/i,
    "source/test evidence must distinguish the loaded local adapter from an opted-in online session");
  assert.doesNotMatch(status,
    /(?:`?window\.)?StickOnline`? (?:was|were)? ?undefined/i,
    "ordinary Pages must not claim the repository-local online adapter is absent");
  assert.match(status,
    /only protected `?main`?[\s\S]{0,180}(?:before|prior to)[\s\S]{0,80}(?:pull request |PR )?#58/i,
    "the only-main checkpoint must remain scoped before the evidence branch existed");

  const staleCandidateClaim = /(?:draft pull request #57|unmerged (?:Pass 12B3B1|B3B1|local)|Pass 12B3B1[^\n.;]{0,100}(?:draft candidate|active only as)|no (?:pull-request )?CI, merge, Pages|No pull-request CI)/i;
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["tests/README.md", testGuide],
  ]) {
    assert.match(document, /Pass 12B3B1/,
      `${file} must retain its owned Pass 12B3B1 contract`);
    assert.doesNotMatch(document, staleCandidateClaim,
      `${file} must not describe merged Pass 12B3B1 as an unmerged draft`);
  }
});

test("Pass 12B3B2 client-control and resource ceilings cannot drift", () => {
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const contributing = read("CONTRIBUTING.md");
  const readme = read("README.md");
  const security = read("SECURITY.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayerArchitecture = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const roadmap = read("docs/ROADMAP.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");
  const multiplayer = read("multiplayer.js");
  const online = read("online-client.js");
  const aggregator = read("server/src/input-aggregator.mjs");
  const authoritative = read("server/src/authoritative-match.mjs");
  const room = read("server/src/arena-room.mjs");
  const boundary = read("server/src/protocol-boundary.mjs");
  const appConfig = read("server/src/app.config.mjs");

  assert.equal(Multiplayer.MAX_HISTORY_LIMIT, 180);
  assert.equal(Multiplayer.MAX_SNAPSHOT_EVENTS, 64);
  assert.equal(Multiplayer.MAX_PENDING_EVENTS, 256);
  assert.equal(Multiplayer.MAX_EVENT_IDENTITY_HISTORY, 512);
  assert.equal(Multiplayer.MAX_SNAPSHOT_JSON_BYTES, 32 * 1024);
  assert.match(multiplayer,
    /Math\.min\(options\.historyLimit, MAX_HISTORY_LIMIT\)/);
  assert.match(multiplayer,
    /deliveredEventOrder\.length > MAX_EVENT_IDENTITY_HISTORY[\s\S]*pendingEvents\.length > MAX_PENDING_EVENTS/);

  for (const contract of [
    /const INITIAL_WAITING_TIMEOUT_MS = 120_000/,
    /const MAX_INBOUND_MESSAGES_PER_WINDOW = 120/,
    /const MAX_INBOUND_BYTES_PER_WINDOW = 32 \* 1024/,
    /const MAX_CONTROL_MESSAGES_PER_WINDOW = 16/,
    /const MAX_INPUT_ATTEMPTS_PER_WINDOW = 120/,
    /const MAX_OUTBOUND_BUFFERED_BYTES = 256 \* 1024/,
  ]) assert.match(room, contract);
  assert.match(room,
    /consumeInboundFrame\(client, buffer\)[\s\S]*record\.messages[\s\S]*MAX_INBOUND_MESSAGES_PER_WINDOW[\s\S]*record\.bytes[\s\S]*MAX_INBOUND_BYTES_PER_WINDOW[\s\S]*byteLength/);
  assert.match(room,
    /consumeApplicationMessage\(client, type\)[\s\S]*MAX_INPUT_ATTEMPTS_PER_WINDOW[\s\S]*CONTROL_MESSAGE_LIMITS\[type\][\s\S]*MAX_CONTROL_MESSAGES_PER_WINDOW/);
  assert.match(room,
    /startInitialWaitingTimer\(\)[\s\S]*INITIAL_WAITING_TIMEOUT_MS[\s\S]*expireInitialWaiting\(generation, true\)/);
  assert.match(room,
    /sendSnapshot\(client, events = \[\]\)[\s\S]*return this\.sendBounded\(client, "snapshot", snapshot\)/);
  assert.match(room,
    /sendBounded\(client, type, payload\)[\s\S]*snapshotFitsOutboundBudget[\s\S]*client\.send[\s\S]*bufferedAfterSend/);
  assert.match(room,
    /closeRoom\(closeCode = CloseCode\.CONSENTED\)[\s\S]*clearInitialWaitingTimer\(\)[\s\S]*match\.disconnect[\s\S]*reservations\.clear\(\)[\s\S]*controlRateWindows\.clear\(\)/);

  assert.match(aggregator, /DEFAULT_MAX_SEQUENCE_ADVANCE = 120/);
  assert.match(aggregator, /DEFAULT_MAX_HELD_INPUT_TICKS = 60/);
  assert.match(aggregator,
    /input\.sequence - session\.lastSequence > this\.#maxSequenceAdvance[\s\S]*return reject\("future-sequence"\)/);
  assert.match(aggregator,
    /authoritativeTick - session\.lastAcceptedAuthoritativeTick >= this\.#maxHeldInputTicks[\s\S]*neutralizeSession\(session\)/);

  assert.match(authoritative,
    /class CompactReplayLedger[\s\S]*new Uint32Array[\s\S]*new Float64Array[\s\S]*new Uint8Array/);
  assert.match(authoritative,
    /REPLAY_CHUNK_CAPACITY = 256[\s\S]*allocateChunk\(\)[\s\S]*this\.chunks\.push/);
  assert.doesNotMatch(authoritative, /ensureCapacity|\.set\(this\.(?:ticks|analogs|weapons|buttons)\)/,
    "replay storage must not copy old and new backing stores during growth");
  assert.match(authoritative,
    /captureEvents\(events\)[\s\S]*Netcode\.MAX_SNAPSHOT_EVENTS[\s\S]*pendingEventDrops/);
  assert.match(authoritative,
    /snapshotJsonBytes\(snapshot\) > Netcode\.MAX_SNAPSHOT_JSON_BYTES[\s\S]*SnapshotLimitError/);

  const requestStart = boundary.indexOf("  async function onRequest(request) {");
  const upgradeStart = boundary.indexOf("  function beforeUpgrade(request) {");
  const resetStart = boundary.indexOf("  function reset() {");
  assert.ok(requestStart >= 0 && upgradeStart > requestStart && resetStart > upgradeStart);
  const requestBlock = boundary.slice(requestStart, upgradeStart);
  const upgradeBlock = boundary.slice(upgradeStart, resetStart);
  assert.ok(requestBlock.indexOf("httpLimiter.consume()")
    < requestBlock.indexOf('request.method !== "POST"'),
  "aggregate HTTP admission accounting must precede malformed-method rejection");
  assert.ok(upgradeBlock.indexOf("upgradeLimiter.consume()")
    < upgradeBlock.indexOf("isAllowedUpgradeUrl(request.url)"),
  "aggregate upgrade accounting must precede malformed-target rejection");

  assert.match(appConfig, /debugError[\s\S]*debugMessage[\s\S]*from "@colyseus\/core\/Debug"/);
  assert.match(appConfig,
    /const frameworkDiagnosticGate[\s\S]*createFrameworkLogger\(operationsLogger, \{[\s\S]*diagnosticGate: frameworkDiagnosticGate,[\s\S]*rejectionTracker,[\s\S]*\}\)[\s\S]*logger: frameworkLogger/);
  assert.doesNotMatch(appConfig, /setLogger\(/,
    "the process-global mutable framework logger must not replace the injected adapter");
  assert.match(appConfig,
    /for \(const namespace of \[[\s\S]*debugError[\s\S]*debugMessage[\s\S]*\]\) namespace\.enabled = false/);
  assert.match(appConfig,
    /function sendFixedError[\s\S]*Cache-Control[\s\S]*no-store[\s\S]*X-Content-Type-Options[\s\S]*nosniff/);
  assert.match(appConfig,
    /const publicCacheQueries = new Map[\s\S]*createHash\("sha256"\)[\s\S]*readFileSync[\s\S]*slice\(0, 12\)/);
  assert.match(appConfig,
    /hasAllowedPublicQuery\(request\)[\s\S]*"\?online=1"[\s\S]*publicCacheQueries\.get\(request\.path\) === query[\s\S]*sendFixedError\(response, 404, "not found"\)/);
  assert.match(appConfig,
    /handleFixedExpressError\(error, _request, response, next, operationsLogger = null\)[\s\S]*response\.headersSent[\s\S]*next\(error\)[\s\S]*operationsLogger\?\.error\("http\.unexpected-error", \{ reason: "failed" \}\)[\s\S]*sendFixedError\(response, 500, "internal server error"\)/);
  assert.match(appConfig,
    /app\.use\(\(error, request, response, next\) => handleFixedExpressError\([\s\S]*operationsLogger,[\s\S]*\)\)/);
  assert.match(online, /"stale-sequence", "future-sequence", "future-tick"/);

  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) {
    assert.match(document, /Pass 12B3B2/, `${file} must own its B3B2 boundary`);
  }
  for (const [file, document] of [
    ["CHANGELOG.md", changelog],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/STATUS.md", status],
  ]) assert.match(document, /pass12b3b2-local/,
    `${file} must record the diagnostic build`);
  assert.match(roadmap,
    /^#### Pass 12B3B2 — remaining client-control and resource security \(complete\)$/m);
  assert.match(roadmap,
    /^#### Pass 12B4B — graceful shutdown, recovery, and rollback \(complete\)$/m);
  assert.match(roadmap,
    /^#### Pass 12C1 — deterministic lifecycle and resource regressions$/m);
  assert.match(roadmap,
    /^#### Pass 12C2 — load, soak, network, browser, and deployment readiness$/m);
  const candidate = "62fde531886bbd800a5b43b344ff47090fa44318";
  const merge = "5b233cb39089a60575d68021cbc6676e84a89157";
  const tree = "0ff371be86b54aacb0f3decc7d9f65b6ddb60d34";
  for (const document of [agents, changelog, security, architecture, roadmap, status, testGuide]) {
    assert.ok(document.includes(tree), "Pass 12B3B2 reviewed tree must remain recorded");
  }
  for (const document of [agents, changelog, roadmap, status]) {
    assert.ok(document.includes(candidate) && document.includes(merge),
      "Pass 12B3B2 candidate and squash merge must remain recorded");
    assert.match(document, /pull request #59/i);
    assert.match(document, /pull request #60/i);
  }
  for (const [number, runId] of [
    [155, "33027598233"],
    [156, "33027714237"],
    [54, "33027714234"],
    [46, "33027714290"],
  ]) {
    assert.ok(roadmap.includes(`#${number}`) && roadmap.includes(runId),
      `Pass 12B3B2 roadmap evidence #${number} must remain associated with ${runId}`);
    assert.ok(status.includes(`#${number}`) && status.includes(runId),
      `Pass 12B3B2 status evidence #${number} must remain associated with ${runId}`);
  }
  assert.match(changelog,
    /## Pass 12B3B2 resource and client-control security — deployed 2026-08-27/);
  const staleCandidateClaim = /(?:draft pull request #59|unmerged (?:Pass 12B3B2|B3B2)|Pass 12B3B2[^\n.;]{0,100}(?:draft candidate|active only as)|not complete, merged|not merged, deployed)/i;
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) assert.doesNotMatch(document, staleCandidateClaim,
    `${file} must not describe merged Pass 12B3B2 as an unmerged draft`);
});

test("Pass 12B4 operations and graceful shutdown remain bounded and fail closed", () => {
  const appConfig = read("server/src/app.config.mjs");
  const boundary = read("server/src/protocol-boundary.mjs");
  const environmentExample = read("server/.env.example");
  const gitignore = read(".gitignore");
  const operations = read("server/src/operations.mjs");
  const online = read("online-client.js");
  const room = read("server/src/arena-room.mjs");
  const runtimeConfig = read("server/src/runtime-config.mjs");
  const serverEntry = read("server/src/index.mjs");
  const startup = read("server/src/startup.mjs");
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const contributing = read("CONTRIBUTING.md");
  const readme = read("README.md");
  const security = read("SECURITY.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayerArchitecture = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const roadmap = read("docs/ROADMAP.md");
  const serverOperations = read("docs/SERVER_OPERATIONS.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");

  assert.equal(Multiplayer.SERVER_BUILD_ID, "pass12b4b-shutdown");
  assert.match(serverEntry, /const SERVER_BUILD_ID = "pass12b4b-shutdown"/);
  const configIndex = serverEntry.indexOf("runtimeConfig = createRuntimeConfig(process.env)");
  const startupIndex = serverEntry.indexOf("startConfiguredApplication(runtimeConfig, undefined");
  assert.ok(configIndex >= 0 && startupIndex > configIndex,
    "configuration must fail closed before Colyseus has import-time effects");
  assert.match(startup,
    /startConfiguredApplication[\s\S]*import\("\.\/app\.config\.mjs"\)[\s\S]*application\.listen\(\)[\s\S]*markReady\(\)/);
  assert.match(startup,
    /catch \{[\s\S]*application\?\.abortStartup\(\)[\s\S]*accepted: false/,
    "post-bind startup failure must invoke fixed cleanup without returning error detail");
  assert.match(appConfig,
    /function listen\(\)[\s\S]*PASS12B4A_STARTUP_LISTEN_TIMEOUT_MS[\s\S]*httpServer\.once\("error", rejectListen\)[\s\S]*runtimeConfig\.listenPath[\s\S]*server\.listen\(runtimeConfig\.listenPath, 0\)[\s\S]*server\.listen\(runtimeConfig\.port, runtimeConfig\.bindHost\)[\s\S]*async function abortStartup\(\)[\s\S]*server\.gracefullyShutdown\(false\)[\s\S]*PASS12B4A_STARTUP_CLEANUP_TIMEOUT_MS[\s\S]*clearAutoPersistInterval\(\)[\s\S]*transport\?\.shutdown\(\)[\s\S]*closeAllConnections\(\)[\s\S]*presence\.shutdown\(\)[\s\S]*driver\.shutdown\(\)/);
  assert.doesNotMatch(serverEntry, /console\.(?:log|warn|error)/,
    "bootstrap output must use the structured operations boundary");
  assert.match(serverEntry,
    /startupLogger\.error\("service\.configuration", \{ reason: "configuration-invalid" \}\)/);

  assert.match(runtimeConfig,
    /export function createRuntimeConfig\(environment\)[\s\S]*STICKMAN_SERVER_MODE[\s\S]*mode !== "local" && mode !== "public"/);
  assert.match(runtimeConfig,
    /makeLocalConfig\(port\)[\s\S]*serverMode: "local"[\s\S]*bindHost: "127\.0\.0\.1"[\s\S]*allowMissingOrigin: true[\s\S]*listenPath: null/);
  assert.match(runtimeConfig,
    /makePublicConfig\(environment, port, cloudProxy\)[\s\S]*NODE_ENV[\s\S]*"production"[\s\S]*PUBLIC_BIND_HOSTS[\s\S]*canonicalHttpsOrigin[\s\S]*allowMissingOrigin: false[\s\S]*cloudProxy[\s\S]*listenPath: cloudProxy[\s\S]*colyseusCloudUnixSocketPath/);
  assert.match(runtimeConfig, /FORBIDDEN_TOPOLOGY_ENVIRONMENT_KEYS[\s\S]*REDIS_URI/);
  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_ENVIRONMENT_KEY = "COLYSEUS_CLOUD"[\s\S]*COLYSEUS_CLOUD_INSTANCE_KEY = "NODE_APP_INSTANCE"/);
  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_ROLLOUT_INSTANCES = Object\.freeze\(\["0", "1"\]\)/);
  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_SOCKET_DIRECTORY = "\/run\/colyseus"/);
  assert.match(runtimeConfig,
    /export function colyseusCloudUnixSocketPath\(nodeAppInstance\)[\s\S]*DEFAULT_SERVER_PORT \+ Number\(nodeAppInstance\)[\s\S]*\.sock/);
  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_ROLLOUT_INSTANCES = Object\.freeze\(\["0", "1"\]\)[\s\S]*cloudEnvironment !== cloudInstance[\s\S]*CLOUD_ROLLOUT_INSTANCES\.has/);
  assert.match(environmentExample,
    /^STICKMAN_SERVER_MODE=local$[\s\S]*^PORT=2567$[\s\S]*^# STICKMAN_PUBLIC_ORIGIN=https:\/\/arena\.example$/m);
  assert.match(gitignore, /^\.env\*$[\s\S]*^!server\/\.env\.example$/m);

  assert.match(appConfig, /export function createApplication\(runtimeConfig, options = \{\}\)/);
  assert.match(appConfig,
    /const presence = new LocalPresence\(\);[\s\S]*const driver = new LocalDriver\(\);/);
  assert.match(appConfig,
    /createRawRequestGuard\(requestPolicy, runtimeConfig\.cloudProxy\)/);
  assert.match(appConfig,
    /allowProxyHeaders = cloudProxy === true \|\| requestPolicy\.mode === "public"/);
  assert.match(appConfig,
    /function stripCloudProxyHeaders\(request\)[\s\S]*delete request\.headers\[name\][\s\S]*request\.rawHeaders\.splice/);
  assert.match(appConfig,
    /function beginCloudHttpDrain\(\)[\s\S]*runtimeConfig\.cloudProxy[\s\S]*httpServer\.close\(\)[\s\S]*closeIdleConnections\(\)[\s\S]*preRequestSockets[\s\S]*socket\.destroy\(\)[\s\S]*if \(!beginCloudHttpDrain\(\)\)[\s\S]*server\.gracefullyShutdown\(false\)/);
  assert.match(appConfig,
    /presence,[\s\S]*driver,[\s\S]*selectProcessIdToCreateRoom: async \(\) => matchMaker\.processId/);
  assert.match(appConfig,
    /isLocalRoom: \(roomId\) => Boolean\(matchMaker\.getLocalRoomById\(roomId\)\)/,
    "one-process lookup must not invoke remote IPC diagnostics with reconnect arguments");
  assert.match(room,
    /createConfiguredArenaRoom\([\s\S]*static onAuth\(token, options, context\)[\s\S]*authorizeAdmission\(token, options, context, requestPolicy\)/);
  assert.match(appConfig,
    /const frameworkDiagnosticGate[\s\S]*createFrameworkLogger\(operationsLogger, \{[\s\S]*diagnosticGate: frameworkDiagnosticGate,[\s\S]*rejectionTracker,[\s\S]*\}\)[\s\S]*logger: frameworkLogger/);
  assert.doesNotMatch(appConfig, /setLogger\(/);

  assert.match(appConfig,
    /app\.all\(\["\/livez", "\/readyz"\][\s\S]*serviceState\.isLive\(\)[\s\S]*serviceState\.isReady\(\)[\s\S]*status: accepted/);
  assert.match(appConfig,
    /isFrameworkPreflightTarget[\s\S]*request\.method !== "OPTIONS"[\s\S]*EDGE_REJECTION_METHOD[\s\S]*EDGE_REJECTION_NOT_FOUND/,
    "only exact matchmaking OPTIONS requests may reach the framework preflight shortcut");
  assert.match(boundary,
    /url\.pathname === "\/__healthcheck"[\s\S]*safeJsonResponse\(404, "not found"\)/);
  assert.doesNotMatch(appConfig, /app\.(?:get|all)\("\/health"/,
    "the obsolete Pass 11 health response must remain removed");
  assert.match(boundary,
    /serviceState != null && !serviceState\.isReady\(\)[\s\S]*safeJsonResponse\(503, "service unavailable"\)/);
  assert.match(boundary,
    /isAllowedConfiguredHost[\s\S]*isAllowedConfiguredRequest[\s\S]*requestPolicy/);

  assert.match(operations,
    /const record = \{\s*timestamp: fixedTimestamp\(clock\),\s*level,\s*event,\s*buildId,\s*\}/);
  for (const field of ["phase", "roomPhase", "reason", "category", "count"]) {
    assert.match(operations, new RegExp(`ownDataValue\\(fields, "${field}"\\)`),
      `${field} must remain an exact structured-log allowlist field`);
  }
  assert.match(operations,
    /createFrameworkDiagnosticGate[\s\S]*warningLogged[\s\S]*errorLogged[\s\S]*createFrameworkLogger\(operationsLogger, options = undefined\)[\s\S]*debug\(\) \{\}[\s\S]*info\(\) \{\}[\s\S]*trace\(\) \{\}[\s\S]*warn\(\)[\s\S]*error\(\)/);
  assert.match(operations,
    /createSecurityRejectionTracker[\s\S]*MAX_SECURITY_REJECTION_COUNT[\s\S]*finishWindow[\s\S]*function flush\(\)[\s\S]*function reset\(\)/);
  assert.doesNotMatch(operations, /\.toString\(|\bString\(/,
    "operations code must not coerce attacker-controlled values");

  assert.match(appConfig,
    /PASS12B4B_DRAIN_TIMEOUT_MS = 5_000[\s\S]*PASS12B4B_FORCE_CLEANUP_TIMEOUT_MS = 1_000[\s\S]*PASS12B4B_MAX_TRACKED_SOCKETS = 256/);
  assert.match(appConfig,
    /defineServer\(\{\s*gracefullyShutdown: false,/,
    "Colyseus must not install a competing signal owner");
  assert.match(startup, /OWNED_SIGNAL_EVENTS = Object\.freeze\(\["SIGTERM", "SIGINT"\]\)/);
  assert.match(startup, /setUncaughtExceptionCaptureCallback\(handlers\.uncaughtException\)/);
  assert.match(startup, /hasUncaughtExceptionCaptureCallback\(\)[\s\S]*throw new Error\("shutdown capture unavailable"\)/,
    "a pre-owned exclusive capture hook must fail startup before framework bootstrap");
  assert.match(startup, /prependListener\("unhandledRejection", handlers\.unhandledRejection\)/);
  assert.match(startup, /removeListener\("unhandledRejection", handlers\.unhandledRejection\)/,
    "one persistent app-owned controller must contain signals and both fatal paths");
  assert.match(serverEntry,
    /createShutdownController\(\{[\s\S]*signalTarget: process[\s\S]*const exitCode = result\.accepted && !context\.fatal \? 0 : 1[\s\S]*process\.exitCode = process\.exitCode === 1 \|\| exitCode === 1 \? 1 : 0[\s\S]*process\.exit\(process\.exitCode === 0 \? 0 : 1\)/);
  assert.match(appConfig,
    /function shutdown\(reason = "shutdown-signal"\)[\s\S]*serviceState\.transition\("draining"\)[\s\S]*rejectionTracker\.flush\(\)[\s\S]*closeCurrentRooms\(\)[\s\S]*admissionTracker\.waitForIdle\(\)[\s\S]*server\.gracefullyShutdown\(false\)[\s\S]*roomRegistry\.snapshot\(\)\.liveRooms !== 0[\s\S]*forceCleanup\(\)/);
  assert.match(appConfig,
    /for \(const client of server\.transport\?\.wss\?\.clients \|\| \[\]\) client\.terminate\(\)[\s\S]*socket\.destroy\(\)[\s\S]*transport\?\.shutdown\(\)[\s\S]*closeAllConnections\(\)[\s\S]*presence\.shutdown\(\)[\s\S]*driver\.shutdown\(\)/,
    "direct fallback must terminate WebSockets and raw sockets before transport and HTTP teardown");
  assert.match(room,
    /clearFrameworkSeatReservations\(\)[\s\S]*Object\.keys\(seats\)[\s\S]*_reconnectionAttempts[\s\S]*attempt\?\.reject\?\.[\s\S]*_autoDisposeTimeout = undefined[\s\S]*onBeforeShutdown\(\)[\s\S]*closeRoom\(CloseCode\.SERVER_SHUTDOWN\)/,
    "process shutdown must revoke pinned-framework seats before the bounded Room drain");
  assert.match(room,
    /serviceAcceptsAdmission\(\)\) throw new ServerError\(503, "service unavailable"\)[\s\S]*await this\.setPrivate\(true, false\)[\s\S]*serviceAcceptsAdmission\(\)\) throw new ServerError\(503, "service unavailable"\)/,
    "both Room-creation readiness races must preserve the fixed draining 503");
  assert.match(online,
    /SERVER_RESTART_DETAIL = "SERVER RESTARTING — TRY AGAIN"[\s\S]*SERVER_RESTART_CODE = 4001[\s\S]*code === SERVER_RESTART_CODE/);
  assert.match(boundary,
    /rawBody = await request\.clone\(\)\.text\(\)[\s\S]*serviceState != null && !serviceState\.isReady\(\)[\s\S]*safeJsonResponse\(503, "service unavailable"\)/,
    "readiness must be rechecked after asynchronous body consumption");

  const b4bCandidate = "055e9fe3ec029ad5ee8f85544f198b027ec6942c";
  const b4bMerge = "9e2d20013f06a2bcef713483cbddc88201d96605";
  const b4bTree = "94fc30540b454f6ee573d9422332f22f0efadd6a";
  for (const document of [agents, changelog, readme, security, architecture,
    multiplayerArchitecture, roadmap, serverOperations, status, testGuide]) {
    assert.ok(document.includes(b4bTree),
      "Pass 12B4B reviewed tree must remain recorded");
  }
  for (const document of [agents, changelog, readme, security, architecture,
    multiplayerArchitecture, roadmap, serverOperations, status, testGuide]) {
    assert.ok(document.includes(b4bCandidate) && document.includes(b4bMerge),
      "Pass 12B4B candidate and squash merge must remain recorded");
    assert.match(document, /pull request #65/i,
      "Pass 12B4B runtime pull request must remain recorded");
    assert.match(document, /pull request #66/i,
      "Pass 12B4B evidence closeout must remain recorded");
  }
  for (const [number, runId] of [
    [173, "33064782806"],
    [174, "33064918249"],
    [60, "33064918062"],
    [52, "33064918050"],
  ]) {
    const evidence = `[run #${number}](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/${runId})`;
    assert.ok(roadmap.includes(evidence),
      `Pass 12B4B roadmap evidence #${number} must remain associated with ${runId}`);
    assert.ok(status.includes(evidence),
      `Pass 12B4B status evidence #${number} must remain associated with ${runId}`);
  }
  assert.match(changelog,
    /## Pass 12B4B graceful shutdown — deployed 2026-08-27/);
  assert.match(status,
    /## Pass 12B4B graceful shutdown and recovery — complete/);
  assert.match(roadmap,
    /#### Pass 12B4B — graceful shutdown, recovery, and rollback \(complete\)/);
  assert.match(roadmap,
    /#### Pass 12C1 — deterministic lifecycle and resource regressions/);
  assert.match(roadmap,
    /#### Pass 12C2 — load, soak, network, browser, and deployment readiness/);
  assert.match(status,
    /exact post-merge empty-query Pages route[\s\S]*nine same-origin repository scripts[\s\S]*no Colyseus global[\s\S]*four-fighter Original Arena regulation at `03:00`/);
  const staleB4bCandidateClaim = /(?:^|\n)#{1,4} ?Pass 12B4B[^\n]*(?:active candidate|unmerged)|(?:Pass 12B4B|B4B)[^.\n]{0,100}(?:is(?: now)?|remains)[^.\n]{0,100}\b(?:active|unmerged)\b/i;
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/SERVER_OPERATIONS.md", serverOperations],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) assert.doesNotMatch(document, staleB4bCandidateClaim,
    `${file} must not describe merged Pass 12B4B as an active unmerged candidate`);

  const candidate = "b7dade0500f2890d23e64839666f05078974794b";
  const merge = "4c4d82c5b177100bc40aaddc64d7e52734e5b5fb";
  const tree = "6db593c04875fe8ab7465c5c3f7bd8ba68010679";
  for (const document of [agents, changelog, security, architecture,
    multiplayerArchitecture, roadmap, status, testGuide]) {
    assert.ok(document.includes(tree), "Pass 12B4A reviewed tree must remain recorded");
  }
  for (const document of [agents, changelog, architecture, roadmap, status]) {
    assert.ok(document.includes(candidate) && document.includes(merge),
      "Pass 12B4A candidate and squash merge must remain recorded");
    assert.match(document, /pull request #61/i);
    assert.match(document, /pull request #62/i);
  }
  for (const [number, runId] of [
    [161, "33033455124"],
    [162, "33033595987"],
    [56, "33033595988"],
    [48, "33033596005"],
  ]) {
    const evidence = `[run #${number}](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/${runId})`;
    assert.ok(roadmap.includes(evidence),
      `Pass 12B4A roadmap evidence #${number} must remain associated with ${runId}`);
    assert.ok(status.includes(evidence),
      `Pass 12B4A status evidence #${number} must remain associated with ${runId}`);
  }
  assert.match(changelog,
    /## Pass 12B4A validated operations and startup baseline — deployed 2026-08-27/);
  assert.match(status,
    /root document and all nine referenced same-origin scripts byte-identical to the reviewed merge/);
  assert.match(status, /fresh post-merge browser connection was unavailable/);
  assert.match(status, /\/online-sdk\.js` still a Pages 404/);
  const b4aIndex = roadmap.indexOf(
    "#### Pass 12B4A — validated operations and startup baseline (complete)");
  const a4Index = roadmap.indexOf(
    "#### Pass 12A4 — exact Schema 5.0.22 migration (complete)");
  const b4bIndex = roadmap.indexOf(
    "#### Pass 12B4B — graceful shutdown, recovery, and rollback (complete)");
  const a5Index = roadmap.indexOf(
    "#### Pass 12A5 — exact Schema 5.0.23 migration");
  const c1Index = roadmap.indexOf(
    "#### Pass 12C1 — deterministic lifecycle and resource regressions");
  const c2Index = roadmap.indexOf(
    "#### Pass 12C2 — load, soak, network, browser, and deployment readiness");
  assert.ok(b4aIndex >= 0 && b4aIndex < a4Index && a4Index < b4bIndex && b4bIndex < a5Index &&
    a5Index < c1Index && c1Index < c2Index,
    "B4A closeout, Schema-only A4, B4B, Schema-only A5, C1, and C2 must remain ordered");
  assert.match(roadmap,
    /After the B4A evidence closeout merged and cleanup left only protected `main`, \[pull request #63[^\n]*\]\(https:\/\/github\.com\/XenoVoyage\/Stickman-Arena\/pull\/63\) completed the separate bounded dependency subpass/);
  assert.match(roadmap,
    /exact-pins only `@colyseus\/schema` `5\.0\.22` and the matching root dependency plus Schema package lock records; every other package entry remains byte-stable/);
  assert.match(roadmap,
    /same signed 146-file layout as `5\.0\.21`[\s\S]*byte-identical emitted CJS, ESM, browser\/UMD, input, codegen, and other runtime JavaScript/);
  assert.match(roadmap,
    /complete 126-test root and 172-test server suites pass[\s\S]*Complete and production audits report zero vulnerabilities and direct outdated returns `\{\}`/);
  assert.match(roadmap,
    /Keep gameplay, protocol `3`, simulation schema `6`, input contract `2`, client runtime, capacity, catalogs, service topology, diagnostic build ID, public version, hosting boundary, and every provider stop gate unchanged/);
  const a4Candidate = "a8a6ece708ec47b2c3969599412475d322ec4e28";
  const a4Merge = "0b1dda568ae0f2f44eee1ffa2a4b0378ab86c108";
  const a4Tree = "c0841d32c6579900327b1d71ddf21e4b9bb60e10";
  for (const document of [agents, changelog, roadmap, status, testGuide]) {
    assert.ok(document.includes(a4Candidate) && document.includes(a4Merge) &&
      document.includes(a4Tree),
    "Pass 12A4 candidate, squash merge, and reviewed tree must remain recorded");
  }
  for (const [number, runId] of [
    [167, "33036827490"],
    [168, "33036951092"],
    [58, "33036951128"],
    [50, "33036951071"],
  ]) {
    const evidence = `[run #${number}](https://github.com/XenoVoyage/Stickman-Arena/actions/runs/${runId})`;
    assert.ok(roadmap.includes(evidence),
      `Pass 12A4 roadmap evidence #${number} must remain associated with ${runId}`);
    assert.ok(status.includes(evidence),
      `Pass 12A4 status evidence #${number} must remain associated with ${runId}`);
  }
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) {
    assert.match(document, /pull request #63/i,
      `${file} must identify the merged Pass 12A4 pull request`);
    assert.match(document, /pull request #64/i,
      `${file} must identify the Pass 12A4 evidence closeout`);
    assert.doesNotMatch(document,
      /(?:^|\n)#{0,4} ?Pass 12A4[^\n]*(?:active candidate)|active(?:-candidate)?[^\n.;]{0,80}Pass 12A4|draft pull request #63|Pass 12A4[^\n.;]{0,100}(?:is active|remains incomplete)/im,
      `${file} must not describe merged Pass 12A4 as an active or incomplete candidate`);
  }
  assert.match(changelog,
    /## Pass 12A4 exact Schema patch maintenance — deployed 2026-08-27/);
  assert.match(status, /## Pass 12A4 exact Schema 5\.0\.22 migration — complete/);
  assert.match(status,
    /root document and all nine same-origin scripts byte-identical to the reviewed merge/);
  assert.match(status, /fresh browser backend was unavailable/);
  assert.match(status, /\/online-sdk\.js` still a Pages 404/);
  assert.match(roadmap,
    /Pass 12B4B — graceful shutdown, recovery, and rollback \(complete\)/);
  assert.match(roadmap,
    /exact-pins only `@colyseus\/schema` `5\.0\.23` and the matching root dependency plus Schema package lock records; every other package entry remains byte-stable/);
  assert.match(changelog,
    /## Pass 12A5 exact Schema patch maintenance/);
  assert.match(status, /## Pass 12A5 exact Schema 5\.0\.23 migration/);
  assert.match(architecture, /@colyseus\/schema` `5\.0\.23`/);
  const staleCandidateClaim = /(?:current (?:unmerged|local|working|bounded) (?:Pass 12B4A |B4A )(?:operations-baseline )?candidate|Pass 12B4A (?:is|remains) (?:an? )?(?:active|unmerged)[^\n.;]{0,80}candidate|Pass 12B4A[^\n.;]{0,100}not yet merged|unmerged B4A candidate|Pass 12B4A[^\n]{0,100}\(active candidate\))/i;
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/SERVER_OPERATIONS.md", serverOperations],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) assert.doesNotMatch(document, staleCandidateClaim,
    `${file} must not describe merged Pass 12B4A as an unmerged candidate`);
});

test("Pass 12C1 lifecycle and resource regressions stay CI-fast and fail closed", () => {
  const lifecycle = read("server/test/lifecycle-resource.test.mjs");
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const contributing = read("CONTRIBUTING.md");
  const readme = read("README.md");
  const security = read("SECURITY.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayerArchitecture = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const roadmap = read("docs/ROADMAP.md");
  const serverOperations = read("docs/SERVER_OPERATIONS.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");

  assert.match(lifecycle, /repeated Room create and dispose leave no registry, timers, queues, or replay owners/);
  assert.match(lifecycle, /compact regulation rematch resets generation-local history then disposes/);
  assert.match(lifecycle, /abandoned reconnect expiry cannot mutate a replacement Room/);
  assert.match(lifecycle, /malformed, oversized, rate-limit, and slow-client closes leave no reservation residue/);
  assert.match(lifecycle, /shutdown clears waiting, playing, and results handles before registry release/);
  assert.match(lifecycle, /ticksRemaining = 1/);
  assert.doesNotMatch(lifecycle, /for \(let tick = 0; tick < 10800/);
  assert.match(lifecycle, /assertApplicationResourcesCleared/);
  assert.match(lifecycle, /handshakeTimers/);
  assert.match(lifecycle, /controlRateWindows/);
  assert.match(lifecycle, /replayLedgerStats/);
  assert.match(changelog, /## Pass 12C1 deterministic lifecycle and resource regressions/);
  assert.match(status, /## Pass 12C1 deterministic lifecycle and resource regressions/);
  assert.match(roadmap, /^#### Pass 12C1 — deterministic lifecycle and resource regressions$/m);
  assert.match(roadmap,
    /^#### Pass 12C2 — load, soak, network, browser, and deployment readiness$/m);
  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["CONTRIBUTING.md", contributing],
    ["README.md", readme],
    ["SECURITY.md", security],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayerArchitecture],
    ["docs/ROADMAP.md", roadmap],
    ["docs/SERVER_OPERATIONS.md", serverOperations],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) {
    assert.match(document, /Pass 12C1/, `${file} must name Pass 12C1`);
    assert.match(document, /Pass 12C2/, `${file} must name remaining Pass 12C2 work`);
  }
});

test("Pass 12C2 tooling stays bounded, provider-neutral, and evidence-safe", () => {
  const loadTool = read("server/tools/load-soak.mjs");
  const networkTool = read("server/tools/network-profiles.mjs");
  const toolTests = read("server/test/readiness-tools.test.mjs");
  const containerfile = read("server/Containerfile");
  const dockerignore = read(".dockerignore");
  const serverPackage = JSON.parse(read("server/package.json"));
  const changelog = read("CHANGELOG.md");
  const roadmap = read("docs/ROADMAP.md");
  const operations = read("docs/SERVER_OPERATIONS.md");
  const multiplayer = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");

  assert.equal(serverPackage.scripts["load:short"],
    "node tools/load-soak.mjs --profile=short");
  assert.equal(serverPackage.scripts["load:soak"],
    "node tools/load-soak.mjs --profile=soak");
  assert.equal(serverPackage.scripts["network:profiles"],
    "node tools/network-profiles.mjs");
  for (const metric of [
    "cpuOneCorePercent",
    "memoryAfterWarmup",
    "eventLoopDelayMs",
    "maxCatchUpStepsWithoutOneMillisecondYield",
    "snapshotApplicationBytesPerSecond",
    "peakConcurrentRooms",
    "resources",
    "shutdownMs",
  ]) assert.match(loadTool, new RegExp(metric), `load tool omitted ${metric}`);
  for (const scenario of [
    "valid-input-traffic",
    "compact-rematch",
    "simultaneous-reconnect-wave",
    "create-join-flood",
    "control-abuse",
    "backpressure",
    "graceful-shutdown-under-load",
  ]) assert.match(loadTool, new RegExp(scenario), `load tool omitted ${scenario}`);
  assert.match(loadTool, /not a production capacity claim/);
  assert.match(loadTool, /backendResourcesCleared/);
  assert.match(loadTool, /exerciseFreshProcessRecovery/);
  assert.match(loadTool, /onceMessage\(room, type, timeoutMs/);
  assert.match(loadTool, /steadyAndScenarioMeasuredMs/);
  assert.match(loadTool, /validTrafficAcknowledgedClients/);
  assert.match(loadTool, /AbortSignal\.timeout/);
  assert.match(toolTests, /timeout: 35_000/);
  assert.match(toolTests, /validTraffic\.acknowledgedClients/);
  assert.match(toolTests, /recovery\.freshProcess/);
  assert.match(toolTests, /profile\.replayedInputs/);
  assert.match(networkTool, /latency/);
  assert.match(networkTool, /jitter/);
  assert.match(networkTool, /burst-reorder/);
  assert.match(networkTool, /loss/);
  assert.match(networkTool, /stale-generation/);
  assert.match(networkTool, /future-generation/);
  assert.match(networkTool, /MAX_DELIVERIES_PER_TICK/);
  assert.match(containerfile,
    /^FROM node:24\.20\.0-bookworm-slim@sha256:[0-9a-f]{64}$/m);
  assert.match(containerfile, /npm ci --prefix server --omit=dev --ignore-scripts/);
  assert.match(containerfile, /^USER node$/m);
  assert.doesNotMatch(containerfile, /(?:TOKEN|PASSWORD|SECRET|CREDENTIAL)=/);
  assert.match(dockerignore, /^\*$/m);
  assert.match(dockerignore, /!server\/src\/\*\*/);
  assert.match(operations, /local image ID[\s\S]*registry manifest digest/);
  assert.match(operations, /Date\.now\(\)\+10000[\s\S]*\['\/livez','\/readyz'\]/);
  assert.match(operations,
    /highest repeatedly tested Room count[\s\S]*operational budget at or below that measured ceiling/);
  assert.match(changelog, /## Pass 12C2 load, network, browser, and deployment readiness/);
  assert.match(status, /## Pass 12C2 load, network, browser, and deployment readiness/);
  assert.match(status,
    /supplemental clean-reload Chrome run[\s\S]*does not satisfy Firefox `NET-BR-02`/);
  assert.match(roadmap,
    /^#### Pass 12C2 — load, soak, network, browser, and deployment readiness$/m);
  for (const [file, document] of [
    ["docs/SERVER_OPERATIONS.md", operations],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayer],
    ["tests/README.md", testGuide],
  ]) {
    for (const boundary of [
      "provider-neutral",
      "TLS",
      "one-process",
      "physical",
      "GitHub Pages",
    ]) assert.match(document, new RegExp(boundary, "i"), `${file} omitted ${boundary}`);
  }
});

test("owner-approved Colyseus Cloud path keeps Pages Play offline and endpoints fixed", () => {
  const agents = read("AGENTS.md");
  const changelog = read("CHANGELOG.md");
  const architecture = read("docs/ARCHITECTURE.md");
  const multiplayer = read("docs/MULTIPLAYER_ARCHITECTURE.md");
  const operations = read("docs/SERVER_OPERATIONS.md");
  const status = read("docs/STATUS.md");
  const testGuide = read("tests/README.md");
  const online = read("online-client.js");
  const game = read("game.js");
  const runtimeConfig = read("server/src/runtime-config.mjs");
  const serverEntry = read("server/src/index.mjs");
  const appConfig = read("server/src/app.config.mjs");
  const ecosystem = read("server/ecosystem.config.cjs");
  const environmentExample = read("server/.env.example");
  const cloudTests = read("server/test/cloud-hosting.test.mjs");
  const serverPackage = JSON.parse(read("server/package.json"));
  const pages = read(".github/workflows/pages.yml");
  const gitignore = read(".gitignore");

  assert.equal(read("VERSION.txt").trim(), "v2026.9.2");
  assert.match(read("index.html"), /class="menu-version">v2026\.9\.2</);
  assert.equal(serverPackage.scripts.build, "node --check src/index.mjs");
  assert.match(ecosystem, /name: "stickman-arena"/);
  assert.match(ecosystem, /script: "src\/index\.mjs"/);
  assert.match(ecosystem, /instances: 1/);
  assert.match(ecosystem, /exec_mode: "fork"/);
  assert.match(ecosystem, /wait_ready: true/);
  assert.doesNotMatch(ecosystem, /\benv\b|token|secret|credential/i);

  assert.match(online,
    /PAGES_ORIGIN = "https:\/\/xenovoyage\.github\.io"[\s\S]*"\/Stickman-Arena\/"[\s\S]*CLOUD_SERVER_ORIGIN = "https:\/\/de-fra-1131bd95\.colyseus\.cloud"/);
  assert.equal((online.match(/https:\/\/de-fra-1131bd95\.colyseus\.cloud/g) || []).length, 1);
  assert.match(online,
    /function isPagesClient\(\)[\s\S]*root\.location\.origin === PAGES_ORIGIN[\s\S]*PAGES_PATHS\.indexOf\(root\.location\.pathname\)/);
  assert.match(online,
    /function loadSdk\(\)[\s\S]*script\.src = serverOrigin\(\) \+ "\/online-sdk\.js"/);
  assert.match(online, /new Colyseus\.Client\(serverOrigin\(\)\)/);
  assert.doesNotMatch(online, /\bserverUrl\b|wss?:\/\//);
  assert.match(game,
    /var onlineAvailable = Online\.requested\(\);[\s\S]*var onlineMode = false/);
  assert.match(game,
    /function startMatch\(\)[\s\S]*onlineAvailable && Online\.quickMatchAvailable\(\)[\s\S]*onlineMode = false[\s\S]*makeState\(nextMatchSeed\(\)\)/);
  assert.match(game,
    /if \(onlineAvailable\)[\s\S]*if \(Online\.quickMatchAvailable\(\)\) ui\.startButton\.textContent = "QUICK MATCH"[\s\S]*ui\.onlineMatchPanel\.hidden = false/);
  assert.match(game,
    /function prepareOnlineRequest\(\)[\s\S]*offlineBotCountValue = ui\.botCountControl\.value[\s\S]*function restoreOfflineBotSettings\(\)/);

  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_ENVIRONMENT_KEY = "COLYSEUS_CLOUD"[\s\S]*COLYSEUS_CLOUD_INSTANCE_KEY = "NODE_APP_INSTANCE"/);
  assert.match(runtimeConfig,
    /mode !== "public" && \(cloudEnvironment \|\| cloudInstance\)/);
  assert.match(runtimeConfig,
    /COLYSEUS_CLOUD_ROLLOUT_INSTANCES = Object\.freeze\(\["0", "1"\]\)[\s\S]*cloudInstance[\s\S]*CLOUD_ROLLOUT_INSTANCES\.has[\s\S]*makePublicConfig\(environment, port, cloudEnvironment\)/);
  assert.match(serverEntry,
    /async function preloadCloudEnvironment\(\)[\s\S]*import\("@colyseus\/tools\/loadenv"\)[\s\S]*console\[method\] = originals\.get\(method\)/);
  assert.ok(
    serverEntry.indexOf("await preloadCloudEnvironment()")
      < serverEntry.indexOf("createRuntimeConfig(process.env)"),
    "Cloud UI environment must load quietly before final validation",
  );
  assert.match(cloudTests,
    /APP_ROOT_PATH[\s\S]*\.env\.cloud[\s\S]*NODE_APP_INSTANCE=2[\s\S]*service\.configuration/);
  assert.match(cloudTests,
    /NODE_APP_INSTANCE: "1"[\s\S]*closeIdleCalls[\s\S]*phase: "stopped"/);
  assert.match(cloudTests,
    /application\.admissionTracker\.snapshot\(\)\.active[\s\S]*preservedBeforeBody[\s\S]*phase: "stopped"/);
  assert.match(cloudTests,
    /public Cloud nginx forwarding headers do not produce the fixed bad-request edge/);
  assert.match(cloudTests,
    /Cloud listen binds the pinned tools Unix socket and sends PM2 ready/);
  assert.match(cloudTests, /toolsListenSource/);
  assert.match(cloudTests, /listenPath: \$\{JSON\.stringify\(listenPath\)\}/);
  assert.match(cloudTests,
    /cloudProxy: true[\s\S]*application\.shutdown\(\)[\s\S]*closeCodes: \[4001, 4001\]/);
  assert.match(appConfig,
    /createRawRequestGuard\(requestPolicy, runtimeConfig\.cloudProxy\)/);
  assert.match(appConfig,
    /allowProxyHeaders = cloudProxy === true \|\| requestPolicy\.mode === "public"/);
  assert.match(appConfig,
    /stripCloudProxyHeaders\(request\)[\s\S]*delete request\.headers\[name\][\s\S]*request\.rawHeaders\.splice/);
  assert.match(appConfig,
    /function beginCloudHttpDrain\(\)[\s\S]*runtimeConfig\.cloudProxy[\s\S]*httpServer\.close\(\)[\s\S]*closeIdleConnections\(\)[\s\S]*preRequestSockets[\s\S]*socket\.destroy\(\)[\s\S]*if \(!beginCloudHttpDrain\(\)\)[\s\S]*server\.gracefullyShutdown\(false\)/);
  assert.match(gitignore, /^\.colyseus-cloud\.json$/m);
  assert.equal(fs.existsSync(path.join(root, ".colyseus-cloud.json")), false);
  assert.doesNotMatch(pages, /\bserver\//);

  for (const [file, document] of [
    ["AGENTS.md", agents],
    ["CHANGELOG.md", changelog],
    ["docs/ARCHITECTURE.md", architecture],
    ["docs/MULTIPLAYER_ARCHITECTURE.md", multiplayer],
    ["docs/SERVER_OPERATIONS.md", operations],
    ["docs/STATUS.md", status],
    ["tests/README.md", testGuide],
  ]) {
    assert.match(document, /de-fra-1131bd95\.colyseus\.cloud/,
      `${file} must identify the selected Cloud endpoint`);
    assert.match(document, /Pages[\s\S]*(?:Play|PLAY)[\s\S]*(?:offline|bots)/i,
      `${file} must preserve Pages offline Play`);
  }
  assert.match(operations, /Root Directory\*\* to `server`/);
  assert.match(operations, /Wright deployed production `7699ec2`/);
  for (const identity of [
    "stickman-arena` (`1868`)",
    "stickman-arena-ir7f26",
    "Frankfurt",
  ]) {
    assert.ok(operations.includes(identity), `operations omitted ${identity}`);
    assert.ok(status.includes(identity), `status omitted ${identity}`);
  }
  for (const setting of [
    "NODE_ENV=production",
    "STICKMAN_SERVER_MODE=public",
    "STICKMAN_BIND_HOST=0.0.0.0",
    "STICKMAN_PUBLIC_ORIGIN=https://de-fra-1131bd95.colyseus.cloud",
    "STICKMAN_ALLOWED_ORIGINS=https://de-fra-1131bd95.colyseus.cloud,https://xenovoyage.github.io",
  ]) {
    assert.ok(operations.includes(setting), `operations omitted ${setting}`);
    assert.ok(environmentExample.includes(`# ${setting}`), `.env.example omitted ${setting}`);
  }
  assert.match(operations,
    /Merge the issue PR to protected `develop`[\s\S]*separate protected `develop` → `main` promotion[\s\S]*Deploy the exact reviewed production `main` revision/);
  assert.match(testGuide,
    /rollback[\s\S]*prior exact reviewed source revision[\s\S]*matching reviewed Pages client/i);
  assert.match(status, /pre-deployment `502`/);
  assert.match(status,
    /public verification pending[\s\S]*Production `main` `7699ec2cb89abb65d5b3a9f0ece42f36debaf8f2`[\s\S]*nginx returned HTTP `502`/i);
  assert.match(changelog, /## Colyseus Cloud Unix-socket listen/);
  assert.match(changelog, /## Colyseus Cloud rolling-socket hotfix/);
  assert.match(operations, /2567\+NODE_APP_INSTANCE\.sock/);
  assert.match(operations, /wait_ready: true/);
  assert.match(operations, /slots `0` and `1`/);
});

test("Pass 9 compatibility matrices stay complete and evidence-safe", () => {
  const manual = read("tests/README.md");
  const status = read("docs/STATUS.md");
  for (const id of [
    "MAC-01", "MAC-02", "MAC-03", "MAC-04", "MAC-05", "MAC-06", "MAC-07",
    "IOS-01", "IOS-02", "IOS-03", "IOS-04", "IOS-05", "IOS-06", "IOS-07", "IOS-08"
  ]) assert.match(manual, new RegExp(`\\| ${id} \\|`), `${id} compatibility row is missing`);
  for (const field of [
    "exact commit or Pages deployment", "device model", "OS version", "browser and version",
    "both landscape directions", "portrait transition", "true multi-touch", "pointer cancellation",
    "visibility loss", "AudioContext startup/resume", "three-minute regulation"
  ]) assert.match(manual, new RegExp(field, "i"), `compatibility evidence omitted ${field}`);
  assert.match(manual, /Run the iOS matrix separately on an iPhone and an iPad/i);
  assert.match(manual, /Pass`, `Fail`, `Blocked`, or `Not run`/);
  assert.match(manual, /browser automation[^\n]+must not satisfy[^\n]+physical/i);
  for (const device of ["MacBook", "iPhone", "iPad"]) {
    assert.match(status, new RegExp(`\\| Physical ${device} \\| Pending \\|`),
      `${device} physical evidence must remain explicitly pending`);
  }
});

test("audio preferences migrate, clamp, persist, and fail safely", () => {
  const current = { version: 1, soundEnabled: false, masterVolume: 37.6 };
  assert.deepEqual(Audio.normalizePreferences(null, 70), {
    version: 1, soundEnabled: true, masterVolume: 70
  });
  assert.deepEqual(Audio.normalizePreferences(null, 0), {
    version: 1, soundEnabled: false, masterVolume: 0
  });
  assert.deepEqual(Audio.normalizePreferences("0", 70), {
    version: 1, soundEnabled: false, masterVolume: 0
  });
  assert.deepEqual(Audio.normalizePreferences("0.37", 70), {
    version: 1, soundEnabled: true, masterVolume: 37
  });
  assert.deepEqual(Audio.normalizePreferences("100", 70), {
    version: 1, soundEnabled: true, masterVolume: 100
  });
  assert.deepEqual(Audio.normalizePreferences({ volume: 0.42, muted: true }, 70), {
    version: 1, soundEnabled: false, masterVolume: 42
  });
  assert.deepEqual(Audio.normalizePreferences(current, 70), {
    version: 1, soundEnabled: false, masterVolume: 38
  });
  for (const invalid of ["not json", [], { version: 99, masterVolume: 20 },
    { version: 1, soundEnabled: true, masterVolume: "Infinity" }]) {
    assert.deepEqual(Audio.normalizePreferences(invalid, 70), {
      version: 1, soundEnabled: true, masterVolume: 70
    });
  }
  assert.deepEqual(Audio.normalizePreferences({ volume: -10 }, 70).masterVolume, 0);
  assert.deepEqual(Audio.normalizePreferences({ volume: 180 }, 70).masterVolume, 100);

  const storage = makeStorage(JSON.stringify({ volume: 0.35, muted: true }));
  const engine = Audio.create({ storage, initialVolume: 70, AudioContext: null });
  assert.deepEqual(engine.snapshot(), {
    version: 1,
    soundEnabled: false,
    masterVolume: 35,
    effectiveGain: 0,
    hasContext: false,
    contextState: "unavailable",
    activeVoices: 0
  });
  assert.deepEqual(JSON.parse(storage.values.get(Audio.PREFERENCE_KEY)), {
    version: 1, soundEnabled: false, masterVolume: 35
  }, "legacy preference was not rewritten as v1");
  engine.setSoundEnabled(true);
  engine.setMasterVolume(44.8);
  engine.setSoundEnabled(false);
  assert.deepEqual(JSON.parse(storage.values.get(Audio.PREFERENCE_KEY)), {
    version: 1, soundEnabled: false, masterVolume: 45
  }, "mute overwrote the selected master volume");
  assert.deepEqual(new Set([...storage.readKeys, ...storage.writeKeys]), new Set([Audio.PREFERENCE_KEY]),
    "audio preferences probed an invented legacy storage key");
  const roundTrip = Audio.create({ storage, initialVolume: 70, AudioContext: null });
  assert.deepEqual({
    soundEnabled: roundTrip.snapshot().soundEnabled,
    masterVolume: roundTrip.snapshot().masterVolume
  }, { soundEnabled: false, masterVolume: 45 });

  const futureRecord = JSON.stringify({ version: 2, soundEnabled: false, masterVolume: 12, future: true });
  const futureStorage = makeStorage(futureRecord);
  const futureEngine = Audio.create({ storage: futureStorage, initialVolume: 70, AudioContext: null });
  assert.equal(futureEngine.snapshot().masterVolume, 70);
  assert.equal(futureStorage.values.get(Audio.PREFERENCE_KEY), futureRecord,
    "unknown future preference version was destructively rewritten");

  const blockedRead = Audio.create({
    storage: makeStorage(undefined, { throwGet: true }), initialVolume: 62, AudioContext: null
  });
  assert.equal(blockedRead.snapshot().masterVolume, 62);
  const blockedWrite = Audio.create({
    storage: makeStorage(undefined, { throwSet: true }), initialVolume: 70, AudioContext: null
  });
  assert.doesNotThrow(() => blockedWrite.setMasterVolume(120));
  assert.deepEqual({
    soundEnabled: blockedWrite.snapshot().soundEnabled,
    masterVolume: blockedWrite.snapshot().masterVolume
  }, { soundEnabled: true, masterVolume: 100 });
  blockedWrite.setMasterVolume(Number.NaN);
  assert.equal(blockedWrite.snapshot().masterVolume, 100);
  assert.ok(Number.isFinite(blockedWrite.snapshot().effectiveGain));
});

test("audio graph doubles bounded output, mutes active voices, and resumes safely", () => {
  const harness = makeAudioContextHarness();
  const storage = makeStorage();
  const engine = Audio.create({ storage, initialVolume: 70, AudioContext: harness.AudioContext });
  assert.equal(harness.contexts.length, 0, "initialization created AudioContext without a gesture");
  assert.equal(engine.route({ type: "explosion", id: 1 }), 0, "routing created audio before resume");
  assert.equal(harness.contexts.length, 0);
  engine.setMasterVolume(64);
  engine.setSoundEnabled(false);
  engine.setSoundEnabled(true);
  engine.setMasterVolume(70);
  assert.equal(harness.contexts.length, 0, "preference setters created AudioContext without a gesture");

  assert.equal(engine.resume(), true);
  assert.equal(harness.contexts.length, 1);
  const context = harness.contexts[0];
  assert.equal(context.resumeCalls, 1);
  assert.equal(engine.snapshot().effectiveGain, 0.308);
  assert.equal(context.gains[0].gain.value, 0.308);
  assert.equal(context.compressors.length, 1);
  assert.equal(context.gains[0].connections.length, 1, "master gain gained a destination bypass");
  assert.equal(context.gains[0].connections[0], context.compressors[0]);
  assert.equal(context.compressors[0].connections.length, 1);
  assert.equal(context.compressors[0].connections[0], context.destination);
  for (const [name, expected] of Object.entries(Audio.COMPRESSOR)) {
    assert.equal(context.compressors[0][name].value, expected, `compressor ${name} drifted`);
  }
  assert.equal(engine.resume(), true);
  assert.equal(harness.contexts.length, 1, "repeat gesture created a second output graph");

  assert.equal(engine.route({ type: "explosion", id: 9 }), 2);
  assert.equal(engine.snapshot().activeVoices, 2);
  for (const amp of context.gains.slice(1)) {
    assert.deepEqual(amp.gain.calls.map((call) => call[0]), ["set", "ramp", "ramp"],
      "voice envelope lost its initial, attack, or finish stage");
  }
  const sourcesBeforeMute = context.sources.length + context.oscillators.length;
  engine.setSoundEnabled(false);
  assert.equal(context.gains[0].gain.value, 0, "Sound Off did not set exact zero gain");
  assert.equal(engine.snapshot().activeVoices, 0, "Sound Off retained active sources");
  for (const source of [...context.sources, ...context.oscillators]) {
    assert.ok(source.stopCalls.length > 0, `${source.kind} was not stopped by mute`);
    assert.ok(source.disconnects > 0, `${source.kind} was not disconnected by mute`);
  }
  for (const amp of context.gains.slice(1)) assert.ok(amp.disconnects > 0, "voice amp was not disconnected by mute");
  for (const filter of context.filters) assert.ok(filter.disconnects > 0, "noise filter was not disconnected by mute");
  assert.equal(engine.route({ type: "fire", weapon: "rifle", id: 10 }), 0);
  assert.equal(context.sources.length + context.oscillators.length, sourcesBeforeMute,
    "muted routing created a source");
  engine.setSoundEnabled(true);
  assert.equal(context.gains[0].gain.value, 0.308, "unmute did not restore the selected level");
  assert.equal(engine.snapshot().activeVoices, 0, "unmute restored a stale tail");

  engine.setMasterVolume(1000);
  assert.equal(engine.snapshot().masterVolume, 100);
  assert.equal(engine.snapshot().effectiveGain, Audio.MAX_MASTER_GAIN);
  assert.equal(context.gains[0].gain.value, 0.44);
  engine.route({ type: "defeat", id: 11 });
  engine.setMasterVolume(-1);
  assert.equal(context.gains[0].gain.value, 0);
  assert.equal(engine.snapshot().activeVoices, 0);
  assert.equal(engine.resume(), false, "zero volume resumed an inaudible context");

  engine.setMasterVolume(50);
  context.state = "interrupted";
  const createdBeforeInterruptedRoute = context.sources.length + context.oscillators.length;
  assert.equal(engine.route({ type: "explosion", id: 12 }), 0,
    "interrupted context accepted a stale voice");
  assert.equal(context.sources.length + context.oscillators.length, createdBeforeInterruptedRoute);
  assert.equal(engine.resume(), true);
  assert.equal(context.resumeCalls, 2, "interrupted context was not resumed on a later gesture");

  context.state = "closed";
  assert.equal(engine.route({ type: "defeat", id: 13 }), 0, "closed context accepted a voice");
  assert.equal(engine.resume(), true, "closed context was not recreated on a later gesture");
  assert.equal(harness.contexts.length, 2);
  assert.equal(harness.contexts[1].state, "running");
  assert.equal(harness.contexts[1].gains[0].gain.value, 0.22);
});

test("audio context and resume failures stay retryable without unhandled rejection", () => {
  const harness = makeAudioContextHarness({ resumeRejects: true });
  let constructions = 0;
  function FlakyAudioContext() {
    constructions += 1;
    if (constructions === 1) throw new Error("constructor blocked");
    return new harness.AudioContext();
  }
  const engine = Audio.create({ initialVolume: 70, AudioContext: FlakyAudioContext });
  assert.equal(engine.resume(), false);
  assert.equal(engine.snapshot().hasContext, false);
  assert.equal(engine.resume(), true);
  assert.equal(engine.snapshot().hasContext, true);
  assert.equal(harness.contexts[0].resumeCatches, 1, "resume rejection was not handled");
  assert.equal(engine.route({ type: "explosion", id: 1 }), 0,
    "rejected resume accepted voices into a suspended context");
  assert.equal(harness.contexts[0].sources.length + harness.contexts[0].oscillators.length, 0);
  assert.equal(engine.resume(), true, "resume rejection prevented a later retry");
  assert.equal(harness.contexts[0].resumeCatches, 2);

  const throwingResumeHarness = makeAudioContextHarness({ resumeThrows: true });
  const throwingResume = Audio.create({ initialVolume: 70, AudioContext: throwingResumeHarness.AudioContext });
  assert.doesNotThrow(() => throwingResume.resume());
  assert.equal(throwingResumeHarness.contexts[0].resumeCalls, 1);
  assert.doesNotThrow(() => throwingResume.resume());
  assert.equal(throwingResumeHarness.contexts[0].resumeCalls, 2, "synchronous resume failure was not retryable");

  const graphHarness = makeAudioContextHarness();
  let graphConstructions = 0;
  function FlakyGraphContext() {
    graphConstructions += 1;
    const context = new graphHarness.AudioContext();
    if (graphConstructions === 1) context.createDynamicsCompressor = () => { throw new Error("graph blocked"); };
    return context;
  }
  const graphEngine = Audio.create({ initialVolume: 70, AudioContext: FlakyGraphContext });
  assert.equal(graphEngine.resume(), false);
  assert.equal(graphEngine.snapshot().hasContext, false);
  assert.equal(graphHarness.contexts[0].closeCalls, 1, "failed graph context was not released");
  assert.equal(graphEngine.resume(), true, "graph construction failure was not retryable");
  assert.equal(graphHarness.contexts.length, 2);

  const closeFailureHarness = makeAudioContextHarness({ closeRejects: true });
  const closeFailureEngine = Audio.create({
    initialVolume: 70,
    AudioContext: function () {
      const context = new closeFailureHarness.AudioContext();
      context.createDynamicsCompressor = () => { throw new Error("graph blocked"); };
      return context;
    }
  });
  assert.doesNotThrow(() => closeFailureEngine.resume());
  assert.equal(closeFailureHarness.contexts[0].closeCatches, 1,
    "failed graph close rejection was not handled");
});

test("audio voices are bounded, deterministic, and cleaned on end", () => {
  const harness = makeAudioContextHarness({ initialState: "running" });
  const engine = Audio.create({ initialVolume: 100, AudioContext: harness.AudioContext });
  engine.resume();
  const context = harness.contexts[0];
  engine.route({ type: "attack", weapon: "unarmed", id: 4 });
  engine.route({ type: "attack", weapon: "unarmed", id: 4 });
  assert.equal(context.buffers.length, 1, "deterministic noise buffer was not cached");
  assert.equal(context.sources[0].buffer, context.sources[1].buffer);
  const firstNoise = Array.from(context.buffers[0].getChannelData(0).slice(0, 16));
  const noiseBytes = Buffer.from(context.buffers[0].getChannelData(0).buffer);
  assert.equal(crypto.createHash("sha256").update(noiseBytes).digest("hex"),
    "e7a149d62128cb7f60723dd38d9b0dca220f0b407edeb3b16618a710680d6d93");
  const secondHarness = makeAudioContextHarness({ initialState: "running" });
  const secondEngine = Audio.create({ initialVolume: 100, AudioContext: secondHarness.AudioContext });
  secondEngine.resume();
  secondEngine.route({ type: "attack", weapon: "unarmed", id: 4 });
  assert.deepEqual(Array.from(secondHarness.contexts[0].buffers[0].getChannelData(0).slice(0, 16)), firstNoise);

  const firstSource = context.sources[0];
  const activeBeforeEnd = engine.snapshot().activeVoices;
  firstSource.onended();
  assert.equal(engine.snapshot().activeVoices, activeBeforeEnd - 1);
  firstSource.onended();
  assert.equal(engine.snapshot().activeVoices, activeBeforeEnd - 1, "ended cleanup was not idempotent");
  assert.ok(firstSource.disconnects > 0);
  assert.ok(context.filters[0].disconnects > 0);

  for (let index = 0; index < Audio.MAX_ACTIVE_VOICES * 2; index += 1) {
    engine.route({ type: "defeat", id: 100 + index });
  }
  assert.equal(engine.snapshot().activeVoices, Audio.MAX_ACTIVE_VOICES);
  const createdAtCap = context.oscillators.length + context.sources.length;
  engine.route({ type: "explosion", id: 999 });
  assert.equal(context.oscillators.length + context.sources.length, createdAtCap,
    "voice cap admitted more sources");
  const activeAtCap = [...context.sources, ...context.oscillators].find((source) =>
    source.onended && source.disconnects === 0);
  activeAtCap.onended();
  assert.equal(engine.snapshot().activeVoices, Audio.MAX_ACTIVE_VOICES - 1);
  engine.route({ type: "defeat", id: 1000 });
  assert.equal(engine.snapshot().activeVoices, Audio.MAX_ACTIVE_VOICES,
    "ended voice did not free exactly one cap slot");
  assert.equal(context.oscillators.length + context.sources.length, createdAtCap + 1);
  engine.setSoundEnabled(false);
  assert.equal(engine.snapshot().activeVoices, 0);

  const startFailureHarness = makeAudioContextHarness({ initialState: "running", startThrows: true });
  const startFailure = Audio.create({ initialVolume: 70, AudioContext: startFailureHarness.AudioContext });
  startFailure.resume();
  assert.doesNotThrow(() => startFailure.route({ type: "defeat", id: 1 }));
  assert.equal(startFailure.snapshot().activeVoices, 0);
  assert.ok(startFailureHarness.contexts[0].oscillators[0].disconnects > 0);

  const stopFailureHarness = makeAudioContextHarness({
    initialState: "running", stopThrows: true, stopThrowsAfter: 1
  });
  const stopFailure = Audio.create({ initialVolume: 70, AudioContext: stopFailureHarness.AudioContext });
  stopFailure.resume();
  stopFailure.route({ type: "explosion", id: 2 });
  assert.doesNotThrow(() => stopFailure.setSoundEnabled(false));
  assert.equal(stopFailure.snapshot().activeVoices, 0);
});

test("audio allocation and scheduling failures cannot escape presentation", () => {
  function runningEngine() {
    const harness = makeAudioContextHarness({ initialState: "running" });
    const engine = Audio.create({ initialVolume: 70, AudioContext: harness.AudioContext });
    engine.resume();
    return { engine, harness, context: harness.contexts[0] };
  }

  const allocation = runningEngine();
  allocation.context.createOscillator = () => { throw new Error("allocation blocked"); };
  assert.doesNotThrow(() => allocation.engine.route({ type: "defeat", id: 1 }));
  assert.equal(allocation.engine.snapshot().activeVoices, 0);

  const parameter = runningEngine();
  const createParameterOscillator = parameter.context.createOscillator.bind(parameter.context);
  parameter.context.createOscillator = () => {
    const oscillator = createParameterOscillator();
    oscillator.frequency.setValueAtTime = () => { throw new Error("parameter blocked"); };
    return oscillator;
  };
  assert.doesNotThrow(() => parameter.engine.route({ type: "defeat", id: 2 }));
  assert.equal(parameter.engine.snapshot().activeVoices, 0);
  assert.ok(parameter.context.oscillators[0].disconnects > 0,
    "partially allocated parameter-failure node was not disconnected");

  const connection = runningEngine();
  const createConnectionOscillator = connection.context.createOscillator.bind(connection.context);
  connection.context.createOscillator = () => {
    const oscillator = createConnectionOscillator();
    oscillator.connect = () => { throw new Error("connection blocked"); };
    return oscillator;
  };
  assert.doesNotThrow(() => connection.engine.route({ type: "defeat", id: 3 }));
  assert.equal(connection.engine.snapshot().activeVoices, 0);
  assert.ok(connection.context.oscillators[0].disconnects > 0);
  assert.ok(connection.context.gains[1].disconnects > 0,
    "partially connected voice gain was not disconnected");

  const buffer = runningEngine();
  buffer.context.createBuffer = () => { throw new Error("buffer blocked"); };
  assert.doesNotThrow(() => buffer.engine.route({ type: "attack", weapon: "unarmed", id: 4 }));
  assert.equal(buffer.engine.snapshot().activeVoices, 0);

  const malformedOffset = runningEngine();
  assert.doesNotThrow(() => malformedOffset.engine.route({
    type: "attack", weapon: "unarmed", id: Symbol("invalid")
  }));
  assert.equal(malformedOffset.engine.snapshot().activeVoices, 0);
  assert.ok(malformedOffset.context.sources[0].disconnects > 0);
  assert.ok(malformedOffset.context.filters[0].disconnects > 0);
  assert.ok(malformedOffset.context.gains[1].disconnects > 0);

  const masterParameter = runningEngine();
  masterParameter.engine.route({ type: "defeat", id: 5 });
  masterParameter.context.gains[0].gain.setValueAtTime = () => { throw new Error("master blocked"); };
  assert.doesNotThrow(() => masterParameter.engine.setSoundEnabled(false));
  assert.deepEqual({
    soundEnabled: masterParameter.engine.snapshot().soundEnabled,
    effectiveGain: masterParameter.engine.snapshot().effectiveGain,
    hasContext: masterParameter.engine.snapshot().hasContext,
    activeVoices: masterParameter.engine.snapshot().activeVoices
  }, { soundEnabled: false, effectiveGain: 0, hasContext: false, activeVoices: 0 });
  assert.equal(masterParameter.context.closeCalls, 1, "unsafe master graph was not released");
  masterParameter.engine.setSoundEnabled(true);
  assert.equal(masterParameter.engine.resume(), true, "released master graph was not retryable");
  assert.equal(masterParameter.harness.contexts.length, 2);
});

test("audio event routing preserves every approved identity and silence boundary", () => {
  function recipe(event) {
    const calls = [];
    const count = Audio.routeEvent(event, {
      tone: (...args) => calls.push(["tone", ...args]),
      noise: (...args) => calls.push(["noise", ...args])
    });
    assert.equal(count, calls.length);
    return calls;
  }
  const routes = [
    [{ type: "attack", weapon: "sword" }, 2],
    [{ type: "attack", weapon: "unarmed" }, 1],
    [{ type: "attack", weapon: "grenade" }, 2],
    [{ type: "meleeSwing", weapon: "sword" }, 2],
    [{ type: "meleeSwing", weapon: "unarmed" }, 2],
    ...["pistol", "shotgun", "rifle"].map((weapon) => [{ type: "fire", weapon }, 2]),
    ...["unarmed", "sword", "pistol", "shotgun", "rifle", "grenade"].map((weapon) => [{ type: "hit", weapon }, 2]),
    [{ type: "hit", weapon: "hazard" }, 1],
    [{ type: "spark", weapon: "rifle" }, 1],
    [{ type: "spark", weapon: "pistol" }, 1],
    [{ type: "grenadeThrow" }, 2],
    [{ type: "grenadeBounce" }, 1],
    [{ type: "explosion" }, 2],
    [{ type: "dryFire" }, 2],
    ...["pistol", "shotgun", "rifle"].map((weapon) => [{ type: "reloadStart", weapon }, 1]),
    [{ type: "reload", weapon: "pistol" }, 1],
    [{ type: "reload", weapon: "shotgun" }, 2],
    [{ type: "reload", weapon: "rifle" }, 1],
    [{ type: "pickup", kind: "weapon" }, 1],
    [{ type: "pickup", kind: "ammo" }, 1],
    [{ type: "pickup", kind: "health" }, 2],
    [{ type: "pickupRespawn", kind: "health" }, 2],
    [{ type: "jump" }, 1],
    [{ type: "defeat" }, 1]
  ];
  for (const [event, expected] of routes) {
    event.id = 73;
    assert.equal(recipe(event).length, expected, `${event.type}/${event.weapon || event.kind || "default"} route drifted`);
  }
  const recipeSnapshot = routes.map(([event]) => [
    event.type, event.weapon || null, event.kind || null, recipe(event)
  ]);
  assert.equal(crypto.createHash("sha256").update(JSON.stringify(recipeSnapshot)).digest("hex"),
    "b982eda969213291565fcd0e81caef52defc8ef67188eee47ae0b426675373dc",
    "an established audio frequency, duration, waveform, gain, filter, slide, or event offset drifted");
  const noise = recipe({ type: "fire", weapon: "shotgun", id: 73 }).find((call) => call[0] === "noise");
  assert.equal(noise.at(-1), 73, "noise routing lost its deterministic event offset");
  assert.equal(recipe({ type: "bulletHit", weapon: "pistol" }).length, 0);
  assert.equal(recipe({ type: "pickupRespawn", kind: "ammo" }).length, 0);
  for (const type of ["respawn", "land", "hazard", "matchEnd", "unknown"]) {
    assert.equal(recipe({ type }).length, 0, `${type} gained an unapproved audio route`);
  }
});

test("runtime files match the reviewed source checkpoint", () => {
  for (const [file, expected] of Object.entries(runtimeHashes)) {
    const actual = crypto.createHash("sha256").update(fs.readFileSync(path.join(root, file))).digest("hex");
    assert.equal(actual, expected, `${file} changed outside an authorized gameplay pass`);
  }
});

test("local documentation links resolve inside the repository", () => {
  for (const file of walkFiles(root).filter((candidate) => candidate.endsWith(".md"))) {
    const markdown = fs.readFileSync(file, "utf8");
    for (const match of markdown.matchAll(/\[[^\]]*\]\(([^)]+)\)/g)) {
      const href = match[1].trim();
      if (/^(?:https?:|mailto:|#)/i.test(href)) continue;
      const target = decodeURI(href.split("#", 1)[0]);
      const resolved = path.resolve(path.dirname(file), target);
      assert.ok(resolved === root || resolved.startsWith(`${root}${path.sep}`), `${file}: ${href} escapes the repository`);
      assert.ok(fs.existsSync(resolved), `${file}: ${href} does not exist`);
    }
  }
});

test("workflows are pinned, least-privilege, and clean only proven merged agent branches", () => {
  const ci = read(".github/workflows/ci.yml");
  const pages = read(".github/workflows/pages.yml");
  const cleanup = read(".github/workflows/branch-cleanup.yml");
  const security = read("SECURITY.md");
  assert.match(ci, /^name: Baseline checks$/m);
  assert.match(ci, /on:\n  pull_request:\n    branches: \[main, develop\]\n  push:\n    branches: \[main, develop\]\n\npermissions:/);
  assert.match(ci, /^  audit:\n    name: audit$/m);
  for (const [file, workflow] of [["ci.yml", ci], ["pages.yml", pages], ["branch-cleanup.yml", cleanup]]) {
    for (const match of workflow.matchAll(/uses:\s+[^@\s]+@([^\s]+)/g)) {
      assert.match(match[1], /^[0-9a-f]{40}$/, `${file} action is not pinned to a full commit SHA`);
    }
  }
  const checkoutV7 = "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1";
  assert.ok(ci.includes(checkoutV7));
  assert.ok(pages.includes(checkoutV7));
  assert.match(pages, /cp -- index\.html styles\.css sim\.js animation\.js bot\.js touch\.js input\.js audio\.js multiplayer\.js online-client\.js game\.js _site\//);
  assert.ok(ci.includes("actions/setup-node@820762786026740c76f36085b0efc47a31fe5020"));
  assert.match(pages, /on:\n  push:\n    branches: \[main\]/);
  assert.doesNotMatch(pages, /branches: \[[^\]]*develop/);
  assert.match(pages, /environment:\s*\n\s+name: github-pages/);
  assert.match(cleanup, /push:\s*\n\s+branches: \[main, develop\]/);
  assert.doesNotMatch(cleanup, /pull_request:/);
  assert.match(cleanup, /concurrency:\s*\n\s+group: merged-agent-branch-cleanup\s*\n\s+cancel-in-progress: false/);
  assert.match(cleanup, /permissions: \{\}/);
  assert.match(cleanup, /contents: write[\s\S]*pull-requests: read/);
  assert.match(cleanup, /actions\/github-script@3a2844b7e9c422d3c10d287c895573f7108da1b3/);
  assert.doesNotMatch(cleanup, /actions\/checkout|\brun:/);
  assert.match(cleanup, /const integrationBranch = context\.ref\.replace\("refs\/heads\/", ""\)/);
  assert.match(cleanup, /const allowedIntegrationBranches = new Set\(\["main", "develop"\]\)/);
  assert.match(cleanup,
    /const protectedBranchNames = new Set\(\[defaultBranch, integrationBranch, \.\.\.allowedIntegrationBranches\]\)/);
  assert.match(cleanup, /!allowedIntegrationBranches\.has\(integrationBranch\)/);
  assert.match(cleanup, /context\.ref !== `refs\/heads\/\$\{integrationBranch\}`/);
  assert.match(cleanup, /defaultBranch !== "main"/);
  assert.match(cleanup, /protectedBranchNames\.has\(branch\)/);
  assert.match(cleanup, /ref: "heads\/agent\/"/);
  assert.match(cleanup, /branchInfo\.data\.protected/);
  assert.match(cleanup, /state: "open", head:/);
  assert.match(cleanup, /state: "open", base:/);
  assert.match(cleanup,
    /pull\.head\.ref === branch && sameRepository\(pull\.head\.repo\)[\s\S]*pull\.base\.ref === integrationBranch && sameRepository\(pull\.base\.repo\) && pull\.head\.sha === tip/);
  assert.match(cleanup,
    /detail\.data\.merged === true[\s\S]*detail\.data\.head\.ref === branch && sameRepository\(detail\.data\.head\.repo\)[\s\S]*detail\.data\.base\.ref === integrationBranch && sameRepository\(detail\.data\.base\.repo\)[\s\S]*detail\.data\.head\.sha === tip/);
  assert.doesNotMatch(cleanup, /(?:pull|detail\.data)\.base\.ref === defaultBranch/);
  assert.match(cleanup, /current\.data\.object\.sha !== tip/);
  assert.ok((cleanup.match(/await openUsage\(branch\)/g) || []).length >= 2);
  assert.match(cleanup, /rel="next"/);
  assert.equal((cleanup.match(/error\.status === 404/g) || []).length, 2,
    "only the final ref recheck and delete may treat a 404 as an already-absent branch");
  assert.match(cleanup, /already absent at final ref check/);
  assert.match(cleanup, /already absent at deletion/);
  assert.match(cleanup, /catch \(error\) \{\s*failures\.push/);
  assert.match(cleanup, /core\.setFailed/);
  assert.match(cleanup, /github\.rest\.git\.deleteRef/);
  assert.match(security,
    /workflow with `contents: write` runs from the protected `main` and `develop` integration branches[\s\S]*exact head was merged into the triggering integration branch/);
});

test("offline shell uses every local runtime file in authority order", () => {
  const html = read("index.html");
  const resources = [
    "styles.css", "sim.js", "animation.js", "bot.js", "touch.js", "input.js", "audio.js",
    "multiplayer.js", "online-client.js", "game.js"
  ];
  for (const resource of resources) {
    const cacheKey = runtimeHashes[resource].slice(0, 12);
    const assetUrl = `${resource}?v=${cacheKey}`;
    assert.match(html, new RegExp(`(?:src|href)=["']${assetUrl.replace(/[.?]/g, "\\$&")}["']`));
    assert.ok(fs.statSync(path.join(root, resource)).size > 1000);
  }
  const scripts = [...html.matchAll(/<script\s+src=["']([^"']+)["']/g)].map((match) => match[1]);
  assert.deepEqual(scripts, [
    "sim.js", "animation.js", "bot.js", "touch.js", "input.js", "audio.js",
    "multiplayer.js", "online-client.js", "game.js"
  ].map((resource) => `${resource}?v=${runtimeHashes[resource].slice(0, 12)}`));
  assert.doesNotMatch(html, /(?:src|href)=["'](?:https?:)?\/\//i);
  assert.doesNotMatch(html, /<(?:script|link)[^>]+type=["']module["']/i);
  for (const file of ["index.html", "styles.css", "sim.js", "animation.js", "bot.js", "touch.js", "input.js", "audio.js", "multiplayer.js", "game.js"]) {
    assert.doesNotMatch(read(file), /\b(?:fetch|WebSocket|EventSource)\s*\(/, `${file} must remain offline`);
  }
  for (const file of ["sim.js", "animation.js", "bot.js"]) {
    assert.doesNotMatch(read(file), /\b(?:Math\.random|Date\.now|performance\.now)\b/, `${file} must remain deterministic`);
  }
});

test("presentation keeps a stable camera and minimal complete menu route", () => {
  const html = read("index.html");
  const css = read("styles.css");
  const game = read("game.js");
  const startMenu = html.slice(html.indexOf('id="startOverlay"'), html.indexOf('id="pauseOverlay"'));
  const pauseMenu = html.slice(html.indexOf('id="pauseOverlay"'), html.indexOf('id="resultOverlay"'));
  const resultMenu = html.slice(html.indexOf('id="resultOverlay"'), html.indexOf('id="controlsDialog"'));
  const topHud = html.slice(html.indexOf('<header class="top-hud">'), html.indexOf('</header>', html.indexOf('<header class="top-hud">')));
  const htmlIds = [...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]);
  const uiRegistry = game.slice(game.indexOf("var ui = {}"), game.indexOf("].forEach(function (id)"));
  const registeredIds = [...uiRegistry.matchAll(/"([A-Za-z][A-Za-z0-9]+)"/g)].map((match) => match[1]);
  assert.equal(new Set(htmlIds).size, htmlIds.length, "HTML contains duplicate IDs");
  for (const id of registeredIds) assert.ok(htmlIds.includes(id), `game.js registers missing #${id}`);
  assert.doesNotMatch(game, /\bshake\b/);
  assert.match(game, /ctx\.setTransform\(scale, 0, 0, scale, ox, oy\)/);
  assert.match(html, /id="mainMenuButton"/);
  assert.match(game, /ui\.mainMenuButton\.addEventListener\("click", returnToMainMenu\)/);
  assert.match(game, /ui\.resultMainMenuButton\.addEventListener\("click", returnToMainMenu\)/);
  assert.match(game, /if \(!started \|\| paused\) return/);
  assert.match(html, /<canvas[^>]+tabindex="-1"/);
  assert.match(html, /id="pauseOverlay"[^>]+role="dialog"[^>]+aria-labelledby="pauseTitle"/);
  assert.doesNotMatch(pauseMenu, /aria-modal="true"/);
  assert.match(css, /\.hud-pause\[hidden\]\s*\{\s*display:\s*none/);
  assert.match(startMenu, /id="startButton"[^>]*>PLAY<\/button>[\s\S]*id="mainControlsButton"[^>]*>CONTROLS<\/button>[\s\S]*id="mainSettingsButton"[^>]*>SETTINGS<\/button>/);
  assert.match(startMenu, /class="menu-actions" role="group" aria-label="Main menu"[\s\S]*<\/div>[\s\S]*<small class="menu-version">v2026\.9\.2<\/small>/);
  assert.equal((startMenu.match(/class="menu-version"/g) || []).length, 1);
  assert.doesNotMatch(pauseMenu, /menu-version/);
  assert.doesNotMatch(resultMenu, /menu-version/);
  assert.match(css, /\.menu-version\s*\{[\s\S]*color:\s*rgba\([^;]+,\s*0\.74\);[\s\S]*font-size:\s*clamp\([^;]+\);[\s\S]*pointer-events:\s*none;/);
  assert.doesNotMatch(css, /\.menu-version\s*\{[^}]*\b(?:display:\s*none|visibility:\s*hidden|opacity:\s*0(?:[;\s}]|\.0))/s);
  assert.doesNotMatch(startMenu, /botCountControl|aimControl|volumeControl|MOVE FAST|FREE-FOR-ALL|FIRST TO/);
  assert.match(pauseMenu, /id="resumeButton"[^>]*>RESUME<\/button>[\s\S]*id="restartButton"[^>]*>RESTART<\/button>[\s\S]*id="pauseControlsButton"[^>]*>CONTROLS<\/button>[\s\S]*id="pauseSettingsButton"[^>]*>SETTINGS<\/button>[\s\S]*id="mainMenuButton"[^>]*>MAIN MENU<\/button>/);
  assert.doesNotMatch(pauseMenu, /MATCH SUSPENDED|pauseSoundVolume|pauseAimMode/);
  for (const dialogId of ["controlsDialog", "settingsDialog"]) {
    assert.match(html, new RegExp(`<dialog id="${dialogId}"`));
    assert.match(html, new RegExp(`aria-controls="${dialogId}"`));
  }
  assert.match(html, /HYBRID · MOVE<\/dt><dd><kbd>A<\/kbd> <kbd>D<\/kbd> move\. <kbd>W<\/kbd> or <kbd>SPACE<\/kbd> jumps; <kbd>S<\/kbd> drops/);
  assert.match(html, /HYBRID · AIM<\/dt><dd>Pointer aims directly\. LEFT CLICK or <kbd>F<\/kbd> attacks; RIGHT CLICK or <kbd>E<\/kbd> picks up/);
  assert.match(html, /KEYBOARD ONLY · AIM<\/dt><dd><kbd>↑<\/kbd> <kbd>↓<\/kbd> aim high or low\. <kbd>F<\/kbd> attacks; <kbd>E<\/kbd> picks up/);
  assert.match(html, /id="controlPresetControl"[\s\S]*value="hybrid" selected[\s\S]*value="keyboard"/);
  assert.match(html, /id="smartActionControl"[\s\S]*value="on" selected[\s\S]*value="off"/);
  assert.match(html, /id="touchControl"[\s\S]*value="auto" selected[\s\S]*value="on"[\s\S]*value="off"/);
  assert.match(html, /for="soundControl"[\s\S]*>SOUND<[\s\S]*ALL EFFECTS ON OR OFF[\s\S]*id="soundControl"[\s\S]*value="on" selected[\s\S]*value="off"/);
  assert.match(html, /for="volumeControl"[\s\S]*>MASTER VOLUME<[\s\S]*id="volumeControl"[^>]*min="0"[^>]*max="100"[^>]*value="70"/);
  assert.match(game, /window\.localStorage[\s\S]*Audio\.create\(\{[\s\S]*initialVolume: ui\.volumeControl\.value/);
  assert.match(game, /syncAudioControls\(audio\.snapshot\(\)\)/);
  assert.match(game, /ui\.soundControl\.addEventListener\("change"[\s\S]*ui\.volumeControl\.addEventListener\("input"/);
  assert.match(game, /audio\.setSoundEnabled/);
  assert.match(game, /audio\.setMasterVolume/);
  assert.match(game, /if \(anyDialogOpen\(\)\) return;[\s\S]*pause\(!paused\)/);
  assert.match(game, /ui\.controlsDialog\.addEventListener\("close", restoreDialogFocus\)/);
  assert.match(game, /ui\.settingsDialog\.addEventListener\("close", restoreDialogFocus\)/);
  assert.match(game, /window\.crypto\.getRandomValues/);
  assert.match(game, /makeState\(nextMatchSeed\(\)\)/);
  assert.match(game, /if \(started\) \{[\s\S]*drawFighter/);
  assert.doesNotMatch(game, /pauseSoundVolume|pauseSoundValue|pauseAimMode/);
  assert.doesNotMatch(html, /GAMEPLAY REVIEW BUILD|No second chances|quick-rules|start-grid|title-card/);
  assert.doesNotMatch(css, /\.(?:quick-rules|start-grid|title-card|is-visible|settings-grid|menu-controls|overlay-card|compact-card|pause-settings|key-hint)\b/);
  assert.match(topHud, /class="player-panel glass-panel"[\s\S]*id="playerScore"[\s\S]*id="healthFill"[\s\S]*id="weaponText"[\s\S]*id="ammoText"/);
  assert.match(topHud, /id="matchTimer"[\s\S]*id="pauseButton"/);
  assert.match(topHud, /aria-label="Regulation time remaining"[\s\S]*>REGULATION<[\s\S]*id="matchTimer">03:00</);
  assert.doesNotMatch(topHud, /FIRST TO|matchGoal|score limit/i);
  assert.match(html, /id="resultEyebrow"[^>]*>REGULATION COMPLETE<[\s\S]*id="rematchButton"[^>]*>REMATCH<\/button>/);
  assert.match(game, /ui\.resultCopy\.textContent = [^;]+highest score[^;]+0:00[^;]+Rematch[^;]+;/i);
  assert.doesNotMatch(html, /brand-panel|controls-panel|bottom-hud|corner-button|menu-button-primary/);
  assert.doesNotMatch(css, /\.(?:brand-panel|brand-mark|controls-panel|bottom-hud|corner-button|menu-button-primary)\b/);
  assert.doesNotMatch(game, /ui\.startButton\.focus\(\)|ui\.resumeButton\.focus\(\)|ui\.rematchButton\.focus\(\)/);
  assert.match(css, /@media \(hover: hover\) and \(pointer: fine\)[\s\S]*\.using-pointer \.menu-button:hover/);
  assert.match(css, /\.using-keyboard \.menu-button:focus/);
  assert.match(game, /classList\.remove\("using-keyboard"\)[\s\S]*classList\.remove\("using-pointer"\)[\s\S]*classList\.add\("using-keyboard"\)/);
  assert.match(game, /classList\.toggle\("using-pointer", event\.pointerType !== "touch"\)/);
});

test("online room menu uses fixed local or Cloud endpoints while offline Play remains available", () => {
  const html = read("index.html");
  const css = read("styles.css");
  const game = read("game.js");
  const online = read("online-client.js");
  const apiBlock = online.slice(online.indexOf("root.StickOnline = Object.freeze"));

  assert.match(html, /id="startButton"[^>]*>PLAY<\/button>/,
    "the offline/default menu must retain its literal Play action");
  assert.match(html, /id="onlineMatchPanel"[^>]+aria-label="Online match options"[^>]+hidden/,
    "the online-only controls must be absent from the default accessibility tree");
  assert.match(html, /id="createMatchButton"[^>]*>CREATE MATCH<\/button>/);
  assert.match(html, /<form id="joinMatchForm"[^>]*novalidate>[\s\S]*<label for="roomCodeInput">JOIN MATCH<\/label>/);
  assert.match(html, /id="roomCodeInput"[^>]+minlength="7"[^>]+maxlength="7"[^>]+pattern="\[A-HJ-NP-Z2-9\]\{7\}"[^>]+autocomplete="off"[^>]+autocapitalize="characters"[^>]+autocorrect="off"[^>]+spellcheck="false"/);
  assert.match(html, /id="roomCodeDisplay"[^>]+hidden[\s\S]*<output id="roomCodeOutput"[^>]+role="status"[^>]+aria-live="polite"[^>]+aria-atomic="true"[^>]+aria-label="Created match room code"><\/output>/);
  assert.match(html, /id="cancelOnlineButton"[^>]*>CANCEL \/ LEAVE<\/button>/);
  assert.match(html, /id="networkStatus"[^>]+role="status"[^>]+aria-live="polite"[^>]+hidden/);

  assert.match(online, /var ROOM_CODE_PATTERN = \/\^\[A-HJ-NP-Z2-9\]\{7\}\$\//);
  assert.match(online, /var MAX_ROOM_CODE_INPUT_LENGTH = 32[\s\S]*value\.length > MAX_ROOM_CODE_INPUT_LENGTH/);
  assert.match(online, /function quickMatch\(\)[\s\S]*connect\("quick-match", null\)/);
  assert.match(online, /function createMatch\(\)[\s\S]*connect\("create-match", null\)/);
  assert.match(online, /function joinMatch\(value\)[\s\S]*canonicalRoomCode\(value\)[\s\S]*connect\("join-code", canonical\)/);
  assert.match(online, /client\.joinOrCreate\("arena", \{[\s\S]*operation: "quick-match"[\s\S]*modeId: Sim\.DEFAULT_MODE_ID[\s\S]*mapId: Sim\.DEFAULT_MAP_ID/);
  assert.match(online, /client\.create\("arena", \{[\s\S]*operation: "create-match"[\s\S]*modeId: Sim\.DEFAULT_MODE_ID[\s\S]*mapId: Sim\.DEFAULT_MAP_ID/);
  assert.match(online, /client\.joinById\(roomCode, \{[\s\S]*operation: "join-code"/);
  assert.match(online, /operation === "join-code" && \[521, 522, 523, 524\]\.indexOf\(code\) >= 0/);
  assert.match(online, /statusCode === 429 \|\| code === 429/);
  assert.match(online, /function rejectAndRemove\(error\)[\s\S]*script\.remove\(\)[\s\S]*script\.onerror[\s\S]*rejectAndRemove/);
  assert.match(online, /var detail = generation === connectionGeneration[\s\S]*safeFailureDetail\(error, operation\)[\s\S]*throw new Error\(detail\)/,
    "public matchmaking rejections must contain only fixed client text");
  assert.match(online, /publicRoomCode = canonicalRoomCode\(joinedRoom\.roomId\)/);
  assert.match(apiBlock, /quickMatch: quickMatch,[\s\S]*createMatch: createMatch,[\s\S]*joinMatch: joinMatch/);
  assert.match(apiBlock, /quickMatchAvailable: quickMatchAvailable/);
  assert.doesNotMatch(apiBlock, /\n\s+connect:/,
    "the public adapter must not accept a general matchmaking/options surface");
  assert.doesNotMatch(online, /serverUrl/);
  assert.match(online,
    /PAGES_ORIGIN = "https:\/\/xenovoyage\.github\.io"[\s\S]*"\/Stickman-Arena\/"[\s\S]*CLOUD_SERVER_ORIGIN = "https:\/\/de-fra-1131bd95\.colyseus\.cloud"/);
  assert.match(online,
    /function requested\(\)[\s\S]*protocol === "file:"[\s\S]*isPagesClient\(\)[\s\S]*get\("online"\) === "1"/);
  assert.match(online,
    /function quickMatchAvailable\(\)[\s\S]*requested\(\) && !isPagesClient\(\)/);
  assert.match(online,
    /script\.src = serverOrigin\(\) \+ "\/online-sdk\.js"[\s\S]*new Colyseus\.Client\(serverOrigin\(\)\)/);

  assert.match(game,
    /if \(onlineAvailable\)[\s\S]*if \(Online\.quickMatchAvailable\(\)\) ui\.startButton\.textContent = "QUICK MATCH"[\s\S]*ui\.onlineMatchPanel\.hidden = false/);
  assert.match(game, /Online\.quickMatch\(\)[\s\S]*Online\.createMatch\(\)[\s\S]*Online\.joinMatch\(ui\.roomCodeInput\.value\)/);
  assert.match(game, /ui\.cancelOnlineButton\.addEventListener\("click", returnToMainMenu\)/);
  assert.match(game, /function updateStatusSurface\(element, text, state, visible\)[\s\S]*element\.textContent !== text[\s\S]*getAttribute\("data-state"\) !== state/,
    "aria-live status text must not be replaced on every animation frame");
  assert.match(game, /pendingBecameActive[\s\S]*ui\.cancelOnlineButton\.focus\(\)[\s\S]*onlineMenuPending = pending/,
    "waiting-state focus must move into the visible Cancel\/Leave surface once");
  assert.match(game, /var retryControl =[\s\S]*retryControl\.focus\(\)/,
    "terminal retry focus must be scrolled into the online menu");
  assert.match(game, /roomCodeValidationDismissed = true[\s\S]*getAttribute\("aria-invalid"\) !== "false"/);
  assert.match(game, /if \(onlineAvailable && Online\.quickMatchAvailable\(\)\) \{[\s\S]*botCount = 2[\s\S]*ui\.botCountControl\.value = "2"[\s\S]*FIXED ONLINE TOPOLOGY/,
    "online Settings must show the server-fixed two-bot topology");
  assert.match(game,
    /function startMatch\(\)[\s\S]*onlineAvailable && Online\.quickMatchAvailable\(\)[\s\S]*onlineMode = false[\s\S]*botCount = Number\(ui\.botCountControl\.value\)/,
    "Pages Play must retain the offline bot path while Create and Join remain available");
  assert.match(game,
    /function prepareOnlineRequest\(\)[\s\S]*offlineBotCountValue = ui\.botCountControl\.value[\s\S]*FIXED ONLINE TOPOLOGY[\s\S]*function restoreOfflineBotSettings\(\)[\s\S]*ui\.botCountControl\.value = offlineBotCountValue[\s\S]*APPLIES NEXT MATCH/,
    "Pages online intent must present fixed topology and restore offline bot settings");
  assert.match(game, /offlineBotCountValue === null/,
    "repeated online retries must not overwrite the saved offline bot count");
  assert.match(game,
    /terminalConnection && !onlineTerminalPresented[\s\S]*restoreOfflineBotSettings\(\)[\s\S]*retryControl\.focus/,
    "terminal Pages admission must restore offline bot settings before retry focus");
  assert.match(game, /connection\.matchmakingOperation === "join-code"[\s\S]*ui\.roomCodeInput[\s\S]*connection\.matchmakingOperation === "create-match"[\s\S]*ui\.createMatchButton/);

  assert.match(css, /\.start-overlay\.is-online \.start-menu\s*\{[^}]*max-height:[^}]*overflow-y:\s*auto[^}]*scroll-padding-block:/s);
  assert.match(css, /\.room-code-display output\s*\{[^}]*user-select:\s*text[^}]*-webkit-user-select:\s*text/s);
  assert.match(css, /\.network-status\[hidden\]\s*\{\s*display:\s*none/,
    "ordinary offline play must not render the hidden online status box");
  assert.match(css, /\.join-match-row input\s*\{[^}]*min-height:\s*2\.8rem[^}]*user-select:\s*text/s);
  assert.match(css, /@media \(max-height: 500px\) and \(orientation: landscape\)[\s\S]*\.start-overlay\.is-online \.wordmark/);
});

test(`all project JavaScript parses under the active ${process.version} runtime`, () => {
  for (const absolute of walkFiles(root).filter((file) => /\.(?:js|mjs)$/.test(file))) {
    const file = path.relative(root, absolute);
    const result = spawnSync(process.execPath, ["--check", absolute], { encoding: "utf8" });
    assert.equal(result.status, 0, `${file}: ${result.stderr}`);
  }
});

test("touch vectors are radial, symmetric, deadzoned, and bounded", () => {
  assert.deepEqual(Touch.normalizeStick(10, 0, 100, 0.2), { x: 0, y: 0, magnitude: 0 });
  const right = Touch.normalizeStick(60, 0, 100, 0.2);
  const left = Touch.normalizeStick(-60, 0, 100, 0.2);
  const diagonal = Touch.normalizeStick(1000, 1000, 100, 0.2);
  assert.ok(Math.abs(right.magnitude - 0.5) < 1e-12);
  assert.equal(left.x, -right.x);
  assert.equal(left.y, right.y);
  assert.ok(Math.abs(diagonal.x - diagonal.y) < 1e-12);
  assert.ok(diagonal.magnitude <= 1);
  assert.ok(Math.hypot(diagonal.x, diagonal.y) <= 1 + Number.EPSILON);
});

test("pointer buttons latch Hybrid attack and pickup without ghost input", () => {
  const pointer = Input.createPointerController();
  pointer.setPosition(700, 350, true);

  assert.equal(pointer.press(0, 11), true);
  assert.equal(pointer.press(0, 12), false, "a second pointer stole the held attack");
  assert.equal(pointer.read().attack, true, "left press did not attack immediately");
  assert.equal(pointer.read().attack, true, "left attack did not remain held");
  assert.equal(pointer.releasePointer(11, 0), true);
  assert.equal(pointer.read().attack, false, "left release left attack held");

  assert.equal(pointer.press(2, 21), true);
  assert.equal(pointer.releasePointer(21, 2), true);
  assert.equal(pointer.press(2, 210), false, "a second sub-frame click displaced the queued pickup");
  assert.equal(pointer.read().pickup, true, "right-click pickup tap was lost before a fixed tick");
  assert.equal(pointer.read().pickup, false, "right-click pickup lasted more than one fixed tick");

  pointer.press(2, 22);
  assert.equal(pointer.cancelPointer(22), true);
  assert.equal(pointer.read().pickup, false, "canceled right click created a ghost pickup");
  pointer.press(0, 23);
  assert.equal(pointer.cancelPointer(23), true);
  assert.equal(pointer.read().attack, false, "canceled left click created a ghost attack");
  pointer.press(0, 24);
  assert.equal(pointer.read().attack, true);
  pointer.setInside(false);
  assert.deepEqual(pointer.read(), { x: 700, y: 350, inside: false, attack: false, pickup: false });
  pointer.releasePointer(24, 0);
  pointer.setInside(true);
  pointer.press(2, 25);
  pointer.clear();
  assert.deepEqual(pointer.read(), { x: 700, y: 350, inside: true, attack: false, pickup: false });
});

test("desktop presets map to one exact canonical serializable actor input", () => {
  const state = Sim.createState({ seed: 0x10203040, botCount: 1 });
  const fighter = state.fighters[0];
  fighter.facing = -1;
  const map = (preset, keys = {}, pointer = {}) => Input.mapActor({ fighter, preset, keys, pointer });

  for (const jumpKey of ["KeyW", "Space"]) {
    const frame = map("hybrid", { [jumpKey]: true }, { inside: true, aimX: 3, aimY: -4 });
    assert.equal(frame.buttons.jump, true, `${jumpKey} did not jump`);
    assert.equal(frame.aimX, 0.6);
    assert.equal(frame.aimY, -0.8);
  }
  const hybrid = map("hybrid", { KeyD: true, KeyS: true }, {
    inside: true, aimX: 0, aimY: -1, attack: true, pickup: true
  });
  assert.equal(hybrid.moveX, 1);
  assert.equal(hybrid.buttons.drop, true);
  assert.equal(hybrid.buttons.attack, true, "Hybrid left-click intent was not mapped");
  assert.equal(hybrid.buttons.pickup, true, "Hybrid right-click intent was not mapped");
  assert.equal(hybrid.aimY, -1);
  const hybridMovementFacing = map("hybrid", { KeyD: true });
  assert.equal(hybridMovementFacing.aimX, 1, "D could not turn a fighter whose prior facing was left");

  const keyboardUp = map("keyboard", { KeyA: true, KeyW: true, ArrowUp: true, KeyF: true, KeyE: true, KeyR: true, KeyQ: true }, {
    inside: true, aimX: 1, aimY: 1, attack: true, pickup: true
  });
  assert.equal(keyboardUp.moveX, -1);
  assert.ok(keyboardUp.aimX < 0 && keyboardUp.aimY < 0);
  assert.equal(keyboardUp.buttons.jump, true);
  assert.equal(keyboardUp.buttons.attack, true);
  assert.equal(keyboardUp.buttons.pickup, true);
  assert.equal(keyboardUp.buttons.reload, true);
  assert.equal(keyboardUp.weaponSlot, 1);

  const keyboardDown = map("keyboard", { ArrowDown: true }, {
    inside: true, aimX: 1, aimY: -1, attack: true, pickup: true
  });
  assert.ok(keyboardDown.aimX < 0 && keyboardDown.aimY > 0, "Arrow Down did not aim low");
  assert.equal(keyboardDown.buttons.drop, false, "Arrow Down also issued Drop");
  assert.equal(keyboardDown.buttons.attack, false, "Keyboard Only accepted pointer attack");
  assert.equal(keyboardDown.buttons.pickup, false, "Keyboard Only accepted pointer pickup");
  const keyboardDrop = map("keyboard", { KeyS: true });
  assert.equal(keyboardDrop.buttons.drop, true, "S did not issue Drop");
  assert.equal(keyboardDrop.aimY, 0, "S also changed aim");
  assert.equal(map("keyboard", { KeyW: true }).aimY, 0, "W simultaneously changed aim");
  assert.equal(map("keyboard", { KeyD: true }).aimX, 1, "Keyboard Only movement could not select right-facing attacks");

  const touchMovementFacing = Input.mapActor({
    fighter,
    preset: "keyboard",
    keys: {},
    pointer: {},
    touch: { moveActive: true, moveX: 0.8, moveY: 0, aimActive: false, buttons: {} }
  });
  assert.equal(touchMovementFacing.aimX, 1, "left-touch movement could not turn the fighter right");
  const mixedPointerTouchFacing = Input.mapActor({
    fighter,
    preset: "hybrid",
    keys: {},
    pointer: { inside: true, aimX: -1, aimY: 0 },
    touch: { moveActive: true, moveX: 0.8, moveY: 0, aimActive: false, buttons: {} }
  });
  assert.equal(mixedPointerTouchFacing.aimX, 1, "stale pointer aim overrode active touch movement");
  assert.equal(map("keyboard", { Space: true }).buttons.jump, true, "Space did not jump in Keyboard Only");

  const canonical = Sim.createInputFrame(state).actors[0];
  assert.deepEqual(Object.keys(keyboardUp).sort(), Object.keys(canonical).sort());
  assert.deepEqual(Object.keys(keyboardUp.buttons).sort(), Object.keys(canonical.buttons).sort());
  assert.deepEqual(JSON.parse(JSON.stringify(keyboardUp)), keyboardUp);
  assert.doesNotMatch(JSON.stringify(keyboardUp), /pointerId|originX|originY|moveActive|aimActive/);
  for (const axis of [keyboardUp.moveX, keyboardUp.moveY, keyboardUp.aimX, keyboardUp.aimY]) {
    assert.ok(Number.isFinite(axis));
  }

  const movementState = Sim.createState({ seed: 0x10203041, botCount: 1 });
  movementState.fighters[0].facing = -1;
  const movementActor = Input.mapActor({
    fighter: movementState.fighters[0], preset: "hybrid", keys: { KeyD: true }, pointer: {}, touch: {}
  });
  Sim.fixedUpdate(movementState, { tick: movementState.tick, actors: [movementActor] }, Sim.STEP);
  assert.equal(movementState.fighters[0].facing, 1, "movement direction did not cross the canonical simulation boundary");
});

test("shared firearm aim resolves to 35 symmetric serializable elevations", () => {
  assert.deepEqual(Sim.GUN_AIM, {
    minStep: -17, maxStep: 17, stepDegrees: 3,
    minDegrees: -51, maxDegrees: 51, facingDeadzone: 0.12
  });
  const elevations = [];
  for (let step = Sim.GUN_AIM.minStep; step <= Sim.GUN_AIM.maxStep; step += 1) {
    const radians = step * Sim.GUN_AIM.stepDegrees * Math.PI / 180;
    const right = Sim.resolveGunAim(Math.cos(radians), Math.sin(radians), 1);
    const left = Sim.resolveGunAim(-Math.cos(radians), Math.sin(radians), -1);
    elevations.push(right.degrees);
    assert.equal(right.step, step);
    assert.equal(right.degrees, step * 3);
    assert.equal(left.step, step);
    assert.equal(right.facing, 1);
    assert.equal(left.facing, -1);
    assert.ok(Math.abs(Math.hypot(right.x, right.y) - 1) < 1e-15);
    assert.ok(Math.abs(Math.hypot(left.x, left.y) - 1) < 1e-15);
    assert.equal(left.x, -right.x);
    assert.equal(left.y, right.y);
    assert.equal(Object.is(right.step, -0), false);
    assert.deepEqual(JSON.parse(JSON.stringify(right)), right);
  }
  assert.equal(elevations.length, 35);
  assert.deepEqual(elevations, Array.from({ length: 35 }, (_, index) => -51 + index * 3));

  for (const sign of [-1, 1]) {
    for (let lowerMagnitude = 0; lowerMagnitude < 17; lowerMagnitude += 1) {
      const halfDegrees = (lowerMagnitude + 0.5) * Sim.GUN_AIM.stepDegrees;
      const exact = sign * halfDegrees * Math.PI / 180;
      const inside = sign * (halfDegrees - 1e-7) * Math.PI / 180;
      const outside = sign * (halfDegrees + 1e-7) * Math.PI / 180;
      assert.equal(Sim.resolveGunAim(Math.cos(exact), Math.sin(exact), 1).step,
        sign * (lowerMagnitude + 1), `half-step ${sign * halfDegrees} did not round away from zero`);
      assert.equal(Sim.resolveGunAim(Math.cos(inside), Math.sin(inside), 1).step,
        lowerMagnitude === 0 ? 0 : sign * lowerMagnitude,
        `inside boundary ${sign * halfDegrees} escaped its bucket`);
      assert.equal(Sim.resolveGunAim(Math.cos(outside), Math.sin(outside), 1).step,
        sign * (lowerMagnitude + 1), `outside boundary ${sign * halfDegrees} stayed in its old bucket`);
    }
    const beyond = sign * 80 * Math.PI / 180;
    assert.equal(Sim.resolveGunAim(Math.cos(beyond), Math.sin(beyond), 1).step, sign * 17);
  }
  assert.equal(Sim.resolveGunAim(-0.1, -1, 1).facing, 1, "vertical aim escaped facing hysteresis");
  assert.equal(Sim.resolveGunAim(-0.2, -0.98, 1).facing, -1, "opposite aim did not cross the deadzone");
  assert.equal(Sim.resolveGunAim(-1, -1, 1, -17).facing, 1,
    "a committed firearm step allowed live aim to replace its facing");
  assert.equal(Object.is(Sim.resolveGunAim(1, 0, 1, -0).step, -0), false,
    "committed zero was not canonicalized");
  assert.deepEqual(Sim.resolveGunAim(NaN, Infinity, -1), Sim.resolveGunAim(0, 0, -1));
});

test("headless firearm fallbacks preserve committed facing and finite canonical input", () => {
  const state = Sim.createState({ seed: 0x3b36, botCount: 1 });
  const fighter = state.fighters[0];
  Sim.grantWeapon(fighter, "pistol", true);
  Object.assign(fighter, {
    weapon: "pistol", facing: 1, aimFacing: -1, aimStep: 17,
    aimX: -1, aimY: 0,
    attack: { kind: "gun", weapon: "pistol", age: 3, duration: 12, facing: 1, aimStep: -17, hitIds: [] }
  });
  const expected = Sim.resolveGunAim(0, 0, 1, -17);
  const installedAnim = globalThis.StickAnim;
  try {
    globalThis.StickAnim = null;
    assert.deepEqual(Sim.gunDirection(fighter), { x: expected.x, y: expected.y });
    assert.ok(Sim.gunMuzzle(fighter).x > fighter.x, "headless muzzle crossed the committed facing");
  } finally {
    globalThis.StickAnim = installedAnim;
  }

  fighter.attack = null;
  fighter.vx = 0;
  const malformed = neutralHuman(state);
  Object.assign(malformed, {
    moveX: Infinity, moveY: -Infinity, aimX: NaN, aimY: Infinity
  });
  Sim.fixedUpdate(state, { tick: state.tick, actors: [malformed] }, Sim.STEP);
  for (const value of [fighter.x, fighter.y, fighter.vx, fighter.vy, fighter.aimX, fighter.aimY]) {
    assert.ok(Number.isFinite(value), "malformed actor input escaped into gameplay state");
  }
  assert.equal(fighter.vx, 0, "non-finite movement became player intent");
  assert.doesNotThrow(() => JSON.parse(Sim.serialize(state)));
});

test("fixed-step firearm facing applies the deadzone to the undistorted input vector", () => {
  const epsilon = 0.001;
  for (const priorFacing of [-1, 1]) {
    for (const verticalSign of [-1, 1]) {
      for (const [magnitude, expectedFacing] of [
        [Sim.GUN_AIM.facingDeadzone - epsilon, priorFacing],
        [Sim.GUN_AIM.facingDeadzone, priorFacing],
        [Sim.GUN_AIM.facingDeadzone + epsilon, -priorFacing]
      ]) {
        const state = Sim.createState({
          seed: 0x3b40 + (priorFacing > 0 ? 10 : 0) + (verticalSign > 0 ? 1 : 0),
          botCount: 1
        });
        const fighter = state.fighters[0];
        fighter.facing = priorFacing;
        fighter.aimFacing = priorFacing;
        const actor = neutralHuman(state);
        actor.aimX = -priorFacing * magnitude;
        actor.aimY = verticalSign * Math.sqrt(1 - magnitude * magnitude);
        const direct = Sim.resolveGunAim(actor.aimX, actor.aimY, priorFacing);
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        assert.equal(fighter.aimFacing, expectedFacing,
          `deadzone ${priorFacing}/${verticalSign}/${magnitude} changed facing incorrectly`);
        assert.equal(fighter.facing, expectedFacing,
          `fixed-step facing disagreed at ${priorFacing}/${verticalSign}/${magnitude}`);
        assert.equal(fighter.aimStep, direct.step,
          `fixed-step elevation used a distorted vector at ${priorFacing}/${verticalSign}/${magnitude}`);
        assert.equal(fighter.aimY, Math.max(-0.82, Math.min(0.82, actor.aimY)),
          "stored grenade aim range changed");
      }
    }
  }
});

test("all input producers preserve canonical vectors while sharing the aim resolver", () => {
  const state = Sim.createState({ seed: 0x3b35, botCount: 1 });
  const fighter = state.fighters[0];
  fighter.facing = 1;
  fighter.aimFacing = 1;
  const keyboardSteps = [
    [{ ArrowUp: true }, -10],
    [{}, 0],
    [{ ArrowDown: true }, 10]
  ];
  for (const [keys, expectedStep] of keyboardSteps) {
    const actor = Input.mapActor({ fighter, preset: "keyboard", keys, pointer: { inside: true, aimX: -1, aimY: 1 } });
    assert.equal(Sim.resolveGunAim(actor.aimX, actor.aimY, fighter.facing).step, expectedStep);
    assert.equal("aimStep" in actor, false);
    assert.equal("aimFacing" in actor, false);
  }

  const producers = [
    Input.mapActor({ fighter, preset: "hybrid", keys: {}, pointer: { inside: true, aimX: 0.94, aimY: -0.342 } }),
    Input.mapActor({ fighter, preset: "hybrid", keys: {}, pointer: {}, touch: {
      aimActive: true, aimX: 0.92, aimY: 0.392, buttons: {}
    } }),
    Bots.makeBotInput(state, state.fighters[1])
  ];
  const canonical = Sim.createInputFrame(state).actors[0];
  for (const actor of producers) {
    assert.deepEqual(Object.keys(actor).sort(), Object.keys(canonical).sort());
    assert.deepEqual(Object.keys(actor.buttons).sort(), Object.keys(canonical.buttons).sort());
    assert.doesNotMatch(JSON.stringify(actor), /aimStep|aimFacing|target|opponent|lock|assist|selected|pointerId|device/iu);
    const resolved = Sim.resolveGunAim(actor.aimX, actor.aimY, fighter.facing);
    assert.ok(resolved.step >= -17 && resolved.step <= 17);
  }
});

test("touch aim assist selects the closest living fighter with a pure normalized vector", () => {
  const self = { id: 0, x: 100, y: 200, health: 100, dead: false };
  const farther = { id: 1, x: 112, y: 216, health: 100, dead: false };
  const closest = { id: 2, x: 103, y: 204, health: 100, dead: false };
  const fighters = [self, farther, closest];
  const before = JSON.stringify(fighters);

  const aim = Touch.closestLiveEnemyAim(fighters, self);
  assert.deepEqual(aim, { x: 0.6, y: 0.8 });
  assert.deepEqual(Object.keys(aim).sort(), ["x", "y"]);
  assert.ok(Math.abs(Math.hypot(aim.x, aim.y) - 1) < 1e-15);
  assert.equal(JSON.stringify(fighters), before, "aim selection mutated fighter state");
});

test("touch aim assist has stable ID ties and filters invalid non-living candidates", () => {
  const self = { id: 0, x: 0, y: 0, health: 100, dead: false };
  const lowerId = { id: 2, x: 10, y: 0, health: 100, dead: false };
  const higherId = { id: 7, x: -10, y: 0, health: 100, dead: false };
  assert.deepEqual(Touch.closestLiveEnemyAim([self, higherId, lowerId], self), { x: 1, y: 0 });
  assert.deepEqual(Touch.closestLiveEnemyAim([lowerId, self, higherId], self), { x: 1, y: 0 });

  const livingRespawnVisual = {
    id: 9, x: 15, y: 0, health: 100, dead: false,
    invuln: 42, respawnVisual: 24, life: { kind: "respawn", age: 0 }
  };
  const invalid = [
    self,
    { id: self.id, x: 1, y: 0, health: 100, dead: false },
    { id: 3, x: 2, y: 0, health: 100, dead: true },
    { id: 31, x: 2, y: 0, health: 100, defeated: true },
    { id: 32, x: 2, y: 0, health: 100, alive: false },
    { id: 4, x: 3, y: 0, health: 0, dead: false },
    { id: 5, x: 4, y: 0, health: -1, dead: false },
    { id: 6, x: 0, y: 0, health: 100, dead: false },
    { id: 8, x: Number.NaN, y: 0, health: 100, dead: false },
    { x: 1, y: 0, health: 100, dead: false },
    null
  ];
  assert.deepEqual(Touch.closestLiveEnemyAim([...invalid, livingRespawnVisual], self), { x: 1, y: 0 },
    "invulnerability or respawn presentation excluded a living fighter");
  assert.equal(Touch.closestLiveEnemyAim(invalid, self), null);
  assert.equal(Touch.closestLiveEnemyAim(null, self), null);
  assert.equal(Touch.closestLiveEnemyAim([self], null), null);
});

test("touch pointers keep independent movement and action ownership", () => {
  const controller = Touch.createController({ radius: 60 });
  assert.equal(controller.startStick("left", 11, 100, 300), true);
  assert.equal(controller.startAction(22, 900, 300, { weapon: "pistol", facing: 1 }), true);
  assert.equal(controller.startStick("left", 33, 120, 320), false);
  assert.equal(controller.startAction(44, 900, 320, { weapon: "pistol", facing: 1 }), false);
  controller.movePointer(11, 780, 300);
  controller.movePointer(22, 840, 250);
  assert.equal(controller.visual("left").pointerId, 11);
  assert.equal(controller.visual("right").pointerId, 22);
  assert.ok(controller.visual("left").magnitude <= 1);
  assert.ok(controller.visual("right").magnitude <= 1);
  assert.equal(controller.cancelPointer(11), true);
  assert.equal(controller.visual("left").active, false);
  assert.equal(controller.visual("right").active, true);
  const independentAction = controller.read(1);
  assert.ok(Math.hypot(independentAction.aimX, independentAction.aimY) > 0.9,
    "canceling movement stole the independent action aim");
  assert.equal(controller.endPointer(22), true);
  assert.equal(controller.read(1).buttons.attack, true,
    "canceling one pointer prevented the other pointer's canonical release");
});

test("left touch movement emits one vertical command per threshold gesture", () => {
  const controller = Touch.createController({
    radius: 100, deadzone: 0, jumpThreshold: 0.6, dropThreshold: 0.6, verticalResetThreshold: 0.25
  });
  assert.equal(controller.startStick("left", 1, 100, 100), true);
  controller.movePointer(1, 170, 100);
  assert.ok(controller.read(1).moveX > 0.69, "horizontal movement was lost");

  controller.movePointer(1, 100, 30);
  assert.equal(controller.read(1).buttons.jump, true, "upward gesture did not jump");
  controller.movePointer(1, 100, 20);
  assert.equal(controller.read(1).buttons.jump, false, "held-up gesture repeated Jump");
  controller.movePointer(1, 100, 85);
  assert.equal(controller.read(1).buttons.jump, false);
  controller.movePointer(1, 100, 170);
  assert.equal(controller.read(1).buttons.drop, true, "downward gesture did not drop");
  controller.movePointer(1, 100, 180);
  assert.equal(controller.read(1).buttons.drop, false, "held-down gesture repeated Drop");

  controller.movePointer(1, 100, 100);
  controller.movePointer(1, 100, 30);
  assert.equal(controller.cancelPointer(1), true);
  assert.equal(controller.read(1).buttons.jump, false, "canceled stick created a ghost Jump");
});

test("touch Action commits each weapon at its intended phase", () => {
  for (const weapon of ["pistol", "shotgun", "grenade"]) {
    const controller = Touch.createController({ radius: 60, aimThreshold: 0.34 });
    controller.startAction(1, 300, 200, { weapon, facing: 1, smartAction: false });
    controller.movePointer(1, 360, 170);
    const aiming = controller.read(1);
    assert.equal(aiming.buttons.attack, false, `${weapon} fired while aiming`);
    assert.ok(aiming.aimX > 0 && aiming.aimY < 0);
    assert.equal(controller.actionVisual().phase, "aiming");
    controller.endPointer(1);
    assert.equal(controller.startAction(2, 300, 200, { weapon, facing: -1 }), false,
      `${weapon} accepted another action before its release command was sampled`);
    const release = controller.read(1);
    assert.equal(release.buttons.attack, true, `${weapon} did not fire on release`);
    assert.ok(release.aimX > 0 && release.aimY < 0, `${weapon} lost its release aim`);
    assert.equal(controller.read(1).buttons.attack, false, `${weapon} release repeated Attack`);
  }

  for (const weapon of ["unarmed", "sword"]) {
    const controller = Touch.createController({ radius: 60 });
    controller.startAction(2, 300, 200, { weapon, facing: -1, smartAction: false });
    const press = controller.read(-1);
    assert.equal(press.buttons.attack, true, `${weapon} did not commit on press`);
    assert.equal(press.aimX, -1);
    assert.equal(controller.read(-1).buttons.attack, false, `${weapon} press repeated Attack`);
    controller.endPointer(2);
    assert.equal(controller.read(-1).buttons.attack, false, `${weapon} also attacked on release`);
  }

  const rifle = Touch.createController({ radius: 60 });
  rifle.startAction(3, 300, 200, { weapon: "rifle", facing: 1, smartAction: false });
  rifle.movePointer(3, 360, 200);
  for (let tick = 1; tick <= rifle.config.rifleHoldTicks + 1; tick += 1) {
    const frame = rifle.read(1);
    assert.equal(frame.buttons.attack, tick >= rifle.config.rifleHoldTicks,
      `rifle attack state was wrong on hold tick ${tick}`);
    assert.equal(rifle.actionVisual().holdProgress, Math.min(1, tick / rifle.config.rifleHoldTicks));
  }
  assert.equal(rifle.actionVisual().phase, "firing");
  rifle.endPointer(3);
  assert.equal(rifle.read(1).buttons.attack, false, "rifle fired on release");
});

test("neutral ranged Action releases once along its snapshotted assisted vector", () => {
  const expected = { x: 0.6, y: -0.8 };
  for (const weapon of ["pistol", "shotgun", "grenade"]) {
    const controller = Touch.createController({ radius: 60 });
    assert.equal(controller.startAction(1, 300, 200, {
      weapon, facing: -1, smartAction: true, pickupEligible: false,
      assistAimX: expected.x, assistAimY: expected.y
    }), true);
    assert.deepEqual({
      phase: controller.actionVisual().phase,
      aimed: controller.actionVisual().aimed,
      assisted: controller.actionVisual().assisted,
      manualAim: controller.actionVisual().manualAim
    }, { phase: "aiming", aimed: true, assisted: true, manualAim: false });
    const hold = controller.read(-1);
    assert.equal(hold.buttons.attack, false, `${weapon} fired before release`);
    assertPointNear({ x: hold.aimX, y: hold.aimY }, expected, `${weapon} assisted hold`);
    controller.endPointer(1);
    const release = controller.read(-1);
    assert.equal(release.buttons.attack, true, `${weapon} did not fire on release`);
    assertPointNear({ x: release.aimX, y: release.aimY }, expected, `${weapon} assisted release`);
    assert.equal(controller.read(-1).buttons.attack, false, `${weapon} assisted release repeated`);
  }

  for (const weapon of ["pistol", "shotgun", "grenade"]) {
    const fastTap = Touch.createController({ radius: 60 });
    fastTap.startAction(2, 300, 200, {
      weapon, facing: -1, smartAction: true, pickupEligible: false,
      assistAimX: expected.x, assistAimY: expected.y
    });
    fastTap.endPointer(2);
    const queued = fastTap.read(-1);
    assert.equal(queued.buttons.attack, true, `${weapon} sub-frame assisted tap was lost`);
    assertPointNear({ x: queued.aimX, y: queued.aimY }, expected, `${weapon} sub-frame assisted aim`);
    assert.equal(fastTap.read(-1).buttons.attack, false, `${weapon} sub-frame assisted tap repeated`);
  }
});

test("neutral assisted rifle fires on the exact hold read and stops on release", () => {
  const controller = Touch.createController({ radius: 60 });
  const expected = { x: -0.8, y: -0.6 };
  controller.startAction(3, 300, 200, {
    weapon: "rifle", facing: 1, smartAction: true, pickupEligible: false,
    assistAimX: expected.x, assistAimY: expected.y
  });
  assert.deepEqual({
    phase: controller.actionVisual().phase,
    assisted: controller.actionVisual().assisted,
    manualAim: controller.actionVisual().manualAim
  }, { phase: "holding", assisted: true, manualAim: false });
  for (let tick = 1; tick <= controller.config.rifleHoldTicks; tick += 1) {
    const frame = controller.read(1);
    assert.equal(frame.buttons.attack, tick === controller.config.rifleHoldTicks,
      `assisted rifle attack state was wrong on hold read ${tick}`);
    assertPointNear({ x: frame.aimX, y: frame.aimY }, expected, `assisted rifle read ${tick}`);
  }
  assert.equal(controller.actionVisual().phase, "firing");
  controller.endPointer(3);
  assert.equal(controller.read(1).buttons.attack, false, "assisted rifle fired on release");

  const manualTakeover = Touch.createController({ radius: 60 });
  manualTakeover.startAction(4, 300, 200, {
    weapon: "rifle", facing: 1, smartAction: true, pickupEligible: false,
    assistAimX: 0.8, assistAimY: -0.6
  });
  for (let tick = 1; tick <= 4; tick += 1) {
    assert.equal(manualTakeover.read(1).buttons.attack, false);
  }
  manualTakeover.movePointer(4, 240, 200);
  assert.deepEqual({
    assisted: manualTakeover.actionVisual().assisted,
    manualAim: manualTakeover.actionVisual().manualAim,
    phase: manualTakeover.actionVisual().phase
  }, { assisted: false, manualAim: true, phase: "holding" });
  for (let tick = 5; tick <= manualTakeover.config.rifleHoldTicks; tick += 1) {
    const frame = manualTakeover.read(1);
    assert.equal(frame.buttons.attack, tick === manualTakeover.config.rifleHoldTicks,
      `manual takeover changed assisted rifle hold timing on read ${tick}`);
    assert.equal(frame.aimX, -1);
    assert.equal(frame.aimY, 0);
  }
  manualTakeover.endPointer(4);
  assert.equal(manualTakeover.read(1).buttons.attack, false);
});

test("Smart Action preserves pickup priority over touch aim assist", () => {
  const pickup = Touch.createController({ radius: 60 });
  pickup.startAction(1, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: true,
    assistAimX: -1, assistAimY: 0
  });
  assert.deepEqual({
    phase: pickup.actionVisual().phase,
    pickupCandidate: pickup.actionVisual().pickupCandidate,
    aimed: pickup.actionVisual().aimed,
    assisted: pickup.actionVisual().assisted,
    manualAim: pickup.actionVisual().manualAim
  }, { phase: "pickup", pickupCandidate: true, aimed: false, assisted: false, manualAim: false });
  pickup.endPointer(1);
  const tap = pickup.read(1);
  assert.equal(tap.buttons.pickup, true);
  assert.equal(tap.buttons.attack, false);
  assert.equal(pickup.read(1).buttons.pickup, false);

  const aimed = Touch.createController({ radius: 60 });
  aimed.startAction(2, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: true,
    assistAimX: 1, assistAimY: 0
  });
  aimed.movePointer(2, 250, 160);
  assert.equal(aimed.actionVisual().pickupCandidate, false);
  assert.equal(aimed.actionVisual().aimed, true);
  assert.equal(aimed.actionVisual().assisted, false);
  assert.equal(aimed.actionVisual().manualAim, true);
  aimed.endPointer(2);
  const shot = aimed.read(1);
  assert.equal(shot.buttons.attack, true);
  assert.equal(shot.buttons.pickup, false);
  assert.ok(shot.aimX < 0 && shot.aimY < 0, "drag was not used as direct aim");

  const melee = Touch.createController({ radius: 60 });
  melee.startAction(3, 300, 200, {
    weapon: "sword", facing: 1, smartAction: true, pickupEligible: true,
    assistAimX: -1, assistAimY: 0
  });
  assert.equal(melee.read(1).buttons.attack, false, "reserved pickup tap attacked on press");
  melee.movePointer(3, 360, 200);
  assert.equal(melee.read(1).buttons.attack, true, "drag did not commit the selected melee direction");
  assert.equal(melee.read(1).buttons.attack, false);

  const riflePickup = Touch.createController({ radius: 60 });
  riflePickup.startAction(4, 300, 200, {
    weapon: "rifle", facing: 1, smartAction: true, pickupEligible: true,
    assistAimX: -1, assistAimY: 0
  });
  for (let tick = 0; tick <= riflePickup.config.rifleHoldTicks; tick += 1) {
    assert.equal(riflePickup.read(1).buttons.attack, false, "pickup candidate began assisted rifle fire");
  }
  riflePickup.endPointer(4);
  const rifleTap = riflePickup.read(1);
  assert.equal(rifleTap.buttons.pickup, true);
  assert.equal(rifleTap.buttons.attack, false);

  const rifleDrag = Touch.createController({ radius: 60 });
  rifleDrag.startAction(5, 300, 200, {
    weapon: "rifle", facing: 1, smartAction: true, pickupEligible: true,
    assistAimX: -1, assistAimY: 0
  });
  rifleDrag.movePointer(5, 240, 200);
  assert.deepEqual({
    pickupCandidate: rifleDrag.actionVisual().pickupCandidate,
    assisted: rifleDrag.actionVisual().assisted,
    manualAim: rifleDrag.actionVisual().manualAim,
    phase: rifleDrag.actionVisual().phase
  }, { pickupCandidate: false, assisted: false, manualAim: true, phase: "holding" });
  for (let tick = 1; tick <= rifleDrag.config.rifleHoldTicks; tick += 1) {
    const frame = rifleDrag.read(1);
    assert.equal(frame.buttons.attack, tick === rifleDrag.config.rifleHoldTicks,
      `pickup-to-manual rifle timing changed on read ${tick}`);
    assert.equal(frame.buttons.pickup, false);
  }
  rifleDrag.endPointer(5);
  assert.equal(rifleDrag.read(1).buttons.attack, false);
});

test("touch drag overrides snapshotted assist only after threshold and never restores it", () => {
  const controller = Touch.createController({ radius: 100, deadzone: 0, aimThreshold: 0.34 });
  const assisted = { x: 0.6, y: -0.8 };
  controller.startAction(1, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: false,
    assistAimX: assisted.x, assistAimY: assisted.y
  });

  controller.movePointer(1, 320, 200);
  const jitter = controller.read(1);
  assertPointNear({ x: jitter.aimX, y: jitter.aimY }, assisted, "subthreshold assisted aim");
  assert.equal(controller.actionVisual().assisted, true);
  assert.equal(controller.actionVisual().manualAim, false);

  controller.movePointer(1, 260, 240);
  const direct = { x: -Math.SQRT1_2, y: Math.SQRT1_2 };
  const dragged = controller.read(1);
  assertPointNear({ x: dragged.aimX, y: dragged.aimY }, direct, "threshold manual aim");
  assert.equal(controller.actionVisual().assisted, false);
  assert.equal(controller.actionVisual().manualAim, true);

  controller.movePointer(1, 300, 200);
  const recentered = controller.read(1);
  assertPointNear({ x: recentered.aimX, y: recentered.aimY }, direct, "recentered manual aim");
  assert.equal(controller.actionVisual().assisted, false);
  assert.equal(controller.actionVisual().manualAim, true);
  controller.endPointer(1);
  const release = controller.read(1);
  assert.equal(release.buttons.attack, true);
  assertPointNear({ x: release.aimX, y: release.aimY }, direct, "manual release aim");
});

test("Smart Action Off and neutral no-target taps stay inert while melee ignores assist", () => {
  const smartOff = Touch.createController({ radius: 60 });
  smartOff.startAction(1, 300, 200, {
    weapon: "pistol", facing: -1, smartAction: false, pickupEligible: false,
    assistAimX: 1, assistAimY: 0
  });
  smartOff.endPointer(1);
  const disabled = smartOff.read(-1);
  assert.equal(disabled.buttons.attack, false, "Smart Action Off accepted neutral aim assist");
  assert.equal(disabled.buttons.pickup, false);

  const noTarget = Touch.createController({ radius: 60 });
  noTarget.startAction(1, 300, 200, {
    weapon: "pistol", facing: -1, smartAction: true, pickupEligible: false
  });
  noTarget.endPointer(1);
  const missing = noTarget.read(-1);
  assert.equal(missing.buttons.attack, false, "Smart Action fired without a live target");
  assert.equal(missing.buttons.pickup, false);

  for (const [assistAimX, assistAimY] of [[0, 0], [Infinity, 0], [1, Number.NaN]]) {
    const malformed = Touch.createController({ radius: 60 });
    malformed.startAction(9, 300, 200, {
      weapon: "pistol", facing: 1, smartAction: true, pickupEligible: false,
      assistAimX, assistAimY
    });
    assert.equal(malformed.actionVisual().assisted, false, "malformed assist vector was accepted");
    malformed.endPointer(9);
    assert.equal(malformed.read(1).buttons.attack, false, "malformed assist vector fired");
  }

  for (const [weapon, facing] of [["unarmed", -1], ["sword", 1]]) {
    const melee = Touch.createController({ radius: 60 });
    melee.startAction(2, 300, 200, {
      weapon, facing, smartAction: true, pickupEligible: false,
      assistAimX: -facing, assistAimY: 0
    });
    assert.equal(melee.actionVisual().assisted, false, `${weapon} accepted ranged aim assist`);
    assert.equal(melee.actionVisual().manualAim, false);
    const press = melee.read(facing);
    assert.equal(press.buttons.attack, true, `${weapon} no longer attacked on press`);
    assert.equal(press.aimX, facing, `${weapon} changed facing toward an assisted target`);
    assert.equal(press.aimY, 0);
    assert.equal(melee.read(facing).buttons.attack, false);
    melee.endPointer(2);
    assert.equal(melee.read(facing).buttons.attack, false, `${weapon} also attacked on release`);
  }
});

test("assisted touch cancellation and clearing cannot create ghost fire", () => {
  for (const weapon of ["pistol", "shotgun", "grenade"]) {
    const controller = Touch.createController({ radius: 60 });
    controller.startAction(1, 300, 200, {
      weapon, facing: 1, smartAction: true, pickupEligible: false,
      assistAimX: -0.6, assistAimY: -0.8
    });
    assert.equal(controller.cancelPointer(1), true);
    assert.equal(controller.read(1).buttons.attack, false, `${weapon} fired after assisted cancellation`);
    assert.equal(controller.read(1).buttons.attack, false, `${weapon} left delayed ghost fire`);
  }

  const queuedRelease = Touch.createController({ radius: 60 });
  queuedRelease.startAction(2, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: false,
    assistAimX: 1, assistAimY: 0
  });
  queuedRelease.endPointer(2);
  queuedRelease.clear();
  assert.equal(queuedRelease.read(1).buttons.attack, false, "clear preserved a queued assisted release");

  for (const terminal of ["cancel", "clear"]) {
    const rifle = Touch.createController({ radius: 60 });
    rifle.startAction(3, 300, 200, {
      weapon: "rifle", facing: 1, smartAction: true, pickupEligible: false,
      assistAimX: 0.8, assistAimY: -0.6
    });
    for (let tick = 1; tick < rifle.config.rifleHoldTicks; tick += 1) {
      assert.equal(rifle.read(1).buttons.attack, false);
    }
    if (terminal === "cancel") rifle.cancelPointer(3);
    else rifle.clear();
    assert.equal(rifle.read(1).buttons.attack, false, `${terminal} completed an assisted rifle hold`);
    assert.equal(rifle.actionVisual().assisted, false);
    assert.equal(rifle.actionVisual().manualAim, false);
  }
});

test("explicit touch actions survive fast taps and all cancellation paths clear", () => {
  const controller = Touch.createController({ radius: 60 });
  controller.startButton("pickup", 1);
  assert.equal(controller.buttonVisual("pickup").held, true);
  assert.equal(controller.read(1).buttons.pickup, true);
  assert.equal(controller.read(1).buttons.pickup, true, "held explicit Pickup did not remain active");
  controller.endPointer(1);
  assert.equal(controller.read(1).buttons.pickup, false);

  controller.startButton("reload", 2);
  controller.endPointer(2);
  assert.equal(controller.startButton("reload", 20), false, "a second tap displaced queued Reload");
  assert.equal(controller.read(1).buttons.reload, true, "sub-frame Reload tap was lost");
  assert.equal(controller.read(1).buttons.reload, false);
  controller.startButton("unarmed", 3);
  controller.cancelPointer(3);
  assert.equal(controller.read(1).buttons.unarmed, false, "canceled Unarmed created ghost input");

  controller.startAction(4, 300, 200, { weapon: "pistol", facing: 1, smartAction: false });
  controller.movePointer(4, 370, 200);
  controller.cancelPointer(4);
  assert.equal(controller.read(1).buttons.attack, false, "canceled release weapon fired");
  controller.startAction(5, 300, 200, { weapon: "sword", facing: 1, smartAction: false });
  controller.cancelPointer(5);
  assert.equal(controller.read(1).buttons.attack, false, "canceled melee press created a ghost attack");
  controller.startAction(6, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: true
  });
  controller.cancelPointer(6);
  assert.equal(controller.read(1).buttons.pickup, false, "canceled smart tap created a ghost pickup");

  controller.startStick("left", 7, 100, 100);
  controller.movePointer(7, 100, 30);
  controller.startButton("reload", 8);
  controller.startAction(9, 300, 200, { weapon: "rifle", facing: 1, smartAction: false });
  controller.movePointer(9, 370, 200);
  for (let tick = 1; tick < controller.config.rifleHoldTicks; tick += 1) controller.read(1);
  controller.clear();
  const neutral = controller.read(-1);
  assert.deepEqual(neutral, {
    moveActive: false,
    aimActive: false,
    moveX: 0,
    moveY: 0,
    aimX: -1,
    aimY: 0,
    buttons: { jump: false, attack: false, pickup: false, reload: false, drop: false, unarmed: false }
  });
});

test("touch intent normalizes through Input to canonical serializable state", () => {
  const state = Sim.createState({ seed: 0x10203040, botCount: 1 });
  const controller = Touch.createController({
    radius: 60, deadzone: 0, jumpThreshold: 0.5, dropThreshold: 0.5, verticalResetThreshold: 0.2
  });
  controller.startStick("left", 10, 100, 100);
  controller.movePointer(10, 136, 55);
  controller.startAction(11, 300, 200, { weapon: "sword", facing: 1, smartAction: false });
  controller.startButton("pickup", 13);
  controller.startButton("reload", 14);
  controller.startButton("unarmed", 15);
  const actor = Input.mapActor({
    fighter: state.fighters[0],
    preset: "hybrid",
    keys: {},
    pointer: {},
    touch: controller.read(1)
  });
  const canonical = Sim.createInputFrame(state).actors[0];
  assert.deepEqual(Object.keys(actor).sort(), Object.keys(canonical).sort());
  assert.deepEqual(Object.keys(actor.buttons).sort(), Object.keys(canonical.buttons).sort());
  assert.deepEqual(JSON.parse(JSON.stringify(actor)), actor);
  assert.doesNotMatch(JSON.stringify(actor), /pointerId|originX|originY|moveActive|aimActive/);
  assert.equal(actor.buttons.jump, true);
  assert.equal(actor.buttons.attack, true);
  assert.equal(actor.buttons.pickup, true);
  assert.equal(actor.buttons.reload, true);
  assert.equal(actor.weaponSlot, 1);
  for (const axis of [actor.moveX, actor.moveY, actor.aimX, actor.aimY]) assert.ok(Number.isFinite(axis));

  const first = Sim.createState({ seed: 0x10203040, botCount: 1 });
  const second = Sim.createState({ seed: 0x10203040, botCount: 1 });
  Sim.fixedUpdate(first, { tick: first.tick, actors: [actor] }, Sim.STEP);
  Sim.fixedUpdate(second, { tick: second.tick, actors: [JSON.parse(JSON.stringify(actor))] }, Sim.STEP);
  assert.equal(Sim.serialize(first), Sim.serialize(second));
});

test("assisted and manual touch aim produce identical canonical replay input", () => {
  const first = Sim.createState({ seed: 0xa55157ed, botCount: 1 });
  const second = Sim.createState({ seed: 0xa55157ed, botCount: 1 });
  const expected = { x: 0.6, y: -0.8 };

  const assisted = Touch.createController({ radius: 100, deadzone: 0, aimThreshold: 0.34 });
  assisted.startAction(1, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: false,
    assistAimX: expected.x, assistAimY: expected.y
  });
  assisted.endPointer(1);

  const manual = Touch.createController({ radius: 100, deadzone: 0, aimThreshold: 0.34 });
  manual.startAction(2, 300, 200, {
    weapon: "pistol", facing: 1, smartAction: true, pickupEligible: false
  });
  manual.movePointer(2, 360, 120);
  manual.endPointer(2);

  const mapTouch = (state, touch) => Input.mapActor({
    fighter: state.fighters[0], preset: "hybrid", keys: {}, pointer: {}, touch
  });
  const assistedActor = mapTouch(first, assisted.read(1));
  const manualActor = mapTouch(second, manual.read(1));
  assert.deepEqual(assistedActor, manualActor);
  assertPointNear({ x: assistedActor.aimX, y: assistedActor.aimY }, expected, "canonical assisted aim");
  assert.equal(assistedActor.buttons.attack, true);

  const canonical = Sim.createInputFrame(first).actors[0];
  assert.deepEqual(Object.keys(assistedActor).sort(), Object.keys(canonical).sort());
  assert.deepEqual(Object.keys(assistedActor.buttons).sort(), Object.keys(canonical.buttons).sort());
  assert.deepEqual(JSON.parse(JSON.stringify(assistedActor)), assistedActor);
  assert.doesNotMatch(JSON.stringify(assistedActor),
    /target|opponent|lock|assist|selected|pointerId|originX|originY|device/iu);

  Sim.fixedUpdate(first, { tick: first.tick, actors: [assistedActor] }, Sim.STEP);
  Sim.fixedUpdate(second, {
    tick: second.tick, actors: [JSON.parse(JSON.stringify(manualActor))]
  }, Sim.STEP);
  assert.equal(Sim.serialize(first), Sim.serialize(second));
});

test("grenade release preserves the serializable aim committed on press", () => {
  const state = Sim.createState({ seed: 0x6a17cafe, botCount: 1 });
  const fighter = state.fighters[0];
  Sim.grantWeapon(fighter, "grenade", true);
  fighter.weapon = "grenade";
  const input = neutralHuman(state);
  input.aimX = 0.6;
  input.aimY = -0.8;
  input.buttons.attack = true;
  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);

  assert.deepEqual({
    kind: fighter.attack.kind,
    aimX: fighter.attack.aimX,
    aimY: fighter.attack.aimY,
    facing: fighter.attack.facing,
    released: fighter.attack.released
  }, { kind: "grenade", aimX: 0.6, aimY: -0.8, facing: 1, released: false });
  assert.deepEqual(Sim.deserialize(Sim.serialize(state)).fighters[0].attack, fighter.attack);

  input.buttons.attack = false;
  input.aimX = -1;
  input.aimY = 1;
  for (let tick = 0; tick < 5; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  }
  const replay = Sim.deserialize(Sim.serialize(state));
  while (!state.grenades.length) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
    Sim.fixedUpdate(replay, { tick: replay.tick, actors: [JSON.parse(JSON.stringify(input))] }, Sim.STEP);
  }

  assert.equal(Sim.serialize(replay), Sim.serialize(state));
  assert.equal(state.fighters[0].facing, 1, "grenade windup flipped away from its committed facing");
  assert.ok(state.grenades[0].vx > 0, "grenade followed live aim instead of its committed direction");
  assert.ok(state.grenades[0].vy < 0, "grenade lost its committed high aim");
  while (state.fighters[0].attack) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  }
  assert.equal(state.fighters[0].facing, -1, "facing did not accept live aim after grenade recovery");
});

test("committed melee facing stays fixed through anticipation and recovery", () => {
  for (const weapon of ["unarmed", "sword"]) {
    for (const committedFacing of [-1, 1]) {
      const state = Sim.createState({ seed: 0xfaceb00c + committedFacing + Sim.WEAPONS[weapon].slot, botCount: 1 });
      const fighter = state.fighters[0];
      const target = state.fighters[1];
      if (weapon === "sword") Sim.grantWeapon(fighter, "sword", true);
      fighter.weapon = weapon;
      fighter.facing = committedFacing;
      target.x = fighter.x + 800;
      target.prevX = target.x;
      const input = neutralHuman(state);
      input.aimX = committedFacing;
      input.buttons.attack = true;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);

      assert.equal(fighter.attack.kind, "melee");
      assert.equal(fighter.attack.facing, committedFacing);
      assert.equal(fighter.facing, committedFacing);
      assert.deepEqual(Sim.deserialize(Sim.serialize(state)).fighters[0].attack, fighter.attack);

      input.buttons.attack = false;
      input.aimX = -committedFacing;
      input.moveX = -committedFacing;
      let committedTicks = 0;
      while (fighter.attack) {
        Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
        committedTicks += 1;
        if (fighter.attack) {
          assert.equal(fighter.attack.facing, committedFacing);
          assert.equal(fighter.facing, committedFacing,
            `${weapon} flipped from ${committedFacing} on committed tick ${committedTicks}`);
        }
        assert.ok(committedTicks <= Sim.WEAPONS[weapon].duration);
      }
      assert.equal(committedTicks, Sim.WEAPONS[weapon].duration);
      assert.equal(fighter.facing, -committedFacing,
        `${weapon} did not accept live input after recovery completed`);
    }
  }
});

test("touch shell is safe-area aware and clears every terminal pointer path", () => {
  const html = read("index.html");
  const css = read("styles.css");
  const game = read("game.js");
  const input = read("input.js");
  for (const id of [
    "touchControls", "touchLeftStick", "touchRightStick", "touchRightLabel",
    "touchPickupButton", "touchReloadButton", "touchUnarmedButton", "rotateDevice",
    "controlPresetControl", "smartActionControl", "touchControl"
  ]) assert.match(html, new RegExp(`id="${id}"`));
  assert.doesNotMatch(html, /id="touchJumpButton"/);
  assert.match(html, /touch\.js\?v=[0-9a-f]{12}[\s\S]*input\.js\?v=[0-9a-f]{12}[\s\S]*game\.js\?v=[0-9a-f]{12}/);
  for (const edge of ["left", "right", "top", "bottom"]) {
    assert.match(css, new RegExp(`env\\(safe-area-inset-${edge}(?:,\\s*0px)?\\)`),
      `safe-area ${edge} inset is missing`);
  }
  assert.match(css, /\.touch-action\s*\{[\s\S]*width:\s*3rem;[\s\S]*height:\s*3rem;[\s\S]*min-width:\s*44px;[\s\S]*min-height:\s*44px;/);
  assert.match(css, /input\[type="range"\]\s*\{[\s\S]*min-height:\s*2\.75rem;/);
  assert.match(css, /\.menu-dialog\s*\{[\s\S]*max-height:[\s\S]*var\(--safe-top\)[\s\S]*var\(--safe-bottom\)[\s\S]*inset-block-start:[\s\S]*var\(--safe-top\)[\s\S]*inset-block-end:[\s\S]*var\(--safe-bottom\)/);
  assert.match(css, /\.touch-actions\s*\{[\s\S]*pointer-events:\s*none/);
  assert.match(css, /\.touch-action\s*\{[\s\S]*pointer-events:\s*auto/);
  assert.match(css, /canvas\s*\{[\s\S]*touch-action:\s*none/);
  for (const eventName of ["pointercancel", "lostpointercapture", "visibilitychange", "orientationchange", "pagehide", "blur"]) {
    assert.match(game, new RegExp(eventName));
  }
  assert.match(game, /Input\.mapActor\(\{[\s\S]*preset: controlPreset,[\s\S]*touch: touch/);
  assert.match(input, /frame\.buttons\.drop = frame\.buttons\.drop \|\| !!touchButtons\.drop/);
  assert.match(input, /if \(touchButtons\.unarmed\) frame\.weaponSlot = 1/);
  assert.match(game, /try \{ element\.setPointerCapture\(pointerId\); \} catch/);
  assert.match(game, /ui\.hud\.inert = touchPortraitBlocked/);
  assert.match(game, /nextPortraitBlocked !== touchPortraitBlocked\) \{[\s\S]{0,100}clearPlayerInput\(\);[\s\S]{0,120}Online\.sendNeutral\(\)/);
  assert.match(game, /if \(started && !paused && !touchPortraitBlocked && state\.match\.phase === "playing"\)/);
  assert.match(game, /window\.addEventListener\("blur", function \(\) \{ clearPlayerInput\(\); if \(started\) pause\(true\); \}\)/);
  assert.match(game, /window\.addEventListener\("pagehide", function \(\) \{ clearPlayerInput\(\); if \(started\) pause\(true\); \}\)/);
  assert.match(game, /document\.addEventListener\("visibilitychange", function \(\) \{[\s\S]{0,160}clearPlayerInput\(\);[\s\S]{0,100}pause\(true\)/);
  assert.match(game, /window\.addEventListener\("resize", function \(\) \{ resize\(\); clearPlayerInput\(\); updateTouchVisibility\(\); \}\)/);
  assert.match(game, /window\.addEventListener\("orientationchange", function \(\) \{ clearPlayerInput\(\); updateTouchVisibility\(\); \}\)/);
  assert.match(game, /ui\.touchPickupButton\.hidden = smartAction \|\| !pickup/);
  assert.match(game, /ui\.touchReloadButton\.hidden = !canReload/);
  assert.match(game, /event\.type === "pointerup"[\s\S]*touchController\.endPointer[\s\S]*touchController\.cancelPointer/);
  assert.doesNotMatch(game, /querySelectorAll\("\.is-pressed"\)[\s\S]{0,180}releaseTerminalPointer/);
});

test("touch shell wires pickup-first aim snapshots and readable assisted phases", () => {
  const game = read("game.js");
  const pointerStart = game.indexOf('canvas.addEventListener("pointerdown"');
  const pointerEnd = game.indexOf("function endCanvasPointer", pointerStart);
  const pointerDown = game.slice(pointerStart, pointerEnd);
  assert.ok(pointerStart >= 0 && pointerEnd > pointerStart, "touch pointerdown integration is missing");
  assert.equal([...pointerDown.matchAll(/nearbyPickup\(player\)/g)].length, 1,
    "touch pointerdown must resolve pickup eligibility exactly once");
  assert.match(pointerDown,
    /var pickup = side === "right" && player && smartAction \? nearbyPickup\(player\) : null;/);
  assert.match(pointerDown,
    /smartAction && !pickup[\s\S]*Touch\.closestLiveEnemyAim\(state\.fighters, player\)/);
  assert.match(pointerDown,
    /pickupEligible: !!pickup,[\s\S]*assistAimX: assistAim \? assistAim\.x : null,[\s\S]*assistAimY: assistAim \? assistAim\.y : null/);

  const visualsStart = game.indexOf("function updateTouchVisuals");
  const visualsEnd = game.indexOf("function updateTouchVisibility", visualsStart);
  const visuals = game.slice(visualsStart, visualsEnd);
  const pickupLabel = visuals.indexOf('"TAP · PICKUP"');
  const autoFireLabel = visuals.indexOf('"AUTO FIRE"');
  const assistedHoldLabel = visuals.indexOf('"ASSIST · HOLD"');
  const assistedReleaseLabel = visuals.indexOf('"ASSIST · RELEASE"');
  assert.ok(pickupLabel >= 0 && autoFireLabel > pickupLabel
    && assistedHoldLabel > autoFireLabel && assistedReleaseLabel > assistedHoldLabel,
  "assisted labels lost pickup priority or rifle firing priority");
});

test("seeded replay and JSON round-trip are byte-identical", () => {
  const first = Sim.createState({ seed: 0x12345678, botCount: 3 });
  const second = Sim.createState({ seed: 0x12345678, botCount: 3 });
  for (let tick = 0; tick < 1800; tick += 1) {
    Sim.fixedUpdate(first, Bots.makeInputs(first, neutralHuman(first)), Sim.STEP);
    Sim.fixedUpdate(second, Bots.makeInputs(second, neutralHuman(second)), Sim.STEP);
  }
  assert.equal(JSON.stringify(first), JSON.stringify(second));
  assert.equal(Sim.serialize(Sim.deserialize(Sim.serialize(first))), Sim.serialize(first));
});

test("default mode and map catalogs are explicit, immutable, and state-isolated", () => {
  assert.deepEqual(Object.keys(Sim.MODE_CATALOG), [Sim.DEFAULT_MODE_ID]);
  assert.deepEqual(Object.keys(Sim.MAP_CATALOG), [Sim.DEFAULT_MAP_ID]);
  assert.equal(Sim.DEFAULT_MODE_ID, "free-for-all");
  assert.equal(Sim.DEFAULT_MAP_ID, "original-arena");

  const mode = Sim.MODE_CATALOG[Sim.DEFAULT_MODE_ID];
  assert.deepEqual(mode, {
    id: "free-for-all",
    label: "Free-for-All Deathmatch",
    playerLimits: { min: 2, max: 4 },
    teamStructure: "free-for-all",
    rules: {
      regulationTicks: 10800,
      scoreScope: "individual",
      scoreRule: "defeats",
      scorePerDefeat: 1,
      resultRule: "highest-score",
      tieRule: "draw"
    }
  });

  const map = Sim.MAP_CATALOG[Sim.DEFAULT_MAP_ID];
  assert.equal(map.id, "original-arena");
  assert.equal(map.label, "Original Arena");
  assert.deepEqual(map.supportedModeIds, [Sim.DEFAULT_MODE_ID]);
  assert.deepEqual([map.width, map.height, map.groundY], [1920, 1080, 880]);
  assert.deepEqual([map.platforms.length, map.hazards.length, map.pickups.length, map.spawns.length],
    [9, 1, 7, 11]);
  assert.deepEqual(map.botRoutes.topObjective, {
    fromPlatformId: 2, toPlatformId: 6, viaPlatformIds: [4, 5]
  });

  function assertDeepFrozen(value, label) {
    assert.equal(Object.isFrozen(value), true, `${label} is mutable`);
    for (const [key, child] of Object.entries(value)) {
      if (child && typeof child === "object") assertDeepFrozen(child, `${label}.${key}`);
    }
  }
  assertDeepFrozen(Sim.MODE_CATALOG, "MODE_CATALOG");
  assertDeepFrozen(Sim.MAP_CATALOG, "MAP_CATALOG");
  assert.deepEqual(JSON.parse(JSON.stringify(Sim.MODE_CATALOG)), Sim.MODE_CATALOG);
  assert.deepEqual(JSON.parse(JSON.stringify(Sim.MAP_CATALOG)), Sim.MAP_CATALOG);

  const first = Sim.createState({ seed: 0x10ca7a10, botCount: 1 });
  const second = Sim.createState({ seed: 0x10ca7a10, botCount: 1 });
  assert.notStrictEqual(first.arena, second.arena);
  assert.notStrictEqual(first.arena.platforms, second.arena.platforms);
  assert.notStrictEqual(first.arena.platforms[0], map.platforms[0]);
  assert.notStrictEqual(first.pickups, second.pickups);
  assert.notStrictEqual(first.pickups[0], map.pickups[0]);
  first.arena.platforms[0].x = 99;
  first.pickups[0].active = false;
  assert.equal(second.arena.platforms[0].x, 0);
  assert.equal(map.platforms[0].x, 0);
  assert.equal(second.pickups[0].active, true);
  assert.equal(Object.prototype.hasOwnProperty.call(map.pickups[0], "active"), false);

  const bot = read("bot.js");
  const game = read("game.js");
  assert.match(bot, /MAP_CATALOG\[mapId\][\s\S]*botRoutes\.topObjective/);
  assert.match(game, /for \(var hazardIndex = 0; hazardIndex < hazards\.length; hazardIndex \+= 1\)/);
});

test("default and explicit mode-map configuration serialize identically", () => {
  const options = { seed: 0x10ca7a11, botCount: 3 };
  const implicit = Sim.createState(options);
  const explicit = Sim.createState({
    ...options,
    modeId: Sim.DEFAULT_MODE_ID,
    mapId: Sim.DEFAULT_MAP_ID
  });
  assert.equal(Sim.serialize(explicit), Sim.serialize(implicit));
  assert.equal(implicit.config.modeId, Sim.DEFAULT_MODE_ID);
  assert.equal(implicit.config.mapId, Sim.DEFAULT_MAP_ID);
  assert.equal(implicit.config.timeLimitTicks,
    Sim.MODE_CATALOG[Sim.DEFAULT_MODE_ID].rules.regulationTicks);

  const snapshot = Sim.snapshot(implicit);
  assert.deepEqual(snapshot.config, implicit.config);
  assert.equal(Sim.serialize(snapshot), Sim.serialize(implicit));
  for (const actor of Sim.createInputFrame(implicit).actors) {
    assert.equal(Object.prototype.hasOwnProperty.call(actor, "modeId"), false);
    assert.equal(Object.prototype.hasOwnProperty.call(actor, "mapId"), false);
  }

  const game = read("game.js");
  assert.match(game, /modeId: Sim\.DEFAULT_MODE_ID,[\s\S]*mapId: Sim\.DEFAULT_MAP_ID/);
  assert.doesNotMatch(game, /(?:mode|map)(?:Select|Selector)/i);
});

test("mode-map validation rejects unknown, inherited, and tampered identities", () => {
  assert.equal(Sim.validateModeMap(Sim.DEFAULT_MODE_ID, Sim.DEFAULT_MAP_ID), true);
  for (const modeId of ["", "FREE-FOR-ALL", "unknown", "__proto__", "constructor", null, undefined, 7, {}, []]) {
    assert.throws(() => Sim.createState({ modeId, mapId: Sim.DEFAULT_MAP_ID }), /unknown modeId/);
  }
  for (const mapId of ["", "ORIGINAL-ARENA", "unknown", "__proto__", "constructor", null, undefined, 7, {}, []]) {
    assert.throws(() => Sim.createState({ modeId: Sim.DEFAULT_MODE_ID, mapId }), /unknown mapId/);
  }
  assert.throws(() => Sim.createState(Object.create({ modeId: Sim.DEFAULT_MODE_ID })), /unknown modeId/);
  assert.throws(() => Sim.createState(Object.create({ mapId: Sim.DEFAULT_MAP_ID })), /unknown mapId/);

  for (const modeId of Object.keys(Sim.MODE_CATALOG)) {
    for (const mapId of Object.keys(Sim.MAP_CATALOG)) {
      const supported = Sim.MAP_CATALOG[mapId].supportedModeIds.includes(modeId);
      if (supported) assert.equal(Sim.validateModeMap(modeId, mapId), true);
      else assert.throws(() => Sim.validateModeMap(modeId, mapId), /incompatible modeId\/mapId/);
    }
  }

  const state = Sim.createState({ seed: 0x10ca7a12, botCount: 1 });
  const wrongMode = JSON.parse(Sim.serialize(state));
  wrongMode.config.modeId = "unknown";
  assert.throws(() => Sim.deserialize(wrongMode), /unknown modeId/);
  assert.throws(() => Sim.fixedUpdate(wrongMode, Sim.createInputFrame(state), Sim.STEP), /unknown modeId/);
  const missingMap = JSON.parse(Sim.serialize(state));
  delete missingMap.config.mapId;
  assert.throws(() => Sim.deserialize(missingMap), /unknown mapId/);

  for (const [key, expectedError] of [["modeId", /unknown modeId/], ["mapId", /unknown mapId/]]) {
    const inheritedIdentity = JSON.parse(Sim.serialize(state));
    const identity = inheritedIdentity.config[key];
    delete inheritedIdentity.config[key];
    Object.setPrototypeOf(inheritedIdentity.config, { [key]: identity });
    const inheritedBefore = Sim.serialize(inheritedIdentity);
    assert.throws(() => Sim.fixedUpdate(inheritedIdentity, Sim.createInputFrame(state), Sim.STEP), expectedError);
    assert.equal(Sim.serialize(inheritedIdentity), inheritedBefore, `rejected inherited ${key} mutated state`);
  }

  const inheritedRootConfig = JSON.parse(Sim.serialize(state));
  const rootConfig = inheritedRootConfig.config;
  delete inheritedRootConfig.config;
  Object.setPrototypeOf(inheritedRootConfig, { config: rootConfig });
  const rootBefore = Sim.serialize(inheritedRootConfig);
  assert.throws(() => Sim.fixedUpdate(inheritedRootConfig, Sim.createInputFrame(state), Sim.STEP), /unknown modeId/);
  assert.equal(Sim.serialize(inheritedRootConfig), rootBefore, "rejected inherited root config mutated state");

  const mismatchedRules = JSON.parse(Sim.serialize(state));
  mismatchedRules.config.timeLimitTicks = 1;
  const mismatchBefore = Sim.serialize(mismatchedRules);
  assert.throws(() => Sim.deserialize(mismatchedRules), /serialized rules do not match modeId/);
  assert.throws(() => Sim.fixedUpdate(mismatchedRules, Sim.createInputFrame(state), Sim.STEP),
    /serialized rules do not match modeId/);
  assert.equal(Sim.serialize(mismatchedRules), mismatchBefore, "rejected mode-rule mismatch mutated state");
  const missingRules = JSON.parse(Sim.serialize(state));
  delete missingRules.config.timeLimitTicks;
  assert.throws(() => Sim.deserialize(missingRules), /serialized rules do not match modeId/);

  const versionFour = JSON.parse(Sim.serialize(state));
  versionFour.version = 4;
  assert.throws(() => Sim.deserialize(versionFour), /unsupported serialized state/);
  assert.throws(() => Sim.createState({ timeLimitTicks: 1 }), /owned by the selected mode/);
});

test("default mode and map preserve the complete legacy replay projection", () => {
  const state = Sim.createState({ seed: 0x12345678, botCount: 3 });
  const rolling = crypto.createHash("sha256");
  const expected = new Map([
    [0, "eac26c7455b200bf2db298dddd0c040d73aae3fe6b45756c510a616b80e61341"],
    [1800, "dac525b535e0d1b4091c625655bb93e7f5f5c9b40a7387212a88253ac844a75a"],
    [10800, "68500120e66ab48b4cd0aebfcb06eabcd238bb024c1be66d615e67c41b4e76e9"]
  ]);
  function recordLegacyProjection(tick) {
    const projection = legacyPass10Projection(state);
    rolling.update(projection);
    rolling.update("\n");
    if (expected.has(tick)) {
      const actual = crypto.createHash("sha256").update(projection).digest("hex");
      assert.equal(actual, expected.get(tick), `legacy projection changed at tick ${tick}`);
    }
  }
  recordLegacyProjection(0);
  for (let tick = 0; tick < 10800; tick += 1) {
    Sim.fixedUpdate(state, Bots.makeInputs(state, neutralHuman(state)), Sim.STEP);
    recordLegacyProjection(tick + 1);
  }
  assert.equal(rolling.digest("hex"),
    "2a8bd7192adf1195d4d1641e3541362e7b7234dc7c89fbcc04f402a01407367b");
  assert.equal(state.match.phase, "finished");
});

test("combat snapshots replay exactly through shotgun flight, rifle burst, reload, and grenade fuse", () => {
  const state = Sim.createState({ seed: 0x5a17c0de, botCount: 3 });
  state.arena.hazards = [];
  state.pickups.forEach((pickup) => { pickup.active = false; });
  const [shotgunner, rifleman, thrower, loader] = state.fighters;
  for (const [index, fighter] of state.fighters.entries()) {
    Object.assign(fighter, {
      x: 150 + index * 350, prevX: 150 + index * 350,
      y: 220, prevY: 220, vx: 0, vy: 0,
      grounded: false, prevGrounded: false, platformId: null,
      invuln: 999, facing: 1, aimFacing: 1, aimStep: 0,
      attack: null, cooldown: 0, reload: 0, hitstun: 0, hurtCooldown: 0
    });
  }
  for (const [fighter, weapon] of [
    [shotgunner, "shotgun"], [rifleman, "rifle"],
    [thrower, "grenade"], [loader, "pistol"]
  ]) {
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
  }
  loader.ammo.pistol.mag = 0;

  const actors = state.fighters.map(neutralActor);
  actors[0].buttons.attack = true;
  actors[1].buttons.attack = true;
  actors[2].aimX = -0.8;
  actors[2].aimY = -0.6;
  actors[2].buttons.attack = true;
  actors[3].buttons.reload = true;
  Sim.fixedUpdate(state, { tick: state.tick, actors }, Sim.STEP);
  actors[0].buttons.attack = false;
  actors[2].buttons.attack = false;
  actors[3].buttons.reload = false;
  for (let tick = 1; tick < 18; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors }, Sim.STEP);
  }

  assert.ok(state.projectiles.some((projectile) => projectile.weapon === "shotgun"));
  assert.ok(state.projectiles.some((projectile) => projectile.weapon === "rifle"));
  assert.ok(Object.keys(state.shotGroups).length > 0);
  assert.equal(state.grenades.length, 1);
  assert.ok(rifleman.attack && rifleman.attack.weapon === "rifle");
  assert.ok(loader.reload > 0);

  const replay = Sim.deserialize(Sim.serialize(state));
  for (let tick = 0; tick < 180; tick += 1) {
    const firstFrame = { tick: state.tick, actors };
    const secondFrame = { tick: replay.tick, actors: JSON.parse(JSON.stringify(actors)) };
    Sim.fixedUpdate(state, firstFrame, Sim.STEP);
    Sim.fixedUpdate(replay, secondFrame, Sim.STEP);
    assert.equal(Sim.serialize(replay), Sim.serialize(state), `combat replay diverged at continuation ${tick}`);
  }
});

test("seeded starts are varied, tiered, safe, and fully unarmed", () => {
  const fourFighterLayouts = new Set();
  const humanTiers = new Set();
  for (let seed = 1; seed <= 96; seed += 1) {
    const state = Sim.createState({ seed, botCount: 3 });
    const layout = state.fighters.map((fighter) => `${fighter.x},${fighter.y},${fighter.platformId}`).join("|");
    fourFighterLayouts.add(layout);
    humanTiers.add(spawnTier(state.fighters[0]));
    assert.deepEqual(new Set(state.fighters.map((fighter) => fighter.spawnIndex)).size, state.fighters.length);
    assert.deepEqual(new Set(state.fighters.map(spawnTier)), new Set(["low", "middle", "high"]));
    for (const fighter of state.fighters) {
      assert.equal(fighter.weapon, "unarmed");
      assert.equal(fighter.locomotion.travelSign, fighter.facing);
      assert.equal(fighter.locomotion.previousTravelSign, fighter.facing);
      assert.equal(fighter.locomotion.turn, null);
      assert.equal(fighter.locomotion.landExit, null);
      assert.equal(fighter.locomotion.runExit, null);
      assert.equal(fighter.locomotion.previousRunExit, null);
      assert.deepEqual(fighter.inventory, {
        unarmed: true, sword: false, pistol: false, shotgun: false, rifle: false, grenade: false
      });
      assert.deepEqual(fighter.ammo, {
        pistol: { mag: 0, reserve: 0 },
        shotgun: { mag: 0, reserve: 0 },
        rifle: { mag: 0, reserve: 0 },
        grenade: { count: 0 }
      });
      assertSafeSpawn(state, fighter);
    }
    const repeated = Sim.createState({ seed, botCount: 3 });
    assert.equal(Sim.serialize(repeated), Sim.serialize(state));
  }
  assert.ok(fourFighterLayouts.size > 8, `only ${fourFighterLayouts.size} four-fighter layouts were produced`);
  assert.deepEqual(humanTiers, new Set(["low", "middle", "high"]));

  for (let seed = 25; seed <= 36; seed += 1) {
    const state = Sim.createState({ seed, botCount: 1 });
    const tiers = state.fighters.map(spawnTier);
    assert.equal(new Set(tiers).size, 2);
    assert.ok(tiers.some((tier) => tier !== "low"));
    state.fighters.forEach((fighter) => assertSafeSpawn(state, fighter));
  }
});

test("respawns remain seeded, safe, separated, and keep collected weapons", () => {
  const first = Sim.createState({ seed: 0x81726354, botCount: 3 });
  const target = first.fighters[1];
  Sim.grantWeapon(target, "sword", true);
  target.weapon = "sword";
  target.dead = true;
  target.deaths = 1;
  target.respawn = 1;
  target.life = { kind: "defeat", age: 1 };
  const previousSpawn = target.spawnIndex;
  const second = Sim.deserialize(Sim.serialize(first));
  Sim.fixedUpdate(first, Sim.createInputFrame(first), Sim.STEP);
  Sim.fixedUpdate(second, Sim.createInputFrame(second), Sim.STEP);
  assert.equal(Sim.serialize(first), Sim.serialize(second));
  assert.equal(target.dead, false);
  assert.notEqual(target.spawnIndex, previousSpawn);
  assert.equal(target.weapon, "sword");
  assert.equal(target.inventory.sword, true);
  assert.equal(target.locomotion.travelSign, target.facing);
  assert.equal(target.locomotion.previousTravelSign, target.facing);
  assert.equal(target.locomotion.turn, null);
  assert.equal(target.locomotion.landExit, null);
  assert.equal(target.locomotion.runExit, null);
  assert.equal(target.locomotion.previousRunExit, null);
  assertSafeSpawn(first, target);
});

test("one authored health pickup has deterministic state and exact tuning", () => {
  assert.equal(Sim.RULES.healthPickupAmount, 30);
  assert.equal(Sim.RULES.pickupRespawnTicks, 600);
  const state = Sim.createState({ seed: 0x6ea17a, botCount: 1 });
  const healthPickups = state.pickups.filter((pickup) => pickup.kind === "health");
  assert.equal(state.pickups.length, 7);
  assert.equal(healthPickups.length, 1);
  assert.deepEqual(state.pickups.filter((pickup) => pickup.kind === "ammo").map((pickup) => pickup.id), [105]);
  assert.deepEqual(healthPickups[0], {
    id: 106, kind: "health", x: 960, y: 785, active: true, respawn: 0
  });
  assert.equal(Object.prototype.hasOwnProperty.call(healthPickups[0], "weapon"), false);
  assert.equal(Sim.serialize(state), Sim.serialize(Sim.createState({ seed: 0x6ea17a, botCount: 1 })));
});

test("health requires a pickup edge, reports actual healing, and caps at 100", () => {
  const state = Sim.createState({ seed: 0x6ea17b, botCount: 1 });
  const fighter = state.fighters[0];
  const health = state.pickups.find((pickup) => pickup.kind === "health");
  state.pickups.forEach((pickup) => { pickup.active = pickup === health; });
  placeAtPickup(fighter, health);
  fighter.health = 40;

  stepPickup(state, false);
  assert.equal(fighter.health, 40, "overlap passively healed the fighter");
  assert.equal(health.active, true, "overlap passively consumed health");
  assert.equal(state.events.some((event) => event.type === "pickup"), false);

  stepPickup(state, true);
  assert.equal(fighter.health, 70);
  assert.equal(health.active, false);
  assert.equal(health.respawn, 600);
  const event = state.events.find((candidate) => candidate.type === "pickup");
  assert.deepEqual({
    fighterId: event.fighterId,
    pickupId: event.pickupId,
    kind: event.kind,
    amount: event.amount,
    health: event.health,
    x: event.x,
    y: event.y
  }, {
    fighterId: fighter.id,
    pickupId: 106,
    kind: "health",
    amount: 30,
    health: 70,
    x: 960,
    y: 785
  });
  assert.equal(Object.prototype.hasOwnProperty.call(event, "weapon"), false);
  assert.deepEqual(Sim.deserialize(Sim.serialize(state)), state);

  const capped = Sim.createState({ seed: 0x6ea17c, botCount: 1 });
  const cappedFighter = capped.fighters[0];
  const cappedHealth = capped.pickups.find((pickup) => pickup.kind === "health");
  capped.pickups.forEach((pickup) => { pickup.active = pickup === cappedHealth; });
  placeAtPickup(cappedFighter, cappedHealth);
  cappedFighter.health = 88;
  stepPickup(capped, true);
  assert.equal(cappedFighter.health, 100);
  assert.equal(capped.events.find((candidate) => candidate.type === "pickup").amount, 12);

  const full = Sim.createState({ seed: 0x6ea17d, botCount: 1 });
  const fullFighter = full.fighters[0];
  const fullHealth = full.pickups.find((pickup) => pickup.kind === "health");
  full.pickups.forEach((pickup) => { pickup.active = pickup === fullHealth; });
  placeAtPickup(fullFighter, fullHealth);
  stepPickup(full, true);
  assert.equal(fullFighter.health, 100);
  assert.equal(fullHealth.active, true, "full-health fighter wasted the pickup");
  assert.equal(full.events.some((candidate) => candidate.type === "pickup"), false);
});

test("pickup selection filters health eligibility before deterministic distance ordering", () => {
  const full = Sim.createState({ seed: 0x6ea17e, botCount: 1 });
  const fullFighter = full.fighters[0];
  const health = full.pickups.find((pickup) => pickup.kind === "health");
  const ammo = full.pickups.find((pickup) => pickup.kind === "ammo");
  full.pickups.forEach((pickup) => { pickup.active = pickup === health || pickup === ammo; });
  Object.assign(ammo, { x: health.x + 10, y: health.y });
  placeAtPickup(fullFighter, health);
  const beforeEligibility = Sim.serialize(full);
  assert.equal(Sim.canCollectPickup(fullFighter, health), false);
  assert.equal(Sim.canCollectPickup(fullFighter, ammo), true);
  assert.equal(Sim.serialize(full), beforeEligibility, "eligibility query mutated authoritative state");
  stepPickup(full, true);
  assert.equal(health.active, true);
  assert.equal(ammo.active, false, "closer ineligible health masked eligible ammo");
  assert.equal(full.events.find((event) => event.type === "pickup").kind, "ammo");

  const damaged = Sim.createState({ seed: 0x6ea17f, botCount: 1 });
  const damagedFighter = damaged.fighters[0];
  const damagedHealth = damaged.pickups.find((pickup) => pickup.kind === "health");
  const damagedAmmo = damaged.pickups.find((pickup) => pickup.kind === "ammo");
  damaged.pickups.forEach((pickup) => { pickup.active = pickup === damagedHealth || pickup === damagedAmmo; });
  Object.assign(damagedAmmo, { x: damagedHealth.x + 10, y: damagedHealth.y });
  placeAtPickup(damagedFighter, damagedHealth);
  damagedFighter.health = 60;
  assert.equal(Sim.canCollectPickup(damagedFighter, damagedHealth), true);
  stepPickup(damaged, true);
  assert.equal(damagedHealth.active, false);
  assert.equal(damagedAmmo.active, true);
  assert.equal(damaged.events.find((event) => event.type === "pickup").kind, "health");

  const tied = Sim.createState({ seed: 0x6ea182, botCount: 1 });
  const tiedFighter = tied.fighters[0];
  const tiedHealth = tied.pickups.find((pickup) => pickup.kind === "health");
  const tiedAmmo = tied.pickups.find((pickup) => pickup.kind === "ammo");
  tied.pickups.forEach((pickup) => { pickup.active = pickup === tiedHealth || pickup === tiedAmmo; });
  Object.assign(tiedAmmo, { x: tiedHealth.x, y: tiedHealth.y });
  placeAtPickup(tiedFighter, tiedHealth);
  tiedFighter.health = 60;
  stepPickup(tied, true);
  assert.equal(tiedAmmo.active, false, "equal distance did not prefer the lower stable pickup ID");
  assert.equal(tiedHealth.active, true);
  assert.equal(tied.events.find((event) => event.type === "pickup").pickupId, 105);
});

test("health respawn is exact, held input cannot ghost-collect, and replay stays identical", () => {
  const state = Sim.createState({ seed: 0x6ea180, botCount: 1 });
  const fighter = state.fighters[0];
  const health = state.pickups.find((pickup) => pickup.kind === "health");
  state.pickups.forEach((pickup) => { pickup.active = pickup === health; });
  placeAtPickup(fighter, health);
  fighter.health = 40;
  stepPickup(state, true);
  assert.equal(fighter.health, 70);

  for (let tick = 0; tick < Sim.RULES.pickupRespawnTicks - 1; tick += 1) stepPickup(state, true);
  assert.equal(health.active, false);
  assert.equal(health.respawn, 1);
  assert.equal(state.events.some((event) => event.type === "pickupRespawn"), false);

  const replay = Sim.deserialize(Sim.serialize(state));
  stepPickup(state, true);
  stepPickup(replay, true);
  assert.equal(Sim.serialize(replay), Sim.serialize(state));
  assert.equal(health.active, true);
  assert.equal(health.respawn, 0);
  assert.equal(fighter.health, 70, "held pickup ghost-collected on respawn");
  const respawn = state.events.find((event) => event.type === "pickupRespawn");
  assert.deepEqual({
    pickupId: respawn.pickupId,
    kind: respawn.kind,
    x: respawn.x,
    y: respawn.y
  }, { pickupId: 106, kind: "health", x: 960, y: 785 });
  assert.equal(state.events.some((event) => event.type === "pickup"), false);

  stepPickup(state, false);
  stepPickup(replay, false);
  stepPickup(state, true);
  stepPickup(replay, true);
  assert.equal(Sim.serialize(replay), Sim.serialize(state));
  assert.equal(fighter.health, 100);
  assert.equal(health.active, false);
});

test("a fresh pickup edge on the exact health-respawn step has stable event order", () => {
  const state = Sim.createState({ seed: 0x6ea181, botCount: 1 });
  const fighter = state.fighters[0];
  const health = state.pickups.find((pickup) => pickup.kind === "health");
  state.pickups.forEach((pickup) => { pickup.active = pickup === health; });
  placeAtPickup(fighter, health);
  fighter.health = 50;
  stepPickup(state, true);
  for (let tick = 0; tick < Sim.RULES.pickupRespawnTicks - 2; tick += 1) stepPickup(state, true);
  assert.equal(health.respawn, 2);

  stepPickup(state, false);
  assert.equal(health.respawn, 1);
  stepPickup(state, true);
  assert.deepEqual(state.events.map((event) => event.type), ["pickupRespawn", "pickup"]);
  assert.equal(state.events[0].tick, state.events[1].tick);
  assert.equal(state.events[0].pickupId, health.id);
  assert.equal(state.events[1].pickupId, health.id);
  assert.equal(state.events[1].amount, 20);
  assert.equal(fighter.health, 100);
  assert.equal(health.active, false);
  assert.equal(health.respawn, Sim.RULES.pickupRespawnTicks);
});

test("health pickup presentation is bounded, contextual, and read-only", () => {
  const game = read("game.js");
  const audio = read("audio.js");
  const html = read("index.html");
  const drawPickup = game.slice(game.indexOf("function drawPickup"), game.indexOf("function worldPosePoint"));
  const events = game.slice(game.indexOf("function processEvents"), game.indexOf("function updatePresentation"));
  const sounds = audio.slice(audio.indexOf("function routeEvent"), audio.indexOf("function create(options)"));
  const nearby = game.slice(game.indexOf("function nearbyPickup"), game.indexOf("function updateHud"));
  const hud = game.slice(game.indexOf("function updateHud"), game.indexOf("function showResult"));
  const effects = game.slice(game.indexOf("function drawEffects"), game.indexOf("function render"));

  assert.match(drawPickup, /var isHealth = pickup\.kind === "health";[\s\S]*if \(!pickup\.active && !isHealth\) return/);
  assert.match(drawPickup, /1 - pickup\.respawn \/ Sim\.RULES\.pickupRespawnTicks/);
  assert.match(drawPickup, /#69ff9d[\s\S]*moveTo\(-11, 0\)[\s\S]*lineTo\(0, 11\)/);
  assert.doesNotMatch(drawPickup, /\b(?:Date|performance|Math\.random|setTimeout|setInterval)\b/);
  assert.doesNotMatch(drawPickup, /\b(?:state|pickup)\.[A-Za-z]\w*\s*=(?!=)/);
  assert.match(events, /event\.type === "pickup"[\s\S]*event\.kind === "health"[\s\S]*pushFlash/);
  assert.match(events, /event\.type === "pickupRespawn" && event\.kind === "health"[\s\S]*burst/);
  assert.match(sounds, /event\.type === "pickup"[\s\S]*event\.kind === "health"[\s\S]*event\.type === "pickupRespawn" && event\.kind === "health"/);
  assert.match(effects, /f\.kind === "pickup"[\s\S]*f\.color[\s\S]*ctx\.arc/);
  assert.match(nearby, /Sim\.canCollectPickup\(player, p\)/);
  assert.match(hud, /pickup\.kind === "health"[\s\S]*"HEALTH \+"/);
  assert.match(html, /id="touchPickupButton"[^>]+aria-label="Pick up nearby item"/);
});

test("bot controller emits shared inputs without mutating state", () => {
  const state = Sim.createState({ seed: 8, botCount: 3 });
  const before = Sim.serialize(state);
  const frame = Bots.makeInputs(state, neutralHuman(state));
  assert.equal(Sim.serialize(state), before);
  assert.equal(frame.tick, state.tick);
  assert.equal(frame.actors.length, 4);
  const canonicalActor = Sim.createInputFrame(state).actors[0];
  const actorKeys = Object.keys(canonicalActor).sort();
  const buttonKeys = Object.keys(canonicalActor.buttons).sort();
  for (const actor of frame.actors) {
    assert.deepEqual(Object.keys(actor).sort(), actorKeys);
    assert.deepEqual(Object.keys(actor.buttons).sort(), buttonKeys);
    assert.ok(Number.isFinite(actor.moveX));
    assert.ok(Number.isFinite(actor.moveY));
    assert.ok(Number.isFinite(actor.aimX));
    assert.ok(Number.isFinite(actor.aimY));
    assert.equal(typeof actor.buttons.attack, "boolean");
  }
  const bot = Bots.makeBotInput(state, state.fighters[1]);
  assert.deepEqual(Object.keys(bot).sort(), actorKeys);
  assert.deepEqual(Object.keys(bot.buttons).sort(), buttonKeys);
  for (const forbidden of [
    "x", "y", "vx", "vy", "health", "damage", "score", "weapon", "ammo",
    "range", "falloff", "cadence", "target", "targetId", "projectileId", "hitIds"
  ]) {
    assert.equal(forbidden in bot, false, `bot input contains authoritative field ${forbidden}`);
  }
});

test("bot frames are phase-aware, order-stable, and pure", () => {
  const state = Sim.createState({ seed: 0x7007, botCount: 3 });
  keepOnlyPickup(state, -1);
  const before = Sim.serialize(state);
  const direct = Bots.makeInputs(state, neutralHuman(state));
  assert.equal(Sim.serialize(state), before, "bot frame derivation mutated simulation state");

  const reordered = Sim.snapshot(state);
  reordered.fighters.reverse();
  reordered.pickups.reverse();
  reordered.arena.platforms.reverse();
  reordered.arena.hazards.reverse();
  const reorderedHuman = reordered.fighters.find((fighter) => fighter.id === 0);
  const reorderedFrame = Bots.makeInputs(reordered, neutralActor(reorderedHuman));
  assert.deepEqual(reorderedFrame, direct,
    "equivalent authoritative arrays changed the canonical bot frame");
  assert.deepEqual(reorderedFrame.actors.map((actor) => actor.id), [0, 1, 2, 3]);

  const spoofedHuman = neutralHuman(state);
  spoofedHuman.id = 1;
  spoofedHuman.weaponSlot = null;
  const authoritativeIds = Bots.makeInputs(state, spoofedHuman).actors.map((actor) => actor.id);
  assert.deepEqual(authoritativeIds, [0, 1, 2, 3],
    "payload identity created a duplicate actor command");
  assert.equal(new Set(authoritativeIds).size, authoritativeIds.length);
  assert.equal(Bots.makeInputs(state, spoofedHuman).actors[0].weaponSlot, null);

  const finishedBot = state.fighters[1];
  finishedBot.facing = -1;
  state.match.phase = "finished";
  const finished = Bots.makeBotInput(state, finishedBot);
  assert.equal(finished.aimX, -1, "finished input discarded the fighter's facing");
  assert.equal(finished.moveX, 0);
  assert.equal(finished.moveY, 0);
  assert.equal(finished.weaponSlot, null);
  assert.ok(Object.values(finished.buttons).every((value) => value === false));

  const finalTick = Sim.createState({ seed: 123, botCount: 1 });
  keepOnlyPickup(finalTick, -1);
  const [target, bot] = finalTick.fighters;
  placeBotFixtureFighter(bot, 500, 880, 0);
  placeBotFixtureFighter(target, 750, 880, 0);
  target.invuln = 1000;
  equipBotFixtureWeapon(bot, "rifle");
  finalTick.match.ticksRemaining = 1;
  assert.equal(Bots.makeBotInput(finalTick, bot).buttons.attack, true,
    "a legal final playing tick suppressed combat");
});

test("bot grenade policy reads count, respects blast safety, and ignores firearm LOS", () => {
  const state = Sim.createState({ seed: 123, botCount: 1 });
  keepOnlyPickup(state, -1);
  const [target, bot] = state.fighters;
  placeBotFixtureFighter(bot, 400, 880, 0);
  placeBotFixtureFighter(target, 750, 880, 0);
  target.invuln = 1000;
  equipBotFixtureWeapon(bot, "grenade");
  state.arena.platforms.push({ id: 90, x: 550, y: 760, w: 30, h: 100 });
  const first = Bots.makeBotInput(state, bot);
  assert.equal(first.buttons.attack, true,
    "a safe ballistic grenade inherited straight firearm line-of-sight");
  state.arena.platforms.pop();

  Sim.fixedUpdate(state, {
    tick: state.tick,
    actors: [neutralActor(target), first]
  }, Sim.STEP);
  for (let step = 1; step <= Sim.WEAPONS.grenade.releaseAge; step += 1) {
    Sim.fixedUpdate(state, {
      tick: state.tick,
      actors: [neutralActor(target), Bots.makeBotInput(state, bot)]
    }, Sim.STEP);
  }
  assert.equal(bot.ammo.grenade.count, Sim.WEAPONS.grenade.count - 1);
  assert.equal(state.grenades.length, 1);

  const unsafe = Sim.createState({ seed: 123, botCount: 1 });
  keepOnlyPickup(unsafe, -1);
  const [nearTarget, nearBot] = unsafe.fighters;
  placeBotFixtureFighter(nearBot, 500, 880, 0);
  placeBotFixtureFighter(nearTarget, 700, 880, 0);
  equipBotFixtureWeapon(nearBot, "grenade");
  assert.equal(Bots.makeBotInput(unsafe, nearBot).buttons.attack, false,
    "bot threw inside the grenade self-damage safety margin");
});

test("bot rifle intent stays held for exact automatic cadence while semiautomatics reset", () => {
  const rifleState = Sim.createState({ seed: 123, botCount: 1 });
  keepOnlyPickup(rifleState, -1);
  const [rifleTarget, rifleBot] = rifleState.fighters;
  placeBotFixtureFighter(rifleBot, 300, 880, 0);
  placeBotFixtureFighter(rifleTarget, 750, 880, 0);
  rifleTarget.invuln = 1000;
  equipBotFixtureWeapon(rifleBot, "rifle");
  const fireTicks = [];
  const held = [];
  for (let step = 0; step < 24; step += 1) {
    const botInput = Bots.makeBotInput(rifleState, rifleBot);
    held.push(botInput.buttons.attack);
    Sim.fixedUpdate(rifleState, {
      tick: rifleState.tick,
      actors: [neutralActor(rifleTarget), botInput]
    }, Sim.STEP);
    for (const event of rifleState.events) {
      if (event.type === "fire" && event.fighterId === rifleBot.id) fireTicks.push(event.tick);
    }
  }
  assert.ok(held.every(Boolean), "rifle intent released during its automatic engagement");
  assert.ok(fireTicks.length >= 4, "rifle fixture did not produce a sustained burst");
  assert.deepEqual(fireTicks.slice(1).map((tick, index) => tick - fireTicks[index]),
    Array(fireTicks.length - 1).fill(Sim.WEAPONS.rifle.cooldown));

  const pistolState = Sim.createState({ seed: 123, botCount: 1 });
  keepOnlyPickup(pistolState, -1);
  const [pistolTarget, pistolBot] = pistolState.fighters;
  placeBotFixtureFighter(pistolBot, 500, 880, 0);
  placeBotFixtureFighter(pistolTarget, 750, 880, 0);
  pistolTarget.invuln = 1000;
  equipBotFixtureWeapon(pistolBot, "pistol");
  const pistolPress = Bots.makeBotInput(pistolState, pistolBot);
  assert.equal(pistolPress.buttons.attack, true);
  Sim.fixedUpdate(pistolState, {
    tick: pistolState.tick,
    actors: [neutralActor(pistolTarget), pistolPress]
  }, Sim.STEP);
  assert.equal(Bots.makeBotInput(pistolState, pistolBot).buttons.attack, false,
    "semiautomatic bot input stayed held during lockout");
});

test("bot ammo policy reloads usable reserves and reselects owned ranged weapons", () => {
  function pistolFixture() {
    const state = Sim.createState({ seed: 0x7011, botCount: 1 });
    keepOnlyPickup(state, 105);
    const ammoPickup = state.pickups.find((pickup) => pickup.id === 105);
    ammoPickup.x = 250;
    ammoPickup.y = 845;
    const [target, bot] = state.fighters;
    placeBotFixtureFighter(bot, 500, 880, 0);
    placeBotFixtureFighter(target, 750, 880, 0);
    target.invuln = 1000;
    equipBotFixtureWeapon(bot, "pistol");
    return { state, target, bot };
  }

  const supplied = pistolFixture();
  supplied.bot.ammo.pistol = { mag: 1, reserve: 20 };
  const suppliedInput = Bots.makeBotInput(supplied.state, supplied.bot);
  assert.equal(suppliedInput.moveX, 1,
    "one loaded round plus ample reserve caused an ammo detour");
  assert.equal(suppliedInput.buttons.reload, false);

  const empty = pistolFixture();
  empty.bot.ammo.pistol = { mag: 0, reserve: 10 };
  const reloadInput = Bots.makeBotInput(empty.state, empty.bot);
  assert.equal(reloadInput.buttons.reload, true,
    "an empty firearm with usable reserve did not reload");
  assert.equal(reloadInput.moveX, 1, "reloadable reserve caused an ammo detour");

  const reselect = pistolFixture();
  reselect.bot.weapon = "unarmed";
  const switchInput = Bots.makeBotInput(reselect.state, reselect.bot);
  assert.equal(switchInput.weaponSlot, Sim.WEAPONS.pistol.slot);
  assert.equal(switchInput.buttons.attack, false,
    "bot attacked before its canonical weapon switch could resolve");

  const relevant = pistolFixture();
  equipBotFixtureWeapon(relevant.bot, "rifle");
  relevant.bot.ammo.pistol = { mag: 0, reserve: 0 };
  const relevantInput = Bots.makeBotInput(relevant.state, relevant.bot);
  assert.equal(relevantInput.moveX, 1,
    "an empty dormant weapon overrode a fully supplied active rifle");

  const alternate = pistolFixture();
  equipBotFixtureWeapon(alternate.bot, "rifle");
  alternate.bot.ammo.rifle = { mag: 0, reserve: 0 };
  const alternateInput = Bots.makeBotInput(alternate.state, alternate.bot);
  assert.equal(alternateInput.weaponSlot, Sim.WEAPONS.pistol.slot,
    "empty active weapon caused a detour despite a supplied ranged alternative");
});

test("damaged bots collect health through the shared pickup edge without a live target", () => {
  const state = Sim.createState({ seed: 0x7012, botCount: 1 });
  keepOnlyPickup(state, 106);
  const [target, bot] = state.fighters;
  target.dead = true;
  target.health = 0;
  target.respawn = 1000;
  const health = state.pickups.find((pickup) => pickup.id === 106);
  placeAtPickup(bot, health);
  bot.health = 70;
  const before = Sim.serialize(state);
  const botInput = Bots.makeBotInput(state, bot);
  assert.equal(Sim.serialize(state), before, "health decision directly mutated state");
  assert.equal(botInput.buttons.pickup, true);
  const authoritativeDistance = Math.hypot(
    health.x - bot.x,
    health.y - (bot.y - 35)
  );
  assert.ok(authoritativeDistance < Sim.RULES.pickupRadius);
  Sim.fixedUpdate(state, {
    tick: state.tick,
    actors: [neutralActor(target), botInput]
  }, Sim.STEP);
  assert.equal(bot.health, 100);
  assert.equal(health.active, false);
  assert.equal(state.events.filter((event) => event.type === "pickup"
    && event.fighterId === bot.id).length, 1);

  const full = Sim.createState({ seed: 0x7012, botCount: 1 });
  keepOnlyPickup(full, 106);
  const [deadTarget, fullBot] = full.fighters;
  deadTarget.dead = true;
  deadTarget.health = 0;
  deadTarget.respawn = 1000;
  placeAtPickup(fullBot, full.pickups.find((pickup) => pickup.id === 106));
  assert.equal(Bots.makeBotInput(full, fullBot).buttons.pickup, false,
    "full-health bot consumed the authored health pickup");
});

test("bot pickup navigation reaches the top platform through authored stable routes", () => {
  for (const originId of [0, 7, 8, 1, 2, 3]) {
    const state = Sim.createState({ seed: 0x7020 + originId, botCount: 1 });
    keepOnlyPickup(state, 105);
    const [target, bot] = state.fighters;
    target.dead = true;
    target.health = 0;
    target.respawn = 2000;
    const origin = state.arena.platforms.find((platform) => platform.id === originId);
    placeBotFixtureFighter(bot, origin.x + origin.w * 0.5, origin.y, origin.id);
    equipBotFixtureWeapon(bot, "rifle");
    bot.ammo.rifle = { mag: 0, reserve: 0 };
    const visited = new Set([origin.id]);
    let pickupPresses = 0;
    let firstPickupDistance = null;

    for (let step = 0; step < 700 && state.pickups[5].active; step += 1) {
      const botInput = Bots.makeBotInput(state, bot);
      assert.equal(botInput.buttons.jump && botInput.buttons.drop, false,
        `origin ${originId} emitted simultaneous vertical commands`);
      if (botInput.buttons.pickup) {
        pickupPresses += 1;
        if (firstPickupDistance === null) {
          const pickup = state.pickups[5];
          firstPickupDistance = Math.hypot(
            pickup.x - bot.x,
            pickup.y - (bot.y - 35)
          );
        }
      }
      Sim.fixedUpdate(state, {
        tick: state.tick,
        actors: [neutralActor(target), botInput]
      }, Sim.STEP);
      visited.add(bot.platformId);
    }

    assert.equal(state.pickups[5].active, false,
      `origin ${originId} could not reach top-platform ammo`);
    assert.ok(visited.has(4) || visited.has(5),
      `origin ${originId} skipped the authored top-route support`);
    assert.equal(pickupPresses, 1,
      `origin ${originId} did not emit exactly one accepted pickup edge`);
    assert.ok(firstPickupDistance < Math.min(58, Sim.RULES.pickupRadius),
      `origin ${originId} asserted Pickup outside authoritative range`);
  }
});

test("bot combat navigation preserves the authored top-platform waypoint", () => {
  const state = Sim.createState({ seed: 0x7040, botCount: 1 });
  keepOnlyPickup(state, -1);
  const [target, bot] = state.fighters;
  placeBotFixtureFighter(bot, 960, 630, 2);
  placeBotFixtureFighter(target, 960, 305, 6);
  target.invuln = 1000;
  const visited = new Set([bot.platformId]);

  for (let step = 0; step < 160 && bot.platformId !== 6; step += 1) {
    const botInput = Bots.makeBotInput(state, bot);
    Sim.fixedUpdate(state, {
      tick: state.tick,
      actors: [neutralActor(target), botInput]
    }, Sim.STEP);
    visited.add(bot.platformId);
  }

  assert.ok(visited.has(4) || visited.has(5),
    "combat steering overwrote the authored intermediate waypoint");
  assert.equal(bot.platformId, 6, "bot never reached its top-platform target");
});

test("bot jump edges recover after simulation rejects them during hitstun", () => {
  const state = Sim.createState({ seed: 0x702f, botCount: 1 });
  keepOnlyPickup(state, -1);
  const [target, bot] = state.fighters;
  placeBotFixtureFighter(bot, 960, 630, 2);
  placeBotFixtureFighter(target, 960, 305, 6);
  target.invuln = 1000;
  bot.hitstun = 4;
  let jumped = false;

  for (let step = 0; step < 80 && !jumped; step += 1) {
    const botInput = Bots.makeBotInput(state, bot);
    if (bot.hitstun > 0) {
      assert.equal(botInput.buttons.jump, false,
        "bot held a jump edge that simulation had to reject during hitstun");
    }
    Sim.fixedUpdate(state, {
      tick: state.tick,
      actors: [neutralActor(target), botInput]
    }, Sim.STEP);
    jumped = !bot.grounded && bot.y < 630;
  }

  assert.equal(jumped, true, "bot never emitted a fresh jump edge after hitstun");
});

test("bot firearm decisions use the actual fine-aim cone", () => {
  function aimFixture(targetX, targetY) {
    const state = Sim.createState({ seed: 333, botCount: 1 });
    keepOnlyPickup(state, -1);
    state.arena.platforms = [];
    state.arena.hazards = [];
    state.match.ticksRemaining = 1;
    const [target, bot] = state.fighters;
    placeBotFixtureFighter(bot, 0, 0);
    placeBotFixtureFighter(target, targetX, targetY);
    equipBotFixtureWeapon(bot, "pistol");
    return Bots.makeBotInput(state, bot);
  }

  const highReachable = aimFixture(350, 350);
  const reachableDegrees = Math.abs(Math.atan2(
    highReachable.aimY,
    Math.abs(highReachable.aimX)
  ) * 180 / Math.PI);
  assert.ok(reachableDegrees < Sim.GUN_AIM.maxDegrees);
  assert.equal(highReachable.buttons.attack, true,
    "reachable high-angle shot was rejected by a raw vertical-distance heuristic");

  const tooSteep = aimFixture(115, 220);
  const steepDegrees = Math.abs(Math.atan2(
    tooSteep.aimY,
    Math.abs(tooSteep.aimX)
  ) * 180 / Math.PI);
  assert.ok(steepDegrees > Sim.GUN_AIM.maxDegrees);
  assert.equal(tooSteep.buttons.attack, false,
    "bot knowingly fired outside the authoritative firearm cone");
});

test("closing regulation suppresses optional ammo detours but preserves combat", () => {
  function closingFixture(remainingTicks) {
    const state = Sim.createState({ seed: 0x7030, botCount: 1 });
    keepOnlyPickup(state, 105);
    state.match.ticksRemaining = remainingTicks;
    const ammoPickup = state.pickups.find((pickup) => pickup.id === 105);
    ammoPickup.x = 300;
    ammoPickup.y = 845;
    const [target, bot] = state.fighters;
    placeBotFixtureFighter(bot, 500, 880, 0);
    placeBotFixtureFighter(target, 800, 880, 0);
    equipBotFixtureWeapon(bot, "pistol");
    bot.ammo.pistol = { mag: 1, reserve: 0 };
    return Bots.makeBotInput(state, bot);
  }

  assert.equal(closingFixture(12 * 60 + 1).moveX, -1,
    "ordinary regulation did not allow a useful ammo detour");
  const closing = closingFixture(12 * 60);
  assert.equal(closing.moveX, 1,
    "closing regulation kept pursuing a distant optional pickup");
  assert.equal(closing.buttons.attack, true,
    "closing regulation suppressed a legal combat action");
});

test("active combat geometry stays deterministic across the fine-aim grid", () => {
  const samples = [];
  const copyPoint = (point) => ({ x: point.x, y: point.y });

  for (const facing of [-1, 1]) {
    for (let age = 11; age <= 16; age += 0.25) {
      const blade = Anim.swordBlade(Anim.sampleClip("swordAttack", age, { weapon: "sword", facing }));
      samples.push({
        kind: "sword", facing, age,
        start: copyPoint(blade.bladeStart), end: copyPoint(blade.bladeEnd),
        direction: copyPoint(blade.direction)
      });
    }
    for (let age = 7; age <= 10; age += 0.25) {
      const strike = Anim.unarmedStrike(Anim.sampleClip("unarmed", age, { weapon: "unarmed", facing }));
      samples.push({
        kind: "unarmed", facing, age,
        start: copyPoint(strike.start), end: copyPoint(strike.end)
      });
    }
  }

  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    for (let aimStep = Sim.GUN_AIM.minStep; aimStep <= Sim.GUN_AIM.maxStep; aimStep += 1) {
      for (const facing of [-1, 1]) {
        const aimed = Anim.gunMuzzle(Anim.sampleClip("gunAim", 0, { weapon, aimStep, facing }), weapon);
        samples.push({
          kind: "gunAim", weapon, aimStep, facing, age: 0,
          muzzle: copyPoint(aimed.point), direction: copyPoint(aimed.direction)
        });
        for (let age = 0; age <= 12; age += 0.25) {
          const fired = Anim.gunMuzzle(Anim.sampleClip("gunFire", age, { weapon, aimStep, facing }), weapon);
          samples.push({
            kind: "gunFire", weapon, aimStep, facing, age,
            muzzle: copyPoint(fired.point), direction: copyPoint(fired.direction)
          });
        }
      }
    }
  }

  assert.equal(samples.length, 10568);
  const digest = crypto.createHash("sha256").update(JSON.stringify(samples)).digest("hex");
  assert.equal(digest, "567333126db7928931c9f37a7de5f700e50c7fddbfee2f88b111b95b9282bdc1");
});

test("sword slash owns one decisive active arc and an exact bounded cosmetic trail", () => {
  assert.deepEqual({
    damage: Sim.WEAPONS.sword.damage,
    cooldown: Sim.WEAPONS.sword.cooldown,
    duration: Sim.WEAPONS.sword.duration,
    activeStart: Sim.WEAPONS.sword.activeStart,
    activeEnd: Sim.WEAPONS.sword.activeEnd,
    knockback: Sim.WEAPONS.sword.knockback,
    hitstun: Sim.WEAPONS.sword.hitstun
  }, {
    damage: 24, cooldown: 44, duration: 44,
    activeStart: 11, activeEnd: 16,
    knockback: 440, hitstun: 12
  });

  const angles = [];
  for (let age = Sim.WEAPONS.sword.activeStart; age <= Sim.WEAPONS.sword.activeEnd; age += 0.05) {
    const pose = Anim.sampleClip("swordAttack", age, { weapon: "sword", facing: 1 });
    const blade = Anim.swordBlade(pose);
    angles.push(Math.atan2(blade.direction.y, blade.direction.x));
    assert.ok(Math.abs(Math.hypot(
      blade.bladeEnd.x - blade.bladeStart.x,
      blade.bladeEnd.y - blade.bladeStart.y
    ) - 58) < 1e-9, `sword blade length changed at ${age}`);
  }
  for (let index = 1; index < angles.length; index += 1) {
    assert.ok(angles[index] >= angles[index - 1] - 1e-9,
      `active sword arc reversed between samples ${index - 1} and ${index}`);
  }
  const activeArcDegrees = (angles.at(-1) - angles[0]) * 180 / Math.PI;
  assert.ok(activeArcDegrees >= 70, `active sword arc reached only ${activeArcDegrees} degrees`);

  const maxTipTravel = (start, end) => {
    let maximum = 0;
    let previous = Anim.swordBlade(Anim.sampleClip("swordAttack", start, {
      weapon: "sword", facing: 1
    })).tip;
    for (let age = start + 0.05; age <= end + 1e-9; age += 0.05) {
      const tip = Anim.swordBlade(Anim.sampleClip("swordAttack", Math.min(age, end), {
        weapon: "sword", facing: 1
      })).tip;
      maximum = Math.max(maximum, Math.hypot(tip.x - previous.x, tip.y - previous.y));
      previous = tip;
    }
    return maximum;
  };
  assert.ok(maxTipTravel(10, 16) > maxTipTravel(0, 9.95),
    "peak sword-tip motion remained in the windup instead of release/contact");

  for (const facing of [-1, 1]) {
    for (const age of [10, 10.5, 11, 13, 16, 18, 20, 21, 22]) {
      const pose = Anim.sampleClip("swordAttack", age, { weapon: "sword", facing });
      const before = JSON.stringify(pose);
      const samples = Anim.swordTrailSamples(pose);
      assert.equal(JSON.stringify(pose), before, `trail mutated its source pose at ${facing}/${age}`);
      assert.ok(samples.length >= 1 && samples.length <= 4, `trail count was ${samples.length} at ${age}`);
      assert.doesNotThrow(() => JSON.parse(JSON.stringify(samples)));
      const visible = Anim.swordBlade(pose);
      assertPointNear(samples[0].bladeStart, visible.bladeStart, `trail current start ${facing}/${age}`);
      assertPointNear(samples[0].bladeEnd, visible.bladeEnd, `trail current end ${facing}/${age}`);
      for (const [index, sample] of samples.entries()) {
        assert.ok(Number.isFinite(sample.age) && Number.isFinite(sample.alpha));
        assert.ok(sample.alpha > 0 && sample.alpha <= 1);
        const expected = Anim.swordBlade(Anim.sampleClip("swordAttack", sample.age, {
          weapon: "sword", facing
        }));
        assertPointNear(sample.bladeStart, expected.bladeStart,
          `trail ${index} start ${facing}/${age}`);
        assertPointNear(sample.bladeEnd, expected.bladeEnd,
          `trail ${index} end ${facing}/${age}`);
        assertPointNear(sample.tip, expected.tip, `trail ${index} tip ${facing}/${age}`);
      }
    }
  }

  for (const age of [0, 9.99, 23, 44]) {
    assert.deepEqual(Anim.swordTrailSamples(Anim.sampleClip("swordAttack", age, {
      weapon: "sword", facing: 1
    })), [], `trail escaped its display window at ${age}`);
  }
  assert.deepEqual(Anim.swordTrailSamples(Anim.sampleClip("swordReady", 10, {
    weapon: "sword", facing: 1
  })), []);
  assert.deepEqual(Anim.swordTrailSamples(Anim.sampleClip("unarmed", 10, {
    weapon: "unarmed", facing: 1
  })), []);

  const followThroughAlpha = [18, 19, 20, 21, 22].map((age) =>
    Anim.swordTrailSamples(Anim.sampleClip("swordAttack", age, {
      weapon: "sword", facing: 1
    }))[0].alpha
  );
  assert.ok(followThroughAlpha.every((alpha, index) => index === 0 || alpha < followThroughAlpha[index - 1]),
    "sword trail did not taper monotonically through follow-through");
  assert.ok(followThroughAlpha.at(-1) < followThroughAlpha[0] * 0.25,
    "sword trail remained too opaque on its last visible follow-through tick");

  for (const age of [10, 11, 13, 16, 18, 20, 21, 22]) {
    const right = Anim.swordTrailSamples(Anim.sampleClip("swordAttack", age, {
      weapon: "sword", facing: 1
    }));
    const left = Anim.swordTrailSamples(Anim.sampleClip("swordAttack", age, {
      weapon: "sword", facing: -1
    }));
    assert.equal(left.length, right.length);
    for (let index = 0; index < right.length; index += 1) {
      assert.equal(left[index].age, right[index].age);
      assert.equal(left[index].alpha, right[index].alpha);
      for (const key of ["bladeStart", "bladeEnd", "tip"]) {
        assertPointNear(left[index][key], {
          x: -right[index][key].x,
          y: right[index][key].y
        }, `trail mirror ${age}/${index}/${key}`);
      }
    }
  }
  assert.doesNotMatch(read("sim.js"), /swordTrailSamples/,
    "cosmetic sword trail crossed into gameplay authority");
});

test("melee swing and accepted contact events stay fixed-step aligned to exact segments", () => {
  for (const weapon of ["unarmed", "sword"]) {
    for (const facing of [-1, 1]) {
      const miss = Sim.createState({ seed: 0x590000 + Sim.WEAPONS[weapon].slot + facing, botCount: 1 });
      const attacker = miss.fighters[0];
      const target = miss.fighters[1];
      if (weapon === "sword") Sim.grantWeapon(attacker, "sword", true);
      attacker.weapon = weapon;
      attacker.facing = facing;
      target.x = attacker.x + facing * 900;
      target.prevX = target.x;
      const actor = neutralHuman(miss);
      actor.aimX = facing;
      actor.buttons.attack = true;
      const swings = [];
      let swingAllocatorDelta = null;
      for (let tick = 0; tick <= Sim.WEAPONS[weapon].duration; tick += 1) {
        const entityIdBefore = miss.nextEntityId;
        Sim.fixedUpdate(miss, { tick: miss.tick, actors: [actor] }, Sim.STEP);
        actor.buttons.attack = false;
        for (const event of miss.events.filter((candidate) => candidate.type === "meleeSwing")) {
          const segment = weapon === "sword" ? Sim.swordSegment(attacker) : Sim.unarmedSegment(attacker);
          swings.push({ event: JSON.parse(JSON.stringify(event)), segment });
          swingAllocatorDelta = miss.nextEntityId - entityIdBefore;
        }
      }
      assert.equal(swings.length, 1, `${weapon} facing ${facing} emitted ${swings.length} swing cues`);
      const { event, segment } = swings[0];
      assert.equal(event.weapon, weapon);
      assert.equal(event.fighterId, attacker.id);
      assert.equal(event.facing, facing);
      assert.ok(event.id < 0, `${weapon} swing cue did not use a presentation-only ID`);
      assert.equal(swingAllocatorDelta, 0, `${weapon} swing cue consumed a gameplay entity ID`);
      assert.deepEqual({ x1: event.x1, y1: event.y1, x2: event.x2, y2: event.y2 }, segment);
      assert.doesNotThrow(() => JSON.parse(Sim.serialize(miss)));

      const contact = Sim.createState({ seed: 0x5a0000 + Sim.WEAPONS[weapon].slot + facing, botCount: 1 });
      const hitter = contact.fighters[0];
      const victim = contact.fighters[1];
      if (weapon === "sword") Sim.grantWeapon(hitter, "sword", true);
      Object.assign(hitter, {
        x: 500, prevX: 500, y: 880, prevY: 880,
        vx: 0, vy: 0, grounded: true, platformId: 0,
        weapon, facing, invuln: 0
      });
      Object.assign(victim, {
        x: 500 + facing * 20, prevX: 500 + facing * 20, y: 880, prevY: 880,
        vx: 0, vy: 0, grounded: true, platformId: 0, invuln: 0
      });
      const attack = neutralHuman(contact);
      attack.aimX = facing;
      attack.buttons.attack = true;
      let accepted = null;
      let acceptedSegment = null;
      for (let tick = 0; tick <= Sim.WEAPONS[weapon].duration && !accepted; tick += 1) {
        Sim.fixedUpdate(contact, { tick: contact.tick, actors: [attack] }, Sim.STEP);
        attack.buttons.attack = false;
        accepted = contact.events.find((candidate) => candidate.type === "hit" && candidate.fighterId === victim.id) || null;
        if (accepted) acceptedSegment = weapon === "sword" ? Sim.swordSegment(hitter) : Sim.unarmedSegment(hitter);
      }
      assert.ok(accepted && acceptedSegment, `${weapon} facing ${facing} produced no accepted contact`);
      assert.ok(pointSegmentDistance(
        { x: accepted.x, y: accepted.y },
        { x: acceptedSegment.x1, y: acceptedSegment.y1 },
        { x: acceptedSegment.x2, y: acceptedSegment.y2 }
      ) < 1e-9, `${weapon} contact effect left its authoritative segment`);
      const tangentLength = Math.hypot(accepted.tangentX, accepted.tangentY);
      assert.ok(Math.abs(tangentLength - 1) < 1e-12, `${weapon} contact tangent was not normalized`);
      const segmentLength = Math.hypot(
        acceptedSegment.x2 - acceptedSegment.x1,
        acceptedSegment.y2 - acceptedSegment.y1
      );
      assert.ok(Math.abs(
        accepted.tangentX - (acceptedSegment.x2 - acceptedSegment.x1) / segmentLength
      ) < 1e-12);
      assert.ok(Math.abs(
        accepted.tangentY - (acceptedSegment.y2 - acceptedSegment.y1) / segmentLength
      ) < 1e-12);
      assert.equal(victim.health, 100 - Sim.WEAPONS[weapon].damage);
      assert.deepEqual(Object.keys(hitter.attack).sort(),
        ["age", "duration", "facing", "hitIds", "kind", "weapon"],
        `${weapon} gained an unapproved attack variant field`);
    }
  }
});

test("every firearm step keeps exact sockets, safe anatomy, and seamless handling", () => {
  const renderedArmClearance = (16 * 1.18 + 3.5 / 2 + 10 / 2) / 1.18;
  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    let previousReady = null;
    for (let aimStep = Sim.GUN_AIM.minStep; aimStep <= Sim.GUN_AIM.maxStep; aimStep += 1) {
      const expected = Sim.resolveGunAim(1, 0, 1, aimStep);
      const ready = Anim.sampleClip("gunAim", 0, { weapon, aimStep, facing: 1 });
      const mirroredReady = Anim.sampleClip("gunAim", 0, { weapon, aimStep, facing: -1 });
      const readyBends = { L: elbowBendCross(ready, "L"), R: elbowBendCross(ready, "R") };
      assert.equal(ready.aimStep, aimStep);
      assert.equal(ready.aimDegrees, aimStep * 3);
      assertPointNear(ready.weaponDir, expected, `${weapon} step ${aimStep} ready direction`, 1e-15);
      for (const key of [...Anim.POINTS, "torsoTop"]) {
        assert.ok(Math.abs(ready[key].x + mirroredReady[key].x) < 1e-9,
          `${weapon} step ${aimStep} ${key}.x did not mirror`);
        assert.ok(Math.abs(ready[key].y - mirroredReady[key].y) < 1e-9,
          `${weapon} step ${aimStep} ${key}.y changed while mirroring`);
      }
      if (previousReady) {
        assert.ok(maxPosePointDelta(ready, previousReady) <= 3,
          `${weapon} adjacent step ${aimStep - 1}->${aimStep} popped`);
      }
      previousReady = ready;

      for (let age = 0; age <= Anim.CLIPS.gunFire.duration; age += 0.25) {
        const right = Anim.sampleClip("gunFire", age, { weapon, aimStep, facing: 1 });
        const left = Anim.sampleClip("gunFire", age, { weapon, aimStep, facing: -1 });
        const sockets = Anim.gunSockets(right, weapon);
        const mirroredSockets = Anim.gunSockets(left, weapon);
        assertPointNear(sockets.direction, expected, `${weapon} step ${aimStep} recoil@${age}`, 1e-15);
        assertPointNear(mirroredSockets.direction,
          { x: -expected.x, y: expected.y }, `${weapon} step ${aimStep} mirrored recoil@${age}`, 1e-15);
        assertPointNear(mirroredSockets.muzzle,
          { x: -sockets.muzzle.x, y: sockets.muzzle.y }, `${weapon} step ${aimStep} mirrored muzzle@${age}`);
        for (const [start, end] of ARM_SEGMENTS) {
          const length = Math.hypot(right[start].x - right[end].x, right[start].y - right[end].y);
          assert.ok(length >= 9.9 && length <= 36,
            `${weapon} step ${aimStep} recoil@${age} ${start}-${end} became ${length}`);
          const clearance = pointSegmentDistance(right.head, right[start], right[end]);
          assert.ok(clearance >= renderedArmClearance,
            `${weapon} step ${aimStep} recoil@${age} ${start}-${end} entered the rendered head`);
        }
        for (const side of ["L", "R"]) {
          assert.ok(readyBends[side] * elbowBendCross(right, side) > 0,
            `${weapon} step ${aimStep} recoil@${age} reversed elbow ${side}`);
        }
        for (const [part, start, end] of [
          ["stock", sockets.stock, sockets.barrelStart],
          ["barrel", sockets.barrelStart, sockets.muzzle]
        ]) {
          assert.ok(pointSegmentDistance(right.head, start, end) >= 22,
            `${weapon} step ${aimStep} recoil@${age} ${part} entered the head`);
        }
        const gripOffset = {
          x: sockets.supportGrip.x - sockets.triggerGrip.x,
          y: sockets.supportGrip.y - sockets.triggerGrip.y
        };
        const axial = gripOffset.x * sockets.direction.x + gripOffset.y * sockets.direction.y;
        const normal = gripOffset.x * sockets.normal.x + gripOffset.y * sockets.normal.y;
        assert.ok(Math.abs(normal) <= 2, `${weapon} step ${aimStep} support grip left the barrel by ${normal}`);
        assert.ok(weapon === "pistol" ? axial >= -13 && axial <= -8 : axial >= 14 && axial <= 18,
          `${weapon} step ${aimStep} support grip axial offset became ${axial}`);
      }
      for (let sample = 0; sample <= Anim.CLIPS.gunFire.duration * 100; sample += 1) {
        const age = sample / 100;
        const recoilPose = Anim.sampleClip("gunFire", age, { weapon, aimStep, facing: 1 });
        for (const side of ["L", "R"]) {
          assert.ok(readyBends[side] * elbowBendCross(recoilPose, side) > 0,
            `${weapon} step ${aimStep} recoil@${age} crossed straight elbow ${side}`);
        }
      }

      const reloadDuration = Anim.reloadDuration(weapon);
      const reloadStart = Anim.sampleClip("reload", 0, { weapon, aimStep, facing: 1 });
      const reloadEnd = Anim.sampleClip("reload", reloadDuration - 1, { weapon, aimStep, facing: 1 });
      assertPoseGeometryNear(reloadStart, ready, `${weapon} step ${aimStep} reload entry`);
      assertPoseGeometryNear(reloadEnd, ready, `${weapon} step ${aimStep} reload exit`);
      for (let age = 0; age < reloadDuration; age += 1) {
        const pose = Anim.sampleClip("reload", age, { weapon, aimStep, facing: 1 });
        for (const [start, end] of ARM_SEGMENTS) {
          const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
          assert.ok(length >= 9.9 && length <= 36,
            `${weapon} step ${aimStep} reload@${age} ${start}-${end} became ${length}`);
        }
      }
    }
  }
});

test("every firearm shot shares one committed muzzle, base direction, and seeded spread", () => {
  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    for (const facing of [-1, 1]) {
      for (let aimStep = Sim.GUN_AIM.minStep; aimStep <= Sim.GUN_AIM.maxStep; aimStep += 1) {
        const state = Sim.createState({ seed: 0x530000 + (aimStep + 17) * 7 + (facing > 0 ? 1 : 0), botCount: 1 });
        const shooter = state.fighters[0];
        const target = state.fighters[1];
        Object.assign(shooter, {
          x: 150, prevX: 150, y: 600, prevY: 600,
          vx: 0, vy: 0, grounded: false, prevGrounded: false,
          platformId: null, facing, aimFacing: facing, aimStep: 0, invuln: 0
        });
        Object.assign(target, {
          x: 1880, prevX: 1880, y: 180, prevY: 180,
          vx: 0, vy: 0, grounded: false, prevGrounded: false,
          platformId: null, invuln: 999
        });
        Sim.grantWeapon(shooter, weapon, true);
        shooter.weapon = weapon;
        const resolved = Sim.resolveGunAim(facing, 0, facing, aimStep);
        const actor = neutralHuman(state);
        actor.aimX = resolved.x;
        actor.aimY = resolved.y;
        actor.buttons.attack = true;
        const replay = Sim.deserialize(Sim.serialize(state));
        const replayActor = JSON.parse(JSON.stringify(actor));

        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        Sim.fixedUpdate(replay, { tick: replay.tick, actors: [replayActor] }, Sim.STEP);
        assert.equal(Sim.serialize(replay), Sim.serialize(state), `${weapon} step ${aimStep} replay diverged`);
        assert.deepEqual({
          kind: shooter.attack.kind,
          weapon: shooter.attack.weapon,
          facing: shooter.attack.facing,
          aimStep: shooter.attack.aimStep
        }, { kind: "gun", weapon, facing, aimStep });
        assert.deepEqual(Sim.deserialize(Sim.serialize(state)).fighters[0].attack, shooter.attack);

        const fire = state.events.find((event) => event.type === "fire");
        assert.ok(fire, `${weapon} step ${aimStep} emitted no fire event`);
        assert.equal(shooter.ammo[weapon].mag, Sim.WEAPONS[weapon].mag - 1,
          `${weapon} step ${aimStep} consumed the wrong ammunition`);
        assertPointNear({ x: fire.aimX, y: fire.aimY }, resolved,
          `${weapon} step ${aimStep} event base direction`, 1e-15);
        assert.equal(fire.aimStep, aimStep);
        assert.equal(fire.facing, facing);
        const visible = Anim.gunMuzzle(Anim.poseForFighter(shooter), weapon);
        const visibleWorld = worldPosePoint({ ...shooter, x: 150, y: 600 }, visible.point);
        assertPointNear({ x: fire.x, y: fire.y }, visibleWorld,
          `${weapon} step ${aimStep} event/visible muzzle`);

        const bullets = state.projectiles.filter((projectile) => projectile.ownerId === shooter.id);
        assert.equal(bullets.length, weapon === "shotgun" ? Sim.WEAPONS.shotgun.pellets : 1);
        if (weapon === "shotgun") {
          const groupIds = new Set(bullets.map((bullet) => bullet.groupId));
          assert.equal(groupIds.size, 1, `shotgun step ${aimStep} split one trigger across groups`);
          const group = state.shotGroups[[...groupIds][0]];
          assert.deepEqual(group, {
            cap: Sim.WEAPONS.shotgun.shotCap,
            remaining: Sim.WEAPONS.shotgun.pellets,
            born: state.tick
          });
        }
        for (const bullet of bullets) {
          assertPointNear({ x: bullet.prevX, y: bullet.prevY }, { x: fire.x, y: fire.y },
            `${weapon} step ${aimStep} projectile origin`);
          const magnitude = Math.hypot(bullet.vx, bullet.vy);
          const direction = { x: bullet.vx / magnitude, y: bullet.vy / magnitude };
          const dot = resolved.x * direction.x + resolved.y * direction.y;
          const cross = resolved.x * direction.y - resolved.y * direction.x;
          const relativeSpread = Math.atan2(cross, dot);
          if (weapon === "pistol") {
            assert.ok(Math.abs(relativeSpread) < 1e-15, `pistol step ${aimStep} gained spread`);
          } else if (weapon === "rifle") {
            assert.ok(Math.abs(relativeSpread) <= Sim.WEAPONS.rifle.spread + 1e-12,
              `rifle step ${aimStep} spread escaped its committed base`);
          } else {
            assert.ok(Math.abs(relativeSpread) <= Sim.WEAPONS.shotgun.spread + 0.018 + 1e-12,
              `shotgun step ${aimStep} spread escaped its committed base`);
          }
        }
      }
    }
  }
});

test("gun recoil keeps committed aim until recovery and rifle recommits only on a shot", () => {
  for (const facing of [-1, 1]) {
    for (const aimStep of [-17, -8, 0, 9, 17]) {
      const state = Sim.createState({ seed: 0x540000 + aimStep + facing, botCount: 1 });
      const fighter = state.fighters[0];
      Sim.grantWeapon(fighter, "pistol", true);
      fighter.weapon = "pistol";
      fighter.facing = facing;
      fighter.aimFacing = facing;
      const committed = Sim.resolveGunAim(facing, 0, facing, aimStep);
      const fire = neutralHuman(state);
      fire.aimX = committed.x;
      fire.aimY = committed.y;
      fire.buttons.attack = true;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [fire] }, Sim.STEP);
      const reversed = Sim.deserialize(Sim.serialize(state));
      const steady = Sim.deserialize(Sim.serialize(state));
      const reversedInput = neutralHuman(reversed);
      reversedInput.aimX = -facing;
      reversedInput.aimY = -committed.y;
      const steadyInput = neutralHuman(steady);
      steadyInput.aimX = committed.x;
      steadyInput.aimY = committed.y;
      const replay = Sim.deserialize(Sim.serialize(reversed));

      while (reversed.fighters[0].attack) {
        Sim.fixedUpdate(reversed, { tick: reversed.tick, actors: [reversedInput] }, Sim.STEP);
        Sim.fixedUpdate(replay, { tick: replay.tick, actors: [JSON.parse(JSON.stringify(reversedInput))] }, Sim.STEP);
        Sim.fixedUpdate(steady, { tick: steady.tick, actors: [steadyInput] }, Sim.STEP);
        assert.equal(Sim.serialize(replay), Sim.serialize(reversed), "JSON replay changed committed recoil");
        const reversedFighter = reversed.fighters[0];
        const steadyFighter = steady.fighters[0];
        if (!reversedFighter.attack) break;
        assert.equal(reversedFighter.attack.aimStep, aimStep);
        assert.equal(reversedFighter.attack.facing, facing);
        assert.equal(reversedFighter.facing, facing);
        assert.deepEqual(poseGeometry(Anim.poseForFighter(reversedFighter)),
          poseGeometry(Anim.poseForFighter(steadyFighter)),
          `pistol ${facing}/${aimStep} live aim redirected recoil`);
      }
      assert.equal(reversed.fighters[0].facing, -facing, "live aim was not accepted after recoil");
      assert.notDeepEqual(poseGeometry(Anim.poseForFighter(reversed.fighters[0])),
        poseGeometry(Anim.poseForFighter(steady.fighters[0])), "post-recovery aim stayed latched");
    }
  }

  const rifleState = Sim.createState({ seed: 0x54f1e, botCount: 1 });
  const rifle = rifleState.fighters[0];
  Sim.grantWeapon(rifle, "rifle", true);
  rifle.weapon = "rifle";
  const held = neutralHuman(rifleState);
  held.buttons.attack = true;
  held.aimX = 1;
  held.aimY = 0;
  Sim.fixedUpdate(rifleState, { tick: rifleState.tick, actors: [held] }, Sim.STEP);
  assert.deepEqual({ facing: rifle.attack.facing, aimStep: rifle.attack.aimStep }, { facing: 1, aimStep: 0 });
  const next = Sim.resolveGunAim(-1, 0, -1, -17);
  held.aimX = next.x;
  held.aimY = next.y;
  let secondShot = null;
  for (let tick = 0; tick < 10 && !secondShot; tick += 1) {
    Sim.fixedUpdate(rifleState, { tick: rifleState.tick, actors: [held] }, Sim.STEP);
    secondShot = rifleState.events.find((event) => event.type === "fire") || null;
    if (!secondShot) assert.deepEqual({ facing: rifle.attack.facing, aimStep: rifle.attack.aimStep },
      { facing: 1, aimStep: 0 }, "rifle recommitted without firing");
  }
  assert.ok(secondShot, "held rifle never fired its next legal shot");
  assert.deepEqual({ facing: rifle.attack.facing, aimStep: rifle.attack.aimStep }, { facing: -1, aimStep: -17 });
});

test("grenade release follows continuous committed aim from hand path to projectile", () => {
  const grenadeArmClearance = 23.5;
  for (const facing of [-1, 1]) {
    for (let degrees = -90; degrees <= 90; degrees += 3) {
      const radians = degrees * Math.PI / 180;
      const aim = { x: Math.cos(radians) * facing, y: Math.sin(radians) };
      for (let age = 13; age <= 18; age += 0.25) {
        const pose = Anim.sampleClip("grenadeThrow", age, {
          weapon: "grenade", aimX: aim.x, aimY: aim.y, facing
        });
        for (const [start, end] of ARM_SEGMENTS) {
          const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
          assert.ok(length >= 9.9 && length <= 36,
            `grenade ${facing}/${degrees}@${age} ${start}-${end} became ${length}`);
          assert.ok(pointSegmentDistance(pose.head, pose[start], pose[end]) >= grenadeArmClearance,
            `grenade ${facing}/${degrees}@${age} ${start}-${end} entered the rendered head`);
        }
      }
    }
  }

  // The facing hysteresis permits a small backward component around vertical.
  // Exercise those authoritative seam inputs after the legacy stored-Y clamp.
  for (const priorFacing of [-1, 1]) {
    for (const rawDegrees of [-100, -96.8, -91, -90, -89.9, -45, 45, 89.9, 90, 91, 96.8, 100]) {
      const radians = rawDegrees * Math.PI / 180;
      const rawAim = { x: Math.cos(radians), y: Math.sin(radians) };
      const facing = Sim.resolveGunAim(rawAim.x, rawAim.y, priorFacing).facing;
      const storedY = Math.max(-0.82, Math.min(0.82, rawAim.y));
      const storedLength = Math.hypot(rawAim.x, storedY);
      const storedAim = { x: rawAim.x / storedLength, y: storedY / storedLength };
      for (let sample = 0; sample <= 100; sample += 1) {
        const age = 13 + sample * 0.05;
        const pose = Anim.sampleClip("grenadeThrow", age, {
          weapon: "grenade", aimX: storedAim.x, aimY: storedAim.y, facing
        });
        for (const [start, end] of ARM_SEGMENTS) {
          assert.ok(pointSegmentDistance(pose.head, pose[start], pose[end]) >= grenadeArmClearance,
            `grenade seam ${priorFacing}/${rawDegrees}@${age} ${start}-${end} lost clearance`);
        }
      }
    }
  }

  for (const facing of [-1, 1]) {
    for (const degrees of [-90, -55, -20, 0, 35, 70, 90]) {
      const radians = degrees * Math.PI / 180;
      const aim = { x: Math.cos(radians) * facing, y: Math.sin(radians) };
      const launch = Sim.grenadeLaunchDirection(aim.x, aim.y, facing);
      const pose15 = Anim.sampleClip("grenadeThrow", 15, {
        weapon: "grenade", aimX: aim.x, aimY: aim.y, facing
      });
      const pose16 = Anim.sampleClip("grenadeThrow", 16, {
        weapon: "grenade", aimX: aim.x, aimY: aim.y, facing
      });
      const handTravel = {
        x: pose16.wristR.x - pose15.wristR.x,
        y: pose16.wristR.y - pose15.wristR.y
      };
      const handLength = Math.hypot(handTravel.x, handTravel.y);
      assert.ok(handLength > 8, `grenade ${facing}/${degrees} release path was unreadable`);
      assert.ok(handTravel.x / handLength * launch.x + handTravel.y / handLength * launch.y > 1 - 1e-12,
        `grenade ${facing}/${degrees} hand path disagreed with launch`);

      const state = Sim.createState({ seed: 0x550000 + degrees + facing, botCount: 1 });
      const fighter = state.fighters[0];
      Sim.grantWeapon(fighter, "grenade", true);
      fighter.weapon = "grenade";
      fighter.facing = facing;
      fighter.aimFacing = facing;
      fighter.vx = 140 * facing;
      const actor = neutralHuman(state);
      actor.moveX = facing;
      actor.aimX = aim.x;
      actor.aimY = aim.y;
      actor.buttons.attack = true;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      actor.buttons.attack = false;
      while (fighter.attack.age < Sim.WEAPONS.grenade.releaseAge - 1) {
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      }
      const releasePose = Anim.sampleClip("grenadeThrow", Sim.WEAPONS.grenade.releaseAge, {
        weapon: "grenade", aimX: fighter.attack.aimX, aimY: fighter.attack.aimY, facing: fighter.attack.facing
      });
      const expectedOrigin = worldPosePoint(fighter, Anim.grenadeReleaseSocket(releasePose).center);
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const event = state.events.find((candidate) => candidate.type === "grenadeThrow");
      const grenade = state.grenades[0];
      assert.ok(event && grenade, `grenade ${facing}/${degrees} did not release`);
      assert.notEqual(fighter.x, fighter.prevX, `grenade ${facing}/${degrees} release fixture did not move`);
      assertPointNear({ x: event.x, y: event.y }, expectedOrigin,
        `grenade ${facing}/${degrees} event/release socket`);
      assertPointNear({ x: event.x, y: event.y }, worldPosePoint({
        ...fighter, x: fighter.prevX, y: fighter.prevY
      }, Anim.grenadeReleaseSocket(releasePose).center),
      `grenade ${facing}/${degrees} event/render-alpha-zero hand`);
      assertPointNear({ x: grenade.prevX, y: grenade.prevY }, expectedOrigin,
        `grenade ${facing}/${degrees} projectile/release socket`);
      assertPointNear({ x: event.aimX, y: event.aimY },
        Sim.grenadeLaunchDirection(fighter.attack.aimX, fighter.attack.aimY, fighter.attack.facing),
        `grenade ${facing}/${degrees} launch direction`, 1e-15);
    }
  }
});

test("authored poses stay finite, mirrored, serializable, and anatomically bounded", () => {
  const clipSpecs = [
    ["idle", Anim.CLIPS.idle.duration, { weapon: "unarmed" }],
    ["run", Anim.CLIPS.run.duration, { weapon: "unarmed" }],
    ["jump", Anim.CLIPS.jump.duration, { weapon: "unarmed" }],
    ["fall", Anim.CLIPS.fall.duration, { weapon: "unarmed" }],
    ["land", Anim.CLIPS.land.duration, { weapon: "unarmed" }],
    ["unarmed", Anim.CLIPS.unarmed.duration, { weapon: "unarmed" }],
    ["swordReady", Anim.CLIPS.swordReady.duration, { weapon: "sword" }],
    ["swordAttack", Anim.CLIPS.swordAttack.duration, { weapon: "sword" }],
    ["grenadeThrow", Anim.CLIPS.grenadeThrow.duration, { weapon: "grenade" }],
    ["hit", Anim.CLIPS.hit.duration, { weapon: "unarmed" }],
    ["defeat", Anim.CLIPS.defeat.duration, { weapon: "unarmed" }],
    ["respawn", Anim.CLIPS.respawn.duration, { weapon: "unarmed" }]
  ];
  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    for (const aimBand of ["high", "level", "low"]) {
      clipSpecs.push(["gunAim", 0, { weapon, aimBand }]);
      clipSpecs.push(["gunFire", Anim.CLIPS.gunFire.duration, { weapon, aimBand }]);
      clipSpecs.push(["reload", Anim.reloadDuration(weapon) - 1, { weapon, aimBand }]);
    }
  }

  for (const [clip, duration, options] of clipSpecs) {
    for (let age = 0; age <= duration; age += 0.25) {
      const right = Anim.sampleClip(clip, age, { ...options, facing: 1 });
      const repeated = Anim.sampleClip(clip, age, { ...options, facing: 1 });
      const left = Anim.sampleClip(clip, age, { ...options, facing: -1 });
      assert.equal(JSON.stringify(right), JSON.stringify(repeated), `${clip} is not deterministic at ${age}`);
      assert.doesNotThrow(() => JSON.parse(JSON.stringify(right)), `${clip} is not serializable at ${age}`);
      assert.ok(right.alpha >= 0 && right.alpha <= 1, `${clip} alpha escaped [0,1] at ${age}`);
      assert.equal(right.scaleX, 1, `${clip} changed fighter width at ${age}`);
      assert.equal(right.scaleY, 1, `${clip} changed fighter height at ${age}`);

      for (const key of [...Anim.POINTS, "torsoTop"]) {
        assert.ok(Number.isFinite(right[key].x) && Number.isFinite(right[key].y), `${clip}.${key} is not finite at ${age}`);
        assert.ok(Math.abs(left[key].x + right[key].x) < 1e-9, `${clip}.${key}.x did not mirror at ${age}`);
        assert.ok(Math.abs(left[key].y - right[key].y) < 1e-9, `${clip}.${key}.y changed while mirroring at ${age}`);
      }

      const torsoContact = Math.hypot(
        right.torsoTop.x - right.head.x,
        right.torsoTop.y - right.head.y
      );
      assert.ok(torsoContact >= right.headRadius - 2 && torsoContact <= right.headRadius - 1,
        `${clip} torso missed the lower head edge at ${age}`);
      const directionLength = Math.hypot(right.weaponDir.x, right.weaponDir.y);
      assert.ok(Math.abs(directionLength - 1) < 1e-9, `${clip} weapon direction is not normalized at ${age}`);
      assert.ok(Math.abs(left.weaponDir.x + right.weaponDir.x) < 1e-9,
        `${clip} weapon direction x did not mirror at ${age}`);
      assert.ok(Math.abs(left.weaponDir.y - right.weaponDir.y) < 1e-9,
        `${clip} weapon direction y changed while mirroring at ${age}`);

      for (const [start, end] of ARM_SEGMENTS) {
        const length = Math.hypot(right[start].x - right[end].x, right[start].y - right[end].y);
        assert.ok(length >= 9.9, `${clip} collapsed ${start}-${end} to ${length} at ${age}`);
        assert.ok(length <= 36, `${clip} stretched ${start}-${end} to ${length} at ${age}`);
      }
      for (const [start, end] of LEG_SEGMENTS) {
        const length = Math.hypot(right[start].x - right[end].x, right[start].y - right[end].y);
        assert.ok(length >= 15, `${clip} collapsed ${start}-${end} to ${length} at ${age}`);
        assert.ok(length <= 40, `${clip} stretched ${start}-${end} to ${length} at ${age}`);
      }
    }
  }

  const idle = Anim.sampleClip("idle", 0, { weapon: "unarmed" });
  const verticals = Anim.POINTS.map((key) => idle[key].y)
    .concat([idle.head.y - idle.headRadius, idle.head.y + idle.headRadius]);
  const authoredHeight = Math.max(...verticals) - Math.min(...verticals);
  const state = Sim.createState({ seed: 0x3a3a, botCount: 1 });
  assert.equal(authoredHeight, 145);
  assert.equal(state.fighters[0].drawScale, 1.18);
  const viewportShare = authoredHeight * state.fighters[0].drawScale / 1080;
  assert.ok(viewportShare >= 0.14 && viewportShare <= 0.16);
});

test("runtime weapon composition preserves locomotion, joints, and authoritative sockets", () => {
  const fixtures = [
    { kind: "idle", age: 0, grounded: true, speed: 0, vy: 0 },
    { kind: "run", age: 0, grounded: true, speed: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 8, grounded: true, speed: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 16, grounded: true, speed: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 24, grounded: true, speed: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 9, grounded: false, speed: 220, vy: -400 },
    { kind: "fall", age: 12, grounded: false, speed: 220, vy: 300 },
    { kind: "land", age: 2, grounded: true, speed: 0, vy: 0 }
  ];
  const lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];

  function fighterFor(fixture, facing, weapon, aimY) {
    return {
      facing,
      weapon,
      aimY,
      grounded: fixture.grounded,
      vx: fixture.speed * facing,
      vy: fixture.vy,
      drawScale: 1.18,
      animTick: fixture.age,
      locomotion: { kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age },
      life: { kind: "alive", age: 0 },
      attack: null,
      action: fixture.kind,
      actionAge: fixture.age,
      reload: 0
    };
  }

  function assertComposedBounds(pose, label) {
    assert.doesNotThrow(() => JSON.parse(JSON.stringify(pose)), `${label} is not serializable`);
    for (const key of [...Anim.POINTS, "torsoTop"]) {
      assert.ok(Number.isFinite(pose[key].x) && Number.isFinite(pose[key].y), `${label}.${key} is not finite`);
    }
    for (const [start, end] of ARM_SEGMENTS) {
      const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
      assert.ok(length >= 9.9 && length <= 36, `${label} ${start}-${end} is ${length}`);
    }
    for (const [start, end] of LEG_SEGMENTS) {
      const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
      assert.ok(length >= 15 && length <= 40, `${label} ${start}-${end} is ${length}`);
    }
  }

  for (const fixture of fixtures) {
    for (const weapon of ["sword", "pistol", "shotgun", "rifle", "grenade"]) {
      for (const aimY of [-1, 0, 1]) {
        const rightFighter = fighterFor(fixture, 1, weapon, aimY);
        const leftFighter = fighterFor(fixture, -1, weapon, aimY);
        const rightReady = Anim.poseForFighter(rightFighter);
        const leftReady = Anim.poseForFighter(leftFighter);
        const label = `${fixture.kind}@${fixture.age} ${weapon} aim ${aimY}`;
        assertComposedBounds(rightReady, label);
        for (const key of [...Anim.POINTS, "torsoTop"]) {
          assert.ok(Math.abs(leftReady[key].x + rightReady[key].x) < 1e-9, `${label}.${key}.x did not mirror`);
          assert.ok(Math.abs(leftReady[key].y - rightReady[key].y) < 1e-9, `${label}.${key}.y did not mirror`);
        }
        assert.ok(rightReady.upperPhase, `${label} lost its weapon phase metadata`);

        if (!["pistol", "shotgun", "rifle"].includes(weapon)) continue;
        const aimStep = Sim.resolveGunAim(1, aimY, 1).step;
        const fireStart = Anim.poseForFighter({
          ...rightFighter,
          attack: { kind: "gun", weapon, age: 0, facing: 1, aimStep },
          action: "fire",
          actionAge: 0
        });
        const reloadStart = Anim.poseForFighter({
          ...rightFighter,
          action: "reload",
          actionAge: 0,
          reload: Anim.reloadDuration(weapon)
        });
        assert.deepEqual(poseGeometry(fireStart), poseGeometry(rightReady), `${label} popped on fire press`);
        assert.deepEqual(poseGeometry(reloadStart), poseGeometry(rightReady), `${label} popped on reload press`);

        for (const [action, duration, increment] of [
          ["fire", Anim.CLIPS.gunFire.duration, 0.25],
          ["reload", Anim.reloadDuration(weapon) - 1, 0.5]
        ]) {
          let previous = null;
          for (let age = 0; age <= duration; age += increment) {
            const actionFighter = action === "fire"
              ? {
                  ...rightFighter,
                  attack: { kind: "gun", weapon, age, facing: 1, aimStep },
                  action: "fire",
                  actionAge: age
                }
              : {
                  ...rightFighter,
                  action: "reload",
                  actionAge: age,
                  reload: Math.max(1, Anim.reloadDuration(weapon) - age)
                };
            const pose = Anim.poseForFighter(actionFighter);
            const actionLabel = `${label} ${action}@${age}`;
            assertComposedBounds(pose, actionLabel);
            for (const key of lowerPoints) {
              assert.deepEqual(pose[key], rightReady[key], `${actionLabel} replaced locomotion ${key}`);
            }
            if (action === "fire") {
              const direct = Anim.sampleClip("gunFire", age, { weapon, aimStep, facing: 1 });
              const visible = Anim.gunMuzzle(pose, weapon);
              const authoritative = Anim.gunMuzzle(direct, weapon);
              assertPointNear(visible.point, authoritative.point, `${actionLabel} moved the muzzle`);
              assertPointNear(visible.direction, authoritative.direction, `${actionLabel} changed barrel direction`);
            }
            if (previous) {
              for (const key of ["elbowL", "elbowR"]) {
                const distance = Math.hypot(pose[key].x - previous[key].x, pose[key].y - previous[key].y);
                assert.ok(distance <= 3.5 * (increment / 0.25),
                  `${actionLabel} popped ${key} by ${distance} in ${increment} tick`);
              }
            }
            previous = pose;
          }
        }
      }
    }
  }
});

test("committed actions keep live feet, exact contact geometry, and seamless boundaries", () => {
  const fixtures = [
    { kind: "idle", age: 0, grounded: true, vx: 0, vy: 0 },
    { kind: "run", age: 0, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 8, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 16, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 24, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 9, grounded: false, vx: 220, vy: -400 },
    { kind: "fall", age: 12, grounded: false, vx: 220, vy: 300 },
    { kind: "land", age: 2, grounded: true, vx: 0, vy: 0 }
  ];
  const actions = [
    { weapon: "unarmed", action: "unarmed", clip: "unarmed", attackKind: "melee" },
    { weapon: "sword", action: "sword", clip: "swordAttack", attackKind: "melee" },
    { weapon: "grenade", action: "grenade", clip: "grenadeThrow", attackKind: "grenade" }
  ];
  const lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];

  for (const fixture of fixtures) {
    for (const spec of actions) {
      const animationRule = Anim.CLIPS[spec.clip];
      const simulationRule = Sim.WEAPONS[spec.weapon];
      assert.equal(animationRule.duration, simulationRule.duration, `${spec.weapon} duration diverged`);
      assert.equal(animationRule.activeStart, simulationRule.activeStart ?? simulationRule.releaseAge,
        `${spec.weapon} active start diverged`);
      const duration = animationRule.duration;
      for (const facing of [-1, 1]) {
        const base = {
          facing,
          weapon: spec.weapon,
          aimY: 0,
          grounded: fixture.grounded,
          vx: fixture.vx * facing,
          vy: fixture.vy,
          drawScale: 1.18,
          animTick: fixture.age,
          locomotion: { kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age },
          life: { kind: "alive", age: 0 },
          attack: null,
          action: fixture.kind,
          actionAge: fixture.age,
          reload: 0
        };
        const ready = Anim.poseForFighter(base);
        const actionPose = (age) => Anim.poseForFighter({
          ...base,
          attack: { kind: spec.attackKind, weapon: spec.weapon, age, duration, facing },
          action: spec.action,
          actionAge: age
        });
        const label = `${fixture.kind}@${fixture.age} ${spec.weapon} facing ${facing}`;

        assertPoseGeometryNear(actionPose(0), ready, `${label} command seam`);
        assertPoseGeometryNear(actionPose(duration - 1), ready, `${label} recovery seam`);
        assert.equal(actionPose(animationRule.recoveryStart).actionWeight, 1, `${label} erased authored follow-through`);

        let previous = ready;
        for (let age = 0; age < duration; age += 0.25) {
          const composed = actionPose(age);
          assert.doesNotThrow(() => JSON.parse(JSON.stringify(composed)), `${label} was not serializable at ${age}`);
          for (const key of lowerPoints) {
            assertPointNear(composed[key], ready[key], `${label} ${key} left live locomotion at age ${age}`);
          }
          for (const [start, end] of ARM_SEGMENTS) {
            const length = Math.hypot(composed[start].x - composed[end].x, composed[start].y - composed[end].y);
            assert.ok(length >= 9.9 && length <= 36, `${label} ${start}-${end} collapsed to ${length} at ${age}`);
          }
          for (const key of ["head", "shoulder", "elbowL", "elbowR", "wristL", "wristR"]) {
            const distance = Math.hypot(composed[key].x - previous[key].x, composed[key].y - previous[key].y);
            assert.ok(distance <= 12, `${label} ${key} popped ${distance}px at ${age}`);
          }
          previous = composed;
        }

        for (let age = animationRule.activeStart; age <= animationRule.activeEnd; age += 0.25) {
          const composed = actionPose(age);
          const direct = Anim.sampleClip(spec.clip, age, { weapon: spec.weapon, facing });
          assert.equal(composed.actionWeight, 1, `${label} was not fully authored at active age ${age}`);
          if (spec.weapon === "sword") {
            const visible = Anim.swordBlade(composed);
            const authoritative = Anim.swordBlade(direct);
            assert.deepEqual(visible.bladeStart, authoritative.bladeStart, `${label} moved sword start at ${age}`);
            assert.deepEqual(visible.bladeEnd, authoritative.bladeEnd, `${label} moved sword end at ${age}`);
            assert.deepEqual(visible.direction, authoritative.direction, `${label} changed sword direction at ${age}`);
          } else if (spec.weapon === "unarmed") {
            assert.deepEqual(Anim.unarmedStrike(composed), Anim.unarmedStrike(direct),
              `${label} changed unarmed contact at ${age}`);
          } else {
            assert.deepEqual(composed.wristR, direct.wristR, `${label} moved grenade grip at ${age}`);
          }
        }
      }
    }
  }
});

test("sword and grenade actions keep every rendered arm outside the head", () => {
  const drawScale = 1.18;
  const requiredClearance = (16 * drawScale + 3.5 / 2 + 10 / 2) / drawScale;
  const swordClearance = {
    blade: (16 * drawScale + 3.5 / 2 + 13 / 2) / drawScale,
    handle: (16 * drawScale + 3.5 / 2 + 7 / 2) / drawScale,
    guard: (16 * drawScale + 3.5 / 2 + 3 / 2) / drawScale
  };
  const fixtures = [
    { kind: "idle", age: 0, grounded: true, vx: 0, vy: 0 },
    { kind: "run", age: 8, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 8, grounded: false, vx: 180, vy: -300 },
    { kind: "fall", age: 12, grounded: false, vx: 180, vy: 300 },
    { kind: "land", age: 2, grounded: true, vx: 0, vy: 0 }
  ];
  const assertClear = (pose, label) => {
    for (const [start, end] of ARM_SEGMENTS) {
      const clearance = pointSegmentDistance(pose.head, pose[start], pose[end]);
      assert.ok(clearance >= requiredClearance,
        `${label} ${start}-${end} entered the rendered head at ${clearance}`);
    }
    if (pose.weapon === "sword") {
      const blade = Anim.swordBlade(pose);
      for (const [part, start, end] of [
        ["blade", blade.bladeStart, blade.bladeEnd],
        ["handle", blade.handleStart, blade.handleEnd],
        ["guard", blade.guardA, blade.guardB]
      ]) {
        const clearance = pointSegmentDistance(pose.head, start, end);
        assert.ok(clearance >= swordClearance[part],
          `${label} sword ${part} entered the rendered head at ${clearance}`);
      }
    }
  };

  for (const [clip, weapon, duration] of [
    ["swordAttack", "sword", Anim.CLIPS.swordAttack.duration],
    ["grenadeThrow", "grenade", Anim.CLIPS.grenadeThrow.duration]
  ]) {
    for (let age = 0; age <= duration; age += 0.01) {
      assertClear(Anim.sampleClip(clip, age, { weapon }), `${clip}@${age.toFixed(2)}`);
    }
    for (const fixture of fixtures) {
      for (const facing of [-1, 1]) {
        for (let age = 0; age <= duration; age += 0.05) {
          const pose = Anim.poseForFighter({
            facing,
            weapon,
            aimY: 0,
            grounded: fixture.grounded,
            vx: fixture.vx * facing,
            vy: fixture.vy,
            animTick: fixture.age,
            locomotion: { kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age },
            life: { kind: "alive", age: 0 },
            attack: {
              kind: weapon === "sword" ? "melee" : "grenade",
              weapon, age, duration, released: false, hitIds: []
            },
            action: weapon,
            actionAge: age,
            reload: 0
          });
          assertClear(pose, `${fixture.kind} ${weapon} facing ${facing} @${age.toFixed(2)}`);
        }
      }
    }
  }
});

test("composed high aim keeps recoil arms clear of the head", () => {
  const fixtures = [
    { kind: "run", age: 0, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 8, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 16, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 24, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 9, grounded: false, vx: 220, vy: -400 },
    { kind: "fall", age: 12, grounded: false, vx: 220, vy: 300 },
    { kind: "land", age: 2, grounded: true, vx: 0, vy: 0 }
  ];

  function assertClear(pose, label) {
    for (const side of ["L", "R"]) {
      const wrist = pose[`wrist${side}`];
      const elbow = pose[`elbow${side}`];
      const forearmClearance = pointSegmentDistance(pose.head, elbow, wrist);
      const renderedClearance = forearmClearance * 1.18;
      const requiredClearance = pose.headRadius * 1.18 + 3.5 / 2 + 10 / 2;
      assert.ok(renderedClearance >= requiredClearance - 1e-9,
        `${label} ${side} forearm clearance ${renderedClearance} was below ${requiredClearance}`);
    }
  }

  for (const fixture of fixtures) {
    for (const weapon of ["pistol", "shotgun", "rifle"]) {
      for (const facing of [-1, 1]) {
        const base = {
          facing,
          weapon,
          aimX: facing,
          aimY: -1,
          aimFacing: facing,
          aimStep: -17,
          grounded: fixture.grounded,
          vx: fixture.vx * facing,
          vy: fixture.vy,
          drawScale: 1.18,
          animTick: fixture.age,
          locomotion: { kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age },
          life: { kind: "alive", age: 0 },
          attack: null,
          action: fixture.kind,
          actionAge: fixture.age,
          reload: 0
        };
        const label = `${fixture.kind}@${fixture.age} ${weapon} facing ${facing}`;
        assertClear(Anim.poseForFighter(base), `${label} ready`);
        for (let age = 0; age <= Anim.CLIPS.gunFire.duration; age += 0.25) {
          assertClear(Anim.poseForFighter({
            ...base,
            attack: {
              kind: "gun", weapon, age, duration: Anim.CLIPS.gunFire.duration,
              facing, aimStep: -17
            },
            action: "fire",
            actionAge: age
          }), `${label} fire@${age}`);
        }
        const reloadLength = Anim.reloadDuration(weapon);
        for (let age = 0; age < reloadLength; age += 0.5) {
          assertClear(Anim.poseForFighter({
            ...base,
            action: "reload",
            actionAge: age,
            reload: reloadLength - age
          }), `${label} reload@${age}`);
        }
      }
    }
  }
});

test("respawn visibility never replaces actionable weapon geometry", () => {
  const state = Sim.createState({ seed: 0x3a3a, botCount: 1 });
  const fighter = state.fighters[0];
  fighter.life = { kind: "respawn", age: 8 };
  fighter.respawnVisual = 16;
  fighter.aimX = 0.88;
  fighter.aimY = -0.48;
  fighter.aimFacing = 1;
  fighter.aimStep = 17;
  fighter.facing = 1;

  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
    fighter.attack = {
      kind: "gun", weapon, age: 2, duration: 12,
      facing: 1, aimStep: -17, hitIds: []
    };
    fighter.action = "fire";
    fighter.actionAge = 2;
    const respawnMuzzle = Sim.gunMuzzle(fighter);
    const respawnDirection = Sim.gunDirection(fighter);
    const respawnPose = Anim.poseForFighter(fighter);
    fighter.life = { kind: "alive", age: 0 };
    assert.deepEqual(respawnMuzzle, Sim.gunMuzzle(fighter), `${weapon} respawn changed its muzzle`);
    assert.deepEqual(respawnDirection, Sim.gunDirection(fighter), `${weapon} respawn changed its direction`);
    assert.ok(respawnPose.alpha < 1 && respawnPose.alpha >= 0.7, `${weapon} lost readable respawn alpha`);
    fighter.life = { kind: "respawn", age: 8 };
  }

  for (const [weapon, age, segment] of [
    ["unarmed", 8, Sim.unarmedSegment],
    ["sword", 13, Sim.swordSegment]
  ]) {
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
    fighter.attack = { kind: "melee", weapon, age, duration: Sim.WEAPONS[weapon].duration, facing: 1, hitIds: [] };
    fighter.action = weapon;
    fighter.actionAge = age;
    const duringRespawn = segment(fighter);
    fighter.life = { kind: "alive", age: 0 };
    assert.deepEqual(duringRespawn, segment(fighter), `${weapon} respawn changed active contact`);
    fighter.life = { kind: "respawn", age: 8 };
  }
});

test("released grenades never leave a duplicate presentation in the hand", () => {
  const state = Sim.createState({ seed: 0x3a3b, botCount: 1 });
  const fighter = state.fighters[0];
  Sim.grantWeapon(fighter, "grenade", true);
  fighter.weapon = "grenade";
  fighter.attack = {
    kind: "grenade", weapon: "grenade", age: 16, duration: Sim.WEAPONS.grenade.duration,
    facing: 1, aimX: 1, aimY: 0, released: false, hitIds: []
  };
  fighter.action = "grenade";
  fighter.actionAge = 16;
  assert.ok(Anim.grenadeSocket(Anim.poseForFighter(fighter)), "grenade vanished before authoritative release");

  fighter.attack.released = true;
  assert.equal(Anim.grenadeSocket(Anim.poseForFighter(fighter)), null,
    "released grenade remained in the hand during its throw");
  fighter.hitstun = Sim.WEAPONS.rifle.hitstun;
  fighter.action = "hit";
  fighter.actionAge = 1;
  assert.equal(Anim.grenadeSocket(Anim.poseForFighter(fighter)), null,
    "released grenade reappeared when hit presentation took priority");

  const lastState = Sim.createState({ seed: 0x3a3c, botCount: 1 });
  const lastFighter = lastState.fighters[0];
  Sim.grantWeapon(lastFighter, "grenade", true);
  lastFighter.weapon = "grenade";
  lastFighter.ammo.grenade.count = 1;
  const actor = neutralHuman(lastState);
  actor.buttons.attack = true;
  Sim.fixedUpdate(lastState, { tick: lastState.tick, actors: [actor] }, Sim.STEP);
  actor.buttons.attack = false;
  assert.ok(Anim.grenadeSocket(Anim.poseForFighter(lastFighter)),
    "last grenade vanished during its pre-release windup");
  for (let tick = 0; tick <= Sim.WEAPONS.grenade.duration + 1; tick += 1) {
    Sim.fixedUpdate(lastState, { tick: lastState.tick, actors: [actor] }, Sim.STEP);
    const held = Anim.grenadeSocket(Anim.poseForFighter(lastFighter));
    if (lastFighter.ammo.grenade.count <= 0) {
      assert.equal(held, null, `last grenade reappeared at attack tick ${tick}`);
    }
  }
  assert.equal(lastFighter.attack, null, "grenade attack did not complete");
  assert.equal(lastFighter.ammo.grenade.count, 0);
  assert.ok(lastState.grenades.length > 0, "released last grenade left no projectile");
  assert.equal(Anim.grenadeSocket(Anim.poseForFighter(lastFighter)), null,
    "empty grenade inventory drew a new ready grenade");
});

test("reload animation and ammunition finish on the same fixed step", () => {
  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    const state = Sim.createState({ seed: 0x3a3a, botCount: 1 });
    const fighter = state.fighters[0];
    const data = Sim.WEAPONS[weapon];
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
    fighter.ammo[weapon].mag = 0;
    fighter.ammo[weapon].reserve = data.mag + 2;
    const actor = neutralHuman(state);
    actor.buttons.reload = true;
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    actor.buttons.reload = false;

    assert.equal(fighter.reload, data.reload, `${weapon} reload started with wrong timer`);
    assert.equal(fighter.actionAge, 0, `${weapon} reload skipped its entry pose`);
    assert.equal(fighter.ammo[weapon].mag, 0, `${weapon} loaded ammunition on press`);
    assert.equal(state.events.filter((event) => event.type === "reloadStart").length, 1);
    const startEvent = state.events.find((event) => event.type === "reloadStart");

    for (let elapsed = 1; elapsed < data.reload; elapsed += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      assert.equal(fighter.reload, data.reload - elapsed, `${weapon} timer diverged at ${elapsed}`);
      assert.equal(fighter.action, "reload", `${weapon} left reload early at ${elapsed}`);
      assert.equal(fighter.actionAge, elapsed, `${weapon} pose age diverged at ${elapsed}`);
      assert.equal(Anim.poseForFighter(fighter).clipTime, elapsed, `${weapon} skipped visible pose ${elapsed}`);
      assert.equal(fighter.ammo[weapon].mag, 0, `${weapon} finished early at ${elapsed}`);
      assert.equal(state.events.some((event) => event.type === "reload"), false,
        `${weapon} emitted reload early at ${elapsed}`);
    }

    assert.equal(fighter.actionAge, data.reload - 1);
    assert.deepEqual(
      poseGeometry(Anim.poseForFighter(fighter)),
      poseGeometry(Anim.poseForFighter({ ...fighter, action: fighter.locomotion.kind, actionAge: fighter.locomotion.age, reload: 0 })),
      `${weapon} final reload pose did not meet ready`
    );
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    assert.equal(fighter.reload, 0, `${weapon} did not finish on step ${data.reload}`);
    assert.notEqual(fighter.action, "reload", `${weapon} retained reload action after completion`);
    assert.equal(fighter.ammo[weapon].mag, data.mag, `${weapon} loaded the wrong amount`);
    assert.equal(fighter.ammo[weapon].reserve, 2, `${weapon} reserve did not move atomically`);
    assert.equal(state.events.filter((event) => event.type === "reload").length, 1,
      `${weapon} emitted the wrong completion count`);
    const completionEvent = state.events.find((event) => event.type === "reload");
    assert.equal(completionEvent.tick - startEvent.tick, data.reload, `${weapon} completion tick diverged`);
  }
});

test("every simulation hitstun duration traverses one complete readable reaction", () => {
  const hitstunByWeapon = {
    rifle: 4,
    pistol: 7,
    shotgun: 7,
    unarmed: 7,
    sword: 12,
    grenade: 14
  };
  for (const [weapon, duration] of Object.entries(hitstunByWeapon)) {
    assert.equal(Sim.WEAPONS[weapon].hitstun, duration, `${weapon} hitstun changed`);
  }

  for (const [weapon, duration] of [["rifle", 4], ["pistol", 7], ["sword", 12], ["grenade", 14]]) {
    const state = Sim.createState({ seed: 0x3a3a + duration, botCount: 1 });
    const fighter = state.fighters[0];
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
    fighter.attack = null;
    fighter.reload = 0;
    fighter.hitstun = duration;
    fighter.anim = "hit";
    fighter.animTick = 1;
    fighter.action = "hit";
    fighter.actionAge = 1;
    fighter.vx = 0;
    fighter.vy = 0;
    fighter.grounded = true;
    const actor = neutralHuman(state);
    let finalHitPose = null;
    let maxHitHeadDisplacement = 0;

    for (let visibleAge = 1; visibleAge <= duration; visibleAge += 1) {
      const pose = Anim.poseForFighter(fighter);
      const readyPose = Anim.poseForFighter({ ...fighter, hitstun: 0, action: null, attack: null });
      maxHitHeadDisplacement = Math.max(
        maxHitHeadDisplacement,
        Math.hypot(pose.head.x - readyPose.head.x, pose.head.y - readyPose.head.y)
      );
      const expected = 13 * (visibleAge - 1) / Math.max(1, duration - 1);
      assert.equal(fighter.actionAge, visibleAge, `${weapon} action age diverged at ${visibleAge}`);
      assert.ok(Math.abs(pose.clipTime - expected) < 1e-9,
        `${weapon} ${duration}-tick hit sampled ${pose.clipTime} instead of ${expected} at ${visibleAge}`);
      assert.doesNotThrow(() => JSON.parse(JSON.stringify(pose)));
      for (const [start, end] of ARM_SEGMENTS) {
        const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
        assert.ok(length >= 9.9 && length <= 36, `${weapon} hit ${start}-${end} collapsed to ${length}`);
      }
      if (visibleAge === 2) {
        assert.notDeepEqual(
          poseGeometry(pose),
          poseGeometry(readyPose),
          `${weapon} hit reaction was overwritten by its ready stance`
        );
      }
      finalHitPose = pose;
      if (visibleAge < duration) {
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        assert.equal(fighter.hitstun, duration - visibleAge);
        assert.equal(fighter.action, "hit");
      }
    }
    assert.ok(maxHitHeadDisplacement >= 4,
      `${weapon} hit reaction displaced its head only ${maxHitHeadDisplacement}`);
    const readyAtBoundary = Anim.poseForFighter({ ...fighter, hitstun: 0, action: null, attack: null });
    assertPoseGeometryNear(finalHitPose, readyAtBoundary, `${weapon} hit recovery seam`);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    assert.equal(fighter.hitstun, 0, `${weapon} hitstun did not clear`);
    assert.notEqual(fighter.action, "hit", `${weapon} retained hit action`);
    assert.notEqual(Anim.poseForFighter(fighter).clip, "hit", `${weapon} retained hit pose`);
  }
});

test("hit composition preserves every live arm rig across movement and hit durations", () => {
  const fixtures = [
    { kind: "idle", age: 0, grounded: true, vx: 0, vy: 0 },
    { kind: "run", age: 10.4, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 8, grounded: false, vx: 180, vy: -300 },
    { kind: "fall", age: 12, grounded: false, vx: 180, vy: 300 },
    { kind: "land", age: 2, grounded: true, vx: 0, vy: 0 }
  ];
  const lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];

  for (const weapon of ["unarmed", "sword", "pistol", "shotgun", "rifle", "grenade"]) {
    for (const duration of [4, 7, 12, 14]) {
      for (const fixture of fixtures) {
        for (const facing of [-1, 1]) {
          let finalPose = null;
          let finalReady = null;
          let maxHeadDisplacement = 0;
          for (let visibleAge = 1; visibleAge <= duration; visibleAge += 1) {
            const fighter = {
              facing,
              weapon,
              aimY: -0.5,
              grounded: fixture.grounded,
              vx: fixture.vx * facing,
              vy: fixture.vy,
              animTick: fixture.age,
              locomotion: { kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age },
              life: { kind: "alive", age: 0 },
              attack: null,
              action: { kind: "hit", age: visibleAge },
              actionAge: visibleAge,
              hitstun: duration - visibleAge + 1,
              reload: 0
            };
            const pose = Anim.poseForFighter(fighter, 0.5);
            const ready = Anim.poseForFighter({ ...fighter, action: null, hitstun: 0 }, 0.5);
            for (const [start, end] of ARM_SEGMENTS) {
              const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
              assert.ok(length >= 9.9 && length <= 36,
                `${fixture.kind} ${weapon}/${duration} facing ${facing} ${start}-${end} became ${length}`);
            }
            for (const key of lowerPoints) {
              assertPointNear(pose[key], ready[key],
                `${fixture.kind} ${weapon}/${duration} facing ${facing} hit lower ${key}`);
            }
            maxHeadDisplacement = Math.max(maxHeadDisplacement,
              Math.hypot(pose.head.x - ready.head.x, pose.head.y - ready.head.y));
            finalPose = pose;
            finalReady = ready;
          }
          assert.ok(maxHeadDisplacement >= 4,
            `${fixture.kind} ${weapon}/${duration} facing ${facing} hit reaction was unreadable`);
          assertPoseGeometryNear(finalPose, finalReady,
            `${fixture.kind} ${weapon}/${duration} facing ${facing} hit seam`);
        }
      }
    }
  }
});

test("hits preserve live firearm and grenade handling without ghosting released throws", () => {
  const fixtures = [
    { kind: "idle", age: 0, grounded: true, vx: 0, vy: 0 },
    { kind: "run", age: 11, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "jump", age: 7, grounded: false, vx: 180, vy: -280 },
    { kind: "fall", age: 10, grounded: false, vx: 180, vy: 260 },
    { kind: "land", age: 3, grounded: true, vx: 90, vy: 0 }
  ];
  const handling = [
    { weapon: "pistol", duration: 7, attack: { kind: "gun", weapon: "pistol", age: 3, duration: 22, aimStep: -17 }, liveAction: "fire" },
    { weapon: "shotgun", duration: 7, attack: { kind: "gun", weapon: "shotgun", age: 4, duration: 34, aimStep: -17 }, liveAction: "fire" },
    { weapon: "rifle", duration: 4, attack: { kind: "gun", weapon: "rifle", age: 5, duration: 8, aimStep: -17 }, liveAction: "fire" },
    { weapon: "grenade", duration: 14, attack: { kind: "grenade", weapon: "grenade", age: 12, duration: 38, released: false }, liveAction: "grenade" },
    { weapon: "grenade", duration: 14, attack: { kind: "grenade", weapon: "grenade", age: 18, duration: 38, released: true }, liveAction: "grenade" }
  ];
  const lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];

  for (const fixture of fixtures) {
    for (const spec of handling) {
      for (const facing of [-1, 1]) {
        const committedGun = spec.attack.kind === "gun";
        let previous = null;
        let maxHeadDisplacement = 0;
        for (let visibleAge = 1; visibleAge <= spec.duration; visibleAge += 1) {
          const attack = { ...spec.attack, facing, aimX: facing, aimY: -0.5 };
          const fighter = {
            facing,
            weapon: spec.weapon,
            aimX: committedGun ? -facing : facing,
            aimY: committedGun ? 0.5 : -0.5,
            aimFacing: committedGun ? -facing : facing,
            aimStep: committedGun ? 17 : 0,
            grounded: fixture.grounded,
            vx: fixture.vx * facing,
            vy: fixture.vy,
            drawScale: 1.18,
            locomotion: {
              kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age,
              previousKind: fixture.kind, previousAge: fixture.age,
              previousGaitPhase: fixture.age, previousVx: fixture.vx * facing,
              previousTravelSign: facing, previousMoveIntent: fixture.kind === "run",
              previousEntryKind: fixture.kind, previousEntryAge: fixture.age,
              previousTurn: null, travelSign: facing,
              moveIntent: fixture.kind === "run", turn: null, landExit: null
            },
            life: { kind: "alive", age: 0 },
            attack,
            action: { kind: "hit", age: visibleAge },
            actionAge: visibleAge,
            hitstun: spec.duration - visibleAge + 1,
            reload: 0
          };
          const pose = Anim.poseForFighter(fighter, 0.5);
          const live = Anim.poseForFighter({
            ...fighter,
            hitstun: 0,
            action: { kind: spec.liveAction, age: attack.age },
            actionAge: attack.age
          }, 0.5);
          if (committedGun) {
            assert.equal(pose.aimStep, -17, `${spec.weapon} hit lost committed aim`);
            assert.equal(live.aimStep, -17, `${spec.weapon} live recoil lost committed aim`);
          }
          for (const key of lowerPoints) {
            assertPointNear(pose[key], live[key], `${fixture.kind} ${spec.weapon} lower ${key}`);
          }
          for (const [start, end] of ARM_SEGMENTS) {
            assertPointNear(
              { x: pose[end].x - pose[start].x, y: pose[end].y - pose[start].y },
              { x: live[end].x - live[start].x, y: live[end].y - live[start].y },
              `${fixture.kind} ${spec.weapon} live ${start}-${end}`
            );
          }
          maxHeadDisplacement = Math.max(maxHeadDisplacement,
            Math.hypot(pose.head.x - live.head.x, pose.head.y - live.head.y));
          if (attack.released) assert.equal(pose.grenadeVisible, false, "released grenade returned during hit");
          if (previous) assert.ok(maxPosePointDelta(pose, previous) <= 25,
            `${fixture.kind} ${spec.weapon} hit pose popped between visible ages`);
          previous = pose;
          if (visibleAge === spec.duration) {
            assertPoseGeometryNear(pose, live, `${fixture.kind} ${spec.weapon} hit recovery seam`);
          }
        }
        assert.ok(maxHeadDisplacement >= 4, `${fixture.kind} ${spec.weapon} hit reaction was unreadable`);
      }
    }
  }
});

test("defeat blends preserve source poses, limb lengths, and released-grenade state", () => {
  const locomotionFixtures = [
    { kind: "idle", age: 9, grounded: true, vx: 0, vy: 0 },
    { kind: "run", age: 13, grounded: true, vx: Sim.RULES.runSpeed, vy: 0 },
    { kind: "run", age: 5, grounded: true, vx: 86, vy: 0 },
    { kind: "jump", age: 7, grounded: false, vx: 180, vy: -280 },
    { kind: "fall", age: 10, grounded: false, vx: 180, vy: 260 },
    { kind: "land", age: 3, grounded: true, vx: 90, vy: 0 }
  ];
  const sources = [
    { label: "unarmed-ready", weapon: "unarmed", action: null, attack: null, reload: 0 },
    { label: "unarmed-strike", weapon: "unarmed", action: { kind: "unarmed", age: 8 }, attack: { kind: "melee", weapon: "unarmed", age: 8, duration: 30 }, reload: 0 },
    { label: "sword-ready", weapon: "sword", action: null, attack: null, reload: 0 },
    { label: "sword-swing", weapon: "sword", action: { kind: "sword", age: 12 }, attack: { kind: "melee", weapon: "sword", age: 12, duration: 44 }, reload: 0 },
    { label: "pistol-ready", weapon: "pistol", action: null, attack: null, reload: 0 },
    { label: "pistol-fire", weapon: "pistol", action: { kind: "fire", age: 3 }, attack: { kind: "gun", weapon: "pistol", age: 3, duration: 22, aimStep: -17 }, reload: 0 },
    { label: "pistol-reload", weapon: "pistol", action: { kind: "reload", age: 35 }, attack: null, reload: 37 },
    { label: "shotgun-fire", weapon: "shotgun", action: { kind: "fire", age: 4 }, attack: { kind: "gun", weapon: "shotgun", age: 4, duration: 34, aimStep: 7 }, reload: 0 },
    { label: "shotgun-reload", weapon: "shotgun", action: { kind: "reload", age: 44 }, attack: null, reload: 46 },
    { label: "rifle-fire", weapon: "rifle", action: { kind: "fire", age: 5 }, attack: { kind: "gun", weapon: "rifle", age: 5, duration: 8, aimStep: 17 }, reload: 0 },
    { label: "rifle-reload", weapon: "rifle", action: { kind: "reload", age: 47 }, attack: null, reload: 49 },
    { label: "grenade-windup", weapon: "grenade", action: { kind: "grenade", age: 12 }, attack: { kind: "grenade", weapon: "grenade", age: 12, duration: 38, released: false }, reload: 0 },
    { label: "grenade-released", weapon: "grenade", action: { kind: "grenade", age: 18 }, attack: { kind: "grenade", weapon: "grenade", age: 18, duration: 38, released: true }, reload: 0 }
  ];

  for (const fixture of locomotionFixtures) {
    for (const spec of sources) {
      for (const facing of [-1, 1]) {
        const committedGun = spec.attack && spec.attack.kind === "gun";
        const locomotion = {
          kind: fixture.kind, age: fixture.age, gaitPhase: fixture.age,
          previousKind: fixture.kind, previousAge: fixture.age,
          previousGaitPhase: fixture.age, previousVx: fixture.vx * facing,
          previousTravelSign: facing, previousMoveIntent: fixture.kind === "run",
          previousEntryKind: fixture.kind, previousEntryAge: fixture.age,
          previousTurn: null, travelSign: facing,
          moveIntent: fixture.kind === "run", turn: null, landExit: null
        };
        const sourceFighter = {
          facing,
          weapon: spec.weapon,
          aimX: committedGun ? -facing : facing,
          aimY: 0.55,
          aimFacing: committedGun ? -facing : facing,
          aimStep: committedGun ? -17 : 10,
          grounded: fixture.grounded,
          vx: fixture.vx * facing,
          vy: fixture.vy,
          prevVx: fixture.vx * facing,
          prevVy: fixture.vy,
          drawScale: 1.18,
          animTick: fixture.age,
          locomotion,
          life: { kind: "alive", age: 0 },
          attack: spec.attack ? { ...spec.attack, facing, aimX: facing, aimY: 0.55 } : null,
          action: spec.action,
          actionAge: spec.action && Number.isFinite(spec.action.age) ? spec.action.age : fixture.age,
          reload: spec.reload,
          hitstun: 0
        };
        const source = {
          facing: sourceFighter.facing,
          weapon: sourceFighter.weapon,
          aimX: sourceFighter.aimX,
          aimY: sourceFighter.aimY,
          aimFacing: sourceFighter.aimFacing,
          aimStep: sourceFighter.aimStep,
          grounded: sourceFighter.grounded,
          vx: sourceFighter.vx,
          vy: sourceFighter.vy,
          prevVx: sourceFighter.prevVx,
          prevVy: sourceFighter.prevVy,
          animTick: sourceFighter.animTick,
          locomotion: JSON.parse(JSON.stringify(sourceFighter.locomotion)),
          attack: sourceFighter.attack ? { ...sourceFighter.attack } : null,
          action: sourceFighter.action,
          actionAge: sourceFighter.actionAge,
          reload: sourceFighter.reload,
          hitstun: sourceFighter.hitstun
        };
        const defeated = {
          ...sourceFighter,
          dead: true,
          attack: null,
          action: "defeat",
          actionAge: 0,
          reload: 0,
          hitstun: 0,
          life: { kind: "defeated", age: 0, source }
        };
        assert.doesNotThrow(() => JSON.parse(JSON.stringify(defeated.life)));
        const expectedSource = Anim.poseForFighter(sourceFighter, 0.5);
        let previous = null;
        for (let age = 0; age <= 12; age += 1) {
          defeated.life.age = age;
          const pose = Anim.poseForFighter(defeated, 0.5);
          if (age === 0) assertPoseGeometryNear(pose, expectedSource,
            `${fixture.kind} ${spec.label} facing ${facing} defeat seam`);
          if (previous) assert.ok(maxPosePointDelta(pose, previous) <= 25,
            `${fixture.kind} ${spec.label} facing ${facing} defeat age ${age} popped`);
          for (const [start, end] of LIMB_SEGMENTS) {
            const length = Math.hypot(pose[start].x - pose[end].x, pose[start].y - pose[end].y);
            const minimum = start === "hip" || start.startsWith("knee") ? 15 : 9.9;
            const maximum = start === "hip" || start.startsWith("knee") ? 40 : 36;
            assert.ok(length >= minimum && length <= maximum,
              `${fixture.kind} ${spec.label} age ${age} ${start}-${end} became ${length}`);
          }
          if (spec.attack && spec.attack.released) {
            assert.equal(pose.grenadeVisible, false, "released grenade returned during defeat");
          }
          previous = pose;
        }
        const direct = Anim.poseForFighter({
          ...defeated,
          life: { kind: "defeated", age: 12, source: null }
        }, 0.5);
        assertPoseGeometryNear(previous, direct,
          `${fixture.kind} ${spec.label} facing ${facing} defeat entry seam`);
      }
    }
  }
});

test("lethal fixed-step damage snapshots the exact serializable presentation source", () => {
  const state = Sim.createState({ seed: 0x4b00, botCount: 1 });
  const attacker = state.fighters[0];
  const target = state.fighters[1];
  for (const [fighter, x] of [[attacker, 500], [target, 600]]) {
    Object.assign(fighter, {
      x, prevX: x, y: 880, prevY: 880,
      vx: 0, vy: 0, prevVx: 0, prevVy: 0,
      grounded: true, prevGrounded: true, platformId: 0,
      invuln: 0, hurtCooldown: 0
    });
  }
  target.health = 1;
  target.weapon = "grenade";
  Sim.grantWeapon(target, "grenade", true);
  target.facing = -1;
  target.aimX = -1;
  target.attack = {
    kind: "grenade", weapon: "grenade", age: 18, duration: 38,
    facing: -1, aimX: -1, aimY: 0, released: true
  };
  target.action = "grenade";
  target.actionAge = 18;
  state.projectiles.push({
    id: state.nextEntityId++, ownerId: attacker.id, weapon: "pistol", groupId: null,
    x: 560, y: 812, prevX: 560, prevY: 812,
    vx: 1200, vy: 0, life: 2,
    damage: Sim.WEAPONS.pistol.damage,
    knockback: Sim.WEAPONS.pistol.knockback,
    hitstun: Sim.WEAPONS.pistol.hitstun
  });

  Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);

  assert.equal(target.dead, true);
  assert.equal(target.life.kind, "defeated");
  assert.equal(target.life.age, 0);
  assert.equal(target.life.source.attack.kind, "grenade");
  assert.equal(target.life.source.attack.released, true);
  assert.equal(Sim.serialize(Sim.deserialize(Sim.serialize(state))), Sim.serialize(state));
  const expected = Anim.poseForFighter({
    ...target,
    ...target.life.source,
    dead: false,
    life: { kind: "alive", age: 0 },
    respawnVisual: 0
  });
  const defeated = Anim.poseForFighter(target);
  assertPoseGeometryNear(defeated, expected, "lethal fixed-step defeat seam");
  assert.equal(defeated.grenadeVisible, false, "released grenade returned on lethal damage");
});

test("authored loops, recoveries, reloads, and respawn presentation have exact seams", () => {
  const assertSameGeometry = (actual, expected, label) =>
    assert.deepEqual(poseGeometry(actual), poseGeometry(expected), label);

  for (const [clip, duration, options] of [
    ["idle", Anim.CLIPS.idle.duration, { weapon: "unarmed" }],
    ["run", Anim.CLIPS.run.duration, { weapon: "unarmed" }],
    ["fall", Anim.CLIPS.fall.duration, { weapon: "unarmed" }],
    ["swordReady", Anim.CLIPS.swordReady.duration, { weapon: "sword" }]
  ]) {
    assertSameGeometry(
      Anim.sampleClip(clip, duration, options),
      Anim.sampleClip(clip, 0, options),
      `${clip} loop has a visible seam`
    );
  }

  const idle = Anim.sampleClip("idle", 0, { weapon: "unarmed" });
  assertSameGeometry(Anim.sampleClip("land", Anim.CLIPS.land.duration, { weapon: "unarmed" }), idle,
    "landing does not recover to idle");
  assertSameGeometry(
    Anim.sampleClip("jump", Anim.CLIPS.jump.duration, { weapon: "unarmed" }),
    Anim.sampleClip("fall", 0, { weapon: "unarmed" }),
    "jump apex does not enter fall cleanly"
  );
  assertSameGeometry(Anim.sampleClip("unarmed", 0, { weapon: "unarmed" }), idle,
    "unarmed anticipation does not start at idle");
  assertSameGeometry(Anim.sampleClip("unarmed", Anim.CLIPS.unarmed.duration, { weapon: "unarmed" }), idle,
    "unarmed recovery does not end at idle");
  assertSameGeometry(Anim.sampleClip("hit", Anim.CLIPS.hit.duration, { weapon: "unarmed" }), idle,
    "hit reaction does not recover to idle");
  assertSameGeometry(Anim.sampleClip("respawn", Anim.CLIPS.respawn.duration, { weapon: "unarmed" }), idle,
    "respawn does not finish at the unchanged silhouette");
  assertSameGeometry(
    Anim.sampleClip("grenadeThrow", Anim.CLIPS.grenadeThrow.duration, { weapon: "grenade" }),
    Anim.sampleClip("grenadeThrow", 0, { weapon: "grenade" }),
    "grenade recovery does not return to grenade ready"
  );
  assertSameGeometry(
    Anim.sampleClip("swordAttack", Anim.CLIPS.swordAttack.duration, { weapon: "sword" }),
    Anim.sampleClip("swordReady", 0, { weapon: "sword" }),
    "sword recovery does not return to sword ready"
  );

  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    assert.equal(Anim.reloadDuration(weapon), Sim.WEAPONS[weapon].reload,
      `${weapon} reload animation diverged from simulation timing`);
    for (const aimBand of ["high", "level", "low"]) {
      const options = { weapon, aimBand };
      const aim = Anim.sampleClip("gunAim", 0, options);
      assertSameGeometry(Anim.sampleClip("gunFire", 0, options), aim,
        `${weapon} ${aimBand} recoil does not start at aim`);
      assertSameGeometry(Anim.sampleClip("gunFire", Anim.CLIPS.gunFire.duration, options), aim,
        `${weapon} ${aimBand} recoil does not recover to aim`);
      assertSameGeometry(Anim.sampleClip("reload", 0, options), aim,
        `${weapon} ${aimBand} reload does not start at aim`);
      assertSameGeometry(Anim.sampleClip("reload", Anim.reloadDuration(weapon) - 1, options), aim,
        `${weapon} ${aimBand} reload does not end at aim`);
      const midpoint = Anim.sampleClip("reload", Math.floor((Anim.reloadDuration(weapon) - 1) / 2), options);
      const midpointDelta = Math.max(...Anim.POINTS.map((key) =>
        Math.hypot(midpoint[key].x - aim[key].x, midpoint[key].y - aim[key].y)));
      assert.ok(midpointDelta > 12, `${weapon} ${aimBand} reload lost its handling motion`);
      assert.match(Anim.sampleClip("reload", 0, options).phase, new RegExp(`^reload-${aimBand}-enter$`));
      assert.match(Anim.sampleClip("reload", Anim.reloadDuration(weapon) - 1, options).phase,
        new RegExp(`^reload-${aimBand}-exit$`));
    }
  }
  assert.equal(Anim.CLIPS.reload.duration, Math.max(...["pistol", "shotgun", "rifle"].map(Anim.reloadDuration)));

  const respawnAlpha = [0, 8, 16, 24].map((age) => Anim.sampleClip("respawn", age).alpha);
  assert.deepEqual(respawnAlpha, [0.7, 0.82, 0.92, 1]);
  assert.ok(respawnAlpha[0] >= 0.7, "respawned fighters must stay readable while they can act");
  assert.ok(respawnAlpha.every((alpha, index) => index === 0 || alpha >= respawnAlpha[index - 1]));
});

test("run support feet stay planted while moving, strafing, and rendering between steps", () => {
  for (const facing of [-1, 1]) {
    for (const moveX of [-1, -0.5, -0.2, -0.11, 0.11, 0.2, 0.5, 1]) {
      const state = Sim.createState({ seed: 0x3a3a + facing + Math.round(moveX * 100), botCount: 1 });
      const fighter = state.fighters[0];
      const groundId = moveX > 0 ? 0 : 7;
      const ground = state.arena.platforms.find((platform) => platform.id === groundId);
      fighter.x = moveX > 0 ? 120 : 1800;
      fighter.prevX = fighter.x;
      fighter.y = ground.y;
      fighter.prevY = fighter.y;
      fighter.vx = moveX * Sim.RULES.runSpeed;
      fighter.vy = 0;
      fighter.grounded = true;
      fighter.platformId = ground.id;
      fighter.facing = facing;
      fighter.locomotion = { kind: "run", age: 0, gaitPhase: 0 };
      const windows = [];
      let contacts = [];

      const closeWindow = () => {
        if (contacts.length >= 4) windows.push(contacts);
        contacts = [];
      };

      for (let tick = 0; tick < 90; tick += 1) {
        const actor = neutralHuman(state);
        actor.moveX = moveX;
        actor.aimX = facing;
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        assert.equal(fighter.grounded, true, `move ${moveX} left platform ${ground.id}`);
        assert.equal(fighter.platformId, ground.id, `move ${moveX} changed support platform`);

        for (const alpha of [0, 0.25, 0.5, 0.75, 1]) {
          const renderFighter = {
            ...fighter,
            x: fighter.prevX + (fighter.x - fighter.prevX) * alpha,
            y: fighter.prevY + (fighter.y - fighter.prevY) * alpha,
            renderStepX: fighter.x,
            renderStepY: fighter.y
          };
          const pose = Anim.poseForFighter(renderFighter, alpha);
          for (const [start, end] of LEG_SEGMENTS) {
            const length = Math.hypot(
              pose[start].x - pose[end].x,
              pose[start].y - pose[end].y
            );
            assert.ok(length >= 15 && length <= 40,
              `move ${moveX} ${start}-${end} became ${length} at alpha ${alpha}`);
          }
          const foot = pose.planted === "R" ? "ankleR" : pose.planted === "L" ? "ankleL" : null;
          if (!foot) {
            closeWindow();
            continue;
          }
          if (contacts.length && contacts[0].foot !== foot) closeWindow();
          const point = worldPosePoint(renderFighter, pose[foot]);
          contacts.push({ ...point, foot });
          assert.ok(Math.abs(point.y - ground.y) <= 0.25,
            `${foot} missed ground by ${Math.abs(point.y - ground.y)}px at alpha ${alpha}`);
        }
      }
      closeWindow();
      assert.ok(windows.length > 0, `move ${moveX}, facing ${facing} produced no support window`);
      for (const window of windows) {
        const xRange = Math.max(...window.map((point) => point.x)) - Math.min(...window.map((point) => point.x));
        const yRange = Math.max(...window.map((point) => point.y)) - Math.min(...window.map((point) => point.y));
        assert.ok(xRange <= 1, `${window[0].foot} slid ${xRange}px for move ${moveX}, facing ${facing}`);
        assert.ok(yRange <= 0.25, `${window[0].foot} bounced ${yRange}px for move ${moveX}, facing ${facing}`);
      }
    }
  }
  for (const phase of [10, 12, 15.75, 26, 28, 31.75]) {
    assert.equal(Anim.sampleClip("run", phase).planted, null,
      `run phase ${phase} claimed a support foot outside its stabilized window`);
  }

  for (const facing of [-1, 1]) {
    for (const travelSign of [-1, 1]) {
      for (const speed of [46, 80, 150, 300, Sim.RULES.runSpeed]) {
        for (let gaitPhase = 0; gaitPhase < 32; gaitPhase += 2) {
          const state = Sim.createState({ seed: 0x3b00 + gaitPhase + speed + facing + travelSign, botCount: 1 });
          const fighter = state.fighters[0];
          const ground = state.arena.platforms.find((platform) => platform.id === 0);
          Object.assign(fighter, {
            x: 410, prevX: 410, y: ground.y, prevY: ground.y,
            vx: speed * travelSign, vy: 0, prevVx: speed * travelSign, prevVy: 0,
            grounded: true, prevGrounded: true, platformId: ground.id,
            facing, prevFacing: facing
          });
          fighter.locomotion = {
            kind: "run", age: 20, gaitPhase,
            previousKind: "run", previousAge: 19, previousGaitPhase: gaitPhase,
            previousVx: speed * travelSign, previousTravelSign: travelSign,
            previousMoveIntent: true, previousEntryKind: "run", previousEntryAge: 18,
            previousTurn: null, previousLandExit: null,
            travelSign, moveIntent: true, turn: null, landExit: null
          };
          const actor = neutralHuman(state);
          actor.aimX = facing;
          actor.moveX = -travelSign;
          let before = Anim.poseForFighter(fighter);
          for (let tick = 0; tick < 10; tick += 1) {
            Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
            const after = Anim.poseForFighter(fighter);
            const delta = maxPosePointDelta(after, before);
            assert.ok(delta <= 22,
              `support boundary facing ${facing} travel ${travelSign} speed ${speed} phase ${gaitPhase} tick ${tick} jumped ${delta}`);
            for (const [start, end] of LEG_SEGMENTS) {
              const length = Math.hypot(after[start].x - after[end].x, after[start].y - after[end].y);
              assert.ok(length >= 15 && length <= 40,
                `support boundary ${start}-${end} became ${length}`);
            }
            before = after;
          }
        }
      }
    }
  }

  let checkedRunExitRoundTrip = false;
  for (const facing of [-1, 1]) {
    for (const travelSign of [-1, 1]) {
      for (const speed of [46, 47, 60, 80, 86]) {
        for (const gaitPhase of [2, 4, 6, 8, 18, 20, 22, 24]) {
          const state = Sim.createState({ seed: 0x3c00 + gaitPhase + speed + facing + travelSign, botCount: 1 });
          const fighter = state.fighters[0];
          const ground = state.arena.platforms.find((platform) => platform.id === 0);
          Object.assign(fighter, {
            x: 410, prevX: 410, y: ground.y, prevY: ground.y,
            vx: speed * travelSign, vy: 0, prevVx: speed * travelSign, prevVy: 0,
            grounded: true, prevGrounded: true, platformId: ground.id,
            facing, prevFacing: facing
          });
          fighter.locomotion = {
            kind: "run", age: 20, gaitPhase,
            previousKind: "run", previousAge: 19, previousGaitPhase: gaitPhase,
            previousVx: speed * travelSign, previousTravelSign: travelSign,
            previousMoveIntent: true, previousEntryKind: "run", previousEntryAge: 18,
            previousTurn: null, previousLandExit: null, previousRunExit: null,
            travelSign, moveIntent: true,
            turn: null, landExit: null, runExit: null
          };
          const actor = neutralHuman(state);
          actor.aimX = facing;
          let before = Anim.poseForFighter(fighter);
          let sawRunExit = false;
          for (let tick = 0; tick < 12; tick += 1) {
            const priorKind = fighter.locomotion.kind;
            Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
            const after = Anim.poseForFighter(fighter);
            if (!sawRunExit && fighter.locomotion.runExit) {
              assert.equal(priorKind, "run");
              assert.equal(fighter.locomotion.kind, "idle");
              assertPoseGeometryNear(after, before,
                `neutral release seam facing ${facing} travel ${travelSign} speed ${speed} phase ${gaitPhase}`);
              sawRunExit = true;
              if (!checkedRunExitRoundTrip) {
                const restored = Sim.deserialize(Sim.serialize(state));
                assert.deepEqual(restored.fighters[0].locomotion.runExit, fighter.locomotion.runExit);
                checkedRunExitRoundTrip = true;
              }
            } else {
              const delta = maxPosePointDelta(after, before);
              assert.ok(delta <= 18,
                `neutral release facing ${facing} travel ${travelSign} speed ${speed} phase ${gaitPhase} tick ${tick} jumped ${delta}`);
            }
            for (const [start, end] of LEG_SEGMENTS) {
              const length = Math.hypot(after[start].x - after[end].x, after[start].y - after[end].y);
              assert.ok(length >= 15 && length <= 40,
                `neutral release ${start}-${end} became ${length}`);
            }
            before = after;
          }
          assert.equal(sawRunExit, true,
            `neutral release never reached idle at speed ${speed}, phase ${gaitPhase}`);
          assert.equal(fighter.locomotion.runExit, null,
            `neutral release persisted beyond its bounded duration`);
        }
      }
    }
  }
});

test("locomotion legs follow travel without snapping when aim-facing changes", () => {
  const lowerPoints = ["hip", "kneeL", "kneeR", "ankleL", "ankleR"];
  for (const velocity of [-Sim.RULES.runSpeed, -86, -38, 0, 38, 86, Sim.RULES.runSpeed]) {
    for (const phase of [0, 4, 8, 12, 16, 20, 24, 28]) {
      const travelSign = velocity < 0 ? -1 : 1;
      const base = {
        weapon: "rifle",
        aimY: 0,
        grounded: true,
        vx: velocity,
        vy: 0,
        drawScale: 1.18,
        animTick: phase,
        locomotion: {
          kind: Math.abs(velocity) > 0 ? "run" : "idle",
          age: phase,
          gaitPhase: phase,
          previousKind: "idle",
          previousAge: 0,
          travelSign,
          moveIntent: Math.abs(velocity) > 0
        },
        life: { kind: "alive", age: 0 },
        attack: null,
        action: "run",
        actionAge: phase,
        reload: 0
      };
      const before = Anim.poseForFighter({ ...base, facing: travelSign });
      const after = Anim.poseForFighter({ ...base, facing: -travelSign });
      for (const key of lowerPoints) {
        assertPointNear(after[key], before[key], `velocity ${velocity} phase ${phase} ${key}`);
      }
      assert.equal(after.planted, before.planted);
    }
  }
});

test("real fixed-step locomotion transitions stay bounded without cached poses", () => {
  const assertBoundedStep = (before, after, limit, label) => {
    const delta = maxPosePointDelta(after, before);
    assert.ok(delta <= limit, `${label} jumped ${delta} authored pixels`);
    for (const [start, end] of LIMB_SEGMENTS) {
      const length = Math.hypot(after[start].x - after[end].x, after[start].y - after[end].y);
      const minimum = start === "hip" || start.startsWith("knee") ? 15 : 9.9;
      const maximum = start === "hip" || start.startsWith("knee") ? 40 : 36;
      assert.ok(length >= minimum && length <= maximum,
        `${label} ${start}-${end} became ${length}`);
    }
  };
  const prepareGrounded = (state, direction) => {
    const fighter = state.fighters[0];
    const ground = state.arena.platforms.find((platform) => platform.id === (direction > 0 ? 0 : 7));
    const x = direction > 0 ? 300 : 1620;
    Object.assign(fighter, {
      x, prevX: x, y: ground.y, prevY: ground.y,
      vx: 0, vy: 0, prevVx: 0, prevVy: 0,
      grounded: true, prevGrounded: true, platformId: ground.id,
      facing: direction, prevFacing: direction, invuln: 0
    });
    fighter.locomotion = {
      kind: "idle", age: 0, gaitPhase: 0,
      previousKind: "idle", previousAge: 0,
      travelSign: direction, moveIntent: false
    };
    return fighter;
  };

  for (const direction of [-1, 1]) {
    for (const magnitude of [0.11, 0.5, 1]) {
      for (const holdTicks of [1, 4, 9, 16, 25]) {
        const state = Sim.createState({ seed: 0x4a00 + holdTicks, botCount: 1 });
        const fighter = prepareGrounded(state, direction);
        const actor = neutralHuman(state);
        actor.aimX = direction;
        actor.moveX = direction * magnitude;
        let before = Anim.poseForFighter(fighter);
        for (let tick = 0; tick < holdTicks; tick += 1) {
          Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
          const after = Anim.poseForFighter(fighter);
          assertBoundedStep(before, after, 22,
            `start ${direction * magnitude} hold ${holdTicks} tick ${tick}`);
          before = after;
        }
        actor.moveX = 0;
        for (let tick = 0; tick < 16; tick += 1) {
          Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
          const after = Anim.poseForFighter(fighter);
          assertBoundedStep(before, after, 22,
            `stop ${direction * magnitude} hold ${holdTicks} tick ${tick}`);
          before = after;
        }
      }
    }
  }

  for (const storedTravelSign of [-1, 1]) {
    const state = Sim.createState({ seed: 0x4a08 + storedTravelSign, botCount: 1 });
    const fighter = prepareGrounded(state, storedTravelSign);
    const actor = neutralHuman(state);
    actor.aimX = storedTravelSign;
    actor.moveX = -storedTravelSign;
    const before = Anim.poseForFighter(fighter);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    let after = Anim.poseForFighter(fighter);
    assert.equal(fighter.locomotion.kind, "run");
    assert.ok(fighter.locomotion.turn, "opposite idle start did not create a turn transition");
    assertPoseGeometryNear(after, before, `opposite idle start ${storedTravelSign} seam`);
    for (let tick = 1; tick <= 8; tick += 1) {
      const prior = after;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      after = Anim.poseForFighter(fighter);
      assertBoundedStep(prior, after, 18, `opposite idle start ${storedTravelSign} tick ${tick}`);
    }
  }

  {
    const state = Sim.createState({ seed: 0x4a10, botCount: 1 });
    const fighter = prepareGrounded(state, 1);
    const actor = neutralHuman(state);
    actor.aimX = 1;
    actor.moveX = 1;
    for (let tick = 0; tick < 14; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    }
    let before = Anim.poseForFighter(fighter);
    actor.moveX = -1;
    for (let tick = 0; tick < 24; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const after = Anim.poseForFighter(fighter);
      assertBoundedStep(before, after, 22, `ground reversal tick ${tick}`);
      before = after;
    }
  }

  {
    const state = Sim.createState({ seed: 0x4a11, botCount: 1 });
    const fighter = prepareGrounded(state, 1);
    const actor = neutralHuman(state);
    actor.aimX = 1;
    actor.moveX = 1;
    for (let tick = 0; tick < 14; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    }
    actor.moveX = -1;
    for (let tick = 0; tick < 16 && !fighter.locomotion.turn; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    }
    assert.ok(fighter.locomotion.turn, "reversal never created its transition");
    let before = Anim.poseForFighter(fighter);
    for (let tick = 0; tick < 24; tick += 1) {
      actor.moveX *= -1;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const after = Anim.poseForFighter(fighter);
      assertBoundedStep(before, after, 18, `rapid reversal tick ${tick}`);
      before = after;
    }
  }

  for (const command of ["restart", "reverse", "jump", "drop"]) {
    const state = Sim.createState({ seed: 0x4a18 + command.length, botCount: 1 });
    const fighter = state.fighters[0];
    const platform = state.arena.platforms.find((candidate) => candidate.id === (command === "drop" ? 2 : 0));
    const x = platform.x + Math.min(220, platform.w * 0.5);
    Object.assign(fighter, {
      x, prevX: x, y: platform.y, prevY: platform.y,
      vx: 80, vy: 0, prevVx: 80, prevVy: 0,
      grounded: true, prevGrounded: true, platformId: platform.id,
      facing: 1, prevFacing: 1
    });
    fighter.locomotion = {
      kind: "run", age: 20, gaitPhase: 20,
      previousKind: "run", previousAge: 19, previousGaitPhase: 20,
      previousVx: 80, previousTravelSign: 1, previousMoveIntent: true,
      previousEntryKind: "run", previousEntryAge: 18,
      previousTurn: null, previousLandExit: null, previousRunExit: null,
      travelSign: 1, moveIntent: true,
      turn: null, landExit: null, runExit: null
    };
    const actor = neutralHuman(state);
    actor.aimX = 1;
    const running = Anim.poseForFighter(fighter);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    let before = Anim.poseForFighter(fighter);
    assertPoseGeometryNear(before, running, `${command} run-release seam`);
    assert.ok(fighter.locomotion.runExit);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    before = Anim.poseForFighter(fighter);

    if (command === "restart") actor.moveX = 1;
    if (command === "reverse") actor.moveX = -1;
    if (command === "jump") actor.buttons.jump = true;
    if (command === "drop") actor.buttons.drop = true;
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    let after = Anim.poseForFighter(fighter);
    if (command === "jump" || command === "drop") {
      assert.equal(fighter.locomotion.kind, command === "jump" ? "jump" : "fall");
      assert.ok(fighter.locomotion.previousRunExit,
        `${command} did not preserve the interrupted run release source`);
      assert.equal(fighter.locomotion.runExit, null);
      assertPoseGeometryNear(after, before, `${command} interrupted run release seam`);
    } else {
      assertBoundedStep(before, after, 22, `${command} interrupted run release`);
      for (let tick = 1; tick <= 9; tick += 1) {
        before = after;
        if (tick === 2) actor.moveX = 0;
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        after = Anim.poseForFighter(fighter);
        assertBoundedStep(before, after, 22,
          `${command} interrupted run release tick ${tick}`);
      }
    }
  }

  for (const facing of [-1, 1]) {
    for (const travelSign of [-1, 1]) {
      for (const speed of [120, 240, Sim.RULES.runSpeed]) {
        for (const exitAge of [1, 3, 5]) {
          for (const resumeSign of [travelSign, -travelSign]) {
            const state = Sim.createState({
              seed: 0x4a1c + speed + exitAge + facing + travelSign + resumeSign,
              botCount: 1
            });
            const fighter = state.fighters[0];
            const ground = state.arena.platforms.find((platform) => platform.id === (travelSign > 0 ? 0 : 7));
            const x = travelSign > 0 ? 300 : 1620;
            Object.assign(fighter, {
              x, prevX: x, y: ground.y, prevY: ground.y,
              vx: speed * travelSign, vy: 0,
              prevVx: speed * travelSign, prevVy: 0,
              grounded: true, prevGrounded: true, platformId: ground.id,
              facing, prevFacing: facing
            });
            fighter.locomotion = {
              kind: "run", age: 20, gaitPhase: travelSign > 0 ? 0 : 18,
              previousKind: "run", previousAge: 19,
              previousGaitPhase: travelSign > 0 ? 0 : 18,
              previousVx: speed * travelSign,
              previousTravelSign: travelSign, previousMoveIntent: true,
              previousEntryKind: "run", previousEntryAge: 18,
              previousTurn: null, previousLandExit: null, previousRunExit: null,
              travelSign, moveIntent: true,
              turn: null, landExit: null, runExit: null
            };
            const actor = neutralHuman(state);
            actor.aimX = facing;
            let before = Anim.poseForFighter(fighter);
            for (let tick = 0; tick < 20 && !fighter.locomotion.runExit; tick += 1) {
              Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
              const after = Anim.poseForFighter(fighter);
              assertBoundedStep(before, after, 18,
                `coast ${facing}/${travelSign}/${speed} tick ${tick}`);
              before = after;
            }
            assert.ok(fighter.locomotion.runExit,
              `coast ${facing}/${travelSign}/${speed} never created a run exit`);
            while (fighter.locomotion.runExit.age < exitAge) {
              Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
              const after = Anim.poseForFighter(fighter);
              assertBoundedStep(before, after, 18,
                `run-exit ${facing}/${travelSign}/${speed} age ${fighter.locomotion.runExit.age}`);
              before = after;
            }
            actor.moveX = resumeSign;
            Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
            const resumed = Anim.poseForFighter(fighter);
            assert.equal(fighter.locomotion.kind, "run");
            assert.ok(fighter.locomotion.turn,
              `idle-to-run resume ${resumeSign} did not create a bounded entry`);
            assertBoundedStep(before, resumed, 18,
              `resume ${facing}/${travelSign}/${speed} age ${exitAge} direction ${resumeSign}`);
          }
        }
      }
    }
  }

  for (const facing of [-1, 1]) {
    for (const travelSign of [-1, 1]) {
      const state = Sim.createState({ seed: 0x4a1f + facing + travelSign, botCount: 1 });
      const fighter = prepareGrounded(state, facing);
      fighter.vx = 77.5 * travelSign;
      fighter.prevVx = fighter.vx;
      fighter.locomotion = {
        kind: "run", age: 30, gaitPhase: 18.687,
        previousKind: "run", previousAge: 29, previousGaitPhase: 18.687,
        previousVx: fighter.vx, previousTravelSign: travelSign,
        previousMoveIntent: false, previousEntryKind: "run", previousEntryAge: 28,
        previousTurn: null, previousLandExit: null, previousRunExit: null,
        travelSign, moveIntent: false,
        turn: null, landExit: null, runExit: null
      };
      const actor = neutralHuman(state);
      actor.aimX = facing;
      actor.moveX = travelSign;
      const before = Anim.poseForFighter(fighter);
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const after = Anim.poseForFighter(fighter);
      assertBoundedStep(before, after, 18,
        `coasting support re-engagement facing ${facing} travel ${travelSign}`);
    }
  }

  for (const facing of [-1, 1]) {
    for (const moveSign of [-1, 1]) {
      for (const gaitPhase of [2, 4, 6, 8, 18, 20, 22, 24]) {
        for (const exitAge of [null, 4, 5]) {
          const state = Sim.createState({
            seed: 0x4a21 + gaitPhase + facing + moveSign + (exitAge || 0),
            botCount: 1
          });
          const fighter = prepareGrounded(state, facing);
          fighter.locomotion = {
            kind: "idle", age: 6, gaitPhase,
            previousKind: "run", previousAge: 30, previousGaitPhase: gaitPhase,
            previousVx: 47 * moveSign, previousTravelSign: -moveSign,
            previousMoveIntent: false, previousEntryKind: "run", previousEntryAge: 29,
            previousTurn: null, previousLandExit: null, previousRunExit: null,
            travelSign: -moveSign, moveIntent: false,
            turn: {
              age: 7, duration: 8,
              sourceKind: "run", sourceAge: 22, sourceGaitPhase: gaitPhase,
              sourceVx: -47 * moveSign, sourceTravelSign: -moveSign,
              sourceMoveIntent: true, sourcePreviousKind: "run", sourcePreviousAge: 21
            },
            landExit: null,
            runExit: exitAge == null ? null : {
              age: exitAge, duration: 6,
              sourceKind: "run", sourceAge: 30, sourceGaitPhase: gaitPhase,
              sourceVx: 47 * moveSign, sourceTravelSign: moveSign,
              sourceMoveIntent: false,
              sourcePreviousKind: "run", sourcePreviousAge: 29,
              sourcePreviousGaitPhase: gaitPhase,
              sourcePreviousVx: 47 * moveSign,
              sourcePreviousTravelSign: moveSign,
              sourcePreviousMoveIntent: false,
              sourcePreviousEntryKind: "run", sourcePreviousEntryAge: 28,
              sourceTurn: null, sourceLandExit: null
            }
          };
          const actor = neutralHuman(state);
          actor.aimX = facing;
          actor.moveX = 0.11 * moveSign;
          let before = Anim.poseForFighter(fighter);
          for (let age = 0; age <= 5; age += 1) {
            Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
            const after = Anim.poseForFighter(fighter);
            assertBoundedStep(before, after, 18,
              `idle run-entry facing ${facing} move ${moveSign} phase ${gaitPhase} exit ${exitAge} age ${age}`);
            before = after;
          }
        }
      }
    }
  }

  for (const facing of [-1, 1]) {
    for (const travelSign of [-1, 1]) {
      for (const gaitPhase of [2, 4, 6, 8, 18, 20, 22, 24]) {
        for (const turnAge of [null, 5, 6, 7]) {
          const state = Sim.createState({
            seed: 0x4a25 + gaitPhase + facing + travelSign + (turnAge || 0),
            botCount: 1
          });
          const fighter = prepareGrounded(state, facing);
          fighter.vx = 47.5 * travelSign;
          fighter.prevVx = fighter.vx;
          fighter.locomotion = {
            kind: "run", age: 6, gaitPhase,
            previousKind: "run", previousAge: 5, previousGaitPhase: gaitPhase,
            previousVx: fighter.vx, previousTravelSign: travelSign,
            previousMoveIntent: true, previousEntryKind: "run", previousEntryAge: 4,
            previousTurn: null, previousLandExit: null, previousRunExit: null,
            travelSign, moveIntent: true,
            turn: turnAge == null ? null : {
              age: turnAge, duration: 8,
              sourceKind: "run", sourceAge: 2, sourceGaitPhase: gaitPhase,
              sourceVx: 47.5 * travelSign, sourceTravelSign: travelSign,
              sourceMoveIntent: true, sourcePreviousKind: "run", sourcePreviousAge: 1
            },
            landExit: null, runExit: null
          };
          const actor = neutralHuman(state);
          actor.aimX = facing;
          actor.moveX = -0.11 * travelSign;
          let before = Anim.poseForFighter(fighter);
          for (let tick = 0; tick < 3; tick += 1) {
            Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
            const after = Anim.poseForFighter(fighter);
            assertBoundedStep(before, after, 18,
              `zero-crossing facing ${facing} travel ${travelSign} phase ${gaitPhase} turn ${turnAge} tick ${tick}`);
            before = after;
          }
        }
      }
    }
  }

  {
    const state = Sim.createState({ seed: 0x4a29, botCount: 1 });
    const fighter = prepareGrounded(state, 1);
    fighter.vx = -60;
    fighter.prevVx = -60;
    fighter.locomotion = {
      kind: "run", age: 15, gaitPhase: 15.56,
      previousKind: "run", previousAge: 14, previousGaitPhase: 15.56,
      previousVx: -60, previousTravelSign: -1,
      previousMoveIntent: true, previousEntryKind: "run", previousEntryAge: 13,
      previousTurn: null, previousLandExit: null, previousRunExit: null,
      travelSign: -1, moveIntent: true,
      turn: null, landExit: null, runExit: null
    };
    const actor = neutralHuman(state);
    actor.aimX = 1;
    const moves = [
      ...Array(5).fill(1),
      ...Array(2).fill(0),
      ...Array(3).fill(0.11),
      ...Array(2).fill(-1),
      0,
      ...Array(5).fill(-0.11),
      ...Array(15).fill(0)
    ];
    let before = Anim.poseForFighter(fighter);
    let releaseCount = 0;
    let priorHadRunExit = false;
    for (let tick = 0; tick < moves.length; tick += 1) {
      actor.moveX = moves[tick];
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const after = Anim.poseForFighter(fighter);
      assertBoundedStep(before, after, 22,
        `reachable repeated run release tick ${tick}`);
      if (fighter.locomotion.runExit && !priorHadRunExit) releaseCount += 1;
      priorHadRunExit = !!fighter.locomotion.runExit;
      before = after;
    }
    assert.ok(releaseCount >= 2, "repeated run release regression did not exercise both stop edges");
    assert.equal(fighter.locomotion.runExit, null);
  }

  for (const gaitPhase of [0, 4, 8, 12, 16, 20, 24, 28, 31]) {
    const state = Sim.createState({ seed: 0x4a20 + gaitPhase, botCount: 1 });
    const fighter = state.fighters[0];
    const ground = state.arena.platforms.find((platform) => platform.id === 0);
    Object.assign(fighter, {
      x: 858, prevX: 858, y: ground.y, prevY: ground.y,
      vx: Sim.RULES.runSpeed, vy: 0, prevVx: Sim.RULES.runSpeed, prevVy: 0,
      grounded: true, prevGrounded: true, platformId: ground.id,
      facing: 1, prevFacing: 1
    });
    fighter.locomotion = {
      kind: "run", age: 20, gaitPhase,
      previousKind: "idle", previousAge: 0,
      travelSign: 1, moveIntent: true
    };
    const actor = neutralHuman(state);
    actor.moveX = 1;
    actor.aimX = 1;
    const before = Anim.poseForFighter(fighter);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    const after = Anim.poseForFighter(fighter);
    assert.equal(fighter.locomotion.kind, "fall");
    assertPoseGeometryNear(after, before, `walk-off phase ${gaitPhase}`);
    let transitionPose = after;
    for (let age = 1; age <= 3; age += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const nextPose = Anim.poseForFighter(fighter);
      assertBoundedStep(transitionPose, nextPose, 25, `walk-off phase ${gaitPhase} age ${age}`);
      for (const alpha of [0, 0.25, 0.5, 0.75, 1]) {
        const rendered = Anim.poseForFighter({
          ...fighter,
          renderStepX: fighter.x,
          renderStepY: fighter.y
        }, alpha);
        assertPoseGeometryNear(rendered, nextPose,
          `walk-off phase ${gaitPhase} age ${age} frozen alpha ${alpha}`);
      }
      transitionPose = nextPose;
    }
  }

  for (const gaitPhase of [0, 8, 16, 24, 31]) {
    const state = Sim.createState({ seed: 0x4a28 + gaitPhase, botCount: 1 });
    const fighter = state.fighters[0];
    const platform = state.arena.platforms.find((candidate) => candidate.id === 4);
    Object.assign(fighter, {
      x: platform.x + 120, prevX: platform.x + 120, y: platform.y, prevY: platform.y,
      vx: 220, vy: 0, prevVx: 220, prevVy: 0,
      grounded: true, prevGrounded: true, platformId: platform.id,
      facing: 1, prevFacing: 1
    });
    fighter.locomotion = {
      kind: "run", age: 20, gaitPhase,
      previousKind: "idle", previousAge: 0, previousGaitPhase: 0,
      previousVx: 0, previousTravelSign: 1, previousMoveIntent: false,
      previousEntryKind: "idle", previousEntryAge: 0, previousTurn: null,
      travelSign: 1, moveIntent: true, turn: null
    };
    const actor = neutralHuman(state);
    actor.moveX = 1;
    actor.aimX = 1;
    actor.buttons.drop = true;
    let before = Anim.poseForFighter(fighter);
    for (let age = 0; age <= 3; age += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      actor.buttons.drop = false;
      const after = Anim.poseForFighter(fighter);
      if (age === 0) assertPoseGeometryNear(after, before, `drop phase ${gaitPhase} seam`);
      else assertBoundedStep(before, after, 25, `drop phase ${gaitPhase} age ${age}`);
      before = after;
    }
  }

  {
    const state = Sim.createState({ seed: 0x4a30, botCount: 1 });
    const fighter = prepareGrounded(state, 1);
    const actor = neutralHuman(state);
    actor.moveX = 1;
    actor.aimX = 1;
    actor.buttons.jump = true;
    const before = Anim.poseForFighter(fighter);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    let after = Anim.poseForFighter(fighter);
    assertPoseGeometryNear(after, before, "idle move+jump seam");
    actor.buttons.jump = false;
    actor.moveX = -1;
    for (let tick = 0; tick < 24 && !fighter.grounded; tick += 1) {
      const prior = after;
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      after = Anim.poseForFighter(fighter);
      assert.equal(after.lowerFacing, 1, `air reversal changed leg commitment at tick ${tick}`);
      assertBoundedStep(prior, after, 25, `air reversal tick ${tick}`);
    }
  }

  for (const facing of [-1, 1]) {
    for (let landAge = 0; landAge <= Anim.CLIPS.land.duration; landAge += 1) {
      const state = Sim.createState({ seed: 0x4a38 + landAge + facing, botCount: 1 });
      const fighter = prepareGrounded(state, facing);
      fighter.landTimer = 8;
      fighter.locomotion = {
        kind: "land", age: landAge, gaitPhase: 13,
        previousKind: "fall", previousAge: 10, previousGaitPhase: 13,
        previousVx: 180 * facing, previousTravelSign: facing, previousMoveIntent: true,
        previousEntryKind: "jump", previousEntryAge: 15, previousTurn: null,
        travelSign: facing, moveIntent: false, turn: null
      };
      const actor = neutralHuman(state);
      actor.aimX = facing;
      actor.buttons.jump = true;
      const before = Anim.poseForFighter(fighter);
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      const after = Anim.poseForFighter(fighter);
      assert.equal(fighter.landTimer, 0, `landing age ${landAge} retained its timer`);
      assert.equal(fighter.locomotion.kind, "jump", `landing age ${landAge} delayed jump locomotion`);
      assertPoseGeometryNear(after, before, `landing age ${landAge} facing ${facing} jump seam`);
    }
  }

  for (const facing of [-1, 1]) {
    for (let exitAge = 1; exitAge <= 5; exitAge += 1) {
      for (const command of ["jump", "walkoff"]) {
        const state = Sim.createState({ seed: 0x4a3c + exitAge + facing, botCount: 1 });
        const fighter = prepareGrounded(state, facing);
        const ground = state.arena.platforms.find((platform) => platform.id === (facing > 0 ? 0 : 7));
        if (command === "walkoff") {
          fighter.x = facing > 0 ? 858 : 1062;
          fighter.prevX = fighter.x;
          fighter.y = ground.y;
          fighter.prevY = ground.y;
          fighter.platformId = ground.id;
        }
        fighter.vx = 220 * facing;
        fighter.prevVx = fighter.vx;
        fighter.locomotion = {
          kind: "run", age: 12, gaitPhase: 13,
          previousKind: "land", previousAge: 3, previousGaitPhase: 13,
          previousVx: 180 * facing, previousTravelSign: facing,
          previousMoveIntent: true, previousEntryKind: "fall", previousEntryAge: 10,
          previousTurn: null, previousLandExit: null,
          travelSign: facing, moveIntent: true, turn: null,
          landExit: {
            age: exitAge, duration: 6, sourceAge: 3,
            sourceTravelSign: facing, sourcePreviousKind: "fall", sourcePreviousAge: 10
          }
        };
        const actor = neutralHuman(state);
        actor.aimX = facing;
        actor.moveX = facing;
        actor.buttons.jump = command === "jump";
        const before = Anim.poseForFighter(fighter);
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        const after = Anim.poseForFighter(fighter);
        assert.equal(fighter.locomotion.kind, command === "jump" ? "jump" : "fall");
        assertPoseGeometryNear(after, before,
          `land-exit ${command} age ${exitAge} facing ${facing} seam`);
      }
    }
  }

  for (const facing of [-1, 1]) {
    for (const moveX of [-facing, facing]) {
      for (let sourceAge = 0; sourceAge <= Anim.CLIPS.land.duration; sourceAge += 1) {
        const state = Sim.createState({ seed: 0x4a50 + sourceAge + facing + moveX, botCount: 1 });
        const fighter = prepareGrounded(state, facing);
        fighter.vx = 180 * facing;
        fighter.prevVx = fighter.vx;
        fighter.landTimer = 1;
        fighter.locomotion = {
          kind: "land", age: sourceAge, gaitPhase: 13,
          previousKind: "fall", previousAge: 10, previousGaitPhase: 13,
          previousVx: 180 * facing, previousTravelSign: facing,
          previousMoveIntent: true, previousEntryKind: "jump", previousEntryAge: 15,
          previousTurn: null, previousLandExit: null,
          travelSign: facing, moveIntent: false, turn: null, landExit: null
        };
        const actor = neutralHuman(state);
        actor.aimX = facing;
        actor.moveX = moveX;
        let before = Anim.poseForFighter(fighter);
        Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
        let after = Anim.poseForFighter(fighter);
        assert.equal(fighter.locomotion.kind, "run");
        assertPoseGeometryNear(after, before,
          `land-exit source ${sourceAge} facing ${facing} move ${moveX} seam`);
        before = after;
        for (let age = 1; age <= 6; age += 1) {
          Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
          after = Anim.poseForFighter(fighter);
          const lowerDelta = maxPosePointDelta(after, before,
            ["hip", "kneeL", "kneeR", "ankleL", "ankleR"]);
          assert.ok(lowerDelta <= 19,
            `land-exit source ${sourceAge} facing ${facing} move ${moveX} age ${age} jumped ${lowerDelta}`);
          for (const [start, end] of LEG_SEGMENTS) {
            const length = Math.hypot(after[start].x - after[end].x, after[start].y - after[end].y);
            assert.ok(length >= 15 && length <= 40,
              `land-exit source ${sourceAge} ${start}-${end} became ${length}`);
          }
          before = after;
        }
      }
    }
  }

  for (const moveX of [0, 1]) {
    const state = Sim.createState({ seed: 0x4a40 + moveX, botCount: 1 });
    const fighter = prepareGrounded(state, 1);
    fighter.vx = 273;
    fighter.prevVx = 273;
    fighter.landTimer = 1;
    fighter.locomotion = {
      kind: "land", age: Anim.CLIPS.land.duration, gaitPhase: 17,
      previousKind: "fall", previousAge: 10,
      travelSign: 1, moveIntent: !!moveX
    };
    fighter.anim = "land";
    fighter.animTick = Anim.CLIPS.land.duration;
    fighter.action = "land";
    fighter.actionAge = Anim.CLIPS.land.duration;
    const actor = neutralHuman(state);
    actor.moveX = moveX;
    actor.aimX = 1;
    const before = Anim.poseForFighter(fighter);
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    const after = Anim.poseForFighter(fighter);
    assert.equal(fighter.locomotion.kind, "run");
    assertPoseGeometryNear(after, before, `land-to-run move ${moveX}`);
  }
});

test("jump launch and quiet landings use authored transition poses", () => {
  const run = {
    facing: 1,
    weapon: "unarmed",
    aimY: 0,
    grounded: true,
    vx: Sim.RULES.runSpeed,
    vy: 0,
    drawScale: 1.18,
    animTick: 8,
    locomotion: { kind: "run", age: 8, gaitPhase: 8 },
    life: { kind: "alive", age: 0 },
    attack: null,
    action: "run",
    actionAge: 8,
    reload: 0
  };
  const launch = {
    ...run,
    grounded: false,
    vy: -Sim.RULES.jumpSpeed,
    locomotion: {
      kind: "jump", age: 0, gaitPhase: 8,
      previousKind: "run", previousAge: 8, previousGaitPhase: 8,
      previousVx: Sim.RULES.runSpeed, previousTravelSign: 1, previousMoveIntent: true,
      previousEntryKind: "run", previousEntryAge: 0, previousTurn: null,
      travelSign: 1, moveIntent: true, turn: null
    },
    action: "jump",
    actionAge: 0
  };
  assertPoseGeometryNear(Anim.poseForFighter(launch), Anim.poseForFighter(run), "run-to-jump command seam");

  const state = Sim.createState({ seed: 0x3a3a, botCount: 1 });
  const fighter = state.fighters[0];
  const platform = state.arena.platforms.find((candidate) => candidate.id === 0);
  fighter.x = platform.x + 100;
  fighter.prevX = fighter.x;
  fighter.y = platform.y - 2;
  fighter.prevY = fighter.y;
  fighter.vx = 0;
  fighter.vy = 120;
  fighter.grounded = false;
  fighter.platformId = null;
  const actor = neutralHuman(state);
  Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
  assert.equal(fighter.grounded, true);
  assert.equal(fighter.platformId, platform.id);
  assert.equal(fighter.locomotion.kind, "land");
  assert.ok(fighter.landTimer > 0, "quiet landing bypassed the authored settle pose");
  assert.equal(state.events.some((event) => event.type === "land"), false,
    "quiet landing emitted the forceful impact effect");
});

test("renderer joins torso under the head and preserves pose alpha and angled grips", () => {
  const game = read("game.js");
  assert.match(game, /strokeLimb\(renderFighter, pose, \["hip", "spine", "torsoTop"\]/);
  assert.doesNotMatch(game, /\["hip", "spine", "shoulder", "neck"\]/);
  assert.match(game, /ctx\.globalAlpha \*= clamp\(pose\.alpha/);
  assert.match(game, /var presentingRespawn = fighter\.respawnVisual > 0/);
  assert.match(game, /if \(!presentingRespawn && fighter\.invuln/);
  assert.match(game, /ctx\.globalAlpha = weaponAlpha \* 0\.28/);
  assert.match(game, /ctx\.globalAlpha = weaponAlpha; ctx\.strokeStyle = "#05080a"/);
  assert.match(game, /sockets\.triggerGrip\.x \+ gripNormal\.x \* 18/);
  assert.doesNotMatch(game, /grip\.x - fighter\.facing \* 2/);
  const torsoDraw = game.indexOf('strokeLimb(renderFighter, pose, ["hip", "spine", "torsoTop"]');
  const headDraw = game.indexOf("ctx.beginPath(); ctx.arc(head.x, head.y");
  assert.ok(torsoDraw >= 0 && headDraw > torsoDraw, "head must mask the torso endpoint");

  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    for (const aimBand of ["high", "level", "low"]) {
      for (const facing of [-1, 1]) {
        for (const clip of ["gunAim", "gunFire"]) {
          const pose = Anim.sampleClip(clip, clip === "gunFire" ? 2 : 0, { weapon, aimBand, facing });
          const sockets = Anim.gunSockets(pose, weapon);
          const handOffset = {
            x: sockets.supportGrip.x - sockets.triggerGrip.x,
            y: sockets.supportGrip.y - sockets.triggerGrip.y
          };
          const perpendicularDistance = Math.abs(
            handOffset.x * sockets.normal.x + handOffset.y * sockets.normal.y
          );
          assert.ok(perpendicularDistance <= 2, `${weapon} ${aimBand} support hand missed the barrel by ${perpendicularDistance}`);
          const gripNormal = sockets.normal.y >= 0
            ? sockets.normal
            : { x: -sockets.normal.x, y: -sockets.normal.y };
          assert.ok(gripNormal.y >= 0, `${weapon} ${aimBand} facing ${facing} grip pointed upward`);
          if (facing < 0) {
            const mirrored = Anim.gunSockets(Anim.sampleClip(clip, clip === "gunFire" ? 2 : 0,
              { weapon, aimBand, facing: 1 }), weapon);
            const mirroredNormal = mirrored.normal.y >= 0
              ? mirrored.normal
              : { x: -mirrored.normal.x, y: -mirrored.normal.y };
            assert.ok(Math.abs(gripNormal.x + mirroredNormal.x) < 1e-9
              && Math.abs(gripNormal.y - mirroredNormal.y) < 1e-9,
            `${weapon} ${aimBand} grip did not mirror`);
          }
        }
      }
    }
  }
});

test("presentation effects stay bounded, exact-socket driven, and weapon specific", () => {
  const game = read("game.js");
  const audio = read("audio.js");
  const sound = audio.slice(audio.indexOf("function routeEvent"), audio.indexOf("function create(options)"));
  const trail = game.slice(game.indexOf("function drawSwordTrail"), game.indexOf("function drawWeapon"));
  const eventRouting = game.slice(game.indexOf("function processEvents"), game.indexOf("function updatePresentation"));

  assert.match(game, /var MAX_PARTICLES = 360;/);
  assert.match(game, /var MAX_FLASHES = 72;/);
  assert.match(game, /function pushBounded\(list, value, limit\)[\s\S]*list\.length >= limit[\s\S]*list\.push\(value\)/);
  assert.match(game, /pushBounded\(particles, particle, MAX_PARTICLES\)/);
  assert.match(game, /pushBounded\(flashes, flash, MAX_FLASHES\)/);
  assert.match(game, /particles\.length = 0;[\s\S]*flashes\.length = 0;/);

  assert.match(trail, /Anim\.swordTrailSamples\(pose\)/);
  assert.match(trail, /Math\.min\(4, samples\.length\)/);
  assert.match(trail, /sample\.bladeStart[\s\S]*sample\.bladeEnd/);
  assert.doesNotMatch(trail, /bladeStart\.[xy]\s*[+*-]|bladeEnd\.[xy]\s*[+*-]/,
    "renderer extended animation-owned trail endpoints");
  const trailDraw = game.indexOf("drawSwordTrail(renderFighter, pose)");
  const bodyDraw = game.indexOf('strokeLimb(renderFighter, pose, ["hip", "kneeL", "ankleL"]');
  const weaponDraw = game.indexOf("drawWeapon(renderFighter, pose)");
  assert.ok(trailDraw >= 0 && bodyDraw > trailDraw && weaponDraw > bodyDraw,
    "cosmetic trail must render behind the fighter and unchanged weapon");

  for (const weapon of ["unarmed", "sword", "pistol", "shotgun", "rifle", "grenade"]) {
    assert.match(game, new RegExp(`${weapon}: Object\\.freeze\\(\\{`),
      `${weapon} has no explicit impact style`);
    assert.match(sound, new RegExp(`weapon === "${weapon}"`),
      `${weapon} has no explicit synthesized sound recipe`);
  }
  for (const eventType of [
    "attack", "meleeSwing", "fire", "hit", "spark", "grenadeThrow",
    "grenadeBounce", "explosion", "dryFire", "reloadStart", "reload"
  ]) assert.match(sound, new RegExp(`event\\.type === "${eventType}"`));
  assert.doesNotMatch(sound, /bulletHit/,
    "pre-group projectile contact duplicated the accepted body-hit sound");
  assert.doesNotMatch(eventRouting, /event\.type === "bulletHit"/,
    "pre-group projectile contact duplicated the accepted body-hit effect");
  assert.match(game, /event\.tangentX[\s\S]*event\.tangentY[\s\S]*f\.weapon === "sword"/);
  assert.match(audio, /createBuffer\(1, sampleCount, audioContext\.sampleRate\)/);
  assert.doesNotMatch(sound, /setTimeout|setInterval|Math\.random/,
    "audio escaped fixed-step event routing or deterministic local synthesis");
  assert.match(audio, /source\.onended = record\.cleanup/);
  assert.match(game, /audio\.route\(event\)/);
  assert.doesNotMatch(game, /\bshake\b/);
});

test("Pass 5 weapon identities have one exact deterministic tuning matrix", () => {
  assert.deepEqual(Sim.WEAPONS.unarmed, {
    slot: 1, damage: 10, cooldown: 30, activeStart: 7, activeEnd: 10,
    duration: 30, knockback: 245, hitstun: 7
  });
  assert.deepEqual(Sim.WEAPONS.sword, {
    slot: 2, damage: 24, cooldown: 44, activeStart: 11, activeEnd: 16,
    duration: 44, knockback: 440, hitstun: 12
  });
  assert.deepEqual(Sim.WEAPONS.pistol, {
    slot: 3, damage: 18, cooldown: 44, reload: 72, mag: 8, reserve: 32,
    speed: 1420, life: 72, knockback: 275, hitstun: 7, spread: 0
  });
  assert.deepEqual(Sim.WEAPONS.shotgun, {
    slot: 4, damage: 4, shotCap: 32, pellets: 8, cooldown: 78,
    reload: 90, mag: 4, reserve: 16, speed: 1260, life: 32,
    knockback: 135, hitstun: 7, spread: 0.19,
    falloffStart: 170, falloffEnd: 520, minDamageScale: 0.35
  });
  assert.deepEqual(Sim.WEAPONS.rifle, {
    slot: 5, damage: 3, cooldown: 5, reload: 96, mag: 36, reserve: 108,
    speed: 1550, life: 68, knockback: 115, hitstun: 4,
    spread: 0.032, automatic: true
  });
  assert.deepEqual(Sim.WEAPONS.grenade, {
    slot: 6, damage: 48, cooldown: 60, count: 3, fuse: 120,
    radius: 190, throwSpeed: 760, knockback: 680, hitstun: 14,
    releaseAge: 16, duration: 38
  });

  assert.ok(Sim.WEAPONS.sword.damage > Sim.WEAPONS.pistol.damage);
  assert.ok(Sim.WEAPONS.sword.knockback > Sim.WEAPONS.pistol.knockback);
  assert.equal(Sim.WEAPONS.pistol.spread, 0);
  assert.equal(Sim.WEAPONS.rifle.automatic, true);
  assert.equal(Object.prototype.hasOwnProperty.call(Sim.WEAPONS.pistol, "automatic"), false);
  assert.equal(Object.prototype.hasOwnProperty.call(Sim.WEAPONS.shotgun, "automatic"), false);
  assert.ok(Sim.WEAPONS.rifle.cooldown < Sim.WEAPONS.pistol.cooldown);
  assert.ok(Sim.WEAPONS.rifle.cooldown < Sim.WEAPONS.shotgun.cooldown);
  assert.ok(Sim.WEAPONS.shotgun.shotCap < 100);
  assert.ok(Sim.WEAPONS.grenade.damage < 100);
  assert.equal(Math.ceil(100 / Sim.WEAPONS.pistol.damage), 6);
  assert.ok(Sim.WEAPONS.rifle.damage * Sim.WEAPONS.rifle.mag >= 100,
    "one accurate rifle magazine cannot finish an engagement");
  assert.ok(Sim.WEAPONS.shotgun.shotCap * 3 < 100
    && Sim.WEAPONS.shotgun.shotCap * 4 >= 100,
  "shotgun full-health threshold is not four perfect triggers");
  assert.ok(Sim.WEAPONS.grenade.damage * 2 < 100
    && Sim.WEAPONS.grenade.damage * 3 >= 100,
  "grenade full-health threshold is not three center blasts");
});

test("shotgun and rifle silhouettes add only socket-derived cosmetic identifiers", () => {
  const game = read("game.js");
  const pickup = game.slice(game.indexOf("function drawPickup"), game.indexOf("function drawFighter"));
  const held = game.slice(game.indexOf("function drawWeapon"), game.indexOf("function drawFighter"));
  assert.match(pickup, /weapon === "shotgun"[\s\S]*broad, grooved fore-end/);
  assert.match(pickup, /weapon === "rifle"[\s\S]*swept magazine/);
  assert.match(held, /weapon === "shotgun"[\s\S]*sockets\.triggerGrip[\s\S]*sockets\.direction/);
  assert.match(held, /weapon === "rifle"[\s\S]*sockets\.triggerGrip[\s\S]*gripNormal/);
  assert.match(held, /authoritative muzzle or changing the collision barrel geometry/);
});

test("visible sword blade equals authoritative collision segment", () => {
  const state = Sim.createState({ seed: 9, botCount: 1 });
  const fighter = state.fighters[0];
  fighter.weapon = "sword";
  fighter.attack = { kind: "melee", weapon: "sword", age: 13, duration: 44, hitIds: [] };
  fighter.action = "sword";
  fighter.actionAge = 13;
  const blade = Anim.swordBlade(Anim.poseForFighter(fighter));
  const scale = fighter.drawScale;
  assert.deepEqual(Sim.swordSegment(fighter), {
    x1: fighter.x + blade.start.x * scale,
    y1: fighter.y - 61 * scale + blade.start.y * scale,
    x2: fighter.x + blade.end.x * scale,
    y2: fighter.y - 61 * scale + blade.end.y * scale
  });
});

test("defeated fighters settle visibly on ground and raised platforms", () => {
  for (const facing of [-1, 1]) {
    const finalPose = Anim.sampleClip("defeat", Anim.CLIPS.defeat.duration, { facing });
    assert.equal(Math.max(...Anim.POINTS.map((key) => finalPose[key].y)), 61);
    for (let age = 0; age <= Anim.CLIPS.defeat.duration; age += 1) {
      const pose = Anim.sampleClip("defeat", age, { facing });
      const lowest = Math.max(...Anim.POINTS.map((key) => pose[key].y));
      assert.ok(lowest >= 61 && lowest <= 65, `defeat contact drifted to ${lowest} at age ${age}`);
    }
  }

  function swordDefeatOnSupport({ platformId, targetX, targetY }) {
    const state = Sim.createState({ seed: 21, botCount: 1 });
    const attacker = state.fighters[0];
    const target = state.fighters[1];

    for (const fighter of [attacker, target]) {
      fighter.x = targetX;
      fighter.y = targetY;
      fighter.prevX = targetX;
      fighter.prevY = targetY;
      fighter.vx = 0;
      fighter.vy = 0;
      fighter.grounded = true;
      fighter.platformId = platformId;
      fighter.invuln = 0;
    }
    attacker.x = targetX - 30;
    attacker.prevX = attacker.x;
    attacker.weapon = "sword";
    attacker.inventory.sword = true;
    target.health = 1;

    const attack = {
      id: attacker.id,
      moveX: 0,
      moveY: 0,
      aimX: 1,
      aimY: 0,
      weaponSlot: null,
      buttons: { jump: false, attack: true, pickup: false, reload: false, drop: false, rematch: false }
    };
    const neutralTarget = {
      id: target.id,
      moveX: 0,
      moveY: 0,
      aimX: -1,
      aimY: 0,
      weaponSlot: null,
      buttons: { jump: false, attack: false, pickup: false, reload: false, drop: false, rematch: false }
    };

    let defeatTick = null;
    let settledTick = null;
    let finalPoseTick = null;
    let respawnTick = null;
    for (let step = 0; step < 130; step += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [attack, neutralTarget] }, Sim.STEP);
      attack.buttons.attack = false;
      if (target.dead && defeatTick == null) defeatTick = state.tick;
      if (target.dead && target.vy === 0 && settledTick == null) settledTick = state.tick;
      if (target.dead && target.life.age >= Anim.CLIPS.defeat.duration && finalPoseTick == null) {
        finalPoseTick = state.tick;
        const support = state.arena.platforms.find((item) => item.id === platformId);
        assert.equal(target.y, support.y);
        assert.ok(target.respawn > 0);
        const pose = Anim.poseForFighter(target);
        const lowestLocalY = Math.max(...Anim.POINTS.map((key) => pose[key].y));
        const lowestWorldY = target.y - 61 * target.drawScale + lowestLocalY * target.drawScale;
        assert.ok(Math.abs(lowestWorldY - support.y) < 1e-9,
          `defeated fighter floats ${support.y - lowestWorldY}px above platform ${platformId}`);
      }
      if (defeatTick != null && !target.dead) {
        respawnTick = state.tick;
        break;
      }
    }

    assert.equal(defeatTick, 12);
    assert.equal(settledTick, 26);
    assert.equal(finalPoseTick, 52);
    assert.equal(respawnTick, 108);
    assert.equal(respawnTick - defeatTick, Sim.RULES.respawnTicks);
    assert.equal(attacker.score, 1);
    assert.equal(target.deaths, 1);
    assert.deepEqual(target.life, { kind: "respawn", age: 0 });
    assert.equal(target.respawnVisual, 24);
    assert.equal(target.grounded, true);
    assertSafeSpawn(state, target);
  }

  for (const fixture of [
    { platformId: 0, targetX: 500, targetY: 880 },
    { platformId: 2, targetX: 960, targetY: 630 }
  ]) swordDefeatOnSupport(fixture);
});

test("ground jumps reach both lowest pickup platforms", () => {
  for (const route of [
    { x: 345, groundId: 0, platformId: 1 },
    { x: 1575, groundId: 7, platformId: 3 }
  ]) {
    const state = Sim.createState({ seed: 12, botCount: 1 });
    const fighter = state.fighters[0];
    fighter.x = route.x;
    fighter.y = state.arena.groundY;
    fighter.prevX = fighter.x;
    fighter.prevY = fighter.y;
    fighter.vx = 0;
    fighter.vy = 0;
    fighter.grounded = true;
    fighter.platformId = route.groundId;
    const input = neutralHuman(state);
    input.buttons.jump = true;
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
    input.buttons.jump = false;
    let minimumY = fighter.y;
    for (let tick = 0; tick < 120 && fighter.platformId !== route.platformId; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
      minimumY = Math.min(minimumY, fighter.y);
    }
    const platform = state.arena.platforms.find((candidate) => candidate.id === route.platformId);
    assert.ok(minimumY < platform.y, `jump only reached y=${minimumY} for platform ${route.platformId}`);
    assert.equal(fighter.platformId, route.platformId, `fighter did not land on platform ${route.platformId}`);
    assert.equal(fighter.y, platform.y);
  }
});

test("drop input alone passes through raised supports but never solid ground", () => {
  function placeOnPlatform(fighter, platform) {
    fighter.x = platform.x + platform.w * 0.5;
    fighter.y = platform.y;
    fighter.prevX = fighter.x;
    fighter.prevY = fighter.y;
    fighter.vx = 0;
    fighter.vy = 0;
    fighter.grounded = true;
    fighter.platformId = platform.id;
    fighter.dropThrough = 0;
    fighter.prevButtons = {
      jump: false,
      attack: false,
      pickup: false,
      reload: false,
      drop: false,
      rematch: false
    };
  }

  for (const platformId of [1, 2, 3, 4, 5, 6, 8]) {
    const state = Sim.createState({ seed: 1200 + platformId, botCount: 1 });
    const fighter = state.fighters[0];
    const platform = state.arena.platforms.find((candidate) => candidate.id === platformId);
    placeOnPlatform(fighter, platform);
    const input = neutralHuman(state);
    input.moveY = 1;
    input.buttons.drop = true;

    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);

    assert.equal(input.buttons.jump, false, `platform ${platformId} unexpectedly required Jump`);
    assert.equal(fighter.grounded, false, `fighter stayed grounded on raised platform ${platformId}`);
    assert.equal(fighter.platformId, null);
    assert.ok(fighter.y > platform.y, `fighter did not move below raised platform ${platformId}`);
    assert.ok(fighter.vy > 0, `fighter did not begin falling through platform ${platformId}`);
    assert.ok(fighter.dropThrough > 0);
  }

  for (const platformId of [0, 7]) {
    const state = Sim.createState({ seed: 1300 + platformId, botCount: 1 });
    const fighter = state.fighters[0];
    const platform = state.arena.platforms.find((candidate) => candidate.id === platformId);
    placeOnPlatform(fighter, platform);
    const input = neutralHuman(state);
    input.moveY = 1;
    input.buttons.drop = true;

    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);

    assert.equal(fighter.grounded, true, `fighter dropped through solid ground ${platformId}`);
    assert.equal(fighter.platformId, platformId);
    assert.equal(fighter.y, platform.y);
    assert.equal(fighter.vy, 0);
    assert.equal(fighter.dropThrough, 0);
  }
});

test("held drop is edge-triggered and cannot cascade through stacked platforms", () => {
  const state = Sim.createState({ seed: 1408, botCount: 1 });
  const fighter = state.fighters[0];
  const top = state.arena.platforms.find((candidate) => candidate.id === 6);
  const middle = state.arena.platforms.find((candidate) => candidate.id === 2);
  fighter.x = 830;
  fighter.y = top.y;
  fighter.prevX = fighter.x;
  fighter.prevY = fighter.y;
  fighter.vx = 0;
  fighter.vy = 0;
  fighter.grounded = true;
  fighter.platformId = top.id;
  fighter.dropThrough = 0;
  fighter.prevButtons = {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false
  };
  const input = neutralHuman(state);
  input.moveY = 1;
  input.buttons.drop = true;

  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  assert.equal(fighter.grounded, false);

  for (let tick = 0; tick < 120 && !fighter.grounded; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  }
  assert.equal(fighter.grounded, true, "fighter never landed on the next stacked platform");
  assert.equal(fighter.platformId, middle.id);
  assert.equal(fighter.y, middle.y);

  for (let tick = 0; tick < 45; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  }
  assert.equal(fighter.grounded, true, "held Down cascaded through another platform");
  assert.equal(fighter.platformId, middle.id);
  assert.equal(fighter.y, middle.y);

  input.buttons.drop = false;
  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  input.buttons.drop = true;
  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  assert.equal(fighter.grounded, false, "release and re-press did not create a new drop edge");
  assert.ok(fighter.y > middle.y);
});

test("bot drop command uses the same independent simulation input", () => {
  const state = Sim.createState({ seed: 1515, botCount: 1 });
  for (const pickup of state.pickups) pickup.active = false;
  const player = state.fighters[0];
  const bot = state.fighters[1];
  const middle = state.arena.platforms.find((candidate) => candidate.id === 2);
  const top = state.arena.platforms.find((candidate) => candidate.id === 6);

  player.x = 960;
  player.y = middle.y;
  player.prevX = player.x;
  player.prevY = player.y;
  player.vx = 0;
  player.vy = 0;
  player.grounded = true;
  player.platformId = middle.id;

  bot.x = 960;
  bot.y = top.y;
  bot.prevX = bot.x;
  bot.prevY = bot.y;
  bot.vx = 0;
  bot.vy = 0;
  bot.grounded = true;
  bot.platformId = top.id;
  bot.dropThrough = 0;
  bot.prevButtons = {
    jump: false,
    attack: false,
    pickup: false,
    reload: false,
    drop: false,
    rematch: false
  };

  const botInput = Bots.makeBotInput(state, bot);
  assert.equal(botInput.buttons.drop, true);
  assert.equal(botInput.buttons.jump, false);
  Sim.fixedUpdate(state, {
    tick: state.tick,
    actors: [neutralHuman(state), botInput]
  }, Sim.STEP);

  assert.equal(bot.grounded, false);
  assert.equal(bot.platformId, null);
  assert.ok(bot.y > top.y);
  assert.ok(bot.dropThrough > 0);
});

test("unarmed contact follows the complete visible punching arm", () => {
  const state = Sim.createState({ seed: 13, botCount: 1 });
  const attacker = state.fighters[0];
  attacker.x = 500;
  attacker.y = 880;
  attacker.facing = 1;
  attacker.weapon = "unarmed";
  attacker.attack = { kind: "melee", weapon: "unarmed", age: 8, duration: 30, hitIds: [] };
  attacker.action = "unarmed";
  attacker.actionAge = 8;
  attacker.anim = "unarmed";
  attacker.animTick = 8;
  const pose = Anim.poseForFighter(attacker);
  const strike = Sim.unarmedSegment(attacker);
  const scale = attacker.drawScale;
  assert.deepEqual(strike, {
    x1: attacker.x + pose.shoulder.x * scale,
    y1: attacker.y - 61 * scale + pose.shoulder.y * scale,
    x2: attacker.x + pose.wristR.x * scale,
    y2: attacker.y - 61 * scale + pose.wristR.y * scale
  });
});

test("overlapping unarmed attacks hit once without striking behind", () => {
  function attackResult(weapon, facing, targetOffset) {
    const state = Sim.createState({ seed: 14, botCount: 1 });
    const attacker = state.fighters[0];
    const target = state.fighters[1];
    attacker.x = 500;
    attacker.y = 880;
    attacker.prevX = attacker.x;
    attacker.prevY = attacker.y;
    attacker.facing = facing;
    attacker.weapon = weapon;
    attacker.invuln = 0;
    attacker.grounded = true;
    attacker.platformId = 0;
    target.x = attacker.x + facing * targetOffset;
    target.y = attacker.y;
    target.prevX = target.x;
    target.prevY = target.y;
    target.invuln = 0;
    target.vx = 0;
    target.vy = 0;
    target.grounded = true;
    target.platformId = 0;
    const input = neutralHuman(state);
    input.aimX = facing;
    input.buttons.attack = true;
    Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
    let hitEvents = state.events.filter((event) => event.type === "hit" && event.fighterId === target.id).length;
    input.buttons.attack = false;
    for (let tick = 0; tick < Sim.WEAPONS[weapon].duration + 3; tick += 1) {
      Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
      hitEvents += state.events.filter((event) => event.type === "hit" && event.fighterId === target.id).length;
    }
    return { health: target.health, hitEvents };
  }
  for (const facing of [-1, 1]) {
    assert.deepEqual(attackResult("unarmed", facing, 0), { health: 90, hitEvents: 1 }, `exact overlap failed facing ${facing}`);
    assert.deepEqual(attackResult("unarmed", facing, 20), { health: 90, hitEvents: 1 }, `forward overlap failed facing ${facing}`);
    assert.deepEqual(attackResult("unarmed", facing, -40), { health: 100, hitEvents: 0 }, `behind target was hit facing ${facing}`);
    assert.deepEqual(attackResult("sword", facing, 0), { health: 76, hitEvents: 1 }, `sword overlap regressed facing ${facing}`);
    assert.deepEqual(attackResult("sword", facing, -40), { health: 100, hitEvents: 0 }, `sword hit behind facing ${facing}`);
  }
});

test("hazard surface and damage begin below the floor", () => {
  const state = Sim.createState({ seed: 15, botCount: 1 });
  const hazard = state.arena.hazards[0];
  assert.ok(hazard.y >= state.arena.groundY + 25);
  assert.equal(hazard.y + hazard.h, state.arena.height);
  const fighter = state.fighters[0];
  fighter.x = hazard.x + hazard.w / 2;
  fighter.y = hazard.y - 1;
  fighter.prevX = fighter.x;
  fighter.prevY = fighter.y;
  fighter.vx = 0;
  fighter.vy = 0;
  fighter.grounded = false;
  fighter.platformId = null;
  fighter.invuln = 0;
  const input = neutralHuman(state);
  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  assert.equal(fighter.health, fighter.maxHealth, "hazard damaged above its visible surface");
  Sim.fixedUpdate(state, { tick: state.tick, actors: [input] }, Sim.STEP);
  assert.equal(fighter.health, fighter.maxHealth - hazard.damage, "hazard did not damage below its visible surface");
});

test("every authored hazard damages from its own deterministic center", () => {
  const state = Sim.createState({ seed: 0x10ca7a13, botCount: 1 });
  state.arena.platforms = [];
  state.arena.hazards = [
    { id: 20, kind: "energy", x: 100, y: 900, w: 100, h: 180, damage: 5 },
    { id: 21, kind: "energy", x: 500, y: 900, w: 100, h: 180, damage: 7 }
  ];
  for (const [fighter, x] of [[state.fighters[0], 125], [state.fighters[1], 575]]) {
    Object.assign(fighter, {
      x, prevX: x, y: 950, prevY: 950,
      vx: 0, vy: 0, grounded: false, prevGrounded: false,
      platformId: null, invuln: 0, hurtCooldown: 0, hazardCooldown: 0
    });
  }
  Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
  assert.deepEqual(state.fighters.map((fighter) => fighter.health), [95, 93]);
  assert.ok(state.fighters[0].vx < 0, "left-half hazard knockback ignored its center");
  assert.ok(state.fighters[1].vx > 0, "right-half hazard knockback ignored its center");
  assert.deepEqual(state.events.filter((event) => event.type === "hazard").map((event) => event.fighterId), [0, 1]);
});

test("semiautomatic guns require new presses while held rifle fire follows its exact cadence", () => {
  function cadenceFixture(weapon, frames) {
    const state = Sim.createState({ seed: 0x505000 + Sim.WEAPONS[weapon].slot, botCount: 1 });
    state.arena.hazards = [];
    state.pickups.forEach((pickup) => { pickup.active = false; });
    const shooter = state.fighters[0];
    Object.assign(shooter, {
      x: 200, prevX: 200, y: 630, prevY: 630,
      vx: 0, vy: 0, grounded: true, platformId: 2,
      invuln: 0, facing: 1, aimFacing: 1, aimStep: 0
    });
    Sim.grantWeapon(shooter, weapon, true);
    shooter.weapon = weapon;
    const actor = neutralActor(shooter);
    const fireTicks = [];
    for (let index = 0; index < frames.length; index += 1) {
      actor.buttons.attack = frames[index];
      Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
      if (state.events.some((event) => event.type === "fire" && event.fighterId === shooter.id)) {
        fireTicks.push(state.tick);
      }
    }
    return { state, shooter, fireTicks };
  }

  for (const weapon of ["pistol", "shotgun"]) {
    const held = cadenceFixture(weapon, Array(Sim.WEAPONS[weapon].cooldown + 20).fill(true));
    assert.deepEqual(held.fireTicks, [1], `${weapon} repeated without a new press edge`);

    const pulse = [true, ...Array(Sim.WEAPONS[weapon].cooldown - 1).fill(false), true];
    const pulsed = cadenceFixture(weapon, pulse);
    assert.deepEqual(pulsed.fireTicks, [1, 1 + Sim.WEAPONS[weapon].cooldown],
      `${weapon} legal pulse cadence drifted`);
  }

  const rifle = cadenceFixture("rifle", Array(1 + Sim.WEAPONS.rifle.cooldown * 6).fill(true));
  assert.deepEqual(rifle.fireTicks.slice(0, 7), [1, 6, 11, 16, 21, 26, 31]);
  assert.ok(rifle.fireTicks.every((tick, index) => index === 0
    || tick - rifle.fireTicks[index - 1] === Sim.WEAPONS.rifle.cooldown));
});

test("rifle magazine exhaustion and reload remain atomic under canonical held input", () => {
  const state = Sim.createState({ seed: 0x515151, botCount: 1 });
  state.arena.hazards = [];
  state.pickups.forEach((pickup) => { pickup.active = false; });
  const fighter = state.fighters[0];
  Sim.grantWeapon(fighter, "rifle", true);
  fighter.weapon = "rifle";
  const actor = neutralActor(fighter);
  actor.buttons.attack = true;
  const fireTicks = [];
  let reloadStartTick = null;
  for (let tick = 0; tick < 240 && reloadStartTick == null; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    if (state.events.some((event) => event.type === "fire" && event.fighterId === fighter.id)) {
      fireTicks.push(state.tick);
    }
    if (state.events.some((event) => event.type === "reloadStart" && event.fighterId === fighter.id)) {
      reloadStartTick = state.tick;
    }
  }
  assert.equal(fireTicks.length, Sim.WEAPONS.rifle.mag);
  assert.equal(fighter.ammo.rifle.mag, 0);
  assert.equal(fighter.ammo.rifle.reserve, Sim.WEAPONS.rifle.reserve);
  assert.ok(fireTicks.every((tick, index) => index === 0
    || tick - fireTicks[index - 1] === Sim.WEAPONS.rifle.cooldown));
  assert.equal(reloadStartTick, fireTicks.at(-1) + 13,
    "empty automatic fire must finish its visible recoil before reloading");
  assert.equal(fighter.reload, Sim.WEAPONS.rifle.reload);

  actor.buttons.attack = false;
  for (let elapsed = 0; elapsed < Sim.WEAPONS.rifle.reload; elapsed += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
  }
  assert.equal(fighter.reload, 0);
  assert.deepEqual(fighter.ammo.rifle, { mag: 36, reserve: 72 });
  assert.equal(state.events.filter((event) => event.type === "reload").length, 1);
});

test("empty firearms emit dry fire without manufacturing or underflowing ammunition", () => {
  for (const weapon of ["pistol", "shotgun", "rifle"]) {
    const state = Sim.createState({ seed: 0x515200 + Sim.WEAPONS[weapon].slot, botCount: 1 });
    const fighter = state.fighters[0];
    Sim.grantWeapon(fighter, weapon, true);
    fighter.weapon = weapon;
    fighter.ammo[weapon] = { mag: 0, reserve: 0 };
    const actor = neutralActor(fighter);
    actor.buttons.attack = true;
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    assert.equal(state.events.filter((event) => event.type === "dryFire"
      && event.fighterId === fighter.id && event.weapon === weapon).length, 1);
    assert.deepEqual(fighter.ammo[weapon], { mag: 0, reserve: 0 });
    assert.equal(state.projectiles.some((projectile) => projectile.ownerId === fighter.id), false);
  }
});

test("shotgun falloff is deterministic and scales accepted knockback with damage", () => {
  const data = Sim.WEAPONS.shotgun;
  const epsilon = 0.001;
  const beforeStart = Sim.shotgunImpactAtDistance(data.falloffStart - epsilon, data.damage);
  const atStart = Sim.shotgunImpactAtDistance(data.falloffStart, data.damage);
  const afterStart = Sim.shotgunImpactAtDistance(data.falloffStart + epsilon, data.damage);
  const beforeEnd = Sim.shotgunImpactAtDistance(data.falloffEnd - epsilon, data.damage);
  const atEnd = Sim.shotgunImpactAtDistance(data.falloffEnd, data.damage);
  const afterEnd = Sim.shotgunImpactAtDistance(data.falloffEnd + epsilon, data.damage);
  assert.equal(beforeStart.scale, 1);
  assert.equal(atStart.scale, 1);
  assert.ok(afterStart.scale < 1);
  assert.ok(beforeEnd.scale > data.minDamageScale);
  assert.ok(Math.abs(atEnd.scale - data.minDamageScale) < 1e-12);
  assert.ok(Math.abs(afterEnd.scale - data.minDamageScale) < 1e-12);
  assert.deepEqual({ damage: atStart.damage, acceptedScale: atStart.acceptedScale }, {
    damage: 4, acceptedScale: 1
  });
  assert.deepEqual({ damage: atEnd.damage, acceptedScale: atEnd.acceptedScale }, {
    damage: 1, acceptedScale: 0.25
  });

  function impactAtAge(fullTravelTicks, missingGroup = false) {
    const state = Sim.createState({ seed: 0x525200 + fullTravelTicks, botCount: 1 });
    state.arena.hazards = [];
    state.pickups.forEach((pickup) => { pickup.active = false; });
    const shooter = state.fighters[0];
    const target = state.fighters[1];
    Object.assign(shooter, { x: 760, prevX: 760, y: 630, prevY: 630, invuln: 999 });
    Object.assign(target, {
      x: 1000, prevX: 1000, y: 630, prevY: 630,
      vx: 0, vy: 0, grounded: true, platformId: 2,
      invuln: 0, hurtCooldown: 0
    });
    const groupId = missingGroup ? null : state.nextEntityId++;
    const stepDistance = data.speed * Sim.STEP;
    if (!missingGroup) {
      state.shotGroups[groupId] = { cap: data.shotCap, remaining: 1, born: 1 - fullTravelTicks };
    }
    state.projectiles.push({
      id: state.nextEntityId++, ownerId: shooter.id, weapon: "shotgun", groupId,
      x: target.x - (Sim.RULES.fighterRadius + 3) - stepDistance * 0.5,
      y: target.y - 68, prevX: 0, prevY: 0,
      vx: data.speed, vy: 0, life: missingGroup ? data.life - fullTravelTicks : data.life,
      damage: data.damage, knockback: data.knockback, hitstun: data.hitstun
    });
    Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
    const hit = state.events.find((event) => event.type === "hit" && event.weapon === "shotgun");
    return { hit, target };
  }

  const close = impactAtAge(4);
  const middle = impactAtAge(15);
  const far = impactAtAge(25);
  const fallbackFar = impactAtAge(25, true);
  assert.deepEqual([close.hit.damage, middle.hit.damage, far.hit.damage], [4, 3, 1]);
  assert.equal(fallbackFar.hit.damage, far.hit.damage,
    "missing-group projectile-life fallback changed far damage");
  assert.ok(close.hit.damage > middle.hit.damage && middle.hit.damage > far.hit.damage);
  assert.ok(Math.abs(close.target.vx - 135) < 1e-9);
  assert.ok(Math.abs(middle.target.vx - 101.25) < 1e-9);
  assert.ok(Math.abs(far.target.vx - 33.75) < 1e-9);
  assert.ok(Math.abs(fallbackFar.target.vx - far.target.vx) < 1e-9);
});

test("stored shotgun caps guard same-step aggregation while one canonical trigger stays at or below 32", () => {
  function fixture({ cap, delays }) {
    const state = Sim.createState({ seed: 0x535353 + cap + delays.length, botCount: 1 });
    state.arena.hazards = [];
    state.pickups.forEach((pickup) => { pickup.active = false; });
    const shooter = state.fighters[0];
    const target = state.fighters[1];
    Object.assign(shooter, { x: 760, prevX: 760, y: 630, prevY: 630, invuln: 999 });
    Object.assign(target, {
      x: 1000, prevX: 1000, y: 630, prevY: 630,
      vx: 0, vy: 0, grounded: true, platformId: 2,
      health: 100, invuln: 0, hurtCooldown: 0
    });
    const data = Sim.WEAPONS.shotgun;
    const groupId = state.nextEntityId++;
    const stepDistance = data.speed * Sim.STEP;
    state.shotGroups[groupId] = { cap, remaining: delays.length, born: 1 };
    for (const delay of delays) {
      state.projectiles.push({
        id: state.nextEntityId++, ownerId: shooter.id, weapon: "shotgun", groupId,
        x: target.x - (Sim.RULES.fighterRadius + 3) - stepDistance * (delay + 0.5),
        y: target.y - 68, prevX: 0, prevY: 0,
        vx: data.speed, vy: 0, life: data.life,
        damage: data.damage, knockback: 0, hitstun: data.hitstun
      });
    }
    const hits = [];
    for (let tick = 0; tick <= Math.max(...delays) + 1; tick += 1) {
      Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
      for (const event of state.events) {
        if (event.type === "hit" && event.weapon === "shotgun") {
          hits.push({ tick: state.tick, damage: event.damage });
        }
      }
    }
    return { state, target, hits };
  }

  const storedCap = fixture({ cap: 7, delays: [0, 0] });
  assert.deepEqual(storedCap.hits, [{ tick: 1, damage: 7 }]);
  assert.equal(storedCap.target.health, 93);

  const splitCustomCap = fixture({ cap: 7, delays: [0, 0, 2, 2] });
  assert.deepEqual(splitCustomCap.hits, [{ tick: 1, damage: 7 }, { tick: 3, damage: 7 }],
    "stored group cap unexpectedly became a new cross-tick budget field");

  const staggered = fixture({ cap: 32, delays: [0, 0, 0, 0, 2, 2, 2, 2] });
  assert.deepEqual(staggered.hits, [{ tick: 1, damage: 16 }, { tick: 3, damage: 16 }]);
  assert.equal(staggered.hits.reduce((sum, hit) => sum + hit.damage, 0), Sim.WEAPONS.shotgun.shotCap);
  assert.equal(staggered.target.health, 68);
  assert.equal(staggered.target.dead, false);
});

test("pistol and rifle projectile damage do not inherit shotgun distance falloff", () => {
  function impact(weapon, remainingLife) {
    const state = Sim.createState({ seed: 0x545400 + remainingLife + Sim.WEAPONS[weapon].slot, botCount: 1 });
    state.arena.hazards = [];
    const shooter = state.fighters[0];
    const target = state.fighters[1];
    Object.assign(shooter, { x: 760, prevX: 760, y: 630, prevY: 630, invuln: 999 });
    Object.assign(target, {
      x: 1000, prevX: 1000, y: 630, prevY: 630,
      vx: 0, vy: 0, grounded: true, platformId: 2,
      invuln: 0, hurtCooldown: 0
    });
    const data = Sim.WEAPONS[weapon];
    const stepDistance = data.speed * Sim.STEP;
    state.projectiles.push({
      id: state.nextEntityId++, ownerId: shooter.id, weapon, groupId: null,
      x: target.x - (Sim.RULES.fighterRadius + 3) - stepDistance * 0.5,
      y: target.y - 68, prevX: 0, prevY: 0,
      vx: data.speed, vy: 0, life: remainingLife,
      damage: data.damage, knockback: data.knockback, hitstun: data.hitstun
    });
    Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
    return state.events.find((event) => event.type === "hit" && event.weapon === weapon).damage;
  }

  for (const weapon of ["pistol", "rifle"]) {
    assert.equal(impact(weapon, Sim.WEAPONS[weapon].life), Sim.WEAPONS[weapon].damage);
    assert.equal(impact(weapon, 2), Sim.WEAPONS[weapon].damage);
  }
});

test("grenade area damage is monotonic, bounded, and requires three center blasts", () => {
  function blast(distance, count = 1) {
    const state = Sim.createState({ seed: 0x555500 + Math.round(distance * 10) + count, botCount: 1 });
    state.arena.hazards = [];
    state.pickups.forEach((pickup) => { pickup.active = false; });
    const owner = state.fighters[0];
    const target = state.fighters[1];
    Object.assign(owner, { x: 760, prevX: 760, y: 630, prevY: 630, invuln: 999 });
    Object.assign(target, {
      x: 1000, prevX: 1000, y: 630, prevY: 630,
      vx: 0, vy: 0, grounded: true, platformId: 2,
      health: 100, invuln: 0, hurtCooldown: 0
    });
    for (let index = 0; index < count; index += 1) {
      state.grenades.push({
        id: state.nextEntityId++, ownerId: owner.id,
        x: target.x - distance, y: target.y - 78,
        prevX: target.x - distance, prevY: target.y - 78,
        vx: 0, vy: -Sim.RULES.gravity * Sim.STEP,
        fuse: 1, bounces: 0, radius: 10
      });
    }
    Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
    return {
      target,
      damage: state.events
        .filter((event) => event.type === "hit" && event.weapon === "grenade")
        .reduce((sum, event) => sum + event.damage, 0),
      explosions: state.events.filter((event) => event.type === "explosion").length
    };
  }

  assert.equal(blast(0).damage, 48);
  assert.equal(blast(95).damage, 32);
  assert.equal(blast(Sim.WEAPONS.grenade.radius).damage, 17);
  assert.equal(blast(Sim.WEAPONS.grenade.radius + 0.1).damage, 0);
  const two = blast(0, 2);
  assert.equal(two.damage, 96);
  assert.equal(two.target.health, 4);
  assert.equal(two.target.dead, false);
  const three = blast(0, 3);
  assert.equal(three.damage, 144);
  assert.equal(three.target.health, 0);
  assert.equal(three.target.dead, true);
  assert.equal(three.explosions, 3);
});

test("grenade release and shorter fuse remain exact fixed-step events", () => {
  const state = Sim.createState({ seed: 0x565656, botCount: 1 });
  state.arena.hazards = [];
  const fighter = state.fighters[0];
  Sim.grantWeapon(fighter, "grenade", true);
  fighter.weapon = "grenade";
  fighter.invuln = 999;
  state.fighters[1].invuln = 999;
  const actor = neutralActor(fighter);
  actor.aimX = 0.8;
  actor.aimY = -0.6;
  actor.buttons.attack = true;
  let releaseTick = null;
  let explosionTick = null;
  for (let tick = 0; tick < 180 && explosionTick == null; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [actor] }, Sim.STEP);
    actor.buttons.attack = false;
    if (state.events.some((event) => event.type === "grenadeThrow")) releaseTick = state.tick;
    if (state.events.some((event) => event.type === "explosion")) explosionTick = state.tick;
  }
  assert.equal(releaseTick, 1 + Sim.WEAPONS.grenade.releaseAge);
  assert.equal(explosionTick, 136);
  assert.equal(explosionTick - releaseTick, Sim.WEAPONS.grenade.fuse - 1);
  assert.equal(fighter.ammo.grenade.count, 2);
});

test("shotgun cannot defeat a full-health fighter in one shot", () => {
  const state = Sim.createState({ seed: 4, botCount: 1 });
  const shooter = state.fighters[0];
  const target = state.fighters[1];
  shooter.x = 420;
  shooter.y = 880;
  shooter.weapon = "shotgun";
  Sim.grantWeapon(shooter, "shotgun", true);
  shooter.invuln = 0;
  target.x = 555;
  target.y = 880;
  target.invuln = 0;
  target.vx = 0;
  const attack = {
    id: shooter.id,
    moveX: 0,
    moveY: 0,
    aimX: 1,
    aimY: 0,
    weaponSlot: null,
    buttons: { jump: false, attack: true, pickup: false, reload: false, drop: false }
  };
  Sim.fixedUpdate(state, { tick: state.tick, actors: [attack] }, Sim.STEP);
  attack.buttons.attack = false;
  let acceptedDamage = state.events
    .filter((event) => event.type === "hit" && event.weapon === "shotgun")
    .reduce((sum, event) => sum + event.damage, 0);
  for (let tick = 0; tick < 34; tick += 1) {
    Sim.fixedUpdate(state, { tick: state.tick, actors: [attack] }, Sim.STEP);
    acceptedDamage += state.events
      .filter((event) => event.type === "hit" && event.weapon === "shotgun")
      .reduce((sum, event) => sum + event.damage, 0);
  }
  assert.ok(acceptedDamage <= Sim.WEAPONS.shotgun.shotCap,
    `one trigger dealt ${acceptedDamage} across its lifetime`);
  assert.ok(target.health > 0 && target.health < 100, `shotgun left ${target.health} health`);
});

test("regulation lasts exactly 10,800 steps and never ends at five points", () => {
  const state = Sim.createState({ seed: 0x300, botCount: 1 });
  const frame = Sim.createInputFrame(state);
  assert.equal(Sim.VERSION, 6);
  assert.equal(Sim.RULES.timeLimitTicks, 60 * 180);
  assert.equal(Sim.RULES.timeLimitTicks,
    Sim.MODE_CATALOG[Sim.DEFAULT_MODE_ID].rules.regulationTicks);
  assert.equal(Object.prototype.hasOwnProperty.call(Sim.RULES, "scoreLimit"), false);
  assert.equal(Object.prototype.hasOwnProperty.call(state.config, "scoreLimit"), false);
  assert.equal(state.match.ticksRemaining, 10800);

  state.fighters[0].score = 5;
  for (let tick = 0; tick < Sim.RULES.timeLimitTicks - 1; tick += 1) {
    Sim.fixedUpdate(state, frame, Sim.STEP);
  }
  assert.equal(state.tick, 10799);
  assert.equal(state.match.ticksRemaining, 1);
  assert.equal(state.match.phase, "playing");

  Sim.fixedUpdate(state, frame, Sim.STEP);
  assert.equal(state.tick, 10800);
  assert.deepEqual(state.match, {
    phase: "finished", ticksRemaining: 0, winnerId: 0, reason: "time"
  });
  assert.equal(state.events.filter((event) => event.type === "matchEnd").length, 1);

  for (const version of [4, 3]) {
    const legacy = JSON.parse(Sim.serialize(state));
    legacy.version = version;
    assert.throws(() => Sim.deserialize(legacy), /unsupported serialized state/);
    assert.throws(() => Sim.fixedUpdate(legacy, frame, Sim.STEP), /incompatible or missing state/);
  }
});

test("regulation winner and draw use highest score only", () => {
  function finish(scores, deaths) {
    const state = Sim.createState({ seed: 0x301, botCount: 3 });
    state.match.ticksRemaining = 1;
    state.fighters.forEach((fighter, index) => {
      fighter.score = scores[index];
      fighter.deaths = deaths[index];
    });
    Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
    return state;
  }

  const unique = finish([4, 8, 7, 2], [0, 9, 0, 0]);
  assert.deepEqual(unique.match, {
    phase: "finished", ticksRemaining: 0, winnerId: 1, reason: "time"
  });
  assert.equal(unique.events.filter((event) => event.type === "matchEnd").length, 1);

  const tied = finish([6, 6, 4, 1], [9, 0, 0, 0]);
  assert.deepEqual(tied.match, {
    phase: "finished", ticksRemaining: 0, winnerId: null, reason: "draw"
  });
  assert.equal(tied.events.filter((event) => event.type === "matchEnd").length, 1);
});

test("final-step combat resolves before one match result", () => {
  const state = Sim.createState({ seed: 0x302, botCount: 1 });
  state.match.ticksRemaining = 1;
  const attacker = state.fighters[0];
  const victim = state.fighters[1];
  for (const [fighter, x] of [[attacker, 500], [victim, 600]]) {
    fighter.x = x;
    fighter.y = 880;
    fighter.prevX = x;
    fighter.prevY = 880;
    fighter.vx = 0;
    fighter.vy = 0;
    fighter.grounded = true;
    fighter.platformId = 0;
    fighter.invuln = 0;
    fighter.hurtCooldown = 0;
  }
  attacker.score = 1;
  victim.score = 2;
  victim.health = 1;
  state.projectiles.push({
    id: state.nextEntityId++,
    ownerId: attacker.id,
    weapon: "pistol",
    groupId: null,
    x: 560,
    y: 812,
    prevX: 560,
    prevY: 812,
    vx: 1200,
    vy: 0,
    life: 2,
    damage: Sim.WEAPONS.pistol.damage,
    knockback: Sim.WEAPONS.pistol.knockback,
    hitstun: Sim.WEAPONS.pistol.hitstun
  });

  Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);

  assert.equal(victim.dead, true);
  assert.deepEqual(state.fighters.map((fighter) => fighter.score), [2, 2]);
  assert.deepEqual(state.match, {
    phase: "finished", ticksRemaining: 0, winnerId: null, reason: "draw"
  });
  assert.deepEqual(state.events.map((event) => event.type), ["bulletHit", "hit", "defeat", "matchEnd"]);

  let matchEndCount = state.events.filter((event) => event.type === "matchEnd").length;
  for (let tick = 0; tick < 3; tick += 1) {
    Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
    matchEndCount += state.events.filter((event) => event.type === "matchEnd").length;
  }
  assert.equal(matchEndCount, 1);
  assert.equal(state.match.ticksRemaining, 0);
  assert.equal(state.match.phase, "finished");
});

test("rematch immediately resets the complete regulation state", () => {
  const state = Sim.createState({ seed: 0x303, botCount: 1 });
  state.match.ticksRemaining = 1;
  state.fighters[0].score = 3;
  state.fighters[1].score = 1;
  Sim.fixedUpdate(state, Sim.createInputFrame(state), Sim.STEP);
  assert.equal(state.match.phase, "finished");

  const rematch = Sim.createInputFrame(state);
  rematch.actors[0].buttons.rematch = true;
  Sim.fixedUpdate(state, rematch, Sim.STEP);

  assert.equal(state.tick, 0);
  assert.equal(state.match.ticksRemaining, Sim.RULES.timeLimitTicks);
  assert.equal(state.config.modeId, Sim.DEFAULT_MODE_ID);
  assert.equal(state.config.mapId, Sim.DEFAULT_MAP_ID);
  assert.deepEqual(state.match, {
    phase: "playing", ticksRemaining: 10800, winnerId: null, reason: null
  });
  assert.deepEqual(state.fighters.map((fighter) => [fighter.score, fighter.deaths]), [[0, 0], [0, 0]]);
  assert.deepEqual(state.events, []);
  assert.equal(Sim.serialize(state), Sim.serialize(Sim.createState({ seed: 0x303, botCount: 1 })));
});

test("bot-controlled matches complete full regulation", () => {
  const observedFirearms = new Set();
  let observedGrenade = false;
  let observedHealth = false;
  for (const seed of [1, 2, 3]) {
    const state = Sim.createState({ seed, botCount: 3 });
    let collectedWeapon = false;
    let matchEndCount = 0;
    while (state.match.phase === "playing" && state.tick <= Sim.RULES.timeLimitTicks) {
      Sim.fixedUpdate(state, allBots(state), Sim.STEP);
      collectedWeapon ||= state.fighters.some((fighter) => fighter.weapon !== "unarmed");
      matchEndCount += state.events.filter((event) => event.type === "matchEnd").length;
      for (const event of state.events) {
        if (event.type === "fire") observedFirearms.add(event.weapon);
        if (event.type === "grenadeThrow") observedGrenade = true;
        if (event.type === "pickup" && event.kind === "health") observedHealth = true;
      }
    }
    const highScore = Math.max(...state.fighters.map((fighter) => fighter.score));
    const leaders = state.fighters.filter((fighter) => fighter.score === highScore);
    assert.equal(state.match.phase, "finished", `seed ${seed} did not finish`);
    assert.equal(state.tick, Sim.RULES.timeLimitTicks, `seed ${seed} ended before 0:00`);
    assert.equal(state.match.ticksRemaining, 0);
    assert.ok(highScore >= 5, `seed ${seed} did not demonstrate play beyond five points`);
    assert.equal(collectedWeapon, true, `seed ${seed} never collected a weapon`);
    assert.equal(matchEndCount, 1, `seed ${seed} emitted ${matchEndCount} match results`);
    assert.equal(state.match.reason, leaders.length === 1 ? "time" : "draw");
    assert.equal(state.match.winnerId, leaders.length === 1 ? leaders[0].id : null);
  }
  assert.deepEqual([...observedFirearms].sort(), ["pistol", "rifle", "shotgun"]);
  assert.equal(observedGrenade, true, "full bot regulation never produced a grenade throw");
  assert.equal(observedHealth, true, "full bot regulation never collected health");
});

test("live poses stay finite and transient collections stay bounded", () => {
  const state = Sim.createState({ seed: 11, botCount: 3 });
  let maxProjectiles = 0;
  let maxGrenades = 0;
  let maxShotGroups = 0;
  let maxEvents = 0;
  for (let tick = 0; tick < 3600; tick += 1) {
    if (state.match.phase === "finished") Sim.resetMatch(state, { seed: state.seed });
    Sim.fixedUpdate(state, allBots(state), Sim.STEP);
    maxProjectiles = Math.max(maxProjectiles, state.projectiles.length);
    maxGrenades = Math.max(maxGrenades, state.grenades.length);
    maxShotGroups = Math.max(maxShotGroups, Object.keys(state.shotGroups).length);
    maxEvents = Math.max(maxEvents, state.events.length);
    for (const fighter of state.fighters) {
      const pose = Anim.poseForFighter(fighter);
      for (const key of Anim.POINTS) {
        assert.ok(Number.isFinite(pose[key].x) && Number.isFinite(pose[key].y));
      }
    }
  }
  assert.ok(maxProjectiles < 200, `projectiles reached ${maxProjectiles}`);
  assert.ok(maxGrenades < 30, `grenades reached ${maxGrenades}`);
  assert.ok(maxShotGroups < 30, `shot groups reached ${maxShotGroups}`);
  assert.ok(maxEvents < 100, `fixed-step events reached ${maxEvents}`);
});

test("fixedUpdate rejects variable time steps", () => {
  assert.equal(Sim.STEP, 1 / 60);
  const state = Sim.createState({ seed: 3, botCount: 1 });
  assert.throws(() => Sim.fixedUpdate(state, Sim.createInputFrame(state), 1 / 30), /1\/60/);
});
