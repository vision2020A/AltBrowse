(function (root) {
  "use strict";

  var Sim = root.StickSim;
  var Netcode = root.StickMultiplayer;
  var room = null;
  var client = null;
  var model = null;
  var connectPromise = null;
  var status = "idle";
  var statusDetail = "";
  var actorId = null;
  var epoch = null;
  var matchGeneration = null;
  var lastActorId = null;
  var lastEpoch = null;
  var started = false;
  var lifecycle = "waiting";
  var rematchOpen = false;
  var rematchVoted = false;
  var rematchVotes = 0;
  var rematchRequired = 2;
  var rematchRemainingMs = 0;
  var pendingRematchVote = null;
  var matchmakingOperation = null;
  var publicRoomCode = null;
  var lastSnapshotAt = 0;
  var resyncRequested = false;
  var connectionGeneration = 0;
  var needsFreshNeutral = false;
  var serverCompatibility = null;
  var assignmentAccepted = false;
  var readySent = false;
  var sdkPromise = null;
  var UPDATE_REQUIRED_DETAIL = "CLIENT/SERVER UPDATE REQUIRED — RELOAD";
  var CONNECTION_FAILED_DETAIL = "CONNECTION FAILED — TRY AGAIN";
  var RATE_LIMIT_DETAIL = "TOO MANY ATTEMPTS — TRY AGAIN SOON";
  var MATCH_CODE_UNAVAILABLE_DETAIL = "MATCH CODE UNAVAILABLE OR EXPIRED";
  var SERVER_RESTART_DETAIL = "SERVER RESTARTING — TRY AGAIN";
  var RECONNECT_FAILED_DETAIL = "RECONNECT FAILED — START A NEW MATCH";
  var INVALID_MATCH_CODE_DETAIL = "ENTER A VALID 7-CHARACTER MATCH CODE";
  var REQUEST_CANCELED_DETAIL = "CONNECTION ATTEMPT CANCELED";
  var SERVER_RESTART_CODE = 4001;
  var FAILED_TO_RECONNECT_CODE = 4003;
  // With the exact-pinned SDK 0.18.2 defaults, attempt nine starts after a
  // nominal 26.2 seconds; attempt ten would start after the server's fixed
  // 30-second reservation. Transport time can only shorten that coverage.
  var MAX_RECONNECT_RETRIES = 9;
  var MAX_ROOM_CODE_INPUT_LENGTH = 32;
  var ROOM_CODE_PATTERN = /^[A-HJ-NP-Z2-9]{7}$/;
  var PAGES_ORIGIN = "https://xenovoyage.github.io";
  var PAGES_PATHS = Object.freeze([
    "/Stickman-Arena/",
    "/Stickman-Arena/index.html"
  ]);
  var CLOUD_SERVER_ORIGIN = "https://de-fra-1131bd95.colyseus.cloud";

  var LOCAL_PREDICTION_FIELDS = Object.freeze([
    "x", "y", "prevX", "prevY", "vx", "vy", "prevVx", "prevVy",
    "facing", "prevFacing", "aimX", "aimY", "aimFacing", "aimStep",
    "grounded", "prevGrounded", "platformId", "dropThrough", "landTimer",
    "locomotion", "anim", "animTick", "action", "actionAge", "recoil"
  ]);

  function copy(value) {
    return value == null ? value : JSON.parse(JSON.stringify(value));
  }

  function setStatus(next, detail) {
    status = next;
    statusDetail = detail || "";
  }

  var LIFECYCLE_PHASES = Object.freeze([
    "waiting", "ready", "playing", "finished", "rematch-vote", "restarting", "closing"
  ]);

  function isPlainDataRecord(value, keys) {
    try {
      if (!value || typeof value !== "object" || Array.isArray(value)) return false;
      var prototype = Object.getPrototypeOf(value);
      if (prototype !== Object.prototype && prototype !== null) return false;
      if (Object.getOwnPropertySymbols(value).length !== 0) return false;
      var names = Object.getOwnPropertyNames(value).sort();
      var expected = keys.slice().sort();
      if (names.length !== expected.length) return false;
      for (var index = 0; index < expected.length; index += 1) {
        if (names[index] !== expected[index]) return false;
        var descriptor = Object.getOwnPropertyDescriptor(value, expected[index]);
        if (!descriptor || !descriptor.enumerable
          || !Object.prototype.hasOwnProperty.call(descriptor, "value")) return false;
      }
      return true;
    } catch (_error) {
      return false;
    }
  }

  function createModel(generation) {
    return Netcode.createClientModel({
      fixedUpdate: Sim.fixedUpdate,
      step: Sim.STEP,
      historyLimit: 180,
      teleportDistance: 260,
      generation: generation
    });
  }

  function resetModel(generation) {
    model = Number.isSafeInteger(generation) && generation > 0 ? createModel(generation) : null;
    lastSnapshotAt = 0;
    resyncRequested = false;
  }

  function compatibilityError() {
    var error = new Error(UPDATE_REQUIRED_DETAIL);
    error.compatibility = true;
    return error;
  }

  function numericErrorValue(error, key) {
    try {
      var descriptor = error && Object.getOwnPropertyDescriptor(error, key);
      if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, "value")) return NaN;
      if (typeof descriptor.value === "number") return descriptor.value;
      return typeof descriptor.value === "string" && /^\d{1,4}$/.test(descriptor.value)
        ? Number(descriptor.value) : NaN;
    } catch (_error) {
      return NaN;
    }
  }

  function ownCompatibilityError(error) {
    try {
      var descriptor = error && Object.getOwnPropertyDescriptor(error, "compatibility");
      return !!(descriptor && Object.prototype.hasOwnProperty.call(descriptor, "value")
        && descriptor.value === true);
    } catch (_error) {
      return false;
    }
  }

  function safeFailureDetail(error, operation) {
    var code = numericErrorValue(error, "code");
    var statusCode = numericErrorValue(error, "status");
    if (!Number.isFinite(statusCode)) statusCode = numericErrorValue(error, "statusCode");
    if (ownCompatibilityError(error) || code === 525) return UPDATE_REQUIRED_DETAIL;
    if (statusCode === 429 || code === 429) return RATE_LIMIT_DETAIL;
    if (code === SERVER_RESTART_CODE) return SERVER_RESTART_DETAIL;
    if (code === FAILED_TO_RECONNECT_CODE) return RECONNECT_FAILED_DETAIL;
    if (operation === "join-code" && [521, 522, 523, 524].indexOf(code) >= 0) {
      return MATCH_CODE_UNAVAILABLE_DETAIL;
    }
    return CONNECTION_FAILED_DETAIL;
  }

  function canonicalRoomCode(value) {
    if (typeof value !== "string" || value.length > MAX_ROOM_CODE_INPUT_LENGTH) return null;
    var canonical = value.trim().toUpperCase();
    return ROOM_CODE_PATTERN.test(canonical) ? canonical : null;
  }

  function canonicalServerHello(value) {
    return {
      protocolVersion: value.protocolVersion,
      simulationSchemaVersion: value.simulationSchemaVersion,
      inputContractVersion: value.inputContractVersion,
      clientRuntimeId: value.clientRuntimeId,
      supportedModeIds: value.supportedModeIds.slice(),
      supportedMapIds: value.supportedMapIds.slice(),
      serverBuildId: value.serverBuildId
    };
  }

  function sameServerHello(left, right) {
    if (!left || !right) return false;
    return left.protocolVersion === right.protocolVersion
      && left.simulationSchemaVersion === right.simulationSchemaVersion
      && left.inputContractVersion === right.inputContractVersion
      && left.clientRuntimeId === right.clientRuntimeId
      && left.serverBuildId === right.serverBuildId
      && left.supportedModeIds.length === right.supportedModeIds.length
      && left.supportedModeIds.every(function (value, index) {
        return value === right.supportedModeIds[index];
      })
      && left.supportedMapIds.length === right.supportedMapIds.length
      && left.supportedMapIds.every(function (value, index) {
        return value === right.supportedMapIds[index];
      });
  }

  function resetAdmission() {
    serverCompatibility = null;
    assignmentAccepted = false;
    readySent = false;
    actorId = null;
    epoch = null;
    started = false;
    rematchOpen = false;
    pendingRematchVote = null;
    resetModel(null);
  }

  function ownsConnection(joinedRoom, generation) {
    return room === joinedRoom && connectionGeneration === generation;
  }

  function clearConnection() {
    room = null;
    client = null;
    connectPromise = null;
    actorId = null;
    epoch = null;
    matchGeneration = null;
    lastActorId = null;
    lastEpoch = null;
    started = false;
    lifecycle = "waiting";
    rematchOpen = false;
    rematchVoted = false;
    rematchVotes = 0;
    rematchRequired = 2;
    rematchRemainingMs = 0;
    pendingRematchVote = null;
    publicRoomCode = null;
    model = null;
    lastSnapshotAt = 0;
    resyncRequested = false;
    needsFreshNeutral = false;
    serverCompatibility = null;
    assignmentAccepted = false;
    readySent = false;
  }

  function failConnection(error, joinedRoom, generation) {
    if (!ownsConnection(joinedRoom, generation)) return;
    var failedRoom = room;
    setStatus("error", safeFailureDetail(error, matchmakingOperation));
    clearConnection();
    if (failedRoom) failedRoom.leave();
  }

  function isPagesClient() {
    return !!(root.location
      && root.location.protocol === "https:"
      && root.location.origin === PAGES_ORIGIN
      && PAGES_PATHS.indexOf(root.location.pathname) >= 0);
  }

  function requested() {
    if (!root.location || root.location.protocol === "file:") return false;
    if (isPagesClient()) return true;
    return new URLSearchParams(root.location.search).get("online") === "1";
  }

  function quickMatchAvailable() {
    return requested() && !isPagesClient();
  }

  function serverOrigin() {
    return isPagesClient() ? CLOUD_SERVER_ORIGIN : root.location.origin;
  }

  function loadSdk() {
    if (root.Colyseus && root.Colyseus.Client) return Promise.resolve(root.Colyseus);
    if (sdkPromise) return sdkPromise;
    sdkPromise = new Promise(function (resolve, reject) {
      var script = root.document.createElement("script");
      script.src = serverOrigin() + "/online-sdk.js";
      script.async = true;
      function rejectAndRemove(error) {
        if (typeof script.remove === "function") script.remove();
        reject(error);
      }
      script.onload = function () {
        if (root.Colyseus && root.Colyseus.Client) resolve(root.Colyseus);
        else rejectAndRemove(new Error("The Colyseus SDK did not initialize."));
      };
      script.onerror = function () {
        rejectAndRemove(new Error("The Colyseus SDK could not be loaded."));
      };
      root.document.head.appendChild(script);
    }).catch(function (error) {
      sdkPromise = null;
      throw error;
    });
    return sdkPromise;
  }

  function fighterById(state, id) {
    var fighters = state && Array.isArray(state.fighters) ? state.fighters : [];
    for (var i = 0; i < fighters.length; i += 1) if (fighters[i].id === id) return fighters[i];
    return null;
  }

  function acceptAssignment(message) {
    if (!serverCompatibility || !message
      || !Netcode.validateServerHello(message.compatibility).accepted
      || !sameServerHello(serverCompatibility, message.compatibility)) {
      throw compatibilityError();
    }
    if (!message || !Number.isInteger(message.actorId) || !Number.isInteger(message.epoch)
      || !Number.isSafeInteger(message.generation) || message.generation < 1
      || LIFECYCLE_PHASES.indexOf(message.lifecycle) < 0) {
      throw compatibilityError();
    }
    if (message.simVersion !== Sim.VERSION
      || message.modeId !== Sim.DEFAULT_MODE_ID || message.mapId !== Sim.DEFAULT_MAP_ID
      || message.tickRate !== 60) {
      throw compatibilityError();
    }
    if (lastActorId != null && lastActorId !== message.actorId) {
      throw compatibilityError();
    }
    if (matchGeneration == null && message.generation !== 1) throw compatibilityError();
    if (matchGeneration != null && message.generation < matchGeneration) return false;
    if (matchGeneration != null && message.generation > matchGeneration + 1) {
      throw compatibilityError();
    }
    if (lastEpoch != null && message.generation === matchGeneration && message.epoch < lastEpoch) {
      return false;
    }
    if (assignmentAccepted && message.generation === matchGeneration
      && message.epoch === epoch && message.actorId === actorId) return false;
    var reset = !assignmentAccepted || message.generation !== matchGeneration
      || message.epoch !== epoch;
    if (!reset) return false;
    matchGeneration = message.generation;
    actorId = message.actorId;
    epoch = message.epoch;
    lastActorId = actorId;
    lastEpoch = epoch;
    lifecycle = message.lifecycle;
    started = lifecycle === "playing" || lifecycle === "finished" || lifecycle === "rematch-vote";
    rematchOpen = false;
    rematchVoted = false;
    rematchVotes = 0;
    rematchRequired = 2;
    rematchRemainingMs = 0;
    pendingRematchVote = null;
    readySent = false;
    resetModel(matchGeneration);
    model.setLocalActorId(actorId);
    assignmentAccepted = true;
    return true;
  }

  function acceptSnapshot(snapshot) {
    if (!assignmentAccepted || !serverCompatibility) return;
    if (!snapshot || !Number.isSafeInteger(snapshot.generation) || snapshot.generation < 1) {
      throw compatibilityError();
    }
    if (snapshot.generation < matchGeneration) return;
    if (snapshot.generation > matchGeneration) throw compatibilityError();
    if (snapshot.simVersion !== Sim.VERSION
      || snapshot.modeId !== Sim.DEFAULT_MODE_ID || snapshot.mapId !== Sim.DEFAULT_MAP_ID) {
      throw compatibilityError();
    }
    if (!Number.isInteger(snapshot.actorId) || !Number.isInteger(snapshot.epoch)) {
      throw compatibilityError();
    }
    if (snapshot.actorId !== actorId || snapshot.epoch !== epoch) throw compatibilityError();
    var result = model.ingestSnapshot(snapshot);
    if (result.accepted) lastSnapshotAt = root.performance.now();
    if (result.needsResync && !resyncRequested && room) {
      resyncRequested = true;
      room.send("resync", { generation: matchGeneration });
    } else if (!result.needsResync) {
      resyncRequested = false;
    }
  }

  function acceptLifecycle(message) {
    var keys = [
      "generation", "phase", "rematchOpen", "rematchVoted", "rematchVotes",
      "rematchRequired", "rematchRemainingMs"
    ];
    if (!isPlainDataRecord(message, keys)
      || !Number.isSafeInteger(message.generation) || message.generation < 1
      || LIFECYCLE_PHASES.indexOf(message.phase) < 0
      || typeof message.rematchOpen !== "boolean"
      || typeof message.rematchVoted !== "boolean"
      || !Number.isSafeInteger(message.rematchVotes) || message.rematchVotes < 0
      || !Number.isSafeInteger(message.rematchRequired) || message.rematchRequired !== 2
      || message.rematchVotes > message.rematchRequired
      || !Number.isFinite(message.rematchRemainingMs) || message.rematchRemainingMs < 0
      || message.rematchRemainingMs > 30000) throw compatibilityError();
    if (matchGeneration == null || message.generation > matchGeneration) throw compatibilityError();
    if (message.generation < matchGeneration) return false;
    lifecycle = message.phase;
    rematchOpen = message.rematchOpen;
    rematchVoted = message.rematchVoted;
    rematchVotes = message.rematchVotes;
    rematchRequired = message.rematchRequired;
    rematchRemainingMs = message.rematchRemainingMs;
    if (pendingRematchVote === rematchVoted) pendingRematchVote = null;
    if (lifecycle === "restarting" || lifecycle === "ready" || lifecycle === "closing") {
      started = false;
    } else if (lifecycle === "finished" || lifecycle === "rematch-vote") {
      started = true;
    }
    if (lifecycle === "finished" || lifecycle === "rematch-vote") {
      setStatus("finished", rematchOpen
        ? (rematchVoted ? "REMATCH VOTED — WAITING FOR OTHER PLAYER" : "REMATCH AVAILABLE")
        : "REMATCH WINDOW CLOSED");
    } else if (lifecycle === "restarting") {
      setStatus("restarting", "STARTING NEW MATCH");
    } else if (lifecycle === "ready") {
      setStatus("waiting", "READYING AUTHORITATIVE MATCH");
    } else if (lifecycle === "waiting") {
      setStatus("waiting", "WAITING FOR OTHER PLAYER");
    } else if (lifecycle === "closing") {
      setStatus("closing", "MATCH ROOM CLOSING");
    }
    return true;
  }

  function connect(operation, roomCode) {
    if (!requested()) return Promise.reject(new Error("Online mode is unavailable from this URL."));
    if (!Sim || !Netcode) return Promise.reject(new Error("The shared simulation failed to load."));
    if (connectPromise) return connectPromise;
    var generation = ++connectionGeneration;
    matchmakingOperation = operation;
    publicRoomCode = null;
    setStatus("connecting", operation === "quick-match"
      ? "FINDING QUICK MATCH"
      : operation === "create-match" ? "CREATING MATCH" : "JOINING MATCH");
    needsFreshNeutral = false;
    resetModel(null);
    connectPromise = loadSdk().then(function (Colyseus) {
      if (generation !== connectionGeneration) {
        throw new Error("Connection attempt was superseded.");
      }
      client = new Colyseus.Client(serverOrigin());
      if (operation === "quick-match") {
        return client.joinOrCreate("arena", {
          compatibility: Netcode.createCompatibilityOffer(),
          operation: "quick-match",
          modeId: Sim.DEFAULT_MODE_ID,
          mapId: Sim.DEFAULT_MAP_ID
        });
      }
      if (operation === "create-match") {
        return client.create("arena", {
          compatibility: Netcode.createCompatibilityOffer(),
          operation: "create-match",
          modeId: Sim.DEFAULT_MODE_ID,
          mapId: Sim.DEFAULT_MAP_ID
        });
      }
      return client.joinById(roomCode, {
        compatibility: Netcode.createCompatibilityOffer(),
        operation: "join-code"
      });
    }).then(function (joinedRoom) {
      if (generation !== connectionGeneration) {
        joinedRoom.leave();
        throw new Error("Connection attempt was superseded.");
      }
      if (operation === "create-match") {
        publicRoomCode = canonicalRoomCode(joinedRoom.roomId);
        if (!publicRoomCode) {
          joinedRoom.leave();
          throw compatibilityError();
        }
      }
      room = joinedRoom;
      room.reconnection.minUptime = 0;
      room.reconnection.maxEnqueuedMessages = 0;
      room.reconnection.maxRetries = MAX_RECONNECT_RETRIES;
      room.onMessage("server-hello", function (message) {
        if (!ownsConnection(joinedRoom, generation)) return;
        try {
          if (!Netcode.validateServerHello(message).accepted) throw compatibilityError();
          var canonical = canonicalServerHello(message);
          if (serverCompatibility && !sameServerHello(serverCompatibility, canonical)) {
            throw compatibilityError();
          }
          serverCompatibility = canonical;
          room.send("hello-ack", canonical);
        } catch (error) {
          failConnection(error, joinedRoom, generation);
        }
      });
      room.onMessage("protocol-error", function () {
        if (!ownsConnection(joinedRoom, generation)) return;
        failConnection(compatibilityError(), joinedRoom, generation);
      });
      room.onMessage("assignment", function (message) {
        if (!ownsConnection(joinedRoom, generation)) return;
        try {
          if (acceptAssignment(message) && !readySent) {
            readySent = true;
            room.send("ready", { generation: matchGeneration });
          }
        } catch (error) {
          failConnection(error, joinedRoom, generation);
        }
      });
      room.onMessage("snapshot", function (snapshot) {
        if (!ownsConnection(joinedRoom, generation) || !assignmentAccepted) return;
        try { acceptSnapshot(snapshot); } catch (error) { failConnection(error, joinedRoom, generation); }
      });
      room.onMessage("lifecycle", function (message) {
        if (!ownsConnection(joinedRoom, generation) || !assignmentAccepted) return;
        try { acceptLifecycle(message); } catch (error) { failConnection(error, joinedRoom, generation); }
      });
      room.onMessage("match-start", function (message) {
        if (!ownsConnection(joinedRoom, generation) || !assignmentAccepted || !readySent) return;
        if (!isPlainDataRecord(message, ["generation", "tick"])
          || !Number.isSafeInteger(message.generation) || message.generation < 1
          || !Number.isSafeInteger(message.tick) || message.tick < 0) {
          failConnection(compatibilityError(), joinedRoom, generation);
          return;
        }
        if (message.generation < matchGeneration) return;
        if (message.generation > matchGeneration) {
          failConnection(compatibilityError(), joinedRoom, generation);
          return;
        }
        started = true;
        lifecycle = "playing";
        publicRoomCode = null;
        setStatus("playing", "AUTHORITATIVE MATCH");
        if (needsFreshNeutral) {
          needsFreshNeutral = false;
          sendNeutral();
        }
      });
      room.onMessage("input-rejected", function (message) {
        if (!ownsConnection(joinedRoom, generation) || !assignmentAccepted) return;
        if (!message || !Number.isSafeInteger(message.generation)) return;
        if (message.generation < matchGeneration) return;
        if (message.generation > matchGeneration) {
          failConnection(compatibilityError(), joinedRoom, generation);
          return;
        }
        var inputReasons = [
          "invalid-payload", "stale-generation", "future-generation", "not-playing",
          "stale-sequence", "future-sequence", "future-tick", "past-tick", "rate-limit"
        ];
        var inputReason = inputReasons.indexOf(message.reason) >= 0 ? message.reason : "invalid-payload";
        statusDetail = "INPUT REJECTED: " + inputReason.toUpperCase();
      });
      room.onMessage("control-rejected", function (message) {
        if (!ownsConnection(joinedRoom, generation) || !assignmentAccepted) return;
        if (!message || !Number.isSafeInteger(message.generation)) return;
        if (message.generation < matchGeneration) return;
        if (message.generation > matchGeneration) {
          failConnection(compatibilityError(), joinedRoom, generation);
          return;
        }
        pendingRematchVote = null;
        var controlReasons = [
          "invalid-payload", "stale-generation", "future-generation", "rematch-closed",
          "not-active", "room-closing"
        ];
        var controlReason = controlReasons.indexOf(message.reason) >= 0
          ? message.reason : "invalid-payload";
        statusDetail = "CONTROL REJECTED: " + controlReason.toUpperCase();
      });
      room.onDrop(function () {
        if (!ownsConnection(joinedRoom, generation)) return;
        needsFreshNeutral = true;
        resetAdmission();
        setStatus("reconnecting", "RECONNECTING");
      });
      room.onReconnect(function () {
        if (!ownsConnection(joinedRoom, generation)) return;
        resetAdmission();
        setStatus("reconnecting", "RESTORING AUTHORITATIVE MATCH");
        room.send("protocol-request", {});
      });
      room.onLeave(function (code) {
        if (!ownsConnection(joinedRoom, generation)) return;
        if (status !== "idle" && status !== "error") {
          setStatus("error", safeFailureDetail({ code: code }, matchmakingOperation));
        }
        clearConnection();
      });
      setStatus("waiting", operation === "create-match"
        ? "MATCH CREATED — SHARE THE ROOM CODE" : "WAITING FOR OTHER PLAYER");
      room.send("protocol-request", {});
      return joinedRoom;
    }).catch(function (error) {
      var detail = generation === connectionGeneration
        ? safeFailureDetail(error, operation) : REQUEST_CANCELED_DETAIL;
      if (generation === connectionGeneration) {
        setStatus("error", detail);
        clearConnection();
      }
      throw new Error(detail);
    });
    return connectPromise;
  }

  function quickMatch() {
    return connect("quick-match", null);
  }

  function createMatch() {
    return connect("create-match", null);
  }

  function joinMatch(value) {
    if (connectPromise) return connectPromise;
    var canonical = canonicalRoomCode(value);
    if (!canonical) {
      matchmakingOperation = "join-code";
      publicRoomCode = null;
      setStatus("error", INVALID_MATCH_CODE_DETAIL);
      return Promise.reject(new Error(INVALID_MATCH_CODE_DETAIL));
    }
    return connect("join-code", canonical);
  }

  function sendInput(input) {
    if (!room || !started || actorId == null || matchGeneration == null
      || status !== "playing" || lifecycle !== "playing") return null;
    var current = model.getPredictedState() || model.getAuthoritativeState();
    var tick = current && Number.isInteger(current.tick) ? current.tick + 1 : undefined;
    var safeInput = copy(input) || {};
    safeInput.buttons = safeInput.buttons || {};
    safeInput.buttons.rematch = false;
    var message = model.createInputMessage(safeInput, tick);
    room.send("input", message);
    return message;
  }

  function setRematchVote(vote) {
    vote = !!vote;
    if (!room || !assignmentAccepted || matchGeneration == null || !rematchOpen
      || (lifecycle !== "finished" && lifecycle !== "rematch-vote")
      || pendingRematchVote !== null || vote === rematchVoted) return false;
    pendingRematchVote = vote;
    room.send("rematch-vote", { generation: matchGeneration, vote: vote });
    statusDetail = vote ? "REMATCH VOTE SENT" : "REMATCH VOTE WITHDRAWN";
    return true;
  }

  function neutralInput() {
    var current = renderState();
    var fighter = fighterById(current, actorId);
    return {
      moveX: 0,
      moveY: 0,
      aimX: fighter && fighter.facing < 0 ? -1 : 1,
      aimY: 0,
      weaponSlot: null,
      buttons: {
        jump: false, attack: false, pickup: false,
        reload: false, drop: false, rematch: false
      }
    };
  }

  function sendNeutral() {
    return sendInput(neutralInput());
  }

  function renderState() {
    if (!model) return null;
    var elapsed = lastSnapshotAt ? root.performance.now() - lastSnapshotAt : 50;
    var remote = model.sampleRemoteState(Math.max(0, Math.min(1, elapsed / 50)));
    if (!remote || actorId == null) return remote;
    var predicted = model.getPredictedState();
    var target = fighterById(remote, actorId);
    var source = fighterById(predicted, actorId);
    if (!target || !source) return remote;
    for (var i = 0; i < LOCAL_PREDICTION_FIELDS.length; i += 1) {
      var key = LOCAL_PREDICTION_FIELDS[i];
      target[key] = copy(source[key]);
    }
    return remote;
  }

  function disconnect() {
    connectionGeneration += 1;
    var leavingRoom = room;
    setStatus("idle", "");
    clearConnection();
    matchmakingOperation = null;
    if (leavingRoom) leavingRoom.leave();
  }

  root.StickOnline = Object.freeze({
    requested: requested,
    quickMatchAvailable: quickMatchAvailable,
    quickMatch: quickMatch,
    createMatch: createMatch,
    joinMatch: joinMatch,
    disconnect: disconnect,
    sendInput: sendInput,
    sendNeutral: sendNeutral,
    setRematchVote: setRematchVote,
    renderState: renderState,
    drainEvents: function () { return model ? model.drainEvents() : []; },
    getStatus: function () {
      return Object.freeze({
        state: status,
        detail: statusDetail,
        actorId: actorId,
        epoch: epoch,
        generation: matchGeneration,
        lifecycle: lifecycle,
        started: started,
        connected: !!room,
        rematchOpen: rematchOpen,
        rematchVoted: rematchVoted,
        rematchVotePending: pendingRematchVote,
        rematchVotes: rematchVotes,
        rematchRequired: rematchRequired,
        rematchRemainingMs: rematchRemainingMs,
        matchmakingOperation: matchmakingOperation,
        roomCode: publicRoomCode
      });
    }
  });
}(typeof window !== "undefined" ? window : globalThis));
