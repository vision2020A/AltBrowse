(function (root, factory) {
  "use strict";
  var api = factory();
  root.StickMultiplayer = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
}(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  var DEFAULT_STEP = 1 / 60;
  var DEFAULT_HISTORY_LIMIT = 180;
  var MAX_HISTORY_LIMIT = 180;
  var MAX_SNAPSHOT_EVENTS = 64;
  var MAX_PENDING_EVENTS = 256;
  var MAX_EVENT_IDENTITY_HISTORY = 512;
  var MAX_SNAPSHOT_JSON_BYTES = 32 * 1024;
  var DEFAULT_TELEPORT_DISTANCE = 260;
  var BUTTON_KEYS = Object.freeze([
    "jump", "attack", "pickup", "reload", "drop", "rematch"
  ]);
  var WIRE_KEYS = Object.freeze([
    "generation", "sequence", "clientTick", "moveX", "moveY", "aimX", "aimY",
    "weaponSlot", "buttons"
  ]);
  var ONLINE_PROTOCOL_VERSION = 3;
  var SIMULATION_SCHEMA_VERSION = 6;
  var INPUT_CONTRACT_VERSION = 2;
  var CLIENT_RUNTIME_ID = "classic-canvas-v1";
  var SERVER_BUILD_ID = "pass12b4b-shutdown";
  var SUPPORTED_MODE_IDS = Object.freeze(["free-for-all"]);
  var SUPPORTED_MAP_IDS = Object.freeze(["original-arena"]);
  var COMPATIBILITY_OFFER_KEYS = Object.freeze([
    "protocolVersion", "simulationSchemaVersion", "inputContractVersion",
    "clientRuntimeId", "supportedModeIds", "supportedMapIds"
  ]);
  var SERVER_HELLO_KEYS = Object.freeze(COMPATIBILITY_OFFER_KEYS.concat(["serverBuildId"]));

  function isPlainObject(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return false;
    var prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  }

  function hasExactOwnDataProperties(value, expectedKeys) {
    if (!isPlainObject(value) || Object.getOwnPropertySymbols(value).length !== 0) return false;
    var names = Object.getOwnPropertyNames(value).sort();
    var expected = expectedKeys.slice().sort();
    if (names.length !== expected.length) return false;
    for (var i = 0; i < expected.length; i += 1) {
      if (names[i] !== expected[i]) return false;
      var descriptor = Object.getOwnPropertyDescriptor(value, expected[i]);
      if (!descriptor || !descriptor.enumerable
        || !Object.prototype.hasOwnProperty.call(descriptor, "value")) return false;
    }
    return true;
  }

  function exactIdentifierList(value, expected) {
    if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype
      || Object.getOwnPropertySymbols(value).length !== 0 || value.length !== expected.length) {
      return false;
    }
    var names = Object.getOwnPropertyNames(value);
    if (names.length !== expected.length + 1 || names[names.length - 1] !== "length") return false;
    for (var i = 0; i < expected.length; i += 1) {
      if (names[i] !== String(i)) return false;
      var descriptor = Object.getOwnPropertyDescriptor(value, String(i));
      if (!descriptor || !descriptor.enumerable
        || !Object.prototype.hasOwnProperty.call(descriptor, "value")
        || descriptor.value !== expected[i]) return false;
    }
    return true;
  }

  function compatibilityResult(accepted, reason) {
    return Object.freeze({ accepted: accepted, reason: reason });
  }

  function validateCompatibilityFields(value, keys, requireCurrentServerBuild) {
    try {
      if (!hasExactOwnDataProperties(value, keys)) {
        return compatibilityResult(false, "invalid-record");
      }
      var protocolVersion = Object.getOwnPropertyDescriptor(value, "protocolVersion").value;
      var simulationSchemaVersion = Object.getOwnPropertyDescriptor(value, "simulationSchemaVersion").value;
      var inputContractVersion = Object.getOwnPropertyDescriptor(value, "inputContractVersion").value;
      var clientRuntimeId = Object.getOwnPropertyDescriptor(value, "clientRuntimeId").value;
      var modeIds = Object.getOwnPropertyDescriptor(value, "supportedModeIds").value;
      var mapIds = Object.getOwnPropertyDescriptor(value, "supportedMapIds").value;
      if (!Number.isSafeInteger(protocolVersion) || protocolVersion !== ONLINE_PROTOCOL_VERSION) {
        return compatibilityResult(false, "protocol-version");
      }
      if (!Number.isSafeInteger(simulationSchemaVersion)
        || simulationSchemaVersion !== SIMULATION_SCHEMA_VERSION) {
        return compatibilityResult(false, "simulation-schema-version");
      }
      if (!Number.isSafeInteger(inputContractVersion)
        || inputContractVersion !== INPUT_CONTRACT_VERSION) {
        return compatibilityResult(false, "input-contract-version");
      }
      if (clientRuntimeId !== CLIENT_RUNTIME_ID) {
        return compatibilityResult(false, "client-runtime-id");
      }
      if (!exactIdentifierList(modeIds, SUPPORTED_MODE_IDS)) {
        return compatibilityResult(false, "supported-mode-ids");
      }
      if (!exactIdentifierList(mapIds, SUPPORTED_MAP_IDS)) {
        return compatibilityResult(false, "supported-map-ids");
      }
      if (keys === SERVER_HELLO_KEYS) {
        var serverBuildId = Object.getOwnPropertyDescriptor(value, "serverBuildId").value;
        if (typeof serverBuildId !== "string" || serverBuildId.length > 64
          || !/^[a-z0-9][a-z0-9._-]*$/.test(serverBuildId)) {
          return compatibilityResult(false, "server-build-id");
        }
        if (requireCurrentServerBuild && serverBuildId !== SERVER_BUILD_ID) {
          return compatibilityResult(false, "server-build-id");
        }
      }
      return compatibilityResult(true, "accepted");
    } catch (_error) {
      return compatibilityResult(false, "invalid-record");
    }
  }

  function validateCompatibilityOffer(value) {
    return validateCompatibilityFields(value, COMPATIBILITY_OFFER_KEYS, false);
  }

  function validateServerHello(value) {
    return validateCompatibilityFields(value, SERVER_HELLO_KEYS, false);
  }

  function validateCurrentServerHello(value) {
    return validateCompatibilityFields(value, SERVER_HELLO_KEYS, true);
  }

  function createCompatibilityOffer() {
    return {
      protocolVersion: ONLINE_PROTOCOL_VERSION,
      simulationSchemaVersion: SIMULATION_SCHEMA_VERSION,
      inputContractVersion: INPUT_CONTRACT_VERSION,
      clientRuntimeId: CLIENT_RUNTIME_ID,
      supportedModeIds: SUPPORTED_MODE_IDS.slice(),
      supportedMapIds: SUPPORTED_MAP_IDS.slice()
    };
  }

  function createServerHello() {
    var hello = createCompatibilityOffer();
    hello.serverBuildId = SERVER_BUILD_ID;
    return hello;
  }

  function cloneJson(value, seen) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw new TypeError("StickMultiplayer: JSON numbers must be finite");
      return value;
    }
    if (Array.isArray(value)) {
      seen = seen || new Set();
      if (seen.has(value)) throw new TypeError("StickMultiplayer: cyclic JSON value");
      seen.add(value);
      var copy = value.map(function (item) { return cloneJson(item, seen); });
      seen.delete(value);
      return copy;
    }
    if (isPlainObject(value)) {
      seen = seen || new Set();
      if (seen.has(value)) throw new TypeError("StickMultiplayer: cyclic JSON value");
      seen.add(value);
      var result = {};
      Object.keys(value).forEach(function (key) {
        var item = value[key];
        if (item === undefined || typeof item === "function" || typeof item === "symbol"
          || typeof item === "bigint") {
          throw new TypeError("StickMultiplayer: value is not plain JSON");
        }
        result[key] = cloneJson(item, seen);
      });
      seen.delete(value);
      return result;
    }
    throw new TypeError("StickMultiplayer: value is not plain JSON");
  }

  function clamp(value, low, high) {
    return value < low ? low : value > high ? high : value;
  }

  function finiteUnit(value, fallback) {
    value = Number(value);
    return Number.isFinite(value) ? clamp(value, -1, 1) : fallback;
  }

  function canonicalButtons(value) {
    value = isPlainObject(value) ? value : {};
    var buttons = {};
    for (var i = 0; i < BUTTON_KEYS.length; i += 1) {
      buttons[BUTTON_KEYS[i]] = !!value[BUTTON_KEYS[i]];
    }
    return buttons;
  }

  function canonicalInput(value, options) {
    value = isPlainObject(value) ? value : {};
    options = options || {};
    var weaponSlot = value.weaponSlot;
    if (weaponSlot == null) {
      weaponSlot = null;
    } else {
      weaponSlot = Number(weaponSlot);
      if (!Number.isInteger(weaponSlot)
        || weaponSlot < options.weaponSlotMin || weaponSlot > options.weaponSlotMax) {
        weaponSlot = null;
      }
    }
    return {
      moveX: finiteUnit(value.moveX, 0),
      moveY: finiteUnit(value.moveY, 0),
      aimX: finiteUnit(value.aimX, 1),
      aimY: finiteUnit(value.aimY, 0),
      weaponSlot: weaponSlot,
      buttons: canonicalButtons(value.buttons)
    };
  }

  function neutralInput(fighter) {
    var facing = fighter && (fighter.aimFacing < 0 || fighter.facing < 0) ? -1 : 1;
    return {
      id: fighter.id,
      moveX: 0,
      moveY: 0,
      aimX: facing,
      aimY: 0,
      weaponSlot: null,
      buttons: canonicalButtons(null)
    };
  }

  function replayInputFrame(state, actorId, input) {
    var fighters = state && Array.isArray(state.fighters) ? state.fighters.slice() : [];
    fighters.sort(function (left, right) { return Number(left.id) - Number(right.id); });
    var actors = fighters.map(function (fighter) {
      var actor = neutralInput(fighter);
      if (fighter.id === actorId) {
        actor.moveX = input.moveX;
        actor.moveY = input.moveY;
        actor.aimX = input.aimX;
        actor.aimY = input.aimY;
        actor.weaponSlot = input.weaponSlot;
        actor.buttons = canonicalButtons(input.buttons);
      }
      return actor;
    });
    return { tick: state && Number.isInteger(state.tick) ? state.tick : 0, actors: actors };
  }

  function finiteLerp(from, to, alpha) {
    if (!Number.isFinite(from) || !Number.isFinite(to)) return Number.isFinite(to) ? to : from;
    var value = from + (to - from) * alpha;
    return Number.isFinite(value) ? value : to;
  }

  function fighterById(state, id) {
    var fighters = state && Array.isArray(state.fighters) ? state.fighters : [];
    for (var i = 0; i < fighters.length; i += 1) {
      if (fighters[i] && fighters[i].id === id) return fighters[i];
    }
    return null;
  }

  function shouldSnapRemote(older, newer, teleportDistance) {
    if (!older || !newer) return true;
    if (!!older.dead !== !!newer.dead || older.dead || newer.dead) return true;
    var oldRespawn = Number(older.respawn);
    var newRespawn = Number(newer.respawn);
    if ((Number.isFinite(oldRespawn) || Number.isFinite(newRespawn)) && oldRespawn !== newRespawn
      && (oldRespawn > 0 || newRespawn > 0)) return true;
    var dx = Number(newer.x) - Number(older.x);
    var dy = Number(newer.y) - Number(older.y);
    return !Number.isFinite(dx) || !Number.isFinite(dy)
      || dx * dx + dy * dy > teleportDistance * teleportDistance;
  }

  function interpolateRemoteFighters(older, newer, actorId, alpha, teleportDistance) {
    var result = cloneJson(newer);
    var fighters = result && Array.isArray(result.fighters) ? result.fighters : [];
    var fields = ["x", "y", "vx", "vy"];
    for (var i = 0; i < fighters.length; i += 1) {
      var target = fighters[i];
      if (!target || target.id === actorId) continue;
      var from = fighterById(older, target.id);
      var to = fighterById(newer, target.id);
      if (!shouldSnapRemote(from, to, teleportDistance)) {
        for (var f = 0; f < fields.length; f += 1) {
          var key = fields[f];
          target[key] = finiteLerp(Number(from[key]), Number(to[key]), alpha);
        }
      }
      // game.js ordinarily interpolates one fixed simulation step from prevX/Y.
      // A remote sample is already network-interpolated (or intentionally
      // snapped), so make it render-ready and prevent a second positional lerp.
      target.prevX = target.x;
      target.prevY = target.y;
      target.prevVx = target.vx;
      target.prevVy = target.vy;
    }
    return result;
  }

  function createClientModel(options) {
    options = options || {};
    var fixedUpdate = typeof options.fixedUpdate === "function" ? options.fixedUpdate : null;
    var step = Number.isFinite(options.step) && options.step > 0 ? options.step : DEFAULT_STEP;
    var historyLimit = Number.isInteger(options.historyLimit) && options.historyLimit > 0
      ? Math.min(options.historyLimit, MAX_HISTORY_LIMIT) : DEFAULT_HISTORY_LIMIT;
    var teleportDistance = Number.isFinite(options.teleportDistance) && options.teleportDistance > 0
      ? options.teleportDistance : DEFAULT_TELEPORT_DISTANCE;
    var actorId = Number.isInteger(options.actorId) ? options.actorId : null;
    var generation = Number.isSafeInteger(options.generation) && options.generation > 0
      ? options.generation : 1;
    var inputOptions = {
      weaponSlotMin: Number.isInteger(options.weaponSlotMin) ? options.weaponSlotMin : 1,
      weaponSlotMax: Number.isInteger(options.weaponSlotMax) ? options.weaponSlotMax : 6
    };
    var nextSequence = Number.isInteger(options.initialSequence) && options.initialSequence >= 0
      ? options.initialSequence : 0;
    var latestSnapshotTick = -1;
    var latestAckSequence = nextSequence - 1;
    var lastClientTick = -1;
    var authoritativeState = null;
    var predictedState = null;
    var inputHistory = [];
    var interpolationBuffer = [];
    var deliveredEventKeys = new Set();
    var deliveredEventOrder = [];
    var pendingEvents = [];
    var overflowedThrough = null;
    var needsResync = false;

    function updateResyncFlag() {
      if (overflowedThrough != null && latestAckSequence >= overflowedThrough) overflowedThrough = null;
      needsResync = overflowedThrough != null;
    }

    function applyPrediction(state, input) {
      if (!fixedUpdate || actorId == null || !state) return state;
      var frame = replayInputFrame(state, actorId, input);
      var returned = fixedUpdate(state, frame, step);
      return returned == null ? state : returned;
    }

    function rebuildPrediction() {
      predictedState = authoritativeState == null ? null : cloneJson(authoritativeState);
      if (!predictedState || !fixedUpdate || actorId == null) return 0;
      for (var i = 0; i < inputHistory.length; i += 1) {
        predictedState = applyPrediction(predictedState, inputHistory[i]);
      }
      return inputHistory.length;
    }

    function createInputMessage(rawInput, requestedClientTick) {
      var input = canonicalInput(rawInput, inputOptions);
      var fallbackTick = predictedState && Number.isInteger(predictedState.tick)
        ? predictedState.tick + 1 : Math.max(latestSnapshotTick + 1, lastClientTick + 1, 0);
      var clientTick = Number(requestedClientTick);
      if (!Number.isInteger(clientTick) || clientTick < 0) clientTick = fallbackTick;
      if (clientTick < lastClientTick) clientTick = lastClientTick;
      lastClientTick = clientTick;

      var message = {
        generation: generation,
        sequence: nextSequence++,
        clientTick: clientTick,
        moveX: input.moveX,
        moveY: input.moveY,
        aimX: input.aimX,
        aimY: input.aimY,
        weaponSlot: input.weaponSlot,
        buttons: canonicalButtons(input.buttons)
      };
      inputHistory.push(message);
      while (inputHistory.length > historyLimit) {
        var removed = inputHistory.shift();
        overflowedThrough = overflowedThrough == null
          ? removed.sequence : Math.max(overflowedThrough, removed.sequence);
      }
      updateResyncFlag();
      if (predictedState && fixedUpdate && actorId != null) {
        predictedState = applyPrediction(predictedState, message);
      }
      return cloneJson(message);
    }

    function enqueueEvents(events, snapshotTick) {
      for (var i = 0; i < events.length; i += 1) {
        var event = events[i];
        if (!isPlainObject(event) || !Number.isInteger(event.id)) continue;
        var eventTick = Number.isInteger(event.tick) ? event.tick : snapshotTick;
        var identity = String(generation) + ":" + String(eventTick) + ":" + String(event.id);
        if (deliveredEventKeys.has(identity)) continue;
        deliveredEventKeys.add(identity);
        deliveredEventOrder.push(identity);
        while (deliveredEventOrder.length > MAX_EVENT_IDENTITY_HISTORY) {
          deliveredEventKeys.delete(deliveredEventOrder.shift());
        }
        var copy = cloneJson(event);
        copy.tick = eventTick;
        pendingEvents.push({ identity: identity, event: copy, order: pendingEvents.length });
        if (pendingEvents.length > MAX_PENDING_EVENTS) pendingEvents.shift();
      }
      pendingEvents.sort(function (left, right) {
        return left.event.tick - right.event.tick || left.event.id - right.event.id || left.order - right.order;
      });
    }

    function ingestSnapshot(snapshot) {
      if (!isPlainObject(snapshot) || !Number.isSafeInteger(snapshot.generation)
        || snapshot.generation < 1 || !Number.isInteger(snapshot.tick) || snapshot.tick < 0
        || !isPlainObject(snapshot.state)) {
        throw new TypeError("StickMultiplayer: invalid authoritative snapshot");
      }
      if (snapshot.generation !== generation) {
        return Object.freeze({
          accepted: false,
          reason: snapshot.generation < generation ? "stale-generation" : "future-generation",
          generation: generation
        });
      }
      if (snapshot.tick <= latestSnapshotTick) {
        return Object.freeze({ accepted: false, reason: "stale", tick: latestSnapshotTick });
      }
      var sourceEvents = snapshot.events == null ? [] : snapshot.events;
      if (!Array.isArray(sourceEvents) || sourceEvents.length > MAX_SNAPSHOT_EVENTS) {
        throw new TypeError("StickMultiplayer: snapshot events exceed the bounded contract");
      }
      var clonedState = cloneJson(snapshot.state);
      var clonedEvents = cloneJson(sourceEvents);
      var ackSequence = Number(snapshot.ackSequence);
      if (!Number.isInteger(ackSequence)) ackSequence = latestAckSequence;
      ackSequence = Math.min(ackSequence, nextSequence - 1);
      latestAckSequence = Math.max(latestAckSequence, ackSequence);
      latestSnapshotTick = snapshot.tick;
      if (lastClientTick < snapshot.tick) lastClientTick = snapshot.tick;
      authoritativeState = clonedState;
      inputHistory = inputHistory.filter(function (message) {
        return message.sequence > latestAckSequence;
      });
      updateResyncFlag();

      interpolationBuffer.push({ tick: snapshot.tick, state: cloneJson(clonedState) });
      if (interpolationBuffer.length > 2) interpolationBuffer.shift();
      enqueueEvents(clonedEvents, snapshot.tick);
      var replayed = rebuildPrediction();
      return Object.freeze({
        accepted: true,
        tick: latestSnapshotTick,
        ackSequence: latestAckSequence,
        replayed: replayed,
        eventCount: pendingEvents.length,
        needsResync: needsResync
      });
    }

    function sampleRemoteState(alpha) {
      if (interpolationBuffer.length === 0) return null;
      if (interpolationBuffer.length === 1) return cloneJson(interpolationBuffer[0].state);
      alpha = Number(alpha);
      if (!Number.isFinite(alpha)) alpha = 1;
      alpha = clamp(alpha, 0, 1);
      return interpolateRemoteFighters(
        interpolationBuffer[0].state,
        interpolationBuffer[1].state,
        actorId,
        alpha,
        teleportDistance
      );
    }

    function drainEvents() {
      var events = pendingEvents.map(function (entry) { return cloneJson(entry.event); });
      pendingEvents.length = 0;
      return events;
    }

    function setLocalActorId(value) {
      if (!Number.isInteger(value)) throw new TypeError("StickMultiplayer: actorId must be an integer");
      if (actorId !== value && inputHistory.length) {
        throw new Error("StickMultiplayer: cannot change actorId with unacknowledged inputs");
      }
      actorId = value;
      rebuildPrediction();
    }

    function getStatus() {
      return Object.freeze({
        actorId: actorId,
        generation: generation,
        latestSnapshotTick: latestSnapshotTick,
        latestAckSequence: latestAckSequence,
        nextSequence: nextSequence,
        pendingInputCount: inputHistory.length,
        historyLimit: historyLimit,
        pendingEventCount: pendingEvents.length,
        eventIdentityCount: deliveredEventKeys.size,
        needsResync: needsResync
      });
    }

    return Object.freeze({
      createInputMessage: createInputMessage,
      ingestSnapshot: ingestSnapshot,
      sampleRemoteState: sampleRemoteState,
      drainEvents: drainEvents,
      setLocalActorId: setLocalActorId,
      getAuthoritativeState: function () {
        return authoritativeState == null ? null : cloneJson(authoritativeState);
      },
      getPredictedState: function () {
        return predictedState == null ? null : cloneJson(predictedState);
      },
      getPendingInputs: function () { return cloneJson(inputHistory); },
      getStatus: getStatus
    });
  }

  return Object.freeze({
    BUTTON_KEYS: BUTTON_KEYS,
    WIRE_KEYS: WIRE_KEYS,
    ONLINE_PROTOCOL_VERSION: ONLINE_PROTOCOL_VERSION,
    SIMULATION_SCHEMA_VERSION: SIMULATION_SCHEMA_VERSION,
    INPUT_CONTRACT_VERSION: INPUT_CONTRACT_VERSION,
    CLIENT_RUNTIME_ID: CLIENT_RUNTIME_ID,
    SERVER_BUILD_ID: SERVER_BUILD_ID,
    MAX_HISTORY_LIMIT: MAX_HISTORY_LIMIT,
    MAX_SNAPSHOT_EVENTS: MAX_SNAPSHOT_EVENTS,
    MAX_PENDING_EVENTS: MAX_PENDING_EVENTS,
    MAX_EVENT_IDENTITY_HISTORY: MAX_EVENT_IDENTITY_HISTORY,
    MAX_SNAPSHOT_JSON_BYTES: MAX_SNAPSHOT_JSON_BYTES,
    SUPPORTED_MODE_IDS: SUPPORTED_MODE_IDS,
    SUPPORTED_MAP_IDS: SUPPORTED_MAP_IDS,
    createCompatibilityOffer: createCompatibilityOffer,
    validateCompatibilityOffer: validateCompatibilityOffer,
    createServerHello: createServerHello,
    validateServerHello: validateServerHello,
    validateCurrentServerHello: validateCurrentServerHello,
    createClientModel: createClientModel
  });
}));
