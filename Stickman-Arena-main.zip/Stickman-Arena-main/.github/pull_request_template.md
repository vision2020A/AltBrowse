## Issue, type, and route

- Issue:
- Type: <!-- issue PR / release PR / emergency -->
- Route: <!-- agent/issue-<number>-<description> -> develop / develop -> main / exact approved emergency route -->
- Owner approvals or gates still required:

## Exact revisions

| Revision | Commit | Tree |
| --- | --- | --- |
| Production `main` | | |
| Alpha `develop` | | |
| Task base | | |
| Frozen candidate | | |

- Canonical-standard provenance when applicable: <!-- exact production commit, tree, and standard-file blob -->

## Summary, scope, and requirement mapping

<!-- Explain the outcome, rationale, impact, non-goals, and map every applicable requirement to its retained or changed canonical owner. -->

- Runtime/gameplay behavior changed: <!-- No / explain separately approved scope -->
- Immutable-surface proof: <!-- Commands/diffs proving runtime, dependencies, lockfiles, product versions, protocols, assets, and deployment payload are unchanged, or list each authorized exception. -->

## File inventory

- Changed:
- Added:
- Deleted:
- Renamed/generated:

## Verification and evidence

- Focused and complete automated checks:
- Remote CI run, exact check context, and trusted source:
- Runtime/browser/console/request evidence:
- Desktop and keyboard evidence:
- Touch and responsive evidence:
- Accessibility evidence:
- Visual evidence against task base and approved production baseline:
- Deployed evidence:
- Manual evidence:
- Simulated evidence:
- Physical-device evidence:
- Unavailable or non-applicable evidence, with reason:
- Dependency, lockfile, product-version, protocol, asset, license, source/provenance, and deployment non-change evidence:

## Protection, risk, and rollback

- Ruleset/settings discrepancies:
- Required owner, Alpha, release, deployment, or cleanup actions:
- Risks and failure modes:
- Exact safe rollback:

## Checklist

- [ ] I read `AGENTS.md`, the canonical Repository Standard, and every affected canonical owner.
- [ ] This branch follows the declared issue, release, or explicitly approved emergency route.
- [ ] I audited every changed, added, deleted, renamed, and generated file.
- [ ] I preserved fixed-step determinism, serializable state/input, offline operation, and presentation-only boundaries unless separately authorized.
- [ ] I added deterministic regressions for every gameplay or runtime defect fixed, or marked that evidence non-applicable.
- [ ] `npm test`, the complete applicable server gate, dependency audit/outdated checks, and `git diff --check` pass.
- [ ] `sha256sum --check SHA256SUMS` passes on the frozen candidate.
- [ ] I documented exact CI, visual, manual, deployed, simulated, physical, unavailable, and non-applicable evidence without relabeling it.
- [ ] Risk, rollback, required settings, approvals, integration, Alpha, release, deployment, and cleanup gates are explicit.
