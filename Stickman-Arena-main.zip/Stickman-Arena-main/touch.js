(function (root) {
  "use strict";

  var CONFIG = Object.freeze({
    radius: 62,
    deadzone: 0.18,
    aimThreshold: 0.34,
    attackThreshold: 0.34,
    verticalThreshold: 0.62,
    jumpThreshold: 0.62,
    dropThreshold: 0.62,
    verticalResetThreshold: 0.3,
    rifleHoldTicks: 10
  });
  var BUTTON_NAMES = ["pickup", "reload", "unarmed"];
  var WEAPON_NAMES = ["unarmed", "sword", "pistol", "shotgun", "rifle", "grenade"];

  function clamp(value, low, high) {
    return Math.max(low, Math.min(high, value));
  }

  function finiteNumber(value, fallback) {
    value = Number(value);
    return Number.isFinite(value) ? value : fallback;
  }

  function normalizeStick(dx, dy, radius, deadzone) {
    var distance = Math.sqrt(dx * dx + dy * dy);
    if (!distance || distance <= radius * deadzone) {
      return { x: 0, y: 0, magnitude: 0 };
    }
    var clampedDistance = Math.min(radius, distance);
    var magnitude = clamp((clampedDistance / radius - deadzone) / (1 - deadzone), 0, 1);
    return {
      x: dx / distance * magnitude,
      y: dy / distance * magnitude,
      magnitude: magnitude
    };
  }

  function closestLiveEnemyAim(fighters, self) {
    if (!Array.isArray(fighters) || !self || !Number.isFinite(self.x) || !Number.isFinite(self.y)) return null;
    var bestDx = 0;
    var bestDy = 0;
    var bestDistance2 = Infinity;
    var bestId = Infinity;
    for (var i = 0; i < fighters.length; i += 1) {
      var candidate = fighters[i];
      if (!candidate || candidate === self || candidate.id === self.id) continue;
      if (candidate.dead || candidate.defeated || candidate.alive === false) continue;
      if (Number.isFinite(candidate.health) && candidate.health <= 0) continue;
      if (!Number.isFinite(candidate.x) || !Number.isFinite(candidate.y)) continue;
      var candidateId = Number(candidate.id);
      if (!Number.isFinite(candidateId)) continue;
      var dx = candidate.x - self.x;
      var dy = candidate.y - self.y;
      var distance2 = dx * dx + dy * dy;
      if (distance2 <= 0) continue;
      if (distance2 < bestDistance2 || (distance2 === bestDistance2 && candidateId < bestId)) {
        bestDx = dx;
        bestDy = dy;
        bestDistance2 = distance2;
        bestId = candidateId;
      }
    }
    if (!Number.isFinite(bestDistance2)) return null;
    var distance = Math.sqrt(bestDistance2);
    return { x: bestDx / distance, y: bestDy / distance };
  }

  function makeStick() {
    return {
      pointerId: null,
      originX: 0,
      originY: 0,
      knobX: 0,
      knobY: 0,
      x: 0,
      y: 0,
      magnitude: 0,
      active: false
    };
  }

  function makeAction() {
    var action = makeStick();
    action.phase = "idle";
    action.weapon = "unarmed";
    action.pickupCandidate = false;
    action.aimed = false;
    action.assisted = false;
    action.manualAim = false;
    action.holdTicks = 0;
    action.lastAimX = 1;
    action.lastAimY = 0;
    return action;
  }

  function makeButton() {
    return { pointerId: null, held: false, pulse: false };
  }

  function isMeleeWeapon(weapon) {
    return weapon === "unarmed" || weapon === "sword";
  }

  function isReleaseWeapon(weapon) {
    return weapon === "pistol" || weapon === "shotgun" || weapon === "grenade";
  }

  function isRangedWeapon(weapon) {
    return isReleaseWeapon(weapon) || weapon === "rifle";
  }

  function createController(options) {
    options = options || {};
    var verticalThreshold = options.verticalThreshold == null
      ? CONFIG.verticalThreshold
      : finiteNumber(options.verticalThreshold, CONFIG.verticalThreshold);
    var jumpThreshold = options.jumpThreshold == null
      ? verticalThreshold
      : finiteNumber(options.jumpThreshold, verticalThreshold);
    var dropThreshold = options.dropThreshold == null
      ? verticalThreshold
      : finiteNumber(options.dropThreshold, verticalThreshold);
    var aimOption = options.aimThreshold == null ? options.attackThreshold : options.aimThreshold;
    var aimThreshold = aimOption == null
      ? CONFIG.aimThreshold
      : finiteNumber(aimOption, CONFIG.aimThreshold);
    jumpThreshold = clamp(jumpThreshold, 0.05, 1);
    dropThreshold = clamp(dropThreshold, 0.05, 1);
    var resetLimit = Math.max(0, Math.min(jumpThreshold, dropThreshold) - 0.01);
    var resetThreshold = options.verticalResetThreshold == null
      ? CONFIG.verticalResetThreshold
      : finiteNumber(options.verticalResetThreshold, CONFIG.verticalResetThreshold);
    var config = {
      radius: Math.max(1, finiteNumber(options.radius, CONFIG.radius)),
      deadzone: clamp(finiteNumber(options.deadzone, CONFIG.deadzone), 0, 0.95),
      aimThreshold: clamp(aimThreshold, 0.05, 1),
      attackThreshold: clamp(aimThreshold, 0.05, 1),
      verticalThreshold: clamp(verticalThreshold, 0.05, 1),
      jumpThreshold: jumpThreshold,
      dropThreshold: dropThreshold,
      verticalResetThreshold: clamp(resetThreshold, 0, resetLimit),
      rifleHoldTicks: CONFIG.rifleHoldTicks
    };
    var left = makeStick();
    var action = makeAction();
    var buttons = {};
    var owners = Object.create(null);
    var verticalArmed = true;
    var jumpPulsePointer = null;
    var dropPulsePointer = null;
    var attackPulse = null;
    var pickupPulsePointer = null;
    BUTTON_NAMES.forEach(function (name) { buttons[name] = makeButton(); });

    function updateVector(control, x, y) {
      var dx = x - control.originX;
      var dy = y - control.originY;
      var distance = Math.sqrt(dx * dx + dy * dy);
      if (distance > config.radius) {
        var overflow = distance - config.radius;
        control.originX += dx / distance * overflow;
        control.originY += dy / distance * overflow;
        dx = x - control.originX;
        dy = y - control.originY;
      }
      var value = normalizeStick(dx, dy, config.radius, config.deadzone);
      control.x = value.x;
      control.y = value.y;
      control.magnitude = value.magnitude;
      control.knobX = control.originX + value.x * config.radius;
      control.knobY = control.originY + value.y * config.radius;
    }

    function updateLeft(x, y) {
      updateVector(left, x, y);
      if (!verticalArmed && Math.abs(left.y) <= config.verticalResetThreshold) verticalArmed = true;
      if (!verticalArmed) return;
      if (left.y <= -config.jumpThreshold) {
        jumpPulsePointer = left.pointerId;
        verticalArmed = false;
      } else if (left.y >= config.dropThreshold) {
        dropPulsePointer = left.pointerId;
        verticalArmed = false;
      }
    }

    function queueAttack(pointerId, aimX, aimY) {
      if (!attackPulse) attackPulse = { pointerId: pointerId, aimX: aimX, aimY: aimY };
    }

    function beginCombat() {
      action.pickupCandidate = false;
      action.aimed = true;
      action.holdTicks = 0;
      if (isMeleeWeapon(action.weapon)) {
        action.phase = "committed";
        queueAttack(action.pointerId, action.lastAimX, action.lastAimY);
      } else if (action.weapon === "rifle") {
        action.phase = "holding";
      } else {
        action.phase = "aiming";
      }
    }

    function updateAction(x, y) {
      updateVector(action, x, y);
      var beganManualAim = !action.manualAim && action.magnitude >= config.aimThreshold;
      if (beganManualAim) {
        action.manualAim = true;
        action.assisted = false;
      }
      if (action.manualAim && action.magnitude > 0) {
        action.lastAimX = action.x / action.magnitude;
        action.lastAimY = action.y / action.magnitude;
      }
      if (beganManualAim && !action.aimed) beginCombat();
    }

    function resetStick(control) {
      control.pointerId = null;
      control.x = 0;
      control.y = 0;
      control.magnitude = 0;
      control.knobX = control.originX;
      control.knobY = control.originY;
      control.active = false;
    }

    function resetAction() {
      resetStick(action);
      action.phase = "idle";
      action.weapon = "unarmed";
      action.pickupCandidate = false;
      action.aimed = false;
      action.assisted = false;
      action.manualAim = false;
      action.holdTicks = 0;
      action.lastAimX = 1;
      action.lastAimY = 0;
    }

    function startStick(side, pointerId, x, y) {
      if (side !== "left" || left.active || jumpPulsePointer != null || dropPulsePointer != null || owners[pointerId] != null) return false;
      left.pointerId = pointerId;
      left.originX = x;
      left.originY = y;
      left.knobX = x;
      left.knobY = y;
      left.x = 0;
      left.y = 0;
      left.magnitude = 0;
      left.active = true;
      verticalArmed = true;
      owners[pointerId] = "stick:left";
      return true;
    }

    function startAction(pointerId, x, y, context) {
      if (action.active || attackPulse || pickupPulsePointer != null || owners[pointerId] != null) return false;
      context = context || {};
      var weapon = WEAPON_NAMES.indexOf(context.weapon) >= 0 ? context.weapon : "unarmed";
      var facing = Number(context.facing) < 0 ? -1 : 1;
      var assistAimX = Number(context.assistAimX);
      var assistAimY = Number(context.assistAimY);
      var assistLength = Number.isFinite(assistAimX) && Number.isFinite(assistAimY)
        ? Math.sqrt(assistAimX * assistAimX + assistAimY * assistAimY)
        : 0;
      action.pointerId = pointerId;
      action.originX = x;
      action.originY = y;
      action.knobX = x;
      action.knobY = y;
      action.x = 0;
      action.y = 0;
      action.magnitude = 0;
      action.active = true;
      action.weapon = weapon;
      action.pickupCandidate = !!(context.smartAction && context.pickupEligible);
      action.aimed = false;
      action.assisted = false;
      action.manualAim = false;
      action.holdTicks = 0;
      action.lastAimX = facing;
      action.lastAimY = 0;
      action.phase = action.pickupCandidate ? "pickup" : "ready";
      owners[pointerId] = "action";
      if (!action.pickupCandidate && isMeleeWeapon(weapon)) beginCombat();
      else if (!action.pickupCandidate && context.smartAction && isRangedWeapon(weapon)
        && Number.isFinite(assistLength) && assistLength > 0.00001) {
        action.lastAimX = assistAimX / assistLength;
        action.lastAimY = assistAimY / assistLength;
        action.assisted = true;
        beginCombat();
      }
      return true;
    }

    function startButton(name, pointerId) {
      var button = buttons[name];
      if (!button || button.held || button.pulse || owners[pointerId] != null) return false;
      button.pointerId = pointerId;
      button.held = true;
      button.pulse = true;
      owners[pointerId] = "button:" + name;
      return true;
    }

    function movePointer(pointerId, x, y) {
      var owner = owners[pointerId];
      if (owner === "stick:left") updateLeft(x, y);
      else if (owner === "action") updateAction(x, y);
      else return false;
      return true;
    }

    function finishPointer(pointerId, commit) {
      var owner = owners[pointerId];
      if (!owner) return false;
      delete owners[pointerId];
      if (owner === "stick:left") {
        resetStick(left);
        verticalArmed = true;
        if (!commit) {
          if (jumpPulsePointer === pointerId) jumpPulsePointer = null;
          if (dropPulsePointer === pointerId) dropPulsePointer = null;
        }
      } else if (owner === "action") {
        if (commit) {
          if (action.pickupCandidate && !action.aimed) {
            if (pickupPulsePointer == null) pickupPulsePointer = pointerId;
          } else if (action.aimed && isReleaseWeapon(action.weapon)) {
            queueAttack(pointerId, action.lastAimX, action.lastAimY);
          }
        } else {
          if (attackPulse && attackPulse.pointerId === pointerId) attackPulse = null;
          if (pickupPulsePointer === pointerId) pickupPulsePointer = null;
        }
        resetAction();
      } else {
        var button = buttons[owner.slice(7)];
        button.pointerId = null;
        button.held = false;
        if (!commit) button.pulse = false;
      }
      return true;
    }

    function endPointer(pointerId) {
      return finishPointer(pointerId, true);
    }

    function cancelPointer(pointerId) {
      return finishPointer(pointerId, false);
    }

    function clear() {
      resetStick(left);
      resetAction();
      verticalArmed = true;
      BUTTON_NAMES.forEach(function (name) {
        buttons[name].held = false;
        buttons[name].pulse = false;
        buttons[name].pointerId = null;
      });
      jumpPulsePointer = null;
      dropPulsePointer = null;
      attackPulse = null;
      pickupPulsePointer = null;
      owners = Object.create(null);
    }

    function read(facing) {
      var rifleAttack = false;
      if (action.active && action.aimed && action.weapon === "rifle") {
        action.holdTicks = Math.min(config.rifleHoldTicks, action.holdTicks + 1);
        rifleAttack = action.holdTicks >= config.rifleHoldTicks;
        action.phase = rifleAttack ? "firing" : "holding";
      }
      var queuedAttack = attackPulse;
      var hasActionAim = action.active && (action.aimed || action.magnitude > 0);
      var frame = {
        moveActive: left.active,
        aimActive: action.active || !!queuedAttack,
        moveX: left.x,
        moveY: left.y,
        aimX: queuedAttack
          ? queuedAttack.aimX
          : (hasActionAim ? action.lastAimX : (Number(facing) < 0 ? -1 : 1)),
        aimY: queuedAttack ? queuedAttack.aimY : (hasActionAim ? action.lastAimY : 0),
        buttons: {
          jump: jumpPulsePointer != null,
          attack: rifleAttack || !!queuedAttack,
          pickup: buttons.pickup.held || buttons.pickup.pulse || pickupPulsePointer != null,
          reload: buttons.reload.held || buttons.reload.pulse,
          drop: dropPulsePointer != null,
          unarmed: buttons.unarmed.held || buttons.unarmed.pulse
        }
      };
      BUTTON_NAMES.forEach(function (name) { buttons[name].pulse = false; });
      jumpPulsePointer = null;
      dropPulsePointer = null;
      attackPulse = null;
      pickupPulsePointer = null;
      return frame;
    }

    function stickVisual(stick) {
      return {
        active: stick.active,
        pointerId: stick.pointerId,
        originX: stick.originX,
        originY: stick.originY,
        knobX: stick.knobX,
        knobY: stick.knobY,
        x: stick.x,
        y: stick.y,
        magnitude: stick.magnitude
      };
    }

    function actionVisual() {
      var result = stickVisual(action);
      result.phase = action.phase;
      result.weapon = action.weapon;
      result.pickupCandidate = action.pickupCandidate;
      result.aimed = action.aimed;
      result.assisted = action.assisted;
      result.manualAim = action.manualAim;
      result.holdProgress = action.weapon === "rifle" && action.aimed
        ? clamp(action.holdTicks / config.rifleHoldTicks, 0, 1)
        : 0;
      return result;
    }

    function visual(side) {
      if (side === "left") return stickVisual(left);
      if (side === "right") return actionVisual();
      return null;
    }

    function buttonVisual(name) {
      var button = buttons[name];
      if (!button) return null;
      return { held: button.held, pointerId: button.pointerId };
    }

    return {
      startStick: startStick,
      startAction: startAction,
      startButton: startButton,
      movePointer: movePointer,
      endPointer: endPointer,
      cancelPointer: cancelPointer,
      clear: clear,
      read: read,
      visual: visual,
      actionVisual: actionVisual,
      buttonVisual: buttonVisual,
      config: Object.freeze(config)
    };
  }

  root.StickTouch = Object.freeze({
    CONFIG: CONFIG,
    normalizeStick: normalizeStick,
    closestLiveEnemyAim: closestLiveEnemyAim,
    createController: createController
  });
}(typeof window !== "undefined" ? window : globalThis));
