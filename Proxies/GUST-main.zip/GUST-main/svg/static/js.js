//<![CDATA[
(function () {
    
  const XHTML_NS = "http://www.w3.org/1999/xhtml";
  const root = document.querySelector("foreignObject").firstElementChild;
  const head = root.querySelector("head");
  const body = root.querySelector("body");
  const originalCreateElement = document.createElement.bind(document);
  const originalCreateElementNS = document.createElementNS.bind(document);

  Object.defineProperty(document, "head", {
    get() {
      return head;
    },
    configurable: true,
  });
  Object.defineProperty(document, "body", {
    get() {
      return body;
    },
    configurable: true,
  });
  Object.defineProperty(document, "documentElement", {
    get() {
      return root;
    },
    configurable: true,
  });

  document.createElement = function (tagName, options) {
    if (typeof tagName === "string") {
      return originalCreateElementNS(XHTML_NS, tagName, options);
    }
    return originalCreateElement(tagName, options);
  };

  document.createElementNS = function (namespaceURI, qualifiedName, options) {
    if (namespaceURI == null || namespaceURI === XHTML_NS) {
      return originalCreateElementNS(XHTML_NS, qualifiedName, options);
    }
    return originalCreateElementNS(namespaceURI, qualifiedName, options);
  };

  function escapeXml(str) {
    if (!str) return "";
    return str.replace(/[<>&]/g, function (m) {
      if (m === "<") return "&lt;";
      if (m === ">") return "&gt;";
      if (m === "&") return "&amp;";
      return m;
    });
  }

  // ── Per-instance storage isolation ────────────────────────────────
  // Each downloaded copy of this file gets a unique instance ID so
  // that multiple tabs/windows (all on file://) never share data.
  const _INST_META_KEY = "__gust_inst__";
  let _INST_ID;
  try {
    _INST_ID = window._sessionInstId;
    if (!_INST_ID) {
      // Prefer sessionStorage so the same tab reloading keeps its ID,
      // but a newly opened copy gets a fresh one.
      _INST_ID = sessionStorage.getItem(_INST_META_KEY);
      if (!_INST_ID) {
        _INST_ID =
          "gi_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
        sessionStorage.setItem(_INST_META_KEY, _INST_ID);
      }
      window._sessionInstId = _INST_ID;
    }
  } catch (e) {
    _INST_ID = "gi_fallback";
  }

  const _LS_PFX = _INST_ID + ":";

  // Namespaced wrapper – all outer-shell code uses `ls` instead of `localStorage`
  const ls = {
    getItem: (k) => {
      try {
        return localStorage.getItem(_LS_PFX + k);
      } catch (e) {
        return null;
      }
    },
    setItem: (k, v) => {
      try {
        localStorage.setItem(_LS_PFX + k, v);
      } catch (e) {}
    },
    removeItem: (k) => {
      try {
        localStorage.removeItem(_LS_PFX + k);
      } catch (e) {}
    },
    // clear() only removes keys belonging to this instance
    clear: () => {
      try {
        const toRemove = [];
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (k && k.startsWith(_LS_PFX)) toRemove.push(k);
        }
        toRemove.forEach((k) => localStorage.removeItem(k));
      } catch (e) {}
    },
    // Enumerate only this instance's keys
    get length() {
      try {
        return Object.keys(localStorage).filter((k) => k.startsWith(_LS_PFX))
          .length;
      } catch (e) {
        return 0;
      }
    },
    key: (i) => {
      try {
        const ks = Object.keys(localStorage).filter((k) =>
          k.startsWith(_LS_PFX),
        );
        return ks[i] ? ks[i].slice(_LS_PFX.length) : null;
      } catch (e) {
        return null;
      }
    },
  };

  // Per-instance IndexedDB name prefix (used for ProxyCache)
  const _IDB_PFX = _INST_ID + "_";
  // ─────────────────────────────────────────────────────────────────

  let WISP = (function () {
    try {
      return ls.getItem("gust:wisp:v1") || "wss://wisp.rhw.one/wisp/";
    } catch {
      return "wss://wisp.rhw.one/wisp/";
    }
  })();
  const $ = (s) => document.getElementById(s);
  const frame = $("frame");
  let _pendingNavHint = null;
  // Set to true right before we assign a blob URL to frame.src.
  // Cleared at the start of the load event so we can distinguish
  // our own intentional blob loads from native iframe escapes.
  // (Chrome treats blob URLs from file:// pages as cross-origin,
  //  so .location.href throws for both cases in the catch below.)
  let _blobLoadPending = false;

  // ── Native navigation escape interceptor ──────────────────────
  // If a proxied page causes the iframe to navigate natively
  // (e.g. Brave search redirect links that bypass the postMessage
  // click intercept), catch the load event, read the landed URL,
  // and re-route it through the proxy immediately.
  frame.addEventListener(
    "load",
    () => {
      const _wasBlobLoad = _blobLoadPending;
      _blobLoadPending = false;
      try {
        const landed = frame.contentWindow?.location?.href;
        if (
          !landed ||
          landed === "about:blank" ||
          landed === "about:srcdoc" ||
          landed.startsWith("blob:")
        )
          return;
        // iframe landed on a real URL natively — reroute via proxy
        _pendingNavHint = null;
        frame.src = "about:blank";
        go(landed, true);
      } catch (crossOriginErr) {
        // .location.href throws for cross-origin pages AND for blob URLs
        // loaded from a file:// context (Chrome treats them as null-origin).
        // Use _wasBlobLoad to tell them apart: if we just intentionally
        // loaded a blob, this is not a native escape — bail out.
        if (_wasBlobLoad) return;
        // Real native escape to a cross-origin URL — recover.
        try {
          const hint = _pendingNavHint;
          _pendingNavHint = null;
          const escapedSrc = frame.src;
          const recoveryUrl =
            hint && !hint.startsWith("blob:") && hint !== "about:blank"
              ? hint
              : escapedSrc &&
                  !escapedSrc.startsWith("blob:") &&
                  escapedSrc !== "about:blank"
                ? escapedSrc
                : null;
          if (recoveryUrl) {
            frame.src = "about:blank";
            go(recoveryUrl, true);
          } else {
            frame.src = "about:blank";
          }
        } catch (_) {}
      }
    },
    true,
  );
  // ─────────────────────────────────────────────────────────────

  const urlInput = $("url");
  const overlay = $("overlay");
  const overlayText = $("overlayText");
  const logbox = $("logbox");
  const progressBar = $("progress");
  const progressWrap = $("progressWrap");
  const statsEl = $("stats");
  const statusDot = $("statusDot");
  const statusText = $("statusText");
  const cacheSizeEl = $("cacheSize");
  const tabTitle = $("tabTitle");
  const securityChip = $("securityChip");
  const securityText = $("securityText");
  const bookmarkBtn = $("bookmarkBtn");
  const bookmarksEl = $("bookmarks");
  const bookmarksWrap = $("bookmarksWrap");
  const bookmarksToggle = $("bookmarksToggle");
  const showBookmarksBtn = $("showBookmarksBtn");
  const homeBtn = $("home");
  const blockToggle = $("blockToggle");
  const blockState = $("blockState");
  const devToggle = $("devToggle");
  const codeBtn = $("codeBtn");
  const logsEl = $("logs");
  const elementsEl = $("elements");
  const elementsTree = $("elementsTree");
  const refreshElements = $("refreshElements");
  const logsResizeHandle = $("logsResizeHandle");
  const elementsResizeHandle = $("elementsResizeHandle");
  const titlebarStatusDot = $("titlebarStatusDot");
  const titlebarStatusLabel = $("titlebarStatusLabel");
  const newTabBtn = $("newTab");
  const closeTabBtn = $("closeTab");
  const newtab = $("newtab");
  const ntBg = $("ntBg");
  const ntTime = $("ntTime");
  const ntDate = $("ntDate");
  const ntSearch = $("ntSearch");
  const ntSearchBtn = $("ntSearchBtn");
  const ntEngine = $("ntEngine");
  const ntEngineLabel = $("ntEngineLabel");
  const ntEngineDropdown = $("ntEngineDropdown");
  const ntFavorites = $("ntFavorites");
  const ntWallpaperBtn = $("ntWallpaperBtn");
  const ntClearCache = $("ntClearCache");
  const ntDevtools = $("ntDevtools");
  const copyLogsBtn = $("copyLogs");

  let curl = null;
  let abortCtrl = null;
  let pageUrl = "";
  let isErrorPage = false;
  let currentDoc = null;
  let hist = [];
  let histIdx = -1;
  let navId = 0;
  let selectedEngine = (function () {
    try {
      return ls.getItem("gust:engine:v1") || "brave";
    } catch {
      return "brave";
    }
  })();

  let totalRequests = 0;
  let pendingRequests = 0;
  let cachedHits = 0;
  let streamCount = 0;
  let idleTimer = null;
  const HOME_INTERNAL = "gust://newtab";

  const SETTINGS_INTERNAL = "gust://settings";

  const VALID_SETTINGS_SECTIONS = new Set([
    "connection",
    "search",
    "privacy",
    "cache",
    "filesandmedia",
    "appearance",
    "homescreen",
    "shortcuts",
    "language",
    "tutorial",
    "about",
    "fallback",
  ]);

  function isSettingsPage(url) {
    return (
      url === SETTINGS_INTERNAL || (url && url.startsWith("gust://settings/"))
    );
  }

  function isInvalidInternal(url) {
    if (!url || !url.startsWith("gust://")) return false;
    if (url === HOME_INTERNAL || url === SETTINGS_INTERNAL) return false;
    if (url.startsWith("gust://settings/")) {
      const section = url.replace("gust://settings/", "").split("/")[0];
      return !VALID_SETTINGS_SECTIONS.has(section);
    }
    return true;
  }

  function renderErrorPage(
    url,
    errorType,
    errorCode,
    errorDescription,
    errorSuggestions,
  ) {
    const suggestionsHTML = (errorSuggestions || [])
      .map((s) => `<li>${s}</li>`)
      .join("");
    frame.srcdoc = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Error - Gust Browser</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap');
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Space Grotesk', 'Segoe UI', sans-serif;
            background: #181c21;
            color: #f0f4f8;
            min-height: 100vh;
            padding: 0;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .error-content {
            background: #1c2026;
            padding: 48px;
            width: 100%;
            height: 100vh;
            margin: 0;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        
        .error-brand {
            position: absolute;
            top: 32px;
            left: 32px;
            display: flex;
            align-items: center;
            gap: 10px;
            opacity: 0.9;
        }
        
        .error-brand i {
            font-size: 24px;
            color: #9de5ff;
        }
        
        .error-brand span {
            font-size: 20px;
            font-weight: 700;
            color: #9de5ff;
            letter-spacing: 0.02em;
        }
        
        .error-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 24px;
            margin-bottom: 32px;
            text-align: center;
            max-width: 700px;
        }
        
        @keyframes error-alarm-ring {
            0%   { box-shadow: 0 0 0 0px rgba(255,149,149,0.5); }
            40%  { box-shadow: 0 0 0 22px rgba(255,149,149,0); }
            100% { box-shadow: 0 0 0 0px rgba(255,149,149,0); }
        }
        @keyframes error-alarm-shake {
            0%,100% { transform: rotate(0deg)   scale(1); }
            8%       { transform: rotate(-18deg) scale(1.15); }
            16%      { transform: rotate(16deg)  scale(1.1); }
            24%      { transform: rotate(-12deg) scale(1.05); }
            32%      { transform: rotate(10deg)  scale(1.05); }
            40%      { transform: rotate(-6deg)  scale(1); }
            48%      { transform: rotate(4deg)   scale(1); }
            56%      { transform: rotate(-2deg)  scale(1); }
            62%,100% { transform: rotate(0deg)   scale(1); }
        }
        .error-icon {
            width: 80px;
            height: 80px;
            background: rgba(255, 149, 149, 0.15);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            animation: error-alarm-ring 1.8s ease-out 0.4s infinite;
        }
        
        .error-icon i {
            font-size: 36px;
            color: #ff9595;
            animation: error-alarm-shake 1.8s cubic-bezier(0.36,0.07,0.19,0.97) 0.4s infinite;
            transform-origin: center bottom;
        }
        
        .error-title-group {
            flex: 1;
            width: 100%;
        }
        
        .error-type {
            font-size: 32px;
            font-weight: 700;
            color: #f0f4f8;
            margin-bottom: 8px;
            line-height: 1.2;
        }
        
        .error-code {
            font-size: 14px;
            color: #7d8a98;
            font-weight: 500;
            font-family: 'JetBrains Mono', monospace;
            letter-spacing: 0.3px;
        }
        
        .error-description {
            max-width: 500px;
            color: #b8c4d0;
            line-height: 1.6;
            margin-bottom: 24px;
            font-size: 15px;
        }
        
        .error-suggestions {
            text-align: left;
            background: rgba(255, 255, 255, 0.03);
            padding: 24px 32px;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            width: 100%;
            max-width: 500px;
        }
        
        .error-suggestions h3 {
            font-size: 14px;
            font-weight: 600;
            color: #9de5ff;
            margin-bottom: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .error-suggestions ul {
            list-style: none;
        }
        
        .error-suggestions li {
            position: relative;
            padding-left: 20px;
            margin-bottom: 8px;
            color: #b8c4d0;
            font-size: 14px;
        }
        
        .error-suggestions li::before {
            content: '•';
            position: absolute;
            left: 0;
            color: #70d4ff;
        }
        
        .error-actions {
            display: flex;
            gap: 12px;
            margin-top: 32px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .error-btn {
            padding: 12px 24px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s;
            border: none;
            font-family: 'Space Grotesk', sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .error-btn-primary {
            background: #9de5ff;
            color: #0d0f12;
        }
        
        .error-btn-primary:hover {
            background: #70d4ff;
            transform: translateY(-2px);
        }
        
        .error-btn-secondary {
            background: transparent;
            color: #b8c4d0;
            border: 1px solid #4f5963;
        }
        
        .error-btn-secondary:hover {
            background: rgba(255, 255, 255, 0.08);
            border-color: #5a6370;
            color: #f0f4f8;
            transform: translateY(-1px);
        }
        
        @media (max-width: 600px) {
            body {
                padding: 12px;
            }
            
            .error-content {
                padding: 32px 24px;
            }
            
            .error-brand {
                position: static;
                margin-bottom: 24px;
            }
            
            .error-header {
                margin-top: 0;
            }
            
            .error-type {
                font-size: 24px;
            }

            .error-icon {
                width: 64px;
                height: 64px;
            }

            .error-icon i {
                font-size: 28px;
            }
        }
    </style>
</head>
<body>
    <div class="error-content">
        <div class="error-brand" onclick="window.parent.postMessage({t:'n', u:'gust://newtab'}, '*')">
            <i class="fas fa-wind"></i>
            <span>GUST</span>
        </div>
        
        <div class="error-header">
            <div class="error-icon">
                <i class="fas fa-triangle-exclamation"></i>
            </div>
            <div class="error-title-group">
                <h1 class="error-type">${errorType}</h1>
                <div class="error-code">${errorCode}</div>
            </div>
        </div>
        
        <div class="error-description">
            ${errorDescription}
        </div>

        ${
          suggestionsHTML
            ? `
        <div class="error-suggestions">
            <h3>Try these steps</h3>
            <ul>
                ${suggestionsHTML}
            </ul>
        </div>`
            : ""
        }
        
        <div class="error-actions">
            <button class="error-btn error-btn-primary" onclick="window.parent.postMessage({type:'reloadPage'}, '*')">
                <i class="fas fa-rotate-right"></i>
                Reload Page
            </button>
            <button class="error-btn error-btn-secondary" onclick="window.parent.postMessage({type:'goBack'}, '*')">
                <i class="fas fa-arrow-left"></i>
                Go Back
            </button>
            <button class="error-btn error-btn-secondary" onclick="window.parent.postMessage({type:'openDevTools'}, '*')">
                <i class="fas fa-server"></i>
                Open Logs
            </button>
        </div>
    </div>
</body>
</html>`;
  }

  const SEARCH_ENGINES = {
    brave: "https://search.brave.com/search?q=",
    ddg: "https://duckduckgo.com/?q=",
    google: "https://www.google.com/search?q=",
    bing: "https://www.bing.com/search?q=",
  };
  const WALLPAPER_QUERIES = [
    "aurora",
    "nebula",
    "ocean",
    "fog",
    "desert",
    "mountain",
    "city night",
    "forest",
    "abstract",
  ];
  const WALLPAPER_STORAGE_KEY = "gust:newtab-wallpaper:v1";
  const FAV_KEY = "gust:favorites:v1";
  const BM_KEY = "gust:bookmarks:v1";
  let favorites = [];
  const defaultBookmarks = [];
  let bookmarks = [];
  let blockEnabled = (function () {
    try {
      const saved = ls.getItem("gust:block:v1");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  })();
  let tabCacheEnabled = true;
  let panelWidthPersist = true;
  let wallpaperIdx = 0;

  const TAB_CACHE_KEY = "gust:tabs:v1";

  function saveTabs() {
    try {
      const tabsToSave = tabs.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        history: t.history,
        historyIndex: t.historyIndex,
      }));
      ls.setItem(
        TAB_CACHE_KEY,
        JSON.stringify({
          tabs: tabsToSave,
          activeTabId: activeTabId,
          nextTabId: nextTabId,
        }),
      );
    } catch (e) {
      console.error("Failed to save tabs:", e);
    }
  }

  function loadTabs() {
    try {
      const saved = ls.getItem(TAB_CACHE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        if (data.tabs && data.tabs.length > 0) {
          tabs = data.tabs;
          activeTabId = data.activeTabId || tabs[0].id;
          nextTabId = data.nextTabId || Math.max(...tabs.map((t) => t.id)) + 1;
          return true;
        }
      }
    } catch (e) {
      console.error("Failed to load tabs:", e);
    }
    return false;
  }

  let tabs = [
    {
      id: 1,
      title: "New Tab",
      url: HOME_INTERNAL,
      history: [],
      historyIndex: -1,
      cachedContent: null,
      cachedUrl: null,
    },
  ];
  let activeTabId = 1;
  let nextTabId = 2;

  function getActiveTab() {
    return tabs.find((t) => t.id === activeTabId);
  }

  const pendingNewTabIds = new Set();

  function createTab(url = HOME_INTERNAL) {
    const tab = {
      id: nextTabId++,
      title: "New Tab",
      url: url,
      history: url !== HOME_INTERNAL ? [url] : [],
      historyIndex: url !== HOME_INTERNAL ? 0 : -1,
      cachedContent: null,
      cachedUrl: null,
      cachedDoc: null,
      blobSrc: null,
      hasError: false,
    };
    tabs.push(tab);
    pendingNewTabIds.add(tab.id);
    saveTabs();
    renderTabs();
    switchToTab(tab.id);
    setTimeout(() => {
      if (tabStripEl) {
        smoothScroll(tabStripEl, tabStripEl.scrollWidth + 60);
        updateTabScrollBtns();
      }
    }, 80);
    if (url !== HOME_INTERNAL) go(url);
  }

  function closeTabAnimated(tabId) {
    const tabStrip = document.querySelector(".tab-strip");
    const tabEl = tabStrip?.querySelector(`.tab[data-tab-id="${tabId}"]`);
    if (tabEl && tabs.length > 1) {
      tabEl.classList.add("tab-leaving");
      tabEl.addEventListener("animationend", () => closeTab(tabId), {
        once: true,
      });
    } else {
      closeTab(tabId);
    }
  }

  function closeTab(tabId) {
    const index = tabs.findIndex((t) => t.id === tabId);
    if (index === -1 || tabs.length === 1) return;

    const ctrl = tabAbortControllers.get(tabId);
    if (ctrl) {
      ctrl.abort();
      tabAbortControllers.delete(tabId);
    }

    closedTabIds.add(tabId);
    setTimeout(() => closedTabIds.delete(tabId), 5000);

    for (let i = fetchQueue.length - 1; i >= 0; i--) {
      if (fetchQueue[i].tabId === tabId) {
        fetchQueue[i].rej(new DOMException("Aborted", "AbortError"));
        fetchQueue.splice(i, 1);
        pendingRequests = Math.max(0, pendingRequests - 1);
      }
    }
    // Only evict in-flight entries that belong to this tab's abort signal,
    // leaving other tabs' in-flight requests intact for deduplication.
    for (const [_url, _promise] of inFlight) {
      if (_promise._tabId === tabId) inFlight.delete(_url);
    }
    updateStats();

    const closingTab = tabs[index];

    // Always silence & revoke the closing tab.
    // If it's the active tab, we can directly mute the frame.
    // If it's a background tab, we can't reach its audio (single iframe arch),
    // but we still revoke its blob URL so the browser can GC the page.
    if (activeTabId === tabId) {
      // Silence current frame media immediately
      try {
        const doc = frame.contentDocument || frame.contentWindow?.document;
        if (doc) {
          doc.querySelectorAll("video, audio").forEach((el) => {
            el.pause();
            el.src = "";
            try {
              el.load();
            } catch (e) {}
          });
        }
      } catch (e) {}
      try {
        const blobSrc = frame.src;
        frame.src = "about:blank";
        if (blobSrc && blobSrc.startsWith("blob:"))
          setTimeout(() => URL.revokeObjectURL(blobSrc), 300);
      } catch (e) {}
    }

    if (closingTab) {
      if (closingTab.blobSrc && closingTab.blobSrc !== frame.src) {
        setTimeout(() => URL.revokeObjectURL(closingTab.blobSrc), 300);
      }
      closingTab.cachedContent = null;
      closingTab.cachedDoc = null;
      closingTab.cachedUrl = null;
      closingTab.blobSrc = null;
      closingTab.hasAudio = false;
    }

    tabs.splice(index, 1);

    if (activeTabId === tabId) {
      const newActiveTab = tabs[Math.max(0, index - 1)];
      switchToTab(newActiveTab.id);
    }

    saveTabs();
    renderTabs();
  }

  function applyMuteToFrame(muted) {
    // 1. Set the iframe's muted attribute (works in some browsers)
    frame.muted = !!muted;
    // 2. Inject a script into the frame to mute/unmute all media elements
    try {
      const doc = frame.contentDocument || frame.contentWindow?.document;
      if (doc) {
        const mediaEls = doc.querySelectorAll("video, audio");
        mediaEls.forEach((el) => {
          el.muted = !!muted;
        });
      }
    } catch (e) {}
    // 3. postMessage so any future media created inside the frame is also muted
    try {
      frame.contentWindow?.postMessage(
        { type: "gust:setMuted", muted: !!muted },
        "*",
      );
    } catch (e) {}
  }

  // Poll the active tab's iframe every 1.5s for playing audio/video
  setInterval(() => {
    const tab = getActiveTab();
    if (!tab || tab.url === HOME_INTERNAL || isSettingsPage(tab.url)) return;
    let playing = false;
    try {
      const doc = frame.contentDocument || frame.contentWindow?.document;
      if (doc) {
        const els = doc.querySelectorAll("video, audio");
        // Check for any non-muted playing media (even if we've muted via tab.muted,
        // check paused state to know if audio was playing before mute)
        playing = [...els].some((el) => !el.paused && el.readyState > 0);
      }
    } catch (e) {}
    if (!!tab.hasAudio !== playing) {
      tab.hasAudio = playing;
      renderTabs();
    }
  }, 1500);

  function switchToTab(tabId) {
    const tab = tabs.find((t) => t.id === tabId);
    if (!tab) return;

    // Silence the current tab's media before switching away
    if (activeTabId !== null && activeTabId !== tabId) {
      const currentTab = tabs.find((t) => t.id === activeTabId);
      if (currentTab) {
        // Pause all media so audio doesn't bleed into the next tab
        try {
          const doc = frame.contentDocument || frame.contentWindow?.document;
          if (doc) {
            doc.querySelectorAll("video, audio").forEach((el) => {
              try {
                el.pause();
              } catch (e) {}
            });
          }
        } catch (e) {}
        // Save scroll position and blob URL
        try {
          currentTab.scrollY = frame.contentWindow?.scrollY || 0;
        } catch (e) {}
        const src = frame.src;
        if (src && src.startsWith("blob:")) currentTab.blobSrc = src;
      }
    }

    activeTabId = tabId;
    // Clear any lingering inspect-element highlight from the previous tab
    const _prevHighlight = $("elemHighlightOverlay");
    if (_prevHighlight) _prevHighlight.style.display = "none";
    pageUrl = tab.url;
    hist = [...tab.history];
    histIdx = tab.historyIndex;

    urlInput.value = tab.url;
    setTabTitle(tab.title);
    updateNav();
    renderTabs();
    saveTabs();

    applyMuteToFrame(!!tab.muted);

    if (elementsEl && !elementsEl.classList.contains("hidden")) {
      setTimeout(() => inspectCurrentPage(), 150);
    }

    if (tab.url === HOME_INTERNAL) {
      showNewTab(false);
    } else if (isSettingsPage(tab.url)) {
      const section = tab.url.replace("gust://settings/", "") || "connection";
      showSettingsPage(
        false,
        section === "gust://settings" ? "connection" : section,
      );
    } else if (tab.blobSrc) {
      newtab.classList.remove("active");
      hideSettingsPage();
      frame.style.display = "block";
      const restoreTab = tab;
      frame.onload = () => {
        applyMuteToFrame(!!restoreTab.muted);
        if (restoreTab.scrollY) {
          try {
            frame.contentWindow?.scrollTo(0, restoreTab.scrollY);
          } catch (e) {}
        }
        frame.onload = null;
      };
      _blobLoadPending = true;
      frame.src = tab.blobSrc;
      isErrorPage = !!tab.hasError;
      updateSecurityChip(tab.url, tab.hasError ? "error" : undefined);
      updateBookmarkButton();
    } else {
      go(tab.url, false);
    }
  }

  function updateTabUrl(url) {
    const tab = getActiveTab();
    if (tab) {
      tab.url = url;
      tab.history = [...hist];
      tab.historyIndex = histIdx;
      saveTabs();
      renderTabs();
    }
  }

  function renderTabs() {
    const tabStrip = document.querySelector(".tab-strip");
    const addBtn = document.getElementById("newTab");

    if (!tabStrip || !addBtn) return;

    const existingTabs = tabStrip.querySelectorAll(".tab");
    existingTabs.forEach((t) => t.remove());

    tabs.forEach((tab) => {
      const tabEl = document.createElement("button");
      tabEl.className = "tab" + (tab.id === activeTabId ? " active" : "");
      tabEl.setAttribute("data-tab-id", tab.id);
      tabEl.setAttribute("draggable", "false");

      const iconSpan = document.createElement("span");
      iconSpan.className = "tab-icon";

      iconSpan.innerHTML = "";

      if (tab.url === HOME_INTERNAL) {
        const icon = document.createElement("i");
        icon.className = "fas fa-earth-americas";
        iconSpan.appendChild(icon);
      } else if (isSettingsPage(tab.url)) {
        const icon = document.createElement("i");
        icon.className = "fas fa-gear";
        iconSpan.appendChild(icon);
      } else if (isInvalidInternal(tab.url) || tab.hasError) {
        const icon = document.createElement("i");
        icon.className = "fas fa-circle-xmark";
        icon.style.color = "var(--err)";
        iconSpan.appendChild(icon);
      } else {
        const favUrl = faviconFor(tab.url);
        const img = document.createElement("img");
        img.setAttribute("data-favicon-url", favUrl);
        img.style.cssText =
          "width: 16px; height: 16px; border-radius: 3px; margin: 0 1px;";
        img.onerror = function () {
          this.style.display = "none";
          if (this.nextElementSibling)
            this.nextElementSibling.style.display = "inline";
        };
        const fallbackIcon = document.createElement("i");
        fallbackIcon.className = "fas fa-globe";
        fallbackIcon.style.display = "none";
        iconSpan.appendChild(img);
        iconSpan.appendChild(fallbackIcon);

        resolveFaviconSrc(favUrl)
          .then((src) => {
            if (src) img.src = src;
          })
          .catch(() => {});
      }
      tabEl.appendChild(iconSpan);

      const titleSpan = document.createElement("span");
      titleSpan.className = "tab-title";
      titleSpan.textContent = tab.title;
      tabEl.appendChild(titleSpan);

      const muteSpan = document.createElement("span");
      muteSpan.className = "tab-mute-icon";
      muteSpan.title = tab.muted ? "Unmute tab" : "Mute tab";
      const muteIcon = document.createElement("i");
      muteIcon.className = `fas ${tab.muted ? "fa-volume-xmark" : "fa-volume-high"}`;
      muteIcon.style.cssText = "color:var(--ac);font-size:11px;";
      muteSpan.appendChild(muteIcon);
      tabEl.appendChild(muteSpan);

      const closeBtn = document.createElement("button");
      closeBtn.className = "tab-close";
      closeBtn.textContent = "×";
      tabEl.appendChild(closeBtn);

      if (tab.muted) tabEl.classList.add("muted");
      if (tab.hasAudio && !tab.muted) tabEl.classList.add("audio-playing");

      const isNewTab = pendingNewTabIds.has(tab.id);
      if (isNewTab) pendingNewTabIds.delete(tab.id);

      muteSpan.addEventListener("click", (e) => {
        e.stopPropagation();
        const t = tabs.find((x) => x.id === tab.id);
        if (!t) return;
        t.muted = !t.muted;
        if (t.id === activeTabId) applyMuteToFrame(t.muted);
        renderTabs();
        saveTabs();
      });

      tabEl.addEventListener("mouseenter", () => {
        const titleEl = tabEl.querySelector(".tab-title");
        if (titleEl && titleEl.scrollWidth > titleEl.clientWidth) {
          showTooltip(tabEl, tab.title);
        }
      });
      tabEl.addEventListener("mouseleave", hideTooltip);

      tabEl.addEventListener("click", (e) => {
        if (!e.target.classList.contains("tab-close")) {
          switchToTab(tab.id);
          setTimeout(() => {
            const strip = tabStripEl;
            const elLeft = tabEl.offsetLeft;
            const elRight = elLeft + tabEl.offsetWidth;
            const visLeft = strip.scrollLeft;
            const visRight = visLeft + strip.clientWidth;
            if (elLeft < visLeft) smoothScroll(strip, elLeft - visLeft - 8);
            else if (elRight > visRight)
              smoothScroll(strip, elRight - visRight + 8);
          }, 30);
        }
      });

      closeBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        closeTabAnimated(tab.id);
      });

      tabStrip.insertBefore(tabEl, addBtn);

      if (isNewTab) {
        void tabEl.offsetWidth;
        tabEl.classList.add("tab-entering");
        tabEl.addEventListener(
          "animationend",
          () => tabEl.classList.remove("tab-entering"),
          { once: true },
        );
      }
    });

    updateTabScrollBtns();
    setTimeout(scrollActiveTabIntoView, 50);
  }

  // ── Drag-to-reorder tabs ──────────────────────────────────────────
  (function initTabDrag() {
    let dragTabId = null;
    let dragTabW = 0;
    let ghostEl = null;
    let slotEl = null;
    let cursorOffX = 0;
    let ghostY = 0;
    let lastX = 0;
    let autoRafId = null;
    let slotIdx = -1; // current insertion index of the slot

    function getTabEls() {
      // All tabs except the dragging one and the slot
      return [
        ...document.querySelectorAll(
          `.tab-strip .tab[data-tab-id]:not([data-tab-id="${dragTabId}"])`,
        ),
      ];
    }

    function createSlot(w) {
      slotEl = document.createElement("div");
      slotEl.className = "tab-drag-slot";
      slotEl.style.setProperty("--slot-w", w + "px");
      // Don't insert into DOM yet — moveSlotTo places it at the correct
      // position on the first call, avoiding a flash of blank space at
      // the tab's original location.
    }

    function moveSlotTo(idx) {
      if (idx === slotIdx && slotEl.parentNode) return;
      slotIdx = idx;
      const strip = document.getElementById("tabStrip");
      const addBtn = document.getElementById("newTab");
      const others = getTabEls();
      const ref = idx < others.length ? others[idx] : addBtn;
      strip.insertBefore(slotEl, ref);
      // Trigger open animation on first insertion only
      if (!slotEl.classList.contains("slot-open")) {
        requestAnimationFrame(() => slotEl.classList.add("slot-open"));
      }
    }

    // Given cursor X, find which slot index to use (based on other tabs' midpoints)
    function getSlotIdx(clientX) {
      const others = getTabEls();
      for (let i = 0; i < others.length; i++) {
        const r = others[i].getBoundingClientRect();
        if (clientX < r.left + r.width / 2) return i;
      }
      return others.length;
    }

    function createGhost(tabEl, cursorX) {
      const rect = tabEl.getBoundingClientRect();
      cursorOffX = cursorX - rect.left;
      ghostY = rect.top;
      dragTabW = rect.width;

      ghostEl = document.createElement("div");
      ghostEl.className = "tab-drag-ghost";
      ghostEl.style.width = dragTabW + "px";
      const icon = tabEl.querySelector(".tab-icon")?.innerHTML || "";
      const title = tabEl.querySelector(".tab-title")?.textContent || "";
      ghostEl.innerHTML =
        `<span style="font-size:14px;color:var(--ac);flex-shrink:0;display:flex;align-items:center;">${icon}</span>` +
        `<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${title}</span>`;
      ghostEl.style.left = cursorX - cursorOffX + "px";
      ghostEl.style.top = ghostY + "px";
      document.body.appendChild(ghostEl);
      requestAnimationFrame(() => ghostEl.classList.add("ghost-visible"));
    }

    function doAutoScroll() {
      const strip = document.getElementById("tabStrip");
      if (strip) {
        const r = strip.getBoundingClientRect();
        const edge = 44,
          speed = 7;
        if (lastX < r.left + edge) strip.scrollLeft -= speed;
        else if (lastX > r.right - edge) strip.scrollLeft += speed;
      }
      autoRafId = requestAnimationFrame(doAutoScroll);
    }

    function onPointerDown(e) {
      if (e.button !== 0) return;
      const tabEl = e.target.closest(".tab[data-tab-id]");
      if (!tabEl || e.target.closest(".tab-close")) return;

      const startX = e.clientX;
      let active = false;

      function onMove(ev) {
        lastX = ev.clientX;

        if (!active && Math.abs(ev.clientX - startX) > 6) {
          active = true;
          dragTabId = tabEl.dataset.tabId;

          // Freeze every tab at its current pixel width so nothing
          // resizes during the drag — not the held tab, not its neighbours.
          document
            .querySelectorAll("#tabStrip .tab[data-tab-id]")
            .forEach((t) => {
              const w = t.getBoundingClientRect().width;
              t.style.flex = "0 0 " + w + "px";
              t.style.minWidth = w + "px";
              t.style.maxWidth = w + "px";
              t.style.width = w + "px";
            });

          tabEl.classList.add("tab-dragging");
          document.body.style.userSelect = "none";
          document.body.style.cursor = "grabbing";
          createGhost(tabEl, startX);
          createSlot(dragTabW);
          slotIdx = getSlotIdx(ev.clientX);
          moveSlotTo(slotIdx);
          autoRafId = requestAnimationFrame(doAutoScroll);
        }
        if (!active) return;

        // Ghost follows cursor horizontally, locked to row vertically
        ghostEl.style.left = ev.clientX - cursorOffX + "px";

        // Move slot to wherever cursor is pointing
        const newIdx = getSlotIdx(ev.clientX);
        moveSlotTo(newIdx);
      }

      function onUp(ev) {
        document.removeEventListener("pointermove", onMove);
        document.removeEventListener("pointerup", onUp);
        if (!active) return;

        cancelAnimationFrame(autoRafId);
        autoRafId = null;
        document.body.style.userSelect = "";
        document.body.style.cursor = "";

        // Commit: rebuild tabs[] from DOM order, with dragTab inserted at slot position
        const strip = document.getElementById("tabStrip");
        const addBtn = document.getElementById("newTab");

        // Replace slot with the real tab
        const dragTabEl = strip.querySelector(
          `.tab[data-tab-id="${dragTabId}"]`,
        );
        if (dragTabEl && slotEl && slotEl.parentNode) {
          slotEl.parentNode.insertBefore(dragTabEl, slotEl);
        }
        if (slotEl) {
          slotEl.remove();
          slotEl = null;
        }
        if (ghostEl) {
          ghostEl.remove();
          ghostEl = null;
        }

        dragTabEl && dragTabEl.classList.remove("tab-dragging");

        // Unfreeze all tab widths
        document
          .querySelectorAll("#tabStrip .tab[data-tab-id]")
          .forEach((t) => {
            t.style.flex = "";
            t.style.minWidth = "";
            t.style.maxWidth = "";
            t.style.width = "";
          });

        // Read final DOM order to commit to tabs[]
        const finalOrder = [...strip.querySelectorAll(".tab[data-tab-id]")].map(
          (el) => el.dataset.tabId,
        );
        const newOrder = finalOrder
          .map((id) => tabs.find((t) => String(t.id) === String(id)))
          .filter(Boolean);
        const changed = newOrder.some(
          (t, i) => String(t.id) !== String(tabs[i]?.id),
        );
        if (changed) {
          tabs.length = 0;
          newOrder.forEach((t) => tabs.push(t));
          saveTabs();
        }

        const savedId = dragTabId;
        dragTabId = null;
        slotIdx = -1;

        renderTabs();
        requestAnimationFrame(() => {
          const landed = document.querySelector(
            `.tab[data-tab-id="${savedId}"]`,
          );
          if (landed) {
            landed.classList.add("tab-drop-settle");
            landed.addEventListener(
              "animationend",
              () => landed.classList.remove("tab-drop-settle"),
              { once: true },
            );
          }
        });
      }

      document.addEventListener("pointermove", onMove);
      document.addEventListener("pointerup", onUp);
    }

    document.addEventListener("pointerdown", onPointerDown);
  })();
  // ─────────────────────────────────────────────────────────────────

  const tabScrollLeft = $("tabScrollLeft");
  const tabScrollRight = $("tabScrollRight");
  const tabStripEl = $("tabStrip");

  function updateTabScrollBtns() {
    if (!tabStripEl) return;
    const atLeft = tabStripEl.scrollLeft <= 4;
    const atRight =
      tabStripEl.scrollLeft + tabStripEl.clientWidth >=
      tabStripEl.scrollWidth - 8;
    const canScroll = tabStripEl.scrollWidth > tabStripEl.clientWidth + 4;
    tabScrollLeft.classList.toggle("visible", canScroll && !atLeft);
    tabScrollRight.classList.toggle("visible", canScroll && !atRight);
    const wrapper = tabStripEl.closest(".tab-strip-wrapper");
    if (wrapper) {
      wrapper.classList.toggle("fade-left", canScroll && !atLeft);
      wrapper.classList.toggle("fade-right", canScroll && !atRight);
    }
  }

  function scrollActiveTabIntoView() {
    const activeEl = tabStripEl.querySelector(".tab.active");
    if (!activeEl) return;
    const strip = tabStripEl;
    const elLeft = activeEl.offsetLeft;
    const elRight = elLeft + activeEl.offsetWidth;
    const visLeft = strip.scrollLeft;
    const visRight = visLeft + strip.clientWidth;
    if (elLeft < visLeft) smoothScroll(strip, elLeft - visLeft - 8);
    else if (elRight > visRight) smoothScroll(strip, elRight - visRight + 8);
  }

  tabScrollLeft.addEventListener("click", () => {
    const tabW = tabStripEl.querySelector(".tab")?.offsetWidth || 120;
    smoothScroll(tabStripEl, -tabW);
  });
  tabScrollRight.addEventListener("click", () => {
    const tabW = tabStripEl.querySelector(".tab")?.offsetWidth || 120;
    const addW = (document.getElementById("newTab")?.offsetWidth || 42) + 8;
    const remaining =
      tabStripEl.scrollWidth - tabStripEl.scrollLeft - tabStripEl.clientWidth;
    smoothScroll(tabStripEl, remaining <= tabW + addW ? remaining + 4 : tabW);
  });
  tabStripEl.addEventListener("scroll", updateTabScrollBtns);
  new ResizeObserver(updateTabScrollBtns).observe(tabStripEl);

  let _scrollRaf = null;
  function smoothScroll(el, delta) {
    if (_scrollRaf) {
      cancelAnimationFrame(_scrollRaf);
      _scrollRaf = null;
    }
    const start = el.scrollLeft;
    const end = Math.max(
      0,
      Math.min(start + delta, el.scrollWidth - el.clientWidth),
    );
    const dur = 180;
    const t0 = performance.now();
    function ease(t) {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }
    function step(now) {
      const p = Math.min((now - t0) / dur, 1);
      el.scrollLeft = start + (end - start) * ease(p);
      if (p < 1) _scrollRaf = requestAnimationFrame(step);
      else _scrollRaf = null;
    }
    _scrollRaf = requestAnimationFrame(step);
  }

  const cookieJar = new Map();

  function getCookieStore(origin) {
    if (!cookieJar.has(origin)) cookieJar.set(origin, new Map());
    return cookieJar.get(origin);
  }

  function splitSetCookie(header) {
    if (!header) return [];
    if (Array.isArray(header)) return header;
    const parts = [];
    let cur = "";
    let inExpires = false;
    for (let i = 0; i < header.length; i++) {
      const ch = header[i];
      if (ch === ",") {
        if (!inExpires) {
          if (cur.trim()) parts.push(cur.trim());
          cur = "";
          continue;
        }
      }
      cur += ch;
      if (cur.toLowerCase().endsWith("expires=")) inExpires = true;
      if (ch === ";" && inExpires) inExpires = false;
    }
    if (cur.trim()) parts.push(cur.trim());
    return parts;
  }

  function parseCookiePair(str) {
    const m = String(str || "").match(/^([^=]+)=([^;]*)/);
    if (!m) return null;
    return {
      name: m[1].trim(),
      value: m[2],
    };
  }

  function updateCookie(origin, cookieStr) {
    const pair = parseCookiePair(cookieStr);
    if (!pair) return;
    const attrs = {};
    const parts = String(cookieStr).split(";").slice(1);
    parts.forEach((p) => {
      const [k, v] = p.split("=");
      if (!k) return;
      attrs[k.trim().toLowerCase()] = (v || "").trim();
    });
    const store = getCookieStore(origin);
    const maxAge = attrs["max-age"] ? Number(attrs["max-age"]) : null;
    let expiresAt = null;
    if (Number.isFinite(maxAge)) expiresAt = Date.now() + maxAge * 1000;
    else if (attrs.expires) {
      const t = Date.parse(attrs.expires);
      if (!Number.isNaN(t)) expiresAt = t;
    }
    if (maxAge === 0 || (expiresAt && expiresAt < Date.now())) {
      store.delete(pair.name);
      return;
    }
    store.set(pair.name, {
      value: pair.value,
      expiresAt,
    });
  }

  function updateCookiesFromSetCookie(origin, setCookieHeader) {
    splitSetCookie(setCookieHeader).forEach((sc) => updateCookie(origin, sc));
  }

  function getCookieHeader(origin) {
    const store = getCookieStore(origin);
    const now = Date.now();
    for (const [name, data] of store.entries()) {
      if (data.expiresAt && data.expiresAt < now) store.delete(name);
    }
    const entries = [...store.entries()].map(([k, v]) => `${k}=${v.value}`);
    return entries.join("; ");
  }

  function syncCookiesToFrame(origin) {
    if (!frame.contentWindow) return;
    const cookie = getCookieHeader(origin);
    frame.contentWindow.postMessage(
      {
        t: "cookieSync",
        origin,
        cookie,
      },
      "*",
    );
  }

  let wsSeq = 0;
  const wsMap = new Map();

  let MAX_CONCURRENT = (function () {
    try {
      return parseInt(ls.getItem("gust:idlethreads:v1")) || 6;
    } catch {
      return 6;
    }
  })();
  let MAX_CONCURRENT_ACTIVE = (function () {
    try {
      return parseInt(ls.getItem("gust:activethreads:v1")) || 6;
    } catch {
      return 6;
    }
  })();
  let _isPageLoading = false;
  let syncState = 1;
  let layoutChecksum = 0;
  let dbSessionFlux = 0;
  let frameBufferAlpha = 1;
  let currentTabBuffer = 0;
  let renderFlux = 1;
  const CACHE_TTL = 24 * 60 * 60 * 1000;
  const MAX_CACHE_SIZE = 100 * 1024 * 1024;
  const PRIORITY = {
    html: 0,
    css: 1,
    js: 2,
    font: 3,
    image: 4,
    other: 5,
  };

  const SKIP_DOMAINS = [
    "google-analytics.com",
    "googletagmanager.com",
    "doubleclick.net",
    "facebook.net",
    "fbcdn.net",
    "analytics.",
    "tracking.",
    "ads.",
    "adservice.",
    "pagead",
    "adsystem",
    "hotjar.com",
    "clarity.ms",
    "sentry.io",
    "bugsnag.com",
    "newrelic.com",
    "segment.com",
  ];

  const DEFAULT_BLOCKED_SELECTORS = [
    'iframe[src*="ads"]',
    'iframe[src*="googleads"]',
    'iframe[src*="doubleclick"]',
    'div[id*="ad-"]',
    'div[class*="ad-"]',
    'div[class*="ads-"]',
    ".ad-banner",
    ".ad-box",
    ".ad-container",
    ".advertisement",
    "#ads",
    "#google_ads_frame",
    "#carbonads",
    "ins.adsbygoogle",
    "div[data-ad-slot]",
    "div[data-ad-unit]",
  ];

  const FILTER_KEY = "gust:custom-filters:v1";
  let cachedCustomFilters = null;
  let _filterObserverReady = false;
  function getCustomFilters() {
    if (!_filterObserverReady) {
      _filterObserverReady = true;
      setTimeout(() => {
        try {
          const _rootEl = document.getElementById("newtab");
          if (!_rootEl) return;
          let _mutationCount = 0;
          new MutationObserver(() => {}).observe(_rootEl, {
            attributes: true,
            childList: true,
            subtree: true,
            characterData: true,
          });
        } catch (e) {}
      }, 900);
    }
    if (cachedCustomFilters) return cachedCustomFilters;
    try {
      const custom = ls.getItem(FILTER_KEY);
      if (!custom) return (cachedCustomFilters = { network: [], cosmetic: [] });
      const lines = custom
        .split("\n")
        .map((s) => s.trim())
        .filter((s) => s.length > 0 && !s.startsWith("!"));
      const network = [];
      const cosmetic = [];
      lines.forEach((l) => {
        if (
          l.startsWith("||") ||
          l.startsWith("/") ||
          !/[#.\[:]/.test(l) ||
          l.includes("^")
        ) {
          let cleaned = l
            .replace(/^\|\|/, "")
            .replace(/\^$/, "")
            .replace(/^\//, "")
            .replace(/\/$/, "");
          if (cleaned) network.push(cleaned.toLowerCase());
        } else {
          cosmetic.push(l);
        }
      });
      return (cachedCustomFilters = { network, cosmetic });
    } catch {
      return (cachedCustomFilters = { network: [], cosmetic: [] });
    }
  }

  function getBlockedSelectors() {
    return [...DEFAULT_BLOCKED_SELECTORS, ...getCustomFilters().cosmetic];
  }

  function shouldSkip(url) {
    if (!blockEnabled) return false;
    try {
      const urlObj = new URL(url);
      const host = urlObj.hostname.toLowerCase();
      const full = url.toLowerCase();
      const allSkipped = [...SKIP_DOMAINS, ...getCustomFilters().network];
      return allSkipped.some((d) => host.includes(d) || full.includes(d));
    } catch {
      return false;
    }
  }

  function loadBookmarks() {
    try {
      const raw = ls.getItem(BM_KEY);
      if (!raw) return [...defaultBookmarks];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [...defaultBookmarks];
      return parsed.filter(
        (b) => b && b.name && b.url && b.url !== HOME_INTERNAL,
      );
    } catch {
      return [...defaultBookmarks];
    }
  }

  function saveBookmarks() {
    try {
      ls.setItem(BM_KEY, JSON.stringify(bookmarks));
    } catch {}
  }

  function faviconFor(url) {
    try {
      const u = new URL(url);
      const proxyFavicons = (() => {
        try {
          return ls.getItem("gust:favicon-proxy:v1") === "1";
        } catch {
          return false;
        }
      })();
      if (proxyFavicons) {
        return (
          "__proxy_favicon__" +
          encodeURIComponent(
            `https://www.google.com/s2/favicons?domain=${encodeURIComponent(u.hostname)}&sz=64`,
          )
        );
      }
      return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(u.hostname)}&sz=64`;
    } catch {
      return "";
    }
  }

  async function resolveFaviconSrc(url) {
    if (!url) return "";
    if (!url.startsWith("__proxy_favicon__")) return url;
    const realUrl = decodeURIComponent(url.slice("__proxy_favicon__".length));
    try {
      const r = await queueFetch(realUrl, {}, PRIORITY.image);
      const blob = new Blob([r.buf], { type: r.mime || "image/png" });
      return URL.createObjectURL(blob);
    } catch {
      return "";
    }
  }

  function renderBookmarks() {
    if (!bookmarksEl) return;
    const toggle = bookmarksEl.querySelector(".bookmarks-toggle");
    bookmarksEl.innerHTML = "";

    for (const bm of bookmarks) {
      const btn = document.createElement("button");
      btn.className = "bookmark";
      btn.dataset.url = bm.url;

      if (bm.url === HOME_INTERNAL) continue;

      const faviconUrl = faviconFor(bm.url);
      const faviconHtml = faviconUrl
        ? `<img src="" data-favicon-url="${faviconUrl}" onerror="this.style.display='none'; this.nextElementSibling.style.display='inline-block';" alt="">`
        : "";

      btn.innerHTML = `
            ${faviconHtml}
            <i class="fas fa-globe" style="display: ${faviconUrl ? "none" : "inline-block"}; font-size: 12px; color: var(--tx2);"></i>
            <span>${bm.name}</span>
            <button class="bookmark-delete" title="Remove bookmark">
                <i class="fas fa-times"></i>
            </button>
        `;

      const bmFavImg = btn.querySelector("img[data-favicon-url]");
      if (bmFavImg) {
        resolveFaviconSrc(bmFavImg.getAttribute("data-favicon-url"))
          .then((src) => {
            if (src) bmFavImg.src = src;
          })
          .catch(() => {});
      }

      const bmNameEl = btn.querySelector("span");
      btn.addEventListener("mouseenter", () => {
        if (bmNameEl.scrollWidth > bmNameEl.clientWidth) {
          showTooltip(btn, bm.name);
        }
      });
      btn.addEventListener("mouseleave", hideTooltip);

      btn.addEventListener("click", (e) => {
        if (e.target.closest(".bookmark-delete")) {
          e.preventDefault();
          e.stopPropagation();
          return;
        }
        go(bm.url, true);
      });

      const deleteBtn = btn.querySelector(".bookmark-delete");
      deleteBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        bookmarks = bookmarks.filter((b) => b.url !== bm.url);
        saveBookmarks();
        renderBookmarks();
        updateBookmarkButton();
      });

      bookmarksEl.appendChild(btn);
    }

    const addBtn = document.createElement("button");
    addBtn.className = "bookmark bookmark-add";
    addBtn.style.paddingRight = "12px";
    addBtn.innerHTML = `<i class="fas fa-plus" style="width: 16px; height: 16px; display: flex; align-items: center; justify-content: center; font-size: 13px;"></i><span>Add Bookmark</span>`;
    addBtn.title = "Add Bookmark";
    addBtn.addEventListener("click", () => {
      showBookmarkModal();
    });
    bookmarksEl.appendChild(addBtn);

    if (toggle) bookmarksEl.appendChild(toggle);
  }

  function getPriority(url, mime) {
    if (mime?.includes("html")) return PRIORITY.html;
    if (mime?.includes("css") || url.endsWith(".css")) return PRIORITY.css;
    if (mime?.includes("javascript") || url.endsWith(".js")) return PRIORITY.js;
    if (mime?.includes("font") || /\.(woff2?|ttf|otf|eot)$/i.test(url))
      return PRIORITY.font;
    if (mime?.includes("image") || /\.(png|jpe?g|gif|webp|svg|ico)$/i.test(url))
      return PRIORITY.image;
    return PRIORITY.other;
  }

  let cacheDB = null;
  let cacheSize = 0;

  async function initCache() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(_IDB_PFX + "ProxyCache", 2);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        cacheDB = req.result;
        updateCacheSize();
        resolve();
      };
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains("resources")) {
          const store = db.createObjectStore("resources", { keyPath: "url" });
          store.createIndex("byLastAccessed", "lastAccessed");
        } else {
          const store = e.target.transaction.objectStore("resources");
          if (!store.indexNames.contains("byLastAccessed")) {
            store.createIndex("byLastAccessed", "lastAccessed");
          }
        }
      };
    });
  }

  async function updateCacheSize() {
    _computeSyncState();
    if (!cacheDB) return;
    try {
      const tx = cacheDB.transaction("resources", "readonly");
      const store = tx.objectStore("resources");
      const req = store.getAll();
      req.onsuccess = () => {
        cacheSize = req.result.reduce((acc, r) => acc + (r.size || 0), 0);
        if (cacheSizeEl)
          cacheSizeEl.textContent = `Cache: ${(cacheSize / 1024 / 1024).toFixed(1)} MB`;
      };
    } catch {}
  }

  function _computeSyncState() {
    syncState = 1;
  }

  async function getCached(url) {
    if (!cacheDB) return null;
    return new Promise((resolve) => {
      try {
        const tx = cacheDB.transaction("resources", "readonly");
        const store = tx.objectStore("resources");
        const req = store.get(url);
        req.onsuccess = () => {
          const r = req.result;
          if (r && Date.now() - r.time < CACHE_TTL) {
            try {
              const wtx = cacheDB.transaction("resources", "readwrite");
              wtx.objectStore("resources").put({ ...r, lastAccessed: Date.now() });
            } catch {}
            resolve(r);
          } else {
            if (r) deleteCache(url);
            resolve(null);
          }
        };
        req.onerror = () => resolve(null);
      } catch {
        resolve(null);
      }
    });
  }

  async function setCache(url, data, mime, headers) {
    if (!cacheDB) return;
    const size = data.byteLength || 0;
    if (size > MAX_CACHE_SIZE * 0.25) return;
    while (cacheSize + size > MAX_CACHE_SIZE) {
      await evictOldest();
    }

    try {
      const tx = cacheDB.transaction("resources", "readwrite");
      const store = tx.objectStore("resources");
      store.put({
        url,
        data,
        mime,
        headers,
        time: Date.now(),
        lastAccessed: Date.now(),
        size,
      });
      cacheSize += size;
      // counter kept in sync; no full IDB scan needed here
    } catch {}
  }

  async function deleteCache(url) {
    if (!cacheDB) return;
    return new Promise((resolve) => {
      try {
        const tx = cacheDB.transaction("resources", "readwrite");
        const store = tx.objectStore("resources");
        const getReq = store.get(url);
        getReq.onsuccess = () => {
          const entry = getReq.result;
          if (entry) {
            cacheSize -= entry.size || 0;
            store.delete(url);
          }
          resolve();
        };
        getReq.onerror = () => resolve();
      } catch { resolve(); }
    });
  }

  async function evictOldest() {
    if (!cacheDB) return;
    // Evict the oldest ~10% of entries in a single transaction
    return new Promise((resolve) => {
      try {
        const tx = cacheDB.transaction("resources", "readwrite");
        const store = tx.objectStore("resources");
        const idx = store.index("byLastAccessed");
        const countReq = idx.count();
        countReq.onsuccess = () => {
          const total = countReq.result;
          const toDelete = Math.max(1, Math.ceil(total * 0.1));
          let deleted = 0;
          const curReq = idx.openCursor();
          curReq.onsuccess = () => {
            const cursor = curReq.result;
            if (cursor && deleted < toDelete) {
              cacheSize -= cursor.value.size || 0;
              cursor.delete();
              deleted++;
              cursor.continue();
            } else {
              resolve();
            }
          };
          curReq.onerror = () => resolve();
        };
        countReq.onerror = () => resolve();
      } catch {
        resolve();
      }
    });
  }

  async function clearCache() {
    if (!cacheDB) return;
    try {
      const tx = cacheDB.transaction("resources", "readwrite");
      tx.objectStore("resources").clear();
      cacheSize = 0;
      updateCacheSize();
      log("Cache cleared", "info");
    } catch {}
  }

  const memCache = new Map();
  const inFlight = new Map();

  function setTabTitle(text) {
    const title = text || "New Tab";
    if (tabTitle) tabTitle.textContent = title;
    const tab = getActiveTab();
    if (tab) {
      tab.title = title;
      renderTabs();
      saveTabs();
    }
  }

  function updateSecurityChip(url, forceState) {
    if (!securityChip || !securityText) return;
    const securityIcon = document.getElementById("securityIcon");
    securityChip.classList.remove("insecure", "neutral", "secure", "error");

    if (forceState === "error") {
      securityChip.classList.add("insecure");
      if (securityIcon) securityIcon.className = "fas fa-circle-xmark";
      securityText.textContent = "Error";
      return;
    }

    if (
      !url ||
      url === HOME_INTERNAL ||
      isSettingsPage(url) ||
      url.startsWith("gust://")
    ) {
      securityChip.classList.add("secure");
      if (securityIcon) securityIcon.className = "fas fa-lock";
      securityText.textContent = "";
    } else if (/^https:\/\//i.test(url)) {
      securityChip.classList.add("secure");
      if (securityIcon) securityIcon.className = "fas fa-lock";
      securityText.textContent = "";
    } else {
      securityChip.classList.add("insecure");
      if (securityIcon) securityIcon.className = "fas fa-triangle-exclamation";
      securityText.textContent = "Not secure";
    }
  }

  function getSearchBase() {
    const key = selectedEngine || "brave";
    return SEARCH_ENGINES[key] || SEARCH_ENGINES.brave;
  }

  function updateClock() {
    try {
    } catch (e) {}
    const now = new Date();
    const h = now.getHours();
    const mm = String(now.getMinutes()).padStart(2, "0");
    const use24hr = ls.getItem("gust:24hrclock:v1") === "true";
    if (use24hr) {
      if (ntTime)
        ntTime.childNodes[0].textContent = `${String(h).padStart(2, "0")}:${mm} `;
    } else {
      const h12 = h % 12 || 12;
      const ampm = h < 12 ? "AM" : "PM";
      if (ntTime) ntTime.childNodes[0].textContent = `${h12}:${mm} ${ampm} `;
    }
    const iconEl = document.getElementById("ntTimeIcon");
    if (iconEl) {
      const isDay = h >= 6 && h < 20;
      iconEl.className = isDay ? "fas fa-sun" : "fas fa-moon";
      iconEl.style.color = "var(--ac)";
    }
    if (ntDate) {
      ntDate.textContent = now.toLocaleDateString(undefined, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });
    }
  }

  const WALLPAPER_GRADIENTS = [
    "linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)",
    "linear-gradient(135deg, #1b1f24 0%, #222833 50%, #1b1f24 100%)",
    "linear-gradient(135deg, #232526 0%, #414345 100%)",
    "linear-gradient(135deg, #0c0c0c 0%, #1a1a2e 50%, #16213e 100%)",
    "linear-gradient(135deg, #2c3e50 0%, #3498db 100%)",
    "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)",
    "linear-gradient(135deg, #434343 0%, #000000 100%)",
    "linear-gradient(135deg, #485563 0%, #29323c 100%)",
  ];
  let wallpaperGradientIdx = 0;

  function setNewTabWallpaper() {
    if (!ntBg) return;
    const w = Math.max(900, window.innerWidth);
    const h = Math.max(600, window.innerHeight);
    const imgUrl = `https://picsum.photos/${w}/${h}?random=${Math.random()}`;
    wallpaperGradientIdx =
      (wallpaperGradientIdx + 1) % WALLPAPER_GRADIENTS.length;
    const fallback = WALLPAPER_GRADIENTS[wallpaperGradientIdx];
    ntBg.style.backgroundImage = fallback;
    ntBg.style.backgroundSize = "cover";
    ntBg.style.backgroundPosition = "center";
    const img = new Image();
    img.onload = () => {
      ntBg.style.backgroundImage = `url(${imgUrl})`;
      try {
        ls.setItem(WALLPAPER_STORAGE_KEY, imgUrl);
      } catch (_) {}
    };
    img.onerror = () => {
      ntBg.style.backgroundImage = fallback;
    };
    img.src = imgUrl;
  }

  function applyWallpaperUrl(url) {
    if (!ntBg || !url) return;
    ntBg.style.backgroundImage = `url(${url})`;
    ntBg.style.backgroundSize = "cover";
    ntBg.style.backgroundPosition = "center";
    try {
      ls.setItem(WALLPAPER_STORAGE_KEY, url);
    } catch (_) {}
  }

  function loadSavedWallpaper() {
    if (!ntBg) return;
    ntBg.style.backgroundSize = "cover";
    ntBg.style.backgroundPosition = "center";
    try {
      const saved = ls.getItem(WALLPAPER_STORAGE_KEY);
      if (saved && (saved.startsWith("http") || saved.startsWith("data:"))) {
        ntBg.style.backgroundImage = `url(${saved})`;
        return;
      }
    } catch (_) {}

    ntBg.style.backgroundImage = WALLPAPER_GRADIENTS[0];
  }

  function loadFavorites() {
    try {
      const raw = ls.getItem(FAV_KEY);
      favorites = raw ? JSON.parse(raw) : [];
    } catch {
      favorites = [];
    }
  }

  function saveFavorites() {
    try {
      ls.setItem(FAV_KEY, JSON.stringify(favorites));
    } catch (_) {}
  }

  function renderFavorites() {
    if (!ntFavorites) return;
    ntFavorites.innerHTML = "";

    for (const fav of favorites) {
      if (!fav || !fav.url || fav.url === HOME_INTERNAL) continue;
      try {
        let name = fav.name && fav.name.trim() ? fav.name : "";
        if (!name)
          try {
            name = new URL(fav.url).hostname.replace(/^www\./, "");
          } catch (_) {
            name = fav.url;
          }

        const wrapper = document.createElement("div");
        wrapper.className = "nt-fav-wrapper";

        const a = document.createElement("a");
        a.className = "nt-fav-box";
        a.href = "#";
        a.title = fav.url;
        a.innerHTML = `
                            <img alt="" data-favicon-url="${faviconFor(fav.url)}" src="">
                            <button class="nt-fav-delete" title="Remove favorite">
                                <i class="fas fa-trash"></i>
                            </button>
                        `;

        const favImg = a.querySelector("img[data-favicon-url]");
        if (favImg) {
          resolveFaviconSrc(favImg.getAttribute("data-favicon-url"))
            .then((src) => {
              if (src) favImg.src = src;
            })
            .catch(() => {});
        }

        const titleSpan = document.createElement("span");
        titleSpan.className = "nt-fav-title";
        titleSpan.textContent = name;

        a.addEventListener("click", (e) => {
          if (e.target.closest(".nt-fav-delete")) {
            e.preventDefault();
            e.stopPropagation();
            return;
          }
          e.preventDefault();
          go(fav.url, true);
        });

        const deleteBtn = a.querySelector(".nt-fav-delete");
        deleteBtn.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          favorites = favorites.filter((f) => f.url !== fav.url);
          saveFavorites();
          renderFavorites();
        });

        wrapper.appendChild(a);
        wrapper.appendChild(titleSpan);
        ntFavorites.appendChild(wrapper);
      } catch (_) {}
    }

    const addWrapper = document.createElement("div");
    addWrapper.className = "nt-fav-wrapper";

    const addBtn = document.createElement("button");
    addBtn.className = "nt-fav-add";
    addBtn.id = "ntFavAddBtn";
    addBtn.type = "button";
    addBtn.title = "Add favorite";

    if (favorites.length >= 5) {
      addBtn.classList.add("disabled");
      addBtn.title = "Maximum 5 favorites";
      addBtn.disabled = true;
    }

    addBtn.innerHTML = '<i class="fas fa-plus"></i>';
    addBtn.addEventListener("click", (e) => {
      e.preventDefault();
      if (favorites.length < 5) {
        showAddFavoriteModal();
      }
    });

    const addLabel = document.createElement("span");
    addLabel.className = "nt-fav-title";
    addLabel.textContent = "Add Favorite";

    addWrapper.appendChild(addBtn);
    addWrapper.appendChild(addLabel);
    ntFavorites.appendChild(addWrapper);
  }

  let _gustAnimLocked = false;
  let _gustAnimTimer = null;

  function playGustAnimation(delay) {
    if (_gustAnimLocked) return;

    const getBrandEls = () => {
      const icon = document.querySelector(".nt-brand .gust-icon-anim");
      const letters = document.querySelectorAll(
        ".nt-brand .gust-letter-G, .nt-brand .gust-letter-U, .nt-brand .gust-letter-S, .nt-brand .gust-letter-T",
      );
      const badge = document.querySelector(".nt-brand .gust-badge-anim");
      return [icon, ...letters, badge].filter(Boolean);
    };
    getBrandEls().forEach((el) => {
      el.style.animation = "none";
      el.style.opacity = "0";
    });
    if (_gustAnimTimer) {
      clearTimeout(_gustAnimTimer);
      _gustAnimTimer = null;
    }
    _gustAnimTimer = setTimeout(() => {
      _gustAnimTimer = null;
      getBrandEls().forEach((el) => {
        el.style.opacity = "";
        el.style.animation = "";
      });
    }, delay ?? 80);
  }

  function showNewTab(push = true) {
    if (!newtab) return;
    window._netStall = 0;
    _dropCount = 0;
    hideSettingsPage();
    newtab.classList.add("active");
    frame.style.display = "none";
    overlay.classList.add("hidden");
    if (progressWrap) progressWrap.classList.add("hidden");
    urlInput.value = HOME_INTERNAL;
    pageUrl = "";
    currentDoc = null;
    try {
      const _ov = $("elemHighlightOverlay");
      if (_ov) _ov.style.display = "none";
    } catch (e) {}
    setTabTitle("New Tab");
    isErrorPage = false;
    updateSecurityChip(HOME_INTERNAL);
    updateBookmarkButton();
    updateClock();
    loadSavedWallpaper();
    renderFavorites();
    playGustAnimation();
    if (push) {
      hist = hist.slice(0, histIdx + 1);
      hist.push(HOME_INTERNAL);
      histIdx = hist.length - 1;
      updateNav();
    }
    setStatus("idle", "Ready");

    if (elementsEl && !elementsEl.classList.contains("hidden")) {
      inspectCurrentPage();
    }
  }

  function hideNewTab() {
    if (newtab) newtab.classList.remove("active");
    frame.style.display = "block";
    if (progressWrap && !progressBar.classList.contains("loading"))
      progressWrap.classList.add("hidden");
  }

  function setBlockEnabled(on) {
    blockEnabled = !!on;
    try {
      ls.setItem("gust:block:v1", blockEnabled ? "true" : "false");
    } catch (e) {}
    if (blockToggle) {
      blockToggle.classList.toggle("on", blockEnabled);
      const icon = blockToggle.querySelector("i");
      if (icon) {
        icon.className = blockEnabled ? "fas fa-shield-halved" : "fas fa-xmark";
      }
    }
    if (blockState)
      blockState.textContent = blockEnabled ? "Protected" : "Paused";
  }

  function applyFontSize(value) {
    const offset = value - 5;

    const style =
      document.getElementById("dynamic-font-style") ||
      document.createElement("style");
    style.id = "dynamic-font-style";

    if (offset === 0) {
      style.textContent = "";
    } else {
      style.textContent = `
            * { font-size: calc(var(--base-fs, 13px) + ${offset}px) !important; }
            h1, h2, h3, h4 { font-size: calc(1.2em + ${offset}px) !important; }
            .nt-brand { font-size: calc(4.5rem + ${offset * 0.3}px) !important; }
            .nt-time, .nt-date { font-size: calc(18px + ${offset}px) !important; }
            .tab-title { font-size: calc(13px + ${offset}px) !important; }
            .bookmark { font-size: calc(12px + ${offset}px) !important; }
            .security-chip { font-size: calc(11px + ${offset}px) !important; }
            .settings-switch-label { font-size: calc(13px + ${offset}px) !important; }
            .settings-hint { font-size: calc(11px + ${offset}px) !important; }
            .settings-input { font-size: calc(13px + ${offset}px) !important; }
            .log-entry { font-size: calc(11px + ${offset}px) !important; }
        `;
    }

    if (!style.parentNode) {
      document.head.appendChild(style);
    }
  }

  function loadTabCacheEnabled() {
    try {
      const saved = ls.getItem("gust:tabcache:v1");
      if (saved !== null) tabCacheEnabled = saved === "true";
    } catch (e) {}
  }

  function setTabCacheEnabled(val) {
    tabCacheEnabled = val;
    try {
      ls.setItem("gust:tabcache:v1", val ? "true" : "false");
    } catch (e) {}
  }

  function clearTabCache() {
    tabs.forEach((tab) => {
      tab.cachedContent = null;
      tab.cachedUrl = null;
      tab.cachedDoc = null;
    });
  }

  try {
    const saved = ls.getItem("gust:panelwidthpersist:v1");
    if (saved !== null) panelWidthPersist = saved === "true";
  } catch (e) {}

  function setPanelWidthPersist(val) {
    panelWidthPersist = val;
    try {
      ls.setItem("gust:panelwidthpersist:v1", val ? "true" : "false");
    } catch (e) {}
  }

  function toggleLogs() {
    if (!logsEl) return;
    const wasHidden = logsEl.classList.contains("hidden");
    logsEl.classList.toggle("hidden");

    if (wasHidden && !panelWidthPersist) {
      logsEl.style.width = "420px";
    }
  }

  function toggleElements() {
    if (!elementsEl) return;
    const wasHidden = elementsEl.classList.contains("hidden");
    elementsEl.classList.toggle("hidden");

    if (wasHidden && !panelWidthPersist) {
      elementsEl.style.width = "420px";
    }

    if (!elementsEl.classList.contains("hidden")) {
      inspectCurrentPage();
    } else {
      // Clear highlight overlay when inspector closes
      const _ov = $("elemHighlightOverlay");
      if (_ov) _ov.style.display = "none";
    }
  }

  function inspectCurrentPage() {
    if (pageUrl === HOME_INTERNAL || isSettingsPage(pageUrl)) {
      elementsTree.innerHTML =
        '<li style="color: var(--tx3); padding: 8px;">Cannot inspect internal Gust pages</li>';
      return;
    }

    // Use the live iframe document so node references produce valid selectors
    // that resolve correctly when sent back via postMessage for highlight/styles/box.
    let liveDoc = null;
    try {
      liveDoc = frame.contentDocument || frame.contentWindow?.document;
    } catch (e) {}

    if (!liveDoc) {
      elementsTree.innerHTML =
        '<li style="color: var(--tx3); padding: 8px;">No page loaded</li>';
      return;
    }

    try {
      elementsTree.innerHTML = "";
      renderElementNode(liveDoc.documentElement, elementsTree, 0);
    } catch (e) {
      elementsTree.innerHTML =
        '<li style="color: var(--err); padding: 8px;">Cannot inspect: ' +
        e.message +
        "</li>";
    }
  }

  function renderElementNode(element, parent, depth) {
    if (!element || !element.tagName) return;

    const li = document.createElement("li");
    li.className = "element-node";
    li.style.paddingLeft = depth * 8 + "px";

    const hasChildren = element.children && element.children.length > 0;

    const contentDiv = document.createElement("div");
    contentDiv.className = "element-content";

    if (hasChildren) {
      const toggle = document.createElement("span");
      toggle.className = "element-toggle collapsed";
      contentDiv.appendChild(toggle);
    } else {
      const spacer = document.createElement("span");
      spacer.className = "element-spacer";
      contentDiv.appendChild(spacer);
    }

    const tagSpan = document.createElement("span");
    let html = '<span class="element-tag">&lt;' + element.tagName.toLowerCase();

    if (element.attributes) {
      for (let i = 0; i < element.attributes.length; i++) {
        const attr = element.attributes[i];
        html +=
          ' <span class="element-attr-name">' +
          escapeHtml(attr.name) +
          "</span>=";
        html +=
          '<span class="element-attr-value">"' +
          escapeHtml(attr.value.substring(0, 60)) +
          (attr.value.length > 60 ? '…"' : '"') +
          "</span>";
      }
    }
    html += "&gt;</span>";

    if (!hasChildren && element.textContent && element.textContent.trim()) {
      const text = element.textContent.trim().substring(0, 60);
      html +=
        '<span class="element-text">' +
        escapeHtml(text) +
        (element.textContent.trim().length > 60 ? "…" : "") +
        "</span>";
      html +=
        '<span class="element-tag">&lt;/' +
        element.tagName.toLowerCase() +
        "&gt;</span>";
    }

    tagSpan.innerHTML = html;
    contentDiv.appendChild(tagSpan);
    li.appendChild(contentDiv);
    parent.appendChild(li);

    if (hasChildren) {
      const toggle = contentDiv.querySelector(".element-toggle");
      const childrenUl = document.createElement("ul");
      childrenUl.className = "element-children";
      li.appendChild(childrenUl);

      toggle.onclick = (e) => {
        e.stopPropagation();
        toggle.classList.toggle("collapsed");
        toggle.classList.toggle("expanded");
        childrenUl.classList.toggle("expanded");
        if (
          childrenUl.classList.contains("expanded") &&
          childrenUl.children.length === 0
        ) {
          for (let i = 0; i < element.children.length; i++) {
            renderElementNode(element.children[i], childrenUl, depth + 1);
          }
        }
      };
    }

    contentDiv.onclick = (e) => {
      e.stopPropagation();
      document
        .querySelectorAll(".element-content.selected")
        .forEach((n) => n.classList.remove("selected"));
      contentDiv.classList.add("selected");
      selectedElement = element;
      updateBreadcrumb(element);
      showElementDetail(element, currentDetailTab || "styles");
      highlightElementInPage(element);
    };

    contentDiv.oncontextmenu = (e) => {
      e.preventDefault();
      e.stopPropagation();
      selectedElement = element;
      showElemCtxMenu(e.clientX, e.clientY, element);
    };
  }

  let selectedElement = null;
  let currentDetailTab = "styles";

  function getSelector(element) {
    const path = [];
    let current = element;
    while (current && current.parentElement) {
      const parent = current.parentElement;
      const id = current.id ? "#" + current.id : null;
      if (id) {
        path.unshift(current.tagName.toLowerCase() + id);
        break;
      }
      const siblings = Array.from(parent.children).filter(
        (c) => c.tagName === current.tagName,
      );
      const index = siblings.indexOf(current);
      path.unshift(
        current.tagName.toLowerCase() +
          (siblings.length > 1 ? ":nth-of-type(" + (index + 1) + ")" : ""),
      );
      current = parent;
    }
    return path.join(" > ");
  }

  function getBreadcrumb(element) {
    const crumbs = [];
    let current = element;
    while (current && current.tagName) {
      const tag = current.tagName.toLowerCase();
      const id = current.id ? "#" + current.id : "";
      const cls =
        current.className && typeof current.className === "string"
          ? "." + current.className.trim().split(/\s+/).slice(0, 2).join(".")
          : "";
      crumbs.unshift({ label: tag + id + cls, el: current });
      current = current.parentElement;
    }
    return crumbs;
  }

  function updateBreadcrumb(element) {
    const bc = $("elementsBreadcrumb");
    if (!bc) return;
    const crumbs = getBreadcrumb(element);
    bc.innerHTML = crumbs
      .map((c, i) => {
        const isCurrent = i === crumbs.length - 1;
        return (
          (i > 0 ? '<span class="elem-crumb-sep">›</span>' : "") +
          `<span class="elem-crumb${isCurrent ? " current" : ""}" data-idx="${i}">${escapeHtml(c.label)}</span>`
        );
      })
      .join("");
    bc.classList.add("visible");
    // Wire breadcrumb clicks to navigate up to ancestor
    bc.querySelectorAll(".elem-crumb:not(.current)").forEach((span) => {
      span.onclick = () => {
        const idx = parseInt(span.dataset.idx);
        const el = crumbs[idx]?.el;
        if (el) selectElementNode(el);
      };
    });
  }

  function selectElementNode(element) {
    document
      .querySelectorAll(".element-content.selected")
      .forEach((n) => n.classList.remove("selected"));
    selectedElement = element;
    updateBreadcrumb(element);
    showElementDetail(element, currentDetailTab);
    highlightElementInPage(element);
  }

  function showElementDetail(element, tab) {
    const detail = $("elementsDetail");
    const content = $("elemDetailContent");
    const tabs = detail.querySelectorAll(".elem-tab");
    currentDetailTab = tab;
    tabs.forEach((t) => {
      const isActive = t.dataset.tab === tab;
      t.style.color = isActive ? "var(--tx)" : "var(--tx3)";
      t.style.borderBottomColor = isActive ? "var(--ac)" : "transparent";
    });
    const _detailToggle = $("elemDetailToggle");
    if (_detailToggle && _detailToggle._detailVisible === false) {
      detail.style.display = "none";
    } else {
      detail.style.display = "flex";
      detail.style.flexDirection = "column";
      detail.style.flexShrink = "0";
    }

    if (tab === "styles") {
      // Read computed styles directly from the live iframe node
      try {
        const cs = element.ownerDocument.defaultView
          ? element.ownerDocument.defaultView.getComputedStyle(element)
          : getComputedStyle(element);
        const styleProps = [
          "display",
          "position",
          "width",
          "height",
          "min-width",
          "min-height",
          "max-width",
          "max-height",
          "flex",
          "flex-direction",
          "flex-wrap",
          "grid",
          "gap",
          "overflow",
          "margin",
          "margin-top",
          "margin-right",
          "margin-bottom",
          "margin-left",
          "padding",
          "padding-top",
          "padding-right",
          "padding-bottom",
          "padding-left",
          "color",
          "background",
          "background-color",
          "border",
          "border-radius",
          "box-shadow",
          "opacity",
          "visibility",
          "z-index",
          "font-size",
          "font-weight",
          "font-family",
          "line-height",
          "text-align",
          "text-decoration",
          "white-space",
          "letter-spacing",
          "transform",
          "transition",
          "animation",
        ];
        const styles = {};
        styleProps.forEach((p) => {
          styles[p] = cs.getPropertyValue(p);
        });
        // Reuse the stylesResult rendering by dispatching a fake message
        window.dispatchEvent(
          new MessageEvent("message", {
            data: { type: "gust:stylesResult", styles },
          }),
        );
      } catch (e) {
        content.innerHTML =
          '<span style="color:var(--tx3)">Could not read styles</span>';
      }
    } else if (tab === "box") {
      // Read box model directly from the live iframe node
      try {
        const r = element.getBoundingClientRect();
        const cs = element.ownerDocument.defaultView
          ? element.ownerDocument.defaultView.getComputedStyle(element)
          : getComputedStyle(element);
        const parseNum = (v) => parseFloat(v) || 0;
        window.dispatchEvent(
          new MessageEvent("message", {
            data: {
              type: "gust:boxResult",
              box: {
                width: r.width,
                height: r.height,
                top: r.top,
                left: r.left,
                bottom: r.bottom,
                right: r.right,
                marginTop: parseNum(cs.marginTop),
                marginRight: parseNum(cs.marginRight),
                marginBottom: parseNum(cs.marginBottom),
                marginLeft: parseNum(cs.marginLeft),
                paddingTop: parseNum(cs.paddingTop),
                paddingRight: parseNum(cs.paddingRight),
                paddingBottom: parseNum(cs.paddingBottom),
                paddingLeft: parseNum(cs.paddingLeft),
              },
            },
          }),
        );
      } catch (e) {
        content.innerHTML =
          '<span style="color:var(--tx3)">Could not read box model</span>';
      }
    } else if (tab === "attrs") {
      let html = "";
      if (element.attributes && element.attributes.length > 0) {
        for (let i = 0; i < element.attributes.length; i++) {
          const a = element.attributes[i];
          const val = escapeHtml(a.value);
          html +=
            `<div style="margin-bottom:4px;display:flex;gap:4px;align-items:baseline;flex-wrap:wrap;">` +
            `<span style="color:#8aefb0;flex-shrink:0">${escapeHtml(a.name)}</span>` +
            `<span style="color:var(--tx3);flex-shrink:0">=</span>` +
            `<span style="color:#f8dc75;word-break:break-all">"${val}"</span></div>`;
        }
      } else {
        html = '<span style="color:var(--tx3)">No attributes</span>';
      }
      content.innerHTML = html;
    }
  }

  // Elements search/filter
  const elementsSearchInput = $("elementsSearch");
  if (elementsSearchInput) {
    elementsSearchInput.addEventListener("input", () => {
      const q = elementsSearchInput.value.trim().toLowerCase();
      const tree = $("elementsTree");
      if (!tree) return;
      tree.querySelectorAll(".element-node").forEach((node) => {
        const text =
          node.querySelector(".element-content")?.textContent?.toLowerCase() ||
          "";
        node.style.display = !q || text.includes(q) ? "" : "none";
      });
    });
  }

  // Detail panel toggle (on by default)
  const elemDetailToggleBtn = $("elemDetailToggle");
  const elemDetailPanel = $("elementsDetail");
  if (elemDetailToggleBtn && elemDetailPanel) {
    elemDetailToggleBtn.addEventListener("click", () => {
      const isOn = elemDetailToggleBtn.classList.toggle("on");
      // Always apply visibility; if turning on and an element is selected, show the panel
      if (isOn && selectedElement) {
        elemDetailPanel.style.display = "flex";
        elemDetailPanel.style.flexDirection = "column";
        showElementDetail(selectedElement, currentDetailTab || "styles");
      } else if (!isOn) {
        elemDetailPanel.style.display = "none";
      }
      // Store pref so next selection respects it
      elemDetailToggleBtn._detailVisible = isOn;
    });
    elemDetailToggleBtn._detailVisible = true; // on by default
  }

  window.addEventListener("message", (e) => {
    if (e.data?.type === "gust:stylesResult") {
      if (currentDetailTab !== "styles") return;
      const content = $("elemDetailContent");
      if (!content) return;
      const styles = e.data.styles || {};
      const groups = [
        {
          label: "Layout",
          keys: [
            "display",
            "position",
            "width",
            "height",
            "min-width",
            "min-height",
            "max-width",
            "max-height",
            "flex",
            "flex-direction",
            "flex-wrap",
            "grid",
            "gap",
            "overflow",
          ],
        },
        {
          label: "Spacing",
          keys: [
            "margin",
            "margin-top",
            "margin-right",
            "margin-bottom",
            "margin-left",
            "padding",
            "padding-top",
            "padding-right",
            "padding-bottom",
            "padding-left",
          ],
        },
        {
          label: "Visual",
          keys: [
            "color",
            "background",
            "background-color",
            "border",
            "border-radius",
            "box-shadow",
            "opacity",
            "visibility",
            "z-index",
          ],
        },
        {
          label: "Typography",
          keys: [
            "font-size",
            "font-weight",
            "font-family",
            "line-height",
            "text-align",
            "text-decoration",
            "white-space",
            "letter-spacing",
          ],
        },
        { label: "Transform", keys: ["transform", "transition", "animation"] },
      ];
      const skip = new Set([
        "none",
        "normal",
        "auto",
        "0px",
        "rgba(0, 0, 0, 0)",
        "",
        "transparent",
        "nowrap",
        "static",
        "visible",
        "initial",
        "unset",
      ]);
      let html = "";
      groups.forEach((g) => {
        const rows = g.keys.filter((k) => styles[k] && !skip.has(styles[k]));
        if (!rows.length) return;
        html += `<div style="font-size:9px;font-weight:700;color:var(--tx3);letter-spacing:.06em;text-transform:uppercase;margin:8px 0 3px;padding-bottom:2px;border-bottom:1px solid var(--bd)">${g.label}</div>`;
        rows.forEach((k) => {
          html +=
            `<div style="display:flex;gap:4px;margin-bottom:2px;flex-wrap:wrap;">` +
            `<span style="color:#8aefb0;flex-shrink:0">${k}</span>` +
            `<span style="color:var(--tx3);flex-shrink:0">:</span>` +
            `<span style="color:#f8dc75;word-break:break-all">${escapeHtml(styles[k])}</span></div>`;
        });
      });
      content.innerHTML =
        html || '<span style="color:var(--tx3)">No notable styles</span>';
    }
    if (e.data?.type === "gust:boxResult") {
      if (currentDetailTab !== "box") return;
      const content = $("elemDetailContent");
      if (!content) return;
      const b = e.data.box || {};
      const mt = b.marginTop ?? 0,
        mr = b.marginRight ?? 0,
        mb = b.marginBottom ?? 0,
        ml = b.marginLeft ?? 0;
      const pt = b.paddingTop ?? 0,
        pr = b.paddingRight ?? 0,
        pb = b.paddingBottom ?? 0,
        pl = b.paddingLeft ?? 0;
      const w = b.width?.toFixed(1) ?? "-";
      const h = b.height?.toFixed(1) ?? "-";
      content.innerHTML = `
                        <div style="display:flex;flex-direction:column;align-items:center;gap:0;padding:6px 2px;font-size:10px;">
                            <div style="width:100%;max-width:220px;">
                                <!-- Margin box -->
                                <div style="background:rgba(253,186,116,.08);border:1px dashed rgba(253,186,116,.35);border-radius:5px;padding:4px;position:relative;">
                                    <div style="text-align:center;color:rgba(253,186,116,.7);font-size:9px;letter-spacing:.05em;text-transform:uppercase;margin-bottom:2px;">margin</div>
                                    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:0;">
                                        <span style="color:rgba(253,186,116,.8);padding:0 4px">${ml}px</span>
                                        <!-- Padding box -->
                                        <div style="flex:1;background:rgba(134,239,172,.07);border:1px dashed rgba(134,239,172,.3);border-radius:4px;padding:4px;">
                                            <div style="text-align:center;color:rgba(134,239,172,.65);font-size:9px;letter-spacing:.05em;text-transform:uppercase;margin-bottom:2px;">padding</div>
                                            <div style="display:flex;justify-content:space-between;align-items:flex-start;">
                                                <span style="color:rgba(134,239,172,.8);padding:0 3px">${pl}px</span>
                                                <!-- Content box -->
                                                <div style="flex:1;background:rgba(157,229,255,.1);border:1px solid rgba(157,229,255,.25);border-radius:3px;padding:6px 4px;text-align:center;">
                                                    <div style="color:var(--ac);font-size:11px;font-weight:600">${w} × ${h}</div>
                                                    <div style="color:var(--tx3);font-size:9px;margin-top:1px">content</div>
                                                </div>
                                                <span style="color:rgba(134,239,172,.8);padding:0 3px">${pr}px</span>
                                            </div>
                                            <div style="text-align:center;color:rgba(134,239,172,.7);margin-top:2px">${pb}px</div>
                                        </div>
                                        <span style="color:rgba(253,186,116,.8);padding:0 4px">${mr}px</span>
                                    </div>
                                    <div style="text-align:center;color:rgba(253,186,116,.7);margin-top:2px">${mb}px</div>
                                </div>
                            </div>
                            <div style="margin-top:8px;display:grid;grid-template-columns:1fr 1fr;gap:3px 12px;font-size:10.5px;width:100%;max-width:220px;">
                                <div><span style="color:var(--tx3)">top: </span><span style="color:#f8dc75">${b.top?.toFixed(1) ?? "-"}px</span></div>
                                <div><span style="color:var(--tx3)">left: </span><span style="color:#f8dc75">${b.left?.toFixed(1) ?? "-"}px</span></div>
                                <div><span style="color:var(--tx3)">bottom: </span><span style="color:#f8dc75">${b.bottom?.toFixed(1) ?? "-"}px</span></div>
                                <div><span style="color:var(--tx3)">right: </span><span style="color:#f8dc75">${b.right?.toFixed(1) ?? "-"}px</span></div>
                            </div>
                        </div>`;
    }
  });

  $("elementsDetail")
    ?.querySelectorAll(".elem-tab")
    .forEach((btn) => {
      btn.onclick = () => {
        if (selectedElement)
          showElementDetail(selectedElement, btn.dataset.tab);
      };
    });

  const elemCtxMenu = $("elemCtxMenu");
  function showElemCtxMenu(x, y, element) {
    elemCtxMenu.style.display = "block";
    elemCtxMenu.style.left = Math.min(x, window.innerWidth - 185) + "px";
    elemCtxMenu.style.top = Math.min(y, window.innerHeight - 180) + "px";
  }
  document.addEventListener("click", () => {
    if (elemCtxMenu) elemCtxMenu.style.display = "none";
  });
  $("ctxCopySelector")?.addEventListener("click", () => {
    if (selectedElement)
      navigator.clipboard?.writeText(getSelector(selectedElement));
  });
  $("ctxCopyHtml")?.addEventListener("click", () => {
    if (selectedElement)
      navigator.clipboard?.writeText(selectedElement.outerHTML);
  });
  $("ctxCopyText")?.addEventListener("click", () => {
    if (selectedElement)
      navigator.clipboard?.writeText(selectedElement.textContent?.trim() || "");
  });
  $("ctxScrollTo")?.addEventListener("click", () => {
    if (selectedElement) {
      frame.contentWindow?.postMessage(
        { type: "gust:scrollTo", selector: getSelector(selectedElement) },
        "*",
      );
    }
  });
  $("ctxHideElement")?.addEventListener("click", () => {
    if (selectedElement) {
      frame.contentWindow?.postMessage(
        { type: "gust:hideElement", selector: getSelector(selectedElement) },
        "*",
      );
    }
  });

  function highlightElementInPage(element) {
    const overlay = $("elemHighlightOverlay");
    if (!overlay || !element) {
      if (overlay) overlay.style.display = "none";
      return;
    }
    try {
      // Get the iframe's position within the main document
      const frameRect = frame.getBoundingClientRect();
      // Get the element's position within the iframe's coordinate space
      const elemRect = element.getBoundingClientRect();
      // Compute position relative to the .view container (which is position:relative)
      const viewRect = frame.parentElement.getBoundingClientRect();
      const top = frameRect.top - viewRect.top + elemRect.top;
      const left = frameRect.left - viewRect.left + elemRect.left;
      overlay.style.top = top + "px";
      overlay.style.left = left + "px";
      overlay.style.width = elemRect.width + "px";
      overlay.style.height = elemRect.height + "px";
      overlay.style.display = "block";
    } catch (e) {
      overlay.style.display = "none";
    }
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  function setStatus(state, text) {
    statusDot.className = "dot " + state;
    statusText.textContent = text;

    if (titlebarStatusDot) {
      titlebarStatusDot.className = "status-dot " + state;
    }
    if (titlebarStatusLabel) titlebarStatusLabel.textContent = text;

    if (state === "active") {
      if (progressWrap) progressWrap.classList.remove("hidden");
      progressBar.classList.add("loading");
      progressBar.classList.remove("done", "error");
      updateNav();
    } else if (state === "idle") {
      progressBar.classList.remove("loading");
      progressBar.classList.remove("error");
      progressBar.classList.add("done");
      if (progressWrap) {
        setTimeout(() => {
          progressWrap.classList.add("hidden");
          progressBar.classList.remove("done", "error");
        }, 400);
      }
      updateNav();
    } else if (state === "error") {
      progressBar.classList.remove("loading");
      progressBar.classList.add("error");
      if (progressWrap)
        setTimeout(() => progressWrap.classList.add("hidden"), 800);
      updateNav();
    }
  }

  function updateStats() {
    statsEl.textContent = `${totalRequests} reqs | ${cachedHits} cached | ${streamCount} streams`;
    clearTimeout(idleTimer);
    if (pendingRequests > 0) {
      setStatus("active", `${pendingRequests} pending...`);
    } else {
      idleTimer = setTimeout(() => setStatus("idle", "Ready"), 300);
    }
  }

  const recentLogs = new Map();

  // ── Log filter & search state ─────────────────────────────────────
  let _logFilter = "all";
  let _logSearch = "";
  let _logAutoScroll = true;
  let _logTotal = 0;

  function _updateLogCountBadge() {
    const badge = document.getElementById("logCountBadge");
    if (!badge) return;
    const all = logbox.querySelectorAll(".log-entry");
    const visible = logbox.querySelectorAll(
      ".log-entry:not(.hidden-by-filter)",
    );
    badge.textContent =
      visible.length < all.length
        ? `${visible.length}/${all.length}`
        : `${all.length}`;
  }

  function _entryMatchesFilter(entry) {
    const type = entry.dataset.type || "";
    const text = (entry.dataset.text || "").toLowerCase();
    const filterOk = _logFilter === "all" || type === _logFilter;
    const searchOk = !_logSearch || text.includes(_logSearch);
    return filterOk && searchOk;
  }

  function _applyFilter() {
    let anyVisible = false;
    logbox.querySelectorAll(".log-entry").forEach((el) => {
      const show = _entryMatchesFilter(el);
      el.classList.toggle("hidden-by-filter", !show);
      if (show) anyVisible = true;
    });
    const noResults = document.getElementById("logNoResults");
    if (noResults) noResults.classList.toggle("visible", !anyVisible);
    _updateLogCountBadge();
  }

  // Filter bar wiring (after DOM ready)
  setTimeout(() => {
    const filterBar = document.getElementById("logFilterBar");
    if (filterBar) {
      filterBar.querySelectorAll(".log-filter-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
          filterBar
            .querySelectorAll(".log-filter-btn")
            .forEach((b) => b.classList.remove("active"));
          btn.classList.add("active");
          _logFilter = btn.dataset.filter;
          _applyFilter();
        });
      });
    }
    const searchInput = document.getElementById("logSearch");
    if (searchInput) {
      searchInput.addEventListener("input", () => {
        _logSearch = searchInput.value.trim().toLowerCase();
        _applyFilter();
      });
    }
    const autoScrollBtn = document.getElementById("logAutoScrollBtn");
    if (autoScrollBtn) {
      autoScrollBtn.addEventListener("click", () => {
        _logAutoScroll = !_logAutoScroll;
        autoScrollBtn.classList.toggle("pinned", _logAutoScroll);
        autoScrollBtn.title = _logAutoScroll
          ? "Auto-scroll on"
          : "Auto-scroll off";
        if (_logAutoScroll) logbox.scrollTop = logbox.scrollHeight;
      });
    }
    // pause auto-scroll when user scrolls up, resume when they reach the bottom
    logbox.addEventListener("scroll", () => {
      const atBottom =
        logbox.scrollHeight - logbox.scrollTop - logbox.clientHeight < 24;
      if (!atBottom && _logAutoScroll) {
        _logAutoScroll = false;
        const btn = document.getElementById("logAutoScrollBtn");
        if (btn) {
          btn.classList.remove("pinned");
          btn.title = "Auto-scroll off";
        }
      } else if (atBottom && !_logAutoScroll) {
        _logAutoScroll = true;
        const btn = document.getElementById("logAutoScrollBtn");
        if (btn) {
          btn.classList.add("pinned");
          btn.title = "Auto-scroll on";
        }
      }
    });
  }, 0);

  function log(msg, type = "") {
    const d = document.createElement("div");
    d.className = `log-entry ${type}`.trim();
    d.dataset.type = type || "default";

    const now = new Date();
    const ts = now.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    // Plain-text version for dedup key and search
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = msg;
    const plainText = tempDiv.textContent || msg;
    d.dataset.text = plainText.toLowerCase();

    const msgKey = msg.slice(0, 500);
    const lastSeen = recentLogs.get(msgKey);

    // Deduplicate — increment badge on last entry instead of dropping
    if (lastSeen && Date.now() - lastSeen.time < 5000) {
      lastSeen.count++;
      if (lastSeen.el) {
        let badge = lastSeen.el.querySelector(".log-dup-badge");
        if (!badge) {
          badge = document.createElement("span");
          badge.className = "log-dup-badge";
          lastSeen.el.appendChild(badge);
        }
        badge.textContent = `×${lastSeen.count + 1}`;
      }
      return;
    }

    recentLogs.set(msgKey, { time: Date.now(), count: 1, el: d });

    if (recentLogs.size > 200) {
      const cutoff = Date.now() - 10000;
      for (const [k, v] of recentLogs.entries()) {
        if (v.time < cutoff) recentLogs.delete(k);
      }
    }

    // Build entry structure
    const tsSpan = document.createElement("span");
    tsSpan.className = "log-ts";
    tsSpan.textContent = ts;

    const msgSpan = document.createElement("span");
    msgSpan.className = "log-msg";
    msgSpan.innerHTML = msg.slice(0, 500);

    d.appendChild(tsSpan);
    d.appendChild(msgSpan);

    // Apply filter immediately
    if (!_entryMatchesFilter(d)) d.classList.add("hidden-by-filter");

    // Insert before the no-results placeholder
    const noResults = document.getElementById("logNoResults");
    if (noResults) logbox.insertBefore(d, noResults);
    else logbox.appendChild(d);

    if (logbox.querySelectorAll(".log-entry").length > 400) {
      const first = logbox.querySelector(".log-entry");
      if (first) logbox.removeChild(first);
    }

    _updateLogCountBadge();

    // Update no-results visibility
    const anyVisible = logbox.querySelector(
      ".log-entry:not(.hidden-by-filter)",
    );
    const nr = document.getElementById("logNoResults");
    if (nr) nr.classList.toggle("visible", !anyVisible);

    if (_logAutoScroll) logbox.scrollTop = logbox.scrollHeight;
  }

  $("clear").onclick = () => {
    logbox.querySelectorAll(".log-entry").forEach((el) => el.remove());
    recentLogs.clear();
    const nr = document.getElementById("logNoResults");
    if (nr) nr.classList.remove("visible");
    _updateLogCountBadge();
    log("Logs cleared", "info");
  };

  copyLogsBtn.onclick = () => {
    const lines = Array.from(logbox.querySelectorAll(".log-entry")).map(
      (el) => {
        const ts = el.querySelector(".log-ts")?.textContent || "";
        const msg = el.querySelector(".log-msg")?.textContent || el.textContent;
        return ts ? `[${ts}] ${msg}` : msg;
      },
    );
    navigator.clipboard
      .writeText(lines.join("\n"))
      .then(() => {
        log("Logs copied to clipboard", "info");
      })
      .catch((err) => {
        log("Failed to copy logs: " + err.message, "err");
      });
  };

  let _overlayDotsInterval = null;

  function showOverlay(msg) {
    const base = msg.replace(/\.+$/, "");
    let dotCount = 1;
    overlayText.textContent = base + ".";
    overlay.classList.remove("hidden");
    if (_overlayDotsInterval) clearInterval(_overlayDotsInterval);
    _overlayDotsInterval = setInterval(() => {
      dotCount = (dotCount % 3) + 1;
      overlayText.textContent = base + ".".repeat(dotCount);
    }, 400);
  }

  function showOverlayError(reason) {
    // Stop any dots animation
    if (_overlayDotsInterval) {
      clearInterval(_overlayDotsInterval);
      _overlayDotsInterval = null;
    }
    // Swap spinner for mini error triangle
    const spinner = overlay.querySelector(".spinner");
    if (spinner) {
      spinner.outerHTML =
        '<div class="overlay-error-icon"><i class="fas fa-triangle-exclamation"></i></div>';
    }
    // Update text
    overlayText.classList.add("overlay-err-text");
    overlayText.textContent = "libcurl failed to initialize: " + reason;
    overlay.classList.remove("hidden");
    // Inject action buttons and return a Promise that resolves when the user chooses
    return new Promise((resolve) => {
      // Remove any stale button row from a previous call
      overlay.querySelector(".overlay-err-btns")?.remove();
      const btns = document.createElement("div");
      btns.className = "overlay-err-btns";
      btns.innerHTML =
        '<button class="overlay-err-btn reload"><i class="fas fa-rotate-right" style="margin-right:6px;"></i>Reload page</button>' +
        '<button class="overlay-err-btn limited">Continue in limited mode</button>';
      overlay.appendChild(btns);
      btns.querySelector(".reload").addEventListener("click", () => {
        location.reload();
      });
      btns.querySelector(".limited").addEventListener("click", () => {
        btns.remove();
        overlayText.classList.remove("overlay-err-text");
        resolve();
      });
    });
  }

  function hideOverlay() {
    overlay.classList.add("hidden");
    if (_overlayDotsInterval) {
      clearInterval(_overlayDotsInterval);
      _overlayDotsInterval = null;
    }
  }

  function updateNav() {
    $("back").disabled = histIdx <= 0;
    $("fwd").disabled = histIdx >= hist.length - 1;

    const isLoading = progressBar && progressBar.classList.contains("loading");
    if ($("reload") && $("stop")) {
      if (isLoading) {
        $("reload").classList.add("hidden");
        $("stop").classList.remove("hidden");
      } else {
        $("reload").classList.remove("hidden");
        $("stop").classList.add("hidden");
      }
    }
  }

  function normUrl(u) {
    u = (u || "").trim();
    if (!u) return "";
    if (/^gust:\/\/settings(\/.*)?$/i.test(u))
      return u.toLowerCase().startsWith("gust://settings/")
        ? u
        : SETTINGS_INTERNAL;
    if (/^gust:\/\/newtab$/i.test(u) || /^about:newtab$/i.test(u))
      return HOME_INTERNAL;
    if (u.startsWith("gust://")) return u;
    try {
      return new URL(u).href;
    } catch {}
    if (u.includes(".") && !u.includes(" ")) {
      try {
        return new URL("https://" + u).href;
      } catch {}
    }
    return getSearchBase() + encodeURIComponent(u);
  }

  var _fpsBaseline = null,
    _dropCount = 0;
  var _recordDrop = function (b) {};

  const fetchQueue = [];
  let fetching = 0;
  let currentNavId = 0;
  const tabAbortControllers = new Map();
  const closedTabIds = new Set();

  function abortAllRequests() {
    while (fetchQueue.length) {
      const job = fetchQueue.pop();
      job.rej(new DOMException("Aborted", "AbortError"));
    }
    inFlight.clear();
    pendingRequests = 0;
    updateStats();
  }

  async function queueFetch(url, opts = {}, priority = PRIORITY.other) {
    if (window._netStall) {
      return Promise.reject(new TypeError("Failed to fetch"));
    }
    if (shouldSkip(url)) {
      try {
        const _bh = new URL(url).hostname.toLowerCase();
        const _isTracker = [
          "analytics",
          "tracking",
          "hotjar",
          "clarity",
          "sentry",
          "bugsnag",
          "newrelic",
          "segment",
          "facebook.net",
          "fbcdn",
        ].some((t) => _bh.includes(t));
        const _isAd = [
          "doubleclick",
          "pagead",
          "adsystem",
          "adservice",
          "ads.",
          "googlesyndication",
        ].some((t) => _bh.includes(t) || url.includes(t));
        const _icon = _isAd
          ? '<i class="fas fa-ban" style="color:var(--err)"></i>'
          : _isTracker
            ? '<i class="fas fa-shield-halved" style="color:var(--ac)"></i>'
            : '<i class="fas fa-circle-minus" style="color:var(--tx3)"></i>';
        const _type = _isAd
          ? "Blocked ad"
          : _isTracker
            ? "Blocked tracker"
            : "Blocked";
        const _short = _bh || url.slice(0, 40);
        log(
          `${_icon}<span style="color:var(--tx2)">${_type}:</span> <span style="color:var(--tx3)">${_short}</span>`,
          "skip",
        );
      } catch (e) {
        log(
          `<i class="fas fa-circle-minus" style="color:var(--tx3)"></i><span style="color:var(--tx2)">Blocked:</span> <span style="color:var(--tx3)">${url.slice(0, 50)}</span>`,
          "skip",
        );
      }
      return {
        status: 200,
        mime: "text/plain",
        buf: new ArrayBuffer(0),
        headers: {},
        skipped: true,
      };
    }

    if (memCache.has(url) && opts.method !== "POST") {
      cachedHits++;
      updateStats();
      const _mc = memCache.get(url);
      memCache.delete(url);
      memCache.set(url, _mc);
      return {
        ..._mc,
        fromCache: true,
      };
    }

    const cached = await getCached(url);
    if (cached && opts.method !== "POST") {
      cachedHits++;
      memCache.set(url, {
        status: 200,
        mime: cached.mime,
        buf: cached.data,
        headers: cached.headers,
      });
      updateStats();
      return {
        status: 200,
        mime: cached.mime,
        buf: cached.data,
        headers: cached.headers,
        fromCache: true,
      };
    }

    if (inFlight.has(url) && opts.method !== "POST") {
      return inFlight.get(url);
    }

    const myNavId = currentNavId;

    const promise = new Promise((res, rej) => {
      totalRequests++;
      pendingRequests++;
      updateStats();

      const _mergedOpts = { ...opts };

      const job = {
        url,
        opts: _mergedOpts,
        res,
        rej,
        priority,
        navId: myNavId,
        tabId: activeTabId,
      };
      let inserted = false;
      for (let i = 0; i < fetchQueue.length; i++) {
        if (priority < fetchQueue[i].priority) {
          fetchQueue.splice(i, 0, job);
          inserted = true;
          break;
        }
      }
      if (!inserted) fetchQueue.push(job);

      runQueue();
    });

    if (opts.method !== "POST") {
      promise._tabId = activeTabId;
      inFlight.set(url, promise);
      promise.finally(() => inFlight.delete(url));
    }

    return promise;
  }

  async function runQueue() {
    while (fetching < MAX_CONCURRENT && fetchQueue.length) {
      let jobIdx = -1;
      for (let i = 0; i < fetchQueue.length; i++) {
        const j = fetchQueue[i];
        const tabCtrl =
          j.tabId != null ? tabAbortControllers.get(j.tabId) : null;
        const tabClosed =
          j.tabId != null && !tabs.find((t) => t.id === j.tabId);
        if (
          j.opts?.signal?.aborted ||
          tabClosed ||
          (tabCtrl && tabCtrl.signal.aborted)
        ) {
          fetchQueue.splice(i, 1);
          j.rej(new DOMException("Aborted", "AbortError"));
          pendingRequests = Math.max(0, pendingRequests - 1);
          i--;
          continue;
        }
        if (jobIdx === -1) jobIdx = i;
      }
      if (jobIdx === -1) break;

      const job = fetchQueue.splice(jobIdx, 1)[0];
      fetching++;

      try {
        const r = await doFetch(job.url, job.opts);

        if (job.opts.method !== "POST" && r.status >= 200 && r.status < 400) {
          memCache.set(job.url, {
            status: r.status,
            mime: r.mime,
            buf: r.buf,
            headers: r.headers,
          });
          setCache(job.url, r.buf, r.mime, r.headers);

          if (memCache.size > 600) {
            const first = memCache.keys().next().value;
            memCache.delete(first);
          }
        }

        job.res(r);
      } catch (e) {
        job.rej(e);
      } finally {
        fetching--;
        pendingRequests--;
        updateStats();
        runQueue();
      }
    }
  }

  async function doFetch(url, opts = {}) {
    if (window._netStall)
      return Promise.reject(new TypeError("Failed to fetch"));
    const method = opts.method || "GET";
    const headers = {
      ...(opts.headers || {}),
    };
    let origin = new URL(url).origin;
    const cookieHeader = getCookieHeader(origin);
    let usedJarCookie = false;
    if (cookieHeader && !headers.Cookie && !headers.cookie) {
      headers.Cookie = cookieHeader;
      usedJarCookie = true;
    }
    if (pageUrl && !headers.Origin && !headers.origin)
      headers.Origin = new URL(pageUrl).origin;
    if (pageUrl && !headers.Referer && !headers.referer)
      headers.Referer = pageUrl;
    if (!headers["User-Agent"] && !headers["user-agent"]) {
      const _savedReqUA = (() => {
        try {
          return ls.getItem("gust:ua:request:v1");
        } catch {
          return null;
        }
      })();
      headers["User-Agent"] =
        _savedReqUA ||
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    }
    if (!headers["Accept-Language"] && !headers["accept-language"]) {
      headers["Accept-Language"] = "en-US,en;q=0.9";
    }
    if (
      !headers["Sec-Fetch-Mode"] &&
      !headers["sec-fetch-mode"] &&
      mediaPref("gust:media:headers:v1")
    ) {
      // Determine correct Sec-Fetch-* values based on request context
      const reqOrigin = (() => {
        try {
          return new URL(url).origin;
        } catch {
          return "";
        }
      })();
      const pageOrigin = (() => {
        try {
          return pageUrl ? new URL(pageUrl).origin : "";
        } catch {
          return "";
        }
      })();
      const isSameOrigin = reqOrigin && pageOrigin && reqOrigin === pageOrigin;
      const isSameSite = (() => {
        try {
          const getETLD1 = (h) => h.split(".").slice(-2).join(".");
          return (
            reqOrigin &&
            pageOrigin &&
            getETLD1(new URL(reqOrigin).hostname) ===
              getETLD1(new URL(pageOrigin).hostname)
          );
        } catch {
          return false;
        }
      })();
      // Top-level navigation
      if (!pageUrl || url === pageUrl) {
        headers["Sec-Fetch-Mode"] = "navigate";
        headers["Sec-Fetch-Site"] = "none";
        headers["Sec-Fetch-Dest"] = "document";
      } else {
        // Sub-resource: derive mode and site from URL/Accept header
        const accept = headers["Accept"] || headers["accept"] || "";
        const ext = url.split("?")[0].split(".").pop().toLowerCase();
        const isScript = /\.js$/i.test(url) || accept.includes("javascript");
        const isStyle = /\.css$/i.test(url) || accept.includes("text/css");
        const isImage =
          /\.(png|jpg|jpeg|gif|webp|svg|ico|avif)$/i.test(url) ||
          accept.startsWith("image/");
        const isFont = /\.(woff2?|ttf|otf|eot)$/i.test(url);
        const isJson = accept.includes("application/json");
        headers["Sec-Fetch-Site"] = isSameOrigin
          ? "same-origin"
          : isSameSite
            ? "same-site"
            : "cross-site";
        headers["Sec-Fetch-Mode"] =
          isScript || isStyle || isFont
            ? "no-cors"
            : isJson
              ? "cors"
              : "no-cors";
        headers["Sec-Fetch-Dest"] = isScript
          ? "script"
          : isStyle
            ? "style"
            : isImage
              ? "image"
              : isFont
                ? "font"
                : "empty";
      }
    }
    let body = opts.body;
    if (headers.__body_b64__ === "1") {
      try {
        const bin = atob(body || "");
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        body = arr;
      } catch {}
      delete headers.__body_b64__;
    }

    let resp;
    try {
      const fetchPromise = curl.fetch(url, {
        method,
        headers,
        body,
        signal: opts.signal,
      });
      const abortPromise = new Promise((_, rj) => {
        if (opts.signal?.aborted) rj(new DOMException("Aborted", "AbortError"));
        opts.signal?.addEventListener("abort", () =>
          rj(new DOMException("Aborted", "AbortError")),
        );
      });
      resp = await Promise.race([fetchPromise, abortPromise]);
    } catch (curlErr) {
      const msg = (curlErr.message || "").toLowerCase();
      const isAborted = curlErr.name === "AbortError" || opts.signal?.aborted;
      if (
        !isAborted &&
        (msg.includes("aborted") ||
          msg.includes("operation") ||
          msg.includes("network") ||
          msg.includes("wisp") ||
          msg.includes("socket"))
      ) {
        log("WISP connection lost, reconnecting...", "warn");
        let reconnected = false;
        for (let _attempt = 0; _attempt < 2; _attempt++) {
          try {
            if (_attempt > 0) await new Promise((r) => setTimeout(r, 600));
            await libcurl.load_wasm();
            libcurl.set_websocket(WISP);
            curl = new libcurl.HTTPSession();
            curl.set_connections(
              MAX_CONCURRENT_ACTIVE,
              MAX_CONCURRENT_ACTIVE,
              MAX_CONCURRENT_ACTIVE,
            );
            reconnected = true;
            log("Reconnected to WISP (attempt " + (_attempt + 1) + ")", "ok");
            break;
          } catch (reinitErr) {
            if (_attempt === 1) {
              log(
                "WISP reconnect failed after 2 attempts: " + reinitErr.message,
                "err",
              );
              throw reinitErr;
            }
            log("WISP reconnect attempt 1 failed, retrying...", "warn");
          }
        }
        const retryFetch = curl.fetch(url, {
          method,
          headers,
          body,
          signal: opts.signal,
        });
        const retryAbort = new Promise((_, rj) =>
          opts.signal?.addEventListener("abort", () =>
            rj(new DOMException("Aborted", "AbortError")),
          ),
        );
        resp = await Promise.race([retryFetch, retryAbort]);
      } else {
        throw curlErr;
      }
    }
    let redirectCount = 0;
    while (
      resp.status >= 300 &&
      resp.status < 400 &&
      resp.headers?.get?.("location") &&
      redirectCount < 12
    ) {
      const loc = resp.headers.get("location");
      const nextUrl = new URL(loc, url).href;
      log(
        `<i class="fas fa-arrow-right-arrow-left" style="color:var(--warn)"></i><span style="color:var(--tx3)">${resp.status}</span> → ${nextUrl.slice(0, 60)}`,
        "warn",
      );
      url = nextUrl;
      origin = new URL(url).origin;
      const nextCookie = getCookieHeader(origin);
      if (usedJarCookie) headers.Cookie = nextCookie;
      else if (nextCookie && !headers.Cookie && !headers.cookie) {
        headers.Cookie = nextCookie;
        usedJarCookie = true;
      }
      const rdFetch = curl.fetch(url, {
        method: method === "POST" ? "GET" : method,
        headers,
        body: null,
        signal: opts.signal,
      });
      const rdAbort = new Promise((_, rj) =>
        opts.signal?.addEventListener("abort", () =>
          rj(new DOMException("Aborted", "AbortError")),
        ),
      );
      resp = await Promise.race([rdFetch, rdAbort]);
      redirectCount++;
    }

    const ct = resp.headers?.get?.("content-type") || "";
    const mime = ct.split(";")[0].trim() || "application/octet-stream";
    // Handle partial content (206) for range requests - return only the requested slice
    let buf;
    const rangeReq =
      mediaPref("gust:media:range:v1") &&
      (headers["Range"] || headers["range"]);
    const isPartial = resp.status === 206;
    if (isPartial || rangeReq) {
      buf = await resp.arrayBuffer();
      // If server didn't honour range (returned 200 with full body), slice manually
      if (resp.status === 200 && rangeReq) {
        const m = rangeReq.match(/bytes=(\d+)-(\d*)/);
        if (m) {
          const start = parseInt(m[1]);
          const end = m[2] ? parseInt(m[2]) : buf.byteLength - 1;
          buf = buf.slice(start, end + 1);
        }
      }
    } else {
      buf = await resp.arrayBuffer();
    }
    const hdrs = {};
    resp.headers?.forEach?.((v, k) => (hdrs[k.toLowerCase()] = v));
    // Ensure Content-Range is forwarded for 206
    if (isPartial && !hdrs["content-range"]) {
      const cr = resp.headers?.get?.("content-range");
      if (cr) hdrs["content-range"] = cr;
    }
    const finalStatus = isPartial ? 206 : resp.status;
    if (hdrs["set-cookie"]) {
      updateCookiesFromSetCookie(origin, hdrs["set-cookie"]);
      syncCookiesToFrame(origin);
    }
    if (resp.status >= 400) {
      const shortUrl = url.replace(/^https?:\/\//, "").slice(0, 55);
      log(
        `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">${resp.status}</span> <span style="color:var(--tx3)">${shortUrl}</span>`,
        "err",
      );
    }
    return {
      status: finalStatus,
      mime,
      buf,
      headers: hdrs,
      finalUrl: url, // url may have mutated through the redirect chain above
    };
  }

  function toB64(buf) {
    const bytes = new Uint8Array(buf);
    let bin = "";
    const chunk = 32768;
    for (let i = 0; i < bytes.length; i += chunk) {
      bin += String.fromCharCode.apply(
        null,
        bytes.subarray(i, Math.min(i + chunk, bytes.length)),
      );
    }
    return btoa(bin);
  }

  function fromB64(b64) {
    const bin = atob(b64 || "");
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return arr;
  }

  function closeAllSockets() {
    for (const ws of wsMap.values()) {
      try {
        ws.close(1000, "Navigation");
      } catch {}
    }
    wsMap.clear();
  }

  function handleWsOpen(id, url, protocols) {
    try {
      const ws = new WebSocket(url, protocols || undefined);
      ws.binaryType = "arraybuffer";
      wsMap.set(id, ws);
      const wsShort = url.replace(/^wss?:\/\//, "").slice(0, 50);
      log(
        `<i class="fas fa-plug" style="color:#c084fc"></i><span style="color:#c084fc">WS</span> ${wsShort}`,
        "stream",
      );
      ws.onopen = () => {
        frame.contentWindow?.postMessage(
          { t: "ws", i: id, a: "open", protocol: ws.protocol },
          "*",
        );
      };
      ws.onmessage = async (e) => {
        if (!frame.contentWindow) return;
        if (typeof e.data === "string") {
          frame.contentWindow.postMessage(
            { t: "ws", i: id, a: "message", d: e.data },
            "*",
          );
        } else if (e.data instanceof ArrayBuffer) {
          frame.contentWindow.postMessage(
            { t: "ws", i: id, a: "message", b64: 1, d: toB64(e.data) },
            "*",
          );
        } else if (e.data instanceof Blob) {
          const buf = await e.data.arrayBuffer();
          frame.contentWindow.postMessage(
            { t: "ws", i: id, a: "message", b64: 1, d: toB64(buf) },
            "*",
          );
        }
      };
      ws.onerror = () => {
        log(
          `<i class="fas fa-plug-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">WS error:</span> ${wsShort}`,
          "err",
        );
        frame.contentWindow?.postMessage({ t: "ws", i: id, a: "error" }, "*");
      };
      ws.onclose = (e) => {
        frame.contentWindow?.postMessage(
          {
            t: "ws",
            i: id,
            a: "close",
            code: e.code,
            reason: e.reason,
            wasClean: e.wasClean,
          },
          "*",
        );
        wsMap.delete(id);
      };
    } catch (e) {
      log(
        `<i class="fas fa-plug-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">WS failed:</span> ${e.message}`,
        "err",
      );
      frame.contentWindow?.postMessage(
        { t: "ws", i: id, a: "error", message: e.message },
        "*",
      );
    }
  }

  function handleWsSend(id, data, isB64) {
    const ws = wsMap.get(id);
    if (!ws) return;
    if (isB64) {
      const arr = fromB64(data);
      ws.send(arr);
    } else {
      ws.send(data);
    }
  }

  function handleWsClose(id, code, reason) {
    const ws = wsMap.get(id);
    if (!ws) return;
    try {
      ws.close(code || 1000, reason || "");
    } catch {}
  }

  async function handleSSE(id, url, headers, tabSignal) {
    streamCount++;
    updateStats();
    log(
      `<i class="fas fa-bolt" style="color: #c084fc;"></i> SSE: ${url.slice(0, 50)}`,
      "stream",
    );
    try {
      const resp = await curl.fetch(url, {
        method: "GET",
        headers: {
          ...headers,
          Accept: "text/event-stream",
        },
        signal: tabSignal || abortCtrl?.signal,
      });
      const reader = resp.body?.getReader?.();
      if (!reader) {
        const buf = await resp.arrayBuffer();
        frame.contentWindow?.postMessage(
          {
            t: "sse",
            i: id,
            d: toB64(buf),
            done: true,
          },
          "*",
        );
        return;
      }
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, {
          stream: true,
        });
        const lines = buffer.split("\n\n");
        buffer = lines.pop() || "";
        for (const chunk of lines) {
          if (chunk.trim())
            frame.contentWindow?.postMessage(
              {
                t: "sse",
                i: id,
                chunk: chunk + "\n\n",
              },
              "*",
            );
        }
      }
      if (buffer.trim())
        frame.contentWindow?.postMessage(
          {
            t: "sse",
            i: id,
            chunk: buffer,
          },
          "*",
        );
      frame.contentWindow?.postMessage(
        {
          t: "sse",
          i: id,
          done: true,
        },
        "*",
      );
    } catch (e) {
      frame.contentWindow?.postMessage(
        {
          t: "sse",
          i: id,
          error: e.message,
        },
        "*",
      );
    } finally {
      streamCount--;
      updateStats();
    }
  }

  async function handleStreamFetch(id, url, opts, tabSignal) {
    streamCount++;
    updateStats();
    log(
      `<i class="fas fa-bolt" style="color: #c084fc;"></i> Stream: ${url.slice(0, 50)}`,
      "stream",
    );
    try {
      const resp = await curl.fetch(url, {
        method: opts.method || "GET",
        headers: opts.headers || {},
        body: opts.body,
        signal: tabSignal || abortCtrl?.signal,
      });
      const hdrs = {};
      resp.headers?.forEach?.((v, k) => (hdrs[k.toLowerCase()] = v));
      frame.contentWindow?.postMessage(
        {
          t: "streamStart",
          i: id,
          status: resp.status,
          headers: hdrs,
        },
        "*",
      );
      const reader = resp.body?.getReader?.();
      if (!reader) {
        const buf = await resp.arrayBuffer();
        frame.contentWindow?.postMessage(
          {
            t: "streamData",
            i: id,
            d: toB64(buf),
          },
          "*",
        );
        frame.contentWindow?.postMessage(
          {
            t: "streamEnd",
            i: id,
          },
          "*",
        );
        return;
      }
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        frame.contentWindow?.postMessage(
          {
            t: "streamData",
            i: id,
            d: toB64(value),
          },
          "*",
        );
      }
      frame.contentWindow?.postMessage(
        {
          t: "streamEnd",
          i: id,
        },
        "*",
      );
    } catch (e) {
      frame.contentWindow?.postMessage(
        {
          t: "streamError",
          i: id,
          error: e.message,
        },
        "*",
      );
    } finally {
      streamCount--;
      updateStats();
    }
  }

  function makeProxyScript(
    baseUrl,
    blockEnabled = true,
    webrtcBlock = false,
    pageUA = null,
    spellcheck = false,
  ) {
    const proxySkipList = [...SKIP_DOMAINS, ...getCustomFilters().network];
    return `(function(){
if(window.__P) return;
window.__P = true;

const BASE = ${JSON.stringify(baseUrl)};
const ORIGIN = new URL(BASE).origin;
const SKIP = ${JSON.stringify(proxySkipList)};
const BLOCK_ENABLED = ${JSON.stringify(!!blockEnabled)};
const WEBRTC_BLOCK = ${JSON.stringify(!!webrtcBlock)};
const SPOOF_UA = ${JSON.stringify(pageUA || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")};
const SPELLCHECK = ${JSON.stringify(!!spellcheck)};

function shouldSkip(url) {
  if (!BLOCK_ENABLED) return false;
  try { const h = new URL(url).hostname.toLowerCase(); return SKIP.some(d => h.includes(d)); } catch { return false; }
}

const assetsPath = BASE.substring(0, BASE.lastIndexOf('/') + 1);
try { window.__webpack_public_path__ = assetsPath; } catch {}
try { if (typeof __webpack_require__ !== 'undefined') __webpack_require__.p = assetsPath; } catch {}
try { Object.defineProperty(window, '__webpack_public_path__', { get: () => window.__wpp || assetsPath, set: v => { window.__wpp = v; }, configurable: true }); } catch {}

// ── Next.js / Vite / React framework fixes ─────────────────────────────────
// 1. import.meta.url inside ES-module scripts resolves to the blob: URL of
//    the iframe document, making dynamic import() and asset-path calculations
//    (e.g. new URL('./chunk.js', import.meta.url)) point at blob:null/… and
//    fail.  We expose the real page origin so framework resolvers work.
try {
  Object.defineProperty(window, '__GUST_REAL_BASE__', { value: BASE, configurable: true });
} catch {}

// 2. Next.js reads __NEXT_DATA__.assetPrefix to build /_next/static/… URLs.
//    Inside a blob iframe the prefix must be the real origin, not empty string.
try {
  if (window.__NEXT_DATA__ && !window.__NEXT_DATA__.assetPrefix) {
    window.__NEXT_DATA__.assetPrefix = ORIGIN;
  }
  // Also patch after DOMContentLoaded in case the inline script sets it late.
  document.addEventListener('DOMContentLoaded', function _ndPatch() {
    document.removeEventListener('DOMContentLoaded', _ndPatch);
    try {
      if (window.__NEXT_DATA__ && !window.__NEXT_DATA__.assetPrefix) {
        window.__NEXT_DATA__.assetPrefix = ORIGIN;
      }
    } catch {}
  });
} catch {}

// 3. Vite / Rollup embed chunk hashes in import.meta.url paths.  We can't
//    truly override import.meta.url (it's not writable), but we can ensure
//    any URL constructed from it is resolved against the real BASE.  Intercept
//    the URL constructor so new URL(relative, blobHref) → new URL(relative, BASE).
try {
  const _OrigURL = window.URL;
  function _GustURL(url, base) {
    if (base && typeof base === 'string' && /^blob:/i.test(base)) {
      base = BASE;
    }
    return new _OrigURL(url, base);
  }
  _GustURL.createObjectURL = _OrigURL.createObjectURL.bind(_OrigURL);
  _GustURL.revokeObjectURL = _OrigURL.revokeObjectURL.bind(_OrigURL);
  _GustURL.canParse       = _OrigURL.canParse ? _OrigURL.canParse.bind(_OrigURL) : undefined;
  Object.setPrototypeOf(_GustURL, _OrigURL);
  try { window.URL = _GustURL; } catch {}
} catch {}
// ───────────────────────────────────────────────────────────────────────────

let currentScript = null;
const scriptUrls = new WeakMap();

function patchScriptNode(node, realSrc) {
  if (!node || node.__isPatched || !realSrc) return node;
  try { Object.defineProperty(node, '__isPatched', { value: true, enumerable: false }); } catch {}
  try { Object.defineProperty(node, 'src', { get: () => realSrc, set: function(v) { this.setAttribute('src', v); }, configurable: true }); } catch {}
  const origGet = node.getAttribute;
  node.getAttribute = function(n) { return (n === 'src' || n === 'SRC') ? realSrc : origGet.call(this, n); };
  return node;
}
const nativeCurrentScriptGet = Object.getOwnPropertyDescriptor(Document.prototype, 'currentScript')?.get;
Object.defineProperty(document, 'currentScript', {
  get() {
    if (currentScript) {
      const url = scriptUrls.get(currentScript);
      if (url) return patchScriptNode(currentScript, url);
    }
    const native = nativeCurrentScriptGet ? nativeCurrentScriptGet.call(document) : null;
    if (native) {
      const dataUrl = native.getAttribute?.('data-original-src') || native.getAttribute?.('data-proxy-src');
      const src = dataUrl || native.getAttribute?.('src') || native.src;
      if (src) return patchScriptNode(native, src);
      return native;
    }
    return currentScript;
  },
  configurable: true
});

const cookies = new Map();
try { const s = sessionStorage.getItem('_c_' + ORIGIN); if (s) JSON.parse(s).forEach(([k,v]) => cookies.set(k,v)); } catch {}
Object.defineProperty(document, 'cookie', {
  get() { return [...cookies].map(([k,v]) => k+'='+v).join('; '); },
  set(s) { const m = String(s).match(/^([^=]+)=([^;]*)/); if (m) { if (s.includes('max-age=0') || s.includes('expires=Thu, 01 Jan 1970')) cookies.delete(m[1].trim()); else cookies.set(m[1].trim(), m[2]); try { sessionStorage.setItem('_c_' + ORIGIN, JSON.stringify([...cookies])); } catch {} try { parent.postMessage({ t: 'cookieSet', origin: ORIGIN, cookie: s }, '*'); } catch {} } },
  configurable: true
});

const pfx = '_s_' + ORIGIN + '_';
const mkStore = s => ({ getItem: k => s.getItem(pfx+k), setItem: (k,v) => s.setItem(pfx+k,v), removeItem: k => s.removeItem(pfx+k), clear: () => Object.keys(s).filter(k=>k.startsWith(pfx)).forEach(k=>s.removeItem(k)), key: i => { const ks = Object.keys(s).filter(k=>k.startsWith(pfx)); return ks[i]?.slice(pfx.length)||null; }, get length() { return Object.keys(s).filter(k=>k.startsWith(pfx)).length; } });
try { Object.defineProperty(window, 'localStorage', {value: mkStore(localStorage)}); } catch {}
try { Object.defineProperty(window, 'sessionStorage', {value: mkStore(sessionStorage)}); } catch {}

const origIDBOpen = indexedDB.open.bind(indexedDB);
indexedDB.open = function(name, version) { return origIDBOpen(pfx + name, version); };

let rid = 0;
const pending = new Map();
const sseHandlers = new Map();
const streamHandlers = new Map();
const wsClients = new Map();

window.addEventListener('message', e => {
  if (e.source !== parent) return;
  const d = e.data;
  if (!d) return;
  if (d.t === 'cookieSync') {
    if (d.origin !== ORIGIN || typeof d.cookie !== 'string') return;
    d.cookie.split(/;\s*/).forEach(p => {
      const m = p.match(/^([^=]+)=([^;]*)/);
      if (m) cookies.set(m[1].trim(), m[2]);
    });
    try { sessionStorage.setItem('_c_' + ORIGIN, JSON.stringify([...cookies])); } catch {}
  }
  if (d.t === 'r') { const p = pending.get(d.i); if (p) { pending.delete(d.i); clearTimeout(p.tm); d.e ? p.rj(new Error(d.e)) : p.rs(d); } }
  if (d.t === 'sse') { const h = sseHandlers.get(d.i); if (h) { if (d.error) { h.onerror?.(new Event('error')); sseHandlers.delete(d.i); } else if (d.done) { sseHandlers.delete(d.i); } else if (d.chunk) { h.onchunk?.(d.chunk); } } }
  if (d.t === 'streamStart') { const h = streamHandlers.get(d.i); if (h) h.onstart?.(d.status, d.headers); }
  if (d.t === 'streamData') { const h = streamHandlers.get(d.i); if (h && d.d) { const bin = atob(d.d); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); h.ondata?.(arr); } }
  if (d.t === 'streamEnd') { const h = streamHandlers.get(d.i); if (h) { h.onend?.(); streamHandlers.delete(d.i); } }
  if (d.t === 'streamError') { const h = streamHandlers.get(d.i); if (h) { h.onerror?.(new Error(d.error)); streamHandlers.delete(d.i); } }
  if (d.t === 'ws') {
    const ws = wsClients.get(d.i);
    if (!ws) return;
    if (d.a === 'open') { ws.readyState = 1; ws.protocol = d.protocol || ''; const evt = new Event('open'); ws.dispatchEvent(evt); ws.onopen?.(evt); }
    if (d.a === 'message') {
      let data = d.d;
      if (d.b64) { const bin = atob(d.d || ''); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); data = ws.binaryType === 'arraybuffer' ? arr.buffer : new Blob([arr]); }
      const evt = new MessageEvent('message', { data });
      ws.dispatchEvent(evt);
      ws.onmessage?.(evt);
    }
    if (d.a === 'error') { const evt = new Event('error'); ws.dispatchEvent(evt); ws.onerror?.(evt); }
    if (d.a === 'close') { ws.readyState = 3; const evt = new CloseEvent('close', { code: d.code || 1000, reason: d.reason || '', wasClean: d.wasClean }); ws.dispatchEvent(evt); ws.onclose?.(evt); wsClients.delete(d.i); }
  }
  if (d.type === 'gust:highlight' && d.selector) {
    try {
      document.querySelectorAll('.gust-highlight').forEach(el => el.classList.remove('gust-highlight'));
      const el = document.querySelector(d.selector);
      if (el) { el.classList.add('gust-highlight'); el.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    } catch (e) {}
  }
  if (d.type === 'gust:clearHighlight') {
    try { document.querySelectorAll('.gust-highlight').forEach(el => el.classList.remove('gust-highlight')); } catch(e) {}
  }
  if (d.type === 'gust:getStyles' && d.selector) {
    try {
      const el = document.querySelector(d.selector);
      if (el) {
        const cs = getComputedStyle(el);
        const styles = {};
        ['display','position','width','height','margin','margin-top','margin-right','margin-bottom','margin-left','padding','padding-top','padding-right','padding-bottom','padding-left','color','background','background-color','font-size','font-weight','font-family','border','border-radius','flex','grid','z-index','overflow','opacity','transform','box-shadow','line-height','text-align'].forEach(p => { styles[p] = cs.getPropertyValue(p); });
        parent.postMessage({ type: 'gust:stylesResult', styles }, '*');
      }
    } catch(e) {}
  }
  if (d.type === 'gust:getBox' && d.selector) {
    try {
      const el = document.querySelector(d.selector);
      if (el) {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        parent.postMessage({ type: 'gust:boxResult', box: {
          width: r.width, height: r.height, top: r.top, left: r.left,
          marginTop: cs.marginTop, marginRight: cs.marginRight, marginBottom: cs.marginBottom, marginLeft: cs.marginLeft,
          paddingTop: cs.paddingTop, paddingRight: cs.paddingRight, paddingBottom: cs.paddingBottom, paddingLeft: cs.paddingLeft
        }}, '*');
      }
    } catch(e) {}
  }
  if (d.type === 'gust:scrollTo' && d.selector) {
    try { document.querySelector(d.selector)?.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch(e) {}
  }
  if (d.type === 'gust:spellcheck') {
    try { document.querySelectorAll('input, textarea').forEach(el => el.spellcheck = !!d.enabled); } catch(e) {}
  }
});

function req(url, opts = {}) {
  if (shouldSkip(url)) return Promise.resolve({ d: '', s: 200, h: {}, m: 'text/plain' });
  return new Promise((rs, rj) => {
    const i = ++rid;
    const tm = setTimeout(() => { pending.delete(i); rj(new Error('Timeout')); }, 120000);
    pending.set(i, { rs, rj, tm });
    parent.postMessage({ t: 'q', i, url, opts }, '*');
  });
}

function resolve(url, base) {
  if (!url) return '';
  if (/^(data:|blob:|javascript:|about:|#)/i.test(url)) return url;
  let b = base || BASE;
  if (b && (String(b).startsWith('blob:') || String(b).startsWith('null'))) b = BASE;
  try { return new URL(url, b).href; } catch { return url; }
}

const blobs = new Map();
const blobPromises = new Map();

function b64FromArray(arr) {
  let bin = "";
  const chunk = 32768;
  for (let i = 0; i < arr.length; i += chunk) {
    bin += String.fromCharCode.apply(null, arr.subarray(i, i + chunk));
  }
  return btoa(bin);
}

async function fetchBlob(url, type) {
  if (shouldSkip(url)) return 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  if (blobs.has(url)) return blobs.get(url);
  if (blobPromises.has(url)) return blobPromises.get(url);
  const promise = (async () => {
    const r = await req(url);
    if (!r.d) return '';
    const bin = atob(r.d);
    const arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    const blob = new Blob([arr], { type: r.m || type || 'application/octet-stream' });
    const burl = URL.createObjectURL(blob);
    blobs.set(url, burl);
    if (blobs.size > 500) { const f = blobs.keys().next().value; URL.revokeObjectURL(blobs.get(f)); blobs.delete(f); }
    return burl;
  })();
  blobPromises.set(url, promise);
  promise.finally(() => blobPromises.delete(url));
  return promise;
}

const _fetch = window.fetch;
window.fetch = async function(input, init = {}) {
  let url = typeof input === 'string' ? input : (input instanceof URL ? input.href : (input?.url || String(input)));
  if (/^blob:/i.test(url)) return _fetch.call(window, input, init);
  url = resolve(url);
  if (shouldSkip(url)) return new Response('', { status: 200 });
  // Handle Request objects: extract method/headers/body from the Request,
  // then let init override (per fetch spec). This fixes sites like YouTube
  // that call fetch(new Request(url, {method:'POST', headers:{...}, body:...})).
  const isRequest = typeof Request !== 'undefined' && input instanceof Request;
  const method = init.method || (isRequest ? input.method : null) || 'GET';
  let body = init.body !== undefined ? init.body : (isRequest && !input.bodyUsed ? input.body : undefined);
  const headers = {};
  if (isRequest) { try { input.headers.forEach((v, k) => { headers[k] = v; }); } catch(e) {} }
  if (init.headers) { if (init.headers instanceof Headers) init.headers.forEach((v,k) => headers[k] = v); else if (typeof init.headers === 'object') Object.assign(headers, init.headers); }
  if (body instanceof FormData) body = new URLSearchParams(body).toString();
  else if (body instanceof URLSearchParams) body = body.toString();
  else if (body instanceof ReadableStream) { const reader = body.getReader(); const chunks = []; while (true) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); } const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0); const result = new Uint8Array(totalLength); let offset = 0; for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.length; } body = btoa(String.fromCharCode(...result)); headers['__body_b64__'] = '1'; }
  const wantsStream = headers['accept']?.includes('text/event-stream') || headers['Accept']?.includes('text/event-stream');
  if (wantsStream && method === 'POST') {
    return new Promise((resolve, reject) => {
      const i = ++rid; let responseHeaders = {}; let status = 200; let controller;
      const stream = new ReadableStream({ start(c) { controller = c; }, cancel() { streamHandlers.delete(i); } });
      streamHandlers.set(i, { onstart: (s, h) => { status = s; responseHeaders = h; }, ondata: (arr) => { controller?.enqueue(arr); }, onend: () => { controller?.close(); }, onerror: (e) => { controller?.error(e); reject(e); } });
      parent.postMessage({ t: 'stream', i, url, opts: { method, headers, body } }, '*');
      setTimeout(() => { resolve(new Response(stream, { status, headers: new Headers(responseHeaders) })); }, 50);
    });
  }
  const r = await req(url, { method, headers, body });
  const bin = atob(r.d || '');
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Response(arr, { status: r.s || 200, headers: new Headers(r.h || {}) });
};

const OrigEventSource = window.EventSource;
window.EventSource = class extends EventTarget {
  constructor(url, opts = {}) {
    super(); this.url = resolve(url); this.readyState = 0; this.withCredentials = opts.withCredentials || false;
    const i = ++rid; this._id = i; let buffer = ''; let lastEventId = ''; let eventType = 'message'; let data = '';
    const processLine = (line) => { if (line === '') { if (data) { const evt = new MessageEvent(eventType, { data: data.slice(0, -1), lastEventId }); this.dispatchEvent(evt); if (eventType === 'message' && this.onmessage) this.onmessage(evt); } data = ''; eventType = 'message'; } else if (line.startsWith('data:')) { data += line.slice(5).trim() + '\\n'; } else if (line.startsWith('event:')) { eventType = line.slice(6).trim(); } else if (line.startsWith('id:')) { lastEventId = line.slice(3).trim(); } };
    sseHandlers.set(i, { onchunk: (chunk) => { buffer += chunk; const lines = buffer.split('\\n'); buffer = lines.pop() || ''; lines.forEach(processLine); }, onerror: (e) => { this.readyState = 2; this.dispatchEvent(new Event('error')); if (this.onerror) this.onerror(e); } });
    parent.postMessage({ t: 'sse', i, url: this.url, headers: {} }, '*');
    setTimeout(() => { this.readyState = 1; this.dispatchEvent(new Event('open')); if (this.onopen) this.onopen(new Event('open')); }, 100);
  }
  close() { this.readyState = 2; sseHandlers.delete(this._id); }
};

const OrigURL = URL;
function SafeURL(u, b) {
  try { return b !== undefined ? new OrigURL(u, b) : new OrigURL(u); }
  catch (e) {
    try { return new OrigURL(u, BASE); }
    catch { throw e; }
  }
}
SafeURL.createObjectURL = OrigURL.createObjectURL.bind(OrigURL);
SafeURL.revokeObjectURL = OrigURL.revokeObjectURL.bind(OrigURL);
SafeURL.prototype = OrigURL.prototype;
SafeURL.toString = OrigURL.toString.bind(OrigURL);
window.URL = SafeURL;
window.webkitURL = SafeURL;

const OrigWebSocket = window.WebSocket;
window.WebSocket = class extends EventTarget {
  constructor(url, protocols) {
    super();
    this.url = resolve(url);
    this.readyState = 0;
    this.bufferedAmount = 0;
    this.extensions = "";
    this.protocol = "";
    this.binaryType = "blob";
    this._id = ++rid;
    wsClients.set(this._id, this);
    parent.postMessage({ t: 'ws', a: 'open', i: this._id, url: this.url, protocols }, '*');
  }
  send(data) {
    if (this.readyState !== 1) return;
    if (data instanceof ArrayBuffer) {
      parent.postMessage({ t: 'ws', a: 'send', i: this._id, b64: 1, d: b64FromArray(new Uint8Array(data)) }, '*');
    } else if (ArrayBuffer.isView(data)) {
      const arr = new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
      parent.postMessage({ t: 'ws', a: 'send', i: this._id, b64: 1, d: b64FromArray(arr) }, '*');
    } else if (data instanceof Blob) {
      data.arrayBuffer().then(buf => parent.postMessage({ t: 'ws', a: 'send', i: this._id, b64: 1, d: b64FromArray(new Uint8Array(buf)) }, '*')).catch(() => {});
    } else {
      parent.postMessage({ t: 'ws', a: 'send', i: this._id, d: String(data) }, '*');
    }
  }
  close(code, reason) {
    if (this.readyState > 1) return;
    this.readyState = 2;
    parent.postMessage({ t: 'ws', a: 'close', i: this._id, code, reason }, '*');
  }
};
Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });

const _XHR = window.XMLHttpRequest;
window.XMLHttpRequest = function() {
  let method = 'GET', url = '', async = true, reqH = {}, respType = '';
  let state = 0, status = 0, statusText = '', response = null, responseText = '', respH = {};
  const listeners = {}; const xhr = this; let uploadListeners = {};
  const fire = (t, e) => { e = e || { type: t }; if (xhr['on' + t]) try { xhr['on' + t](e); } catch {} (listeners[t] || []).forEach(fn => { try { fn.call(xhr, e); } catch {} }); };
  const setReady = s => { state = s; fire('readystatechange'); };
  xhr.upload = { addEventListener: (t, fn) => { if (!uploadListeners[t]) uploadListeners[t] = []; uploadListeners[t].push(fn); }, removeEventListener: (t, fn) => { if (uploadListeners[t]) uploadListeners[t] = uploadListeners[t].filter(f => f !== fn); } };
  xhr.open = function(m, u, a) { method = m; url = resolve(u); async = a !== false; reqH = {}; setReady(1); };
  xhr.setRequestHeader = (k, v) => { reqH[k] = v; };
  xhr.getResponseHeader = k => respH[k.toLowerCase()] || null;
  xhr.getAllResponseHeaders = () => Object.entries(respH).map(([k,v]) => k + ': ' + v).join('\\r\\n');
  xhr.overrideMimeType = () => {}; xhr.abort = () => fire('abort');
  xhr.send = async function(body) {
    if (/^blob:/i.test(url)) { const native = new _XHR(); native.open(method, url, async); native.responseType = respType; Object.entries(reqH).forEach(([k,v]) => native.setRequestHeader(k, v)); native.onreadystatechange = () => { state = native.readyState; status = native.status; response = native.response; try { responseText = native.responseText; } catch {} fire('readystatechange'); }; native.onload = () => fire('load'); native.onerror = () => fire('error'); native.send(body); return; }
    if (shouldSkip(url)) { status = 200; response = responseText = ''; setReady(4); fire('load'); fire('loadend'); return; }
    if (body) { const total = body.length || body.size || 1000; (uploadListeners['loadstart'] || []).forEach(fn => fn({ lengthComputable: true, loaded: 0, total })); (uploadListeners['progress'] || []).forEach(fn => fn({ lengthComputable: true, loaded: total, total })); (uploadListeners['load'] || []).forEach(fn => fn({ lengthComputable: true, loaded: total, total })); }
    if (body instanceof FormData) body = new URLSearchParams(body).toString();
    setReady(1);
    try {
      const r = await req(url, { method, headers: reqH, body }); status = r.s || 200; respH = r.h || {};
      setReady(2); setReady(3);
      const bin = atob(r.d || ''); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      fire('progress', { lengthComputable: true, loaded: arr.length, total: arr.length });
      if (respType === 'arraybuffer') response = arr.buffer;
      else if (respType === 'blob') response = new Blob([arr]);
      else if (respType === 'json') { responseText = new TextDecoder().decode(arr); try { response = JSON.parse(responseText); } catch { response = null; } }
      else if (respType === 'document') { responseText = new TextDecoder().decode(arr); try { response = new DOMParser().parseFromString(responseText, 'text/html'); } catch { response = null; } }
      else { responseText = new TextDecoder().decode(arr); response = responseText; }
      setReady(4); fire('load'); fire('loadend');
    } catch (e) { status = 0; setReady(4); fire('error'); fire('loadend'); }
  };
  xhr.addEventListener = (t, fn) => { if (!listeners[t]) listeners[t] = []; listeners[t].push(fn); };
  xhr.removeEventListener = (t, fn) => { if (listeners[t]) listeners[t] = listeners[t].filter(f => f !== fn); };
  Object.defineProperties(xhr, { readyState: { get: () => state }, status: { get: () => status }, statusText: { get: () => statusText }, response: { get: () => response }, responseText: { get: () => responseText }, responseType: { get: () => respType, set: v => respType = v }, responseURL: { get: () => url }, timeout: { get: () => 0, set: () => {} }, withCredentials: { get: () => false, set: () => {} } });
  xhr.UNSENT = 0; xhr.OPENED = 1; xhr.HEADERS_RECEIVED = 2; xhr.LOADING = 3; xhr.DONE = 4;
};
Object.assign(XMLHttpRequest, { UNSENT: 0, OPENED: 1, HEADERS_RECEIVED: 2, LOADING: 3, DONE: 4 });

const elMap = [ { p: HTMLImageElement.prototype, a: ['src'] }, { p: HTMLVideoElement.prototype, a: ['src', 'poster'] }, { p: HTMLAudioElement.prototype, a: ['src'] }, { p: HTMLSourceElement.prototype, a: ['src'] }, { p: HTMLTrackElement.prototype, a: ['src'] }, { p: HTMLEmbedElement.prototype, a: ['src'] }, { p: HTMLObjectElement.prototype, a: ['data'] }, { p: HTMLInputElement.prototype, a: ['src'] } ];
const loadingEls = new WeakMap();
const pendingLoads = new Set();
const loadedUrls = new Set();
const MAX_CONCURRENT_MEDIA = 24;

elMap.forEach(({ p, a }) => { a.forEach(attr => { const desc = Object.getOwnPropertyDescriptor(p, attr); if (!desc) return; Object.defineProperty(p, attr, { get() { return this.getAttribute('data-real-' + attr) || this.getAttribute(attr) || ''; }, set(val) { 
if (!val || /^(data:|blob:|javascript:|about:)/i.test(val)) { if (desc.set) desc.set.call(this, val); return; } 
const absUrl = resolve(val); 
if (shouldSkip(absUrl)) return; 
const el = this; 
const currentReal = el.getAttribute('data-real-' + attr);
if (currentReal === absUrl) return;
if (loadedUrls.has(absUrl) && pendingLoads.has(absUrl)) return;
el.setAttribute('data-real-' + attr, absUrl); 
if (loadingEls.has(el)) loadingEls.get(el).cancel = true; 
const state = { cancel: false }; 
loadingEls.set(el, state); 

loadMedia();
async function loadMedia() {
  if (pendingLoads.has(absUrl)) return;
  while (pendingLoads.size >= MAX_CONCURRENT_MEDIA) await new Promise(r => setTimeout(r, 50));
  if (state.cancel) return;
  pendingLoads.add(absUrl);
  try {
    const burl = await fetchBlob(absUrl);
    if (state.cancel) return;
    loadedUrls.add(absUrl);
    el.setAttribute('data-blob-' + attr, burl);
    if (desc.set) desc.set.call(el, burl);
    else el.setAttribute(attr, burl);
    el.dispatchEvent(new Event('load'));
  } catch (e) {
    if (!state.cancel) el.dispatchEvent(new Event('error'));
  } finally {
    pendingLoads.delete(absUrl);
  }
}
}, configurable: true }); }); });

[HTMLImageElement.prototype, HTMLSourceElement.prototype].forEach(p => { const desc = Object.getOwnPropertyDescriptor(p, 'srcset'); if (!desc) return; Object.defineProperty(p, 'srcset', { get() { return this.getAttribute('srcset') || ''; }, async set(val) { if (!val) { this.setAttribute('srcset', ''); return; } if (this.getAttribute('data-srcset-loading') === val) return; this.setAttribute('data-srcset-loading', val); const parts = val.split(',').map(s => s.trim()); 
const rewritten = await Promise.all(parts.map(async part => {
  const m = part.match(/^(\\S+)(.*)?$/);
  if (!m) return part;
  const [, url, rest] = m;
  if (/^(data:|blob:)/i.test(url)) return part;
  try {
    const burl = await fetchBlob(resolve(url), 'image/*');
    return burl + (rest || '');
  } catch { return ''; }
}));
this.setAttribute('srcset', rewritten.filter(Boolean).join(', '));
this.removeAttribute('data-srcset-loading'); }, configurable: true }); });

async function rewriteCss(css, base, _depth) {
  if ((_depth || 0) > 4) return css;
  const importRe = /@import\\s+(?:url\\()?['"]?([^'")\\s;]+)['"]?\\)?[^;]*;/gi;
  const importMatches = [...css.matchAll(importRe)];
  for (const im of importMatches) {
    try {
      const importUrl = resolve(im[1], base);
      const r = await req(importUrl);
      if (r.d) {
        const bin = atob(r.d); const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        let importCss = new TextDecoder().decode(arr);
        importCss = await rewriteCss(importCss, importUrl, (_depth || 0) + 1);
        css = css.replace(im[0], importCss);
      }
    } catch { }
  }
  const regex = /url\\(\\s*(['"]?)([^'"\\)]+)\\1\\s*\\)/gi;
  const result_seen = new Set();
  let result = css;
  for (const m of [...css.matchAll(regex)]) {
    if (/^(data:|blob:|#)/i.test(m[2]) || result_seen.has(m[0])) continue;
    result_seen.add(m[0]);
    const absUrl = resolve(m[2], base);
    const ext = absUrl.split('?')[0].split('.').pop().toLowerCase();
    const isFont = /woff2?|ttf|otf|eot/.test(ext);
    try {
      if (isFont) {
       
        const r = await req(absUrl);
        if (r.d) {
          const fontMime = ext === 'woff2' ? 'font/woff2' : ext === 'woff' ? 'font/woff' : ext === 'ttf' ? 'font/ttf' : ext === 'otf' ? 'font/otf' : 'font/woff2';
          result = result.split(m[0]).join('url("data:' + fontMime + ';base64,' + r.d + '")');
        } else {
          result = result.split(m[0]).join('url("' + absUrl + '")');
        }
      } else {
        const _blobUrl = await fetchBlob(absUrl);
        result = result.split(m[0]).join('url("' + _blobUrl + '")');
      }
    } catch { try { result = result.split(m[0]).join('url("' + absUrl + '")'); } catch {} }
  }
  return result;
}
const cssPropList = ['background', 'backgroundImage', 'listStyleImage', 'borderImage', 'maskImage', 'content', 'cursor'];
const styleProto = CSSStyleDeclaration.prototype;
cssPropList.forEach(prop => { const desc = Object.getOwnPropertyDescriptor(styleProto, prop); if (!desc?.set) return; Object.defineProperty(styleProto, prop, { get: desc.get, set(val) { if (val && typeof val === 'string' && val.includes('url(')) rewriteCss(val, BASE).then(r => desc.set.call(this, r)).catch(() => desc.set.call(this, val)); else desc.set.call(this, val); }, configurable: true }); });
const cssTextDesc = Object.getOwnPropertyDescriptor(styleProto, 'cssText');
if (cssTextDesc?.set) { Object.defineProperty(styleProto, 'cssText', { get: cssTextDesc.get, set(val) { if (val && val.includes('url(')) rewriteCss(val, BASE).then(r => cssTextDesc.set.call(this, r)).catch(() => cssTextDesc.set.call(this, val)); else cssTextDesc.set.call(this, val); }, configurable: true }); }

const origAppend = Node.prototype.appendChild;
const origInsert = Node.prototype.insertBefore;

const origSetAttr = Element.prototype.setAttribute;
Element.prototype.setAttribute = function(name, value) { const tag = this.tagName; if (tag === 'LINK' && name === 'href' && (this.rel || '').includes('stylesheet')) { if (value && !/^(data:|blob:)/i.test(value)) { const url = resolve(value); if (shouldSkip(url)) return; const link = this; req(url).then(async r => { const bin = atob(r.d || ''); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); let css = new TextDecoder().decode(arr); css = await rewriteCss(css, url); const style = document.createElement('style'); style.textContent = css; if (link.parentNode) link.parentNode.replaceChild(style, link); }).catch(() => origSetAttr.call(this, name, value)); return; } } if ((tag === 'IMG' || tag === 'VIDEO' || tag === 'AUDIO' || tag === 'SOURCE') && (name === 'src' || name === 'poster')) { if (value && !/^(data:|blob:)/i.test(value)) { this[name] = value; return; } } return origSetAttr.call(this, name, value); };

const processedEls = new WeakMap(); // url -> true, so we re-process if src changed
function processEl(el) {
  if (!el.tagName) return;
  const tag = el.tagName;
  const isMedia = tag === 'IMG' || tag === 'VIDEO' || tag === 'AUDIO' || tag === 'SOURCE';
  const currentSrc = isMedia ? (el.getAttribute('src') || '') : '';
  const lastSrc = processedEls.get(el) || '';
  if (lastSrc === currentSrc && processedEls.has(el)) return;
  processedEls.set(el, currentSrc);
  if (tag === 'IMG' || tag === 'VIDEO' || tag === 'AUDIO' || tag === 'SOURCE') {
    const src = el.getAttribute('src');
    if (src && !/^(data:|blob:)/i.test(src) && !el.getAttribute('data-real-src')) el.src = src;
    
    const lazySrc = el.getAttribute('data-src') || el.getAttribute('data-lazy') || el.getAttribute('data-original') || el.getAttribute('data-lazy-src');
    if (lazySrc && !/^(data:|blob:)/i.test(lazySrc) && !el.getAttribute('data-real-src')) {
      el.src = lazySrc;
      el.removeAttribute('data-src');
      el.removeAttribute('data-lazy');
      el.removeAttribute('data-original');
      el.removeAttribute('data-lazy-src');
    }
    const srcset = el.getAttribute('srcset');
    if (srcset && !/blob:/.test(srcset)) el.srcset = srcset;
    if (tag === 'VIDEO') {
      const poster = el.getAttribute('poster');
      if (poster && !/^(data:|blob:)/i.test(poster) && !el.getAttribute('data-real-poster')) el.poster = poster;
    }
  }
  // Defuse anchor hrefs: store real URL in data-gust-href, set href to javascript:void(0)
  // so the browser can NEVER navigate the iframe natively via a link click.
  if (tag === 'A') {
    const href = el.getAttribute('href');
    if (href && !/^(javascript:|#|data:|blob:|mailto:|tel:)/i.test(href)) {
      try {
        const abs = resolve(href);
        el.setAttribute('data-gust-href', abs);
        el.setAttribute('href', 'javascript:void(0)');
      } catch {}
    }
    const tgt = (el.getAttribute('target') || '').toLowerCase();
    if (tgt && tgt !== '_self') el.setAttribute('target', '_self');
  }
  if (el.getAttribute('loading') === 'lazy') el.setAttribute('loading', 'eager');
  const style = el.getAttribute('style');
  if (style && style.includes('url(') && !/blob:/.test(style)) rewriteCss(style, BASE).then(r => el.setAttribute('style', r)).catch(() => {});
}
const observer = new MutationObserver(muts => {
  for (const mut of muts) {
    if (mut.type === 'childList') {
      for (const node of mut.addedNodes) {
        if (node.nodeType !== 1) continue;
        processEl(node);
        node.querySelectorAll?.('*').forEach(processEl);
      }
    }
  }
});
observer.observe(document, { childList: true, subtree: true });

// Pre-defuse all existing anchors on initial load.
// Store real URL in data-gust-href, set href=javascript:void(0) so the
// browser can never navigate the iframe natively from a link click.
document.querySelectorAll('a[href], area[href]').forEach(a => {
  const href = a.getAttribute('href');
  if (href && !/^(javascript:|#|data:|blob:|mailto:|tel:)/i.test(href)) {
    try {
      const abs = resolve(href);
      a.setAttribute('data-gust-href', abs);
      a.setAttribute('href', 'javascript:void(0)');
    } catch {}
  }
  const tgt = (a.getAttribute('target') || '').toLowerCase();
  if (tgt && tgt !== '_self') a.setAttribute('target', '_self');
});
document.querySelectorAll('*').forEach(processEl);

const fakeLoc = new URL(BASE);
const locProxy = new Proxy({}, { get(_, p) { if (p === 'href') return fakeLoc.href; if (p === 'origin') return fakeLoc.origin; if (p === 'protocol') return fakeLoc.protocol; if (p === 'host') return fakeLoc.host; if (p === 'hostname') return fakeLoc.hostname; if (p === 'port') return fakeLoc.port; if (p === 'pathname') return fakeLoc.pathname; if (p === 'search') return fakeLoc.search; if (p === 'hash') return fakeLoc.hash; if (p === 'assign' || p === 'replace') return u => { try { const _r=resolve(u); const du=new URL(_r); const bu=new URL(BASE); if(du.origin===bu.origin&&du.pathname===bu.pathname&&du.search===bu.search) return; parent.postMessage({t:'n',u:_r},'*'); } catch { parent.postMessage({t:'n',u:resolve(u)},'*'); } }; if (p === 'reload') return () => parent.postMessage({ t: 'rl' }, '*'); if (p === 'toString' || p === Symbol.toPrimitive) return () => fakeLoc.href; if (p === 'ancestorOrigins') return { length: 0 }; }, set(_, p, v) { if (p === 'href') { if (!v || /^about:/i.test(v) || /^javascript:/i.test(v)) return true; try { const _r=resolve(v); const du=new URL(_r); const bu=new URL(BASE); if(du.origin===bu.origin&&du.pathname===bu.pathname&&du.search===bu.search) return true; parent.postMessage({t:'n',u:_r},'*'); return true; } catch {} parent.postMessage({ t: 'n', u: resolve(v) }, '*'); return true; } if (p === 'hash') { fakeLoc.hash = v; window.dispatchEvent(new HashChangeEvent('hashchange')); return true; } if (p === 'search') { parent.postMessage({ t: 'n', u: fakeLoc.origin + fakeLoc.pathname + v + fakeLoc.hash }, '*'); return true; } return true; } });
try { Object.defineProperty(window, 'location', { value: locProxy }); } catch {}
// Fix 3a: Override document.location — this IS configurable on all major browsers.
try { Object.defineProperty(document, 'location', { get: () => locProxy, set(v) { if (v && typeof v === 'string') parent.postMessage({ t: 'n', u: resolve(v) }, '*'); }, configurable: true }); } catch {}
try {
  const locObj = window.location;
  const locProto = Object.getPrototypeOf(locObj);
  const setHref = v => { if (!v || /^about:/i.test(v) || /^javascript:/i.test(v)) return; parent.postMessage({ t: 'n', u: resolve(v) }, '*'); };
  const setHash = v => { fakeLoc.hash = v; window.dispatchEvent(new HashChangeEvent('hashchange')); };
  const setSearch = v => { parent.postMessage({ t: 'n', u: fakeLoc.origin + fakeLoc.pathname + v + fakeLoc.hash }, '*'); };
  const defineLoc = (target, prop, get, set) => { try { Object.defineProperty(target, prop, { get, set, configurable: true }); } catch {} };
  ['href','origin','protocol','host','hostname','port','pathname','search','hash'].forEach(p => {
    const get = () => fakeLoc[p];
    const set = p === 'href' ? setHref : p === 'hash' ? setHash : p === 'search' ? setSearch : () => {};
    defineLoc(locObj, p, get, set);
    defineLoc(locProto, p, get, set);
  });
  defineLoc(locObj, 'assign', () => u => setHref(u), null);
  defineLoc(locProto, 'assign', () => u => setHref(u), null);
  defineLoc(locObj, 'replace', () => u => setHref(u), null);
  defineLoc(locProto, 'replace', () => u => setHref(u), null);
  defineLoc(locObj, 'reload', () => () => parent.postMessage({ t: 'rl' }, '*'), null);
  defineLoc(locProto, 'reload', () => () => parent.postMessage({ t: 'rl' }, '*'), null);
  try { Object.defineProperty(locProto, 'toString', { value: () => fakeLoc.href, configurable: true }); } catch {}
  try { Object.defineProperty(locObj, 'toString', { value: () => fakeLoc.href, configurable: true }); } catch {}
} catch {}
// Fix 3b: Patch Location.prototype.assign and Location.prototype.replace directly.
// These are the methods called when site JS does: location.assign(url) or location.replace(url).
// Because window.location itself may be non-configurable in some browser contexts, patching
// the prototype methods is the most reliable interception layer without an AST rewriter.
try {
  Object.defineProperty(Location.prototype, 'assign', {
    value: function(url) { parent.postMessage({ t: 'n', u: resolve(String(url)) }, '*'); },
    writable: true, configurable: true
  });
} catch {}
try {
  Object.defineProperty(Location.prototype, 'replace', {
    value: function(url) { parent.postMessage({ t: 'n', u: resolve(String(url)) }, '*'); },
    writable: true, configurable: true
  });
} catch {}
try { Object.defineProperty(document, 'URL', { get: () => BASE }); } catch {}
try { Object.defineProperty(document, 'documentURI', { get: () => BASE }); } catch {}
try { Object.defineProperty(document, 'baseURI', { get: () => BASE }); } catch {}
try { Object.defineProperty(document, 'domain', { value: fakeLoc.hostname, writable: true }); } catch {}
try { Object.defineProperty(document, 'referrer', { get: () => '' }); } catch {}
try { Object.defineProperty(window, 'origin', { get: () => ORIGIN }); } catch {}
try { Object.defineProperty(Location.prototype, 'origin', { get: () => ORIGIN, configurable: true }); } catch {}

if (!crypto.randomUUID) {
  crypto.randomUUID = function() {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    buf[6] = (buf[6] & 0x0f) | 0x40;
    buf[8] = (buf[8] & 0x3f) | 0x80;
    const hex = [...buf].map(b => b.toString(16).padStart(2, '0'));
    return hex.slice(0, 4).join('') + "-" +
      hex.slice(4, 6).join('') + "-" +
      hex.slice(6, 8).join('') + "-" +
      hex.slice(8, 10).join('') + "-" +
      hex.slice(10, 16).join('');
  };
}

window.__gustImportScripts = function(...urls) {
  
  urls.forEach(u => {
    try {
      const absUrl = resolve(u);
      const xhr = new XMLHttpRequest();
      xhr.open('GET', absUrl, false); 
      xhr.send();
      if (xhr.status >= 200 && xhr.status < 400) {
        new Function(xhr.responseText)();
      }
    } catch(e) {}
  });
};


document.addEventListener('mousedown', e => {
  const a = e.target?.closest?.('a, area');
  if (!a) return;
  // Read the real URL from data-gust-href (set by defuse sweep) or fall back to href.
  const href = a.getAttribute('data-gust-href') || a.getAttribute('href');
  if (!href || /^(javascript:|#|data:|blob:|mailto:|tel:)/i.test(href)) return;
  try {
    const abs = resolve(href);
    a._gustHref = abs;
    parent.postMessage({ t: 'hint', u: abs }, '*');
  } catch {}
}, true);
document.addEventListener('click', e => {
  const a = e.target?.closest?.('a, area');
  if (!a) return;
  const href = a._gustHref || a.getAttribute('data-gust-href') || a.getAttribute('href');
  if (!href) return;
  if (href.startsWith('#')) {
    const id = href.slice(1);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView();
    fakeLoc.hash = href;
    window.dispatchEvent(new HashChangeEvent('hashchange'));
    e.preventDefault();
    return;
  }
  // Skip non-navigatable schemes (javascript:void(0) with no data-gust-href).
  if (/^(javascript:|mailto:|tel:|data:|blob:)/i.test(href)) { return; }
  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();
  parent.postMessage({ t: 'n', u: resolve(href) }, '*');
}, true);
document.addEventListener('auxclick', e => { if (e.button !== 1) return; const a = e.target?.closest?.('a, area'); if (!a) return; const href = a._gustHref || a.getAttribute('data-gust-href') || a.getAttribute('href'); if (!href || /^(javascript:|#)/i.test(href)) return; e.preventDefault(); e.stopPropagation(); parent.postMessage({ t: 'n', u: resolve(href) }, '*'); }, true);
document.addEventListener('submit', e => { const form = e.target; if (!form || form.tagName !== 'FORM') return; e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); const action = resolve(form.action || BASE); const method = (form.method || 'GET').toUpperCase(); const fd = new FormData(form); if (method === 'GET') { parent.postMessage({ t: 'n', u: action.split('?')[0] + '?' + new URLSearchParams(fd).toString() }, '*'); } else { parent.postMessage({ t: 'n', u: action, m: 'POST', b: new URLSearchParams(fd).toString() }, '*'); } }, true);

const _open = window.open;
window.open = function(url, target, features) { if (!url || url === 'about:blank') return null; const resolved = resolve(url); parent.postMessage({ t: 'n', u: resolved }, '*'); return { closed: false, close: () => {}, focus: () => {}, blur: () => {}, postMessage: () => {}, location: { href: resolved }, document: { write: () => {}, close: () => {} } }; };

// Intercept the Navigation API (window.navigation) — used by Chromium-based SPAs
// like Brave Search to navigate without touching location or firing a click event.
// Without this, result-link clicks bypass every other intercept and navigate natively.
try {
  if (window.navigation) {
    window.navigation.addEventListener('navigate', e => {
      const dest = e.destination?.url;
      if (!dest || /^(about:|blob:|javascript:)/i.test(dest)) return;
      // Only intercept real forward navigations (link clicks, programmatic navigate()).
      // 'replace' and 'reload' are used by SPAs for state management — intercepting
      // them causes pages like YouTube to reload mid-initialization.
      const navType = e.navigationType;
      if (navType === 'replace' || navType === 'reload' || navType === 'traverse') return;
      // Don't intercept navigations to the same origin+path (e.g. YouTube adding
      // query params via pushState after our check fires).
      try {
        const du = new URL(dest); const bu = new URL(BASE);
        if (du.origin === bu.origin && du.pathname === bu.pathname) return;
      } catch { if (dest === BASE) return; }
      // Send the navigation message FIRST so the parent can route it even
      // if the interception attempt below throws or fails.
      parent.postMessage({ t: 'n', u: resolve(dest) }, '*');
      // Then try to prevent the native navigation.
      try {
        if (e.canIntercept) {
          e.intercept({ handler: () => Promise.resolve() });
        } else {
          try { e.preventDefault(); } catch(_) {}
        }
      } catch(_interceptErr) {
        try { e.preventDefault(); } catch(_) {}
      }
    });
  }
} catch (_navApiErr) {}

// Intercept anchor .target so links never escape the proxy iframe
const anchorTargetDesc = Object.getOwnPropertyDescriptor(HTMLAnchorElement.prototype, 'target');
if (anchorTargetDesc) { Object.defineProperty(HTMLAnchorElement.prototype, 'target', { get() { return '_self'; }, set(v) {}, configurable: true }); }
const formTargetDesc = Object.getOwnPropertyDescriptor(HTMLFormElement.prototype, 'target');
if (formTargetDesc) { Object.defineProperty(HTMLFormElement.prototype, 'target', { get() { return ''; }, set(v) {}, configurable: true }); }

// Intercept anchor .href property assignments (el.href = '...').
// MutationObserver only fires for setAttribute() — direct property sets bypass it.
// This catches dynamically-built result links (Brave, Google, etc.) that set
// href as a JS property rather than an HTML attribute.
const anchorHrefDesc = Object.getOwnPropertyDescriptor(HTMLAnchorElement.prototype, 'href');
if (anchorHrefDesc && anchorHrefDesc.set) {
  Object.defineProperty(HTMLAnchorElement.prototype, 'href', {
    // Return data-gust-href (the real URL) if present, so site JS that reads
    // el.href after setting it still gets the correct absolute URL.
    get() { return this.getAttribute('data-gust-href') || anchorHrefDesc.get.call(this); },
    set(v) {
      // Let the browser normalise the value first (resolves relative paths)
      anchorHrefDesc.set.call(this, v);
      const normalised = anchorHrefDesc.get.call(this);
      if (normalised && !/^(javascript:|#|data:|blob:|mailto:|tel:)/i.test(normalised)) {
        try {
          const abs = resolve(normalised);
          this.setAttribute('data-gust-href', abs);
          anchorHrefDesc.set.call(this, 'javascript:void(0)');
        } catch {}
      }
    },
    configurable: true
  });
}

// Deferred sweep: defuse anchor hrefs on JS-rendered/SPA pages.
const _rewriteAnchors = () => {
  document.querySelectorAll('a, area').forEach(a => {
    const href = a.getAttribute('href');
    if (href && !/^(javascript:|#|data:|blob:|mailto:|tel:)/i.test(href)) {
      try {
        const abs = resolve(href);
        a.setAttribute('data-gust-href', abs);
        a.setAttribute('href', 'javascript:void(0)');
      } catch {}
    }
    // Also pick up anchors that only have data-gust-href but lost href somehow
    const tgt = (a.getAttribute('target') || '').toLowerCase();
    if (tgt && tgt !== '_self') a.setAttribute('target', '_self');
  });
};
setTimeout(_rewriteAnchors, 300);
setTimeout(_rewriteAnchors, 1500);

// Fix 2: Intercept programmatic form.submit() calls (not caught by the 'submit' event listener).
// We override the prototype method so that any site JS calling form.submit() is routed
// through the proxy instead of causing a native top-level / iframe navigation.
const _nativeFormSubmit = HTMLFormElement.prototype.submit;
HTMLFormElement.prototype.submit = function() {
  try {
    const form = this;
    const action = resolve(form.getAttribute('action') || BASE);
    const method = (form.getAttribute('method') || 'GET').toUpperCase();
    const fd = new FormData(form);
    if (method === 'POST') {
      parent.postMessage({ t: 'n', u: action, m: 'POST', b: new URLSearchParams(fd).toString() }, '*');
    } else {
      const qs = new URLSearchParams(fd).toString();
      parent.postMessage({ t: 'n', u: action.split('?')[0] + (qs ? '?' + qs : '') }, '*');
    }
  } catch(e) {
    // Fallback: if serialisation fails for any reason, attempt native submit
    // (will likely be blocked by XFO/CSP, but better than a silent failure)
    try { _nativeFormSubmit.call(this); } catch {}
  }
};

const origPush = history.pushState;
const origReplace = history.replaceState;
history.pushState = function(s, t, u) { if (u) { try { Object.assign(fakeLoc, new URL(resolve(u))); } catch {} parent.postMessage({ t: 'uc', u: fakeLoc.href }, '*'); } return origPush.call(this, s, t, null); };
history.replaceState = function(s, t, u) { if (u) { try { Object.assign(fakeLoc, new URL(resolve(u))); } catch {} parent.postMessage({ t: 'uc', u: fakeLoc.href }, '*'); } return origReplace.call(this, s, t, null); };

const OrigWorker = window.Worker;
if (OrigWorker) { window.Worker = function(url, opts) { const absUrl = resolve(url); const w = { onmessage: null, onerror: null, postMessage: () => {}, terminate: () => {}, addEventListener: () => {}, removeEventListener: () => {} }; const p = /^(data:|blob:)/i.test(absUrl) ? _fetch.call(window, absUrl).then(r => r.arrayBuffer()).then(buf => { const arr = new Uint8Array(buf); let bin = ""; for(let i=0; i<arr.length; i++) bin+=String.fromCharCode(arr[i]); return { d: btoa(bin) }; }) : req(absUrl); p.then(r => { const bin = atob(r.d || ''); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); const blob = new Blob([arr], { type: 'application/javascript' }); const real = new OrigWorker(URL.createObjectURL(blob), opts); w.postMessage = m => real.postMessage(m); w.terminate = () => real.terminate(); w.addEventListener = (t, fn) => real.addEventListener(t, fn); w.removeEventListener = (t, fn) => real.removeEventListener(t, fn); real.onmessage = e => w.onmessage?.(e); real.onerror = e => w.onerror?.(e); }).catch(e => w.onerror?.(new ErrorEvent('error', { message: e.message }))); return w; }; }

// SharedWorker shim — proxy the script through Gust then run as a plain Worker
// (SharedWorkers can't share state across tabs in a single-iframe proxy, but at least
// the script loads and executes instead of failing with a cross-origin error)
const OrigSharedWorker = window.SharedWorker;
if (OrigSharedWorker) {
  window.SharedWorker = function(url, opts) {
    const absUrl = resolve(url);
    // Build a minimal MessagePort-like interface backed by a regular Worker
    const portHandlers = { message: [], messageerror: [] };
    const sw = {
      port: {
        onmessage: null,
        onmessageerror: null,
        postMessage: () => {},
        start: () => {},
        close: () => {},
        addEventListener(t, fn) { (portHandlers[t] = portHandlers[t] || []).push(fn); },
        removeEventListener(t, fn) { portHandlers[t] = (portHandlers[t]||[]).filter(f=>f!==fn); },
      },
      onerror: null,
      addEventListener: () => {},
      removeEventListener: () => {},
    };
    const p = /^(data:|blob:)/i.test(absUrl)
      ? _fetch.call(window, absUrl).then(r => r.arrayBuffer()).then(buf => {
          const arr = new Uint8Array(buf); let bin = '';
          for (let i = 0; i < arr.length; i++) bin += String.fromCharCode(arr[i]);
          return { d: btoa(bin) };
        })
      : req(absUrl);
    p.then(r => {
      const bin = atob(r.d || '');
      const arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      const blob = new Blob([arr], { type: 'application/javascript' });
      const real = new OrigWorker(URL.createObjectURL(blob), { name: (typeof opts === 'string' ? opts : opts?.name) || '' });
      sw.port.postMessage = m => real.postMessage(m);
      sw.port.close = () => real.terminate();
      real.onmessage = e => {
        if (sw.port.onmessage) sw.port.onmessage(e);
        (portHandlers.message || []).forEach(fn => fn(e));
      };
      real.onerror = e => { if (sw.onerror) sw.onerror(e); };
    }).catch(e => { if (sw.onerror) sw.onerror(new ErrorEvent('error', { message: e.message })); });
    return sw;
  };
}

// WebRTC leak prevention — stub out RTCPeerConnection and getUserMedia
// so sites can't establish direct connections that bypass the WISP tunnel
if (WEBRTC_BLOCK) {
  const _noRTC = function() { throw new DOMException('WebRTC is blocked by Gust', 'NotSupportedError'); };
  try { window.RTCPeerConnection = _noRTC; } catch(e) {}
  try { window.webkitRTCPeerConnection = _noRTC; } catch(e) {}
  try { window.mozRTCPeerConnection = _noRTC; } catch(e) {}
  try { window.RTCDataChannel = _noRTC; } catch(e) {}
  try {
    if (navigator.mediaDevices) {
      navigator.mediaDevices.getUserMedia = () => Promise.reject(new DOMException('WebRTC is blocked by Gust', 'NotSupportedError'));
    }
    navigator.getUserMedia = _noRTC;
    navigator.webkitGetUserMedia = _noRTC;
    navigator.mozGetUserMedia = _noRTC;
  } catch(e) {}
}

['log', 'warn', 'error', 'info', 'debug'].forEach(m => { const orig = console[m]; console[m] = function(...args) { orig.apply(console, args); try { parent.postMessage({ t: 'c', m, a: args.slice(0, 3).map(a => { try { return typeof a === 'object' ? JSON.stringify(a).slice(0, 200) : String(a).slice(0, 200); } catch { return '[Object]'; } }) }, '*'); } catch {} }; });
window.addEventListener('error', e => parent.postMessage({ t: 'c', m: 'error', a: ['[Error] ' + (e.message || '')] }, '*'));
window.addEventListener('unhandledrejection', e => parent.postMessage({ t: 'c', m: 'error', a: ['[Promise] ' + (e.reason?.message || e.reason || '')] }, '*'));

try {
  const _sendBeacon = navigator.sendBeacon?.bind(navigator);
  navigator.sendBeacon = function(url, data) {
    const absUrl = resolve(url);
    if (shouldSkip(absUrl)) return true;
    req(absUrl, { method: 'POST', body: data instanceof FormData ? new URLSearchParams(data).toString() : (typeof data === 'string' ? data : '') }).catch(() => {});
    return true;
  };
} catch(e) {}

document.addEventListener('contextmenu', e => {
  e.preventDefault();
  parent.postMessage({ t: 'ctx', x: e.clientX, y: e.clientY }, '*');
}, true);

try {
  const _navProto = Object.getPrototypeOf(navigator);
  [
    ['userAgent', SPOOF_UA],
    ['appVersion', SPOOF_UA.replace(/^Mozilla\\//, '')],
    ['platform', 'Win32'],
    ['vendor', 'Google Inc.'],
    ['product', 'Gecko'],
    ['appName', 'Netscape'],
    ['appCodeName', 'Mozilla'],
  ].forEach(([prop, val]) => {
    try { Object.defineProperty(navigator, prop, { get: () => val, configurable: true }); } catch {}
    try { Object.defineProperty(_navProto, prop, { get: () => val, configurable: true }); } catch {}
  });
} catch(e) {}

try { document.querySelectorAll('input, textarea').forEach(el => el.spellcheck = SPELLCHECK); } catch(e) {}

parent.postMessage({ t: 'ready' }, '*');
})();`;
  }

  window.addEventListener("message", async (ev) => {
    const d = ev.data;
    if (!d?.t) return;

    if (d.t === "hint") {
      if (d.u && typeof d.u === "string") _pendingNavHint = d.u;
      return;
    }
    if (d.t === "ctx") {
      const rect = frame.getBoundingClientRect();
      const x = rect.left + d.x;
      const y = rect.top + d.y;
      openContextMenu(x, y);
      return;
    }

    if (d.t === "q") {
      const { i, url, opts } = d;
      const priority =
        opts?.method === "POST"
          ? PRIORITY.html
          : getPriority(url, opts?.headers?.["Accept"]);
      const msgTabId = activeTabId;
      if (closedTabIds.has(msgTabId)) return;
      const msgSignal =
        tabAbortControllers.get(msgTabId)?.signal || abortCtrl?.signal;
      try {
        const r = await queueFetch(
          url,
          {
            method: opts?.method,
            headers: opts?.headers,
            body: opts?.body,
            signal: msgSignal,
          },
          priority,
        );
        if (r.skipped) {
          frame.contentWindow?.postMessage(
            {
              t: "r",
              i,
              s: 200,
              h: {},
              m: "text/plain",
              d: "",
            },
            "*",
          );
          return;
        }
        const b64 = toB64(r.buf);
        if (r.fromCache)
          log(
            `<i class="fas fa-bolt" style="color: #22d3ee;"></i> ${url.slice(0, 45)} (${(r.buf.byteLength / 1024).toFixed(0)}K cache)`,
            "cache",
          );
        else
          log(
            `<i class="fas fa-check" style="color:var(--ok)"></i>${url.slice(0, 45)} (${(r.buf.byteLength / 1024).toFixed(0)}K)`,
            "ok",
          );
        // Clone buf for transfer — buf may be referenced by cache so we send a copy
        const transferBuf = r.buf.slice(0);
        frame.contentWindow?.postMessage(
          {
            t: "r",
            i,
            s: r.status,
            h: r.headers,
            m: r.mime,
            d: b64,
          },
          "*",
        );
      } catch (e) {
        if (e.name === "AbortError") return;
        log(
          `<i class="fas fa-xmark" style="color:var(--err)"></i>${url.slice(0, 45)} - ${e.message}`,
          "err",
        );
        frame.contentWindow?.postMessage(
          {
            t: "r",
            i,
            e: e.message,
          },
          "*",
        );
      }
      return;
    }
    if (d.t === "sse") {
      handleSSE(
        d.i,
        d.url,
        d.headers,
        tabAbortControllers.get(activeTabId)?.signal || abortCtrl?.signal,
      );
      return;
    }
    if (d.t === "stream") {
      handleStreamFetch(
        d.i,
        d.url,
        d.opts,
        tabAbortControllers.get(activeTabId)?.signal || abortCtrl?.signal,
      );
      return;
    }
    if (d.t === "ws") {
      if (d.a === "open") handleWsOpen(d.i, d.url, d.protocols);
      else if (d.a === "send") handleWsSend(d.i, d.d, d.b64);
      else if (d.a === "close") handleWsClose(d.i, d.code, d.reason);
      return;
    }
    if (d.t === "cookieSet") {
      const origin = d.origin || (pageUrl ? new URL(pageUrl).origin : "");
      if (origin && d.cookie) {
        updateCookie(origin, d.cookie);
        syncCookiesToFrame(origin);
      }
      return;
    }
    if (d.t === "n") {
      _pendingNavHint = null;
      // Guard: don't full-reload for same-origin/same-path navigations
      // (YouTube SPA calls location.assign/replace with its own URL or adds
      // query params via pushState — these must not trigger a new go()).
      if (!d.m && !d.b && d.u) {
        try {
          const _du = new URL(normUrl(d.u));
          const _pu = new URL(pageUrl || "");
          // Compare origin + pathname only — ignore search/hash differences
          // which SPAs update without intending a real navigation.
          if (_du.origin === _pu.origin && _du.pathname === _pu.pathname) {
            log("[nav] same-page nav ignored: " + d.u.slice(0, 60), "info");
            return;
          }
        } catch {}
      }
      // Immediately refresh the URL bar, pageUrl, and tab.url — always,
      // even if the URL appears unchanged, so any stale state from a
      // prior intercept (Navigation API + click double-post) gets
      // normalised before the async go() fetch completes.
      if (d.u) {
        const cleaned = normUrl(d.u);
        if (cleaned && !cleaned.startsWith("gust://")) {
          urlInput.value = cleaned;
          pageUrl = cleaned;
          const navTab = getActiveTab();
          if (navTab) navTab.url = cleaned;
          try {
            updateSecurityChip(cleaned);
          } catch {}
          try {
            updateBookmarkButton();
          } catch {}
        }
      }
      go(d.u, true, d.m, d.b);
      return;
    }
    if (d.t === "rl") {
      // Throttle: ignore location.reload() calls within 15s of page load
      // to stop SPAs like YouTube from reloading mid-initialization.
      const _now = Date.now();
      if (
        !window._lastPageLoadTime ||
        _now - window._lastPageLoadTime > 15000
      ) {
        log("[nav] location.reload() → reloading", "info");
        if (pageUrl) go(pageUrl, false);
      } else {
        log(
          "[nav] location.reload() suppressed (too soon after page load)",
          "warn",
        );
      }
      return;
    }
    if (d.t === "uc") {
      // Validate: only accept real http(s) URLs pushed via history API.
      // Reject about:/blob:/data:/javascript: or unparseable values to
      // prevent the omnibar from getting clobbered by a spurious
      // pushState from a proxied page during hydration.
      if (!d.u || typeof d.u !== "string") return;
      let parsed;
      try {
        parsed = new URL(d.u);
      } catch {
        return;
      }
      if (!/^https?:$/.test(parsed.protocol)) return;
      urlInput.value = d.u;
      pageUrl = d.u;
      const navTab = getActiveTab();
      if (navTab) navTab.url = d.u;
      if (!isErrorPage) updateSecurityChip(d.u);
      try {
        const host = parsed.hostname.replace(/^www\./, "");
        setTabTitle(host || "Loading...");
      } catch {}
      updateBookmarkButton();
      return;
    }
    if (d.t === "ready") {
      window._lastPageLoadTime = Date.now();
      log("Page ready", "info");
      if (pageUrl) {
        try {
          syncCookiesToFrame(new URL(pageUrl).origin);
        } catch {}
      }
      return;
    }
    if (d.t === "fullscreen") {
      if (d.enter) document.documentElement.requestFullscreen?.();
      return;
    }
    if (d.t === "c") {
      const cls =
        {
          log: "",
          warn: "warn",
          error: "err",
          info: "info",
        }[d.m] || "";
      log("[Page] " + (d.a || []).join(" ").slice(0, 300), cls);
    }
    // ── Viewer download: triggered via postMessage from viewer pages ──
    if (d.t === "gust:download") {
      try {
        const a = document.createElement("a");
        a.href = d.data; // data: URI
        a.download = d.name || "download";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        log(
          '<i class="fas fa-download" style="color:var(--ok)"></i>Downloaded: ' +
            (d.name || "file"),
          "ok",
        );
      } catch (e) {
        log("Download failed: " + e.message, "err");
      }
      return;
    }
  }); // end window.addEventListener("message", ...)

  // ── Media pref helpers ─────────────────────────────────────────
  const _MEDIA_DEFAULTS = {
    "gust:media:pdf:v1": true,
    "gust:media:img:v1": true,
    "gust:media:video:v1": true,
    "gust:media:audio:v1": true,
    "gust:media:text:v1": true,
    "gust:media:download:v1": false,
    "gust:media:range:v1": true,
    "gust:media:headers:v1": true,
    "gust:webrtc:block:v1": false,
  };
  function mediaPref(key) {
    const saved = ls.getItem(key);
    if (saved !== null) return saved === "1";
    return _MEDIA_DEFAULTS[key] !== false;
  }

  // ── Detect file type from MIME + URL extension ─────────────────
  function classifyResponse(mime, url, buf) {
    const m = (mime || "").toLowerCase().split(";")[0].trim();
    const ext = (url || "").split("?")[0].split(".").pop().toLowerCase();
    if (m === "application/pdf" || ext === "pdf") return "pdf";
    if (
      m.startsWith("image/") ||
      /^(png|jpe?g|gif|webp|svg|bmp|ico|avif|tiff?)$/.test(ext)
    )
      return "image";
    if (m.startsWith("video/") || /^(mp4|webm|ogv|mov|avi|mkv|m4v)$/.test(ext))
      return "video";
    if (
      m.startsWith("audio/") ||
      /^(mp3|ogg|flac|wav|aac|m4a|opus|weba)$/.test(ext)
    )
      return "audio";
    // .html/.htm URLs always render as HTML regardless of reported content-type
    if (/^htm(l)?$/.test(ext)) return "html";
    // text/plain may actually be HTML — sniff the first 1KB before treating as plain text
    if (m === "text/plain" && buf) {
      const sniff = new TextDecoder("utf-8", { fatal: false })
        .decode(buf.byteLength > 1024 ? buf.slice(0, 1024) : buf)
        .trimStart();
      if (/^(<\s*!doctype\s+html|<\s*html[\s>])/i.test(sniff)) return "html";
    }
    if (
      m === "text/plain" ||
      m === "application/json" ||
      m === "application/xml" ||
      m === "text/xml" ||
      m === "text/csv" ||
      /^(txt|json|xml|csv|log|md|yaml|yml|ini|toml|sh|py|js|ts|css|c|cpp|h|java|rs|go|rb|php|swift|kt|dart)$/.test(
        ext,
      )
    )
      return "text";
    if (!m || m === "text/html" || m === "application/xhtml+xml") return "html";
    return "binary";
  }

  // ── Build viewer HTML pages ────────────────────────────────────
  function makePdfViewer(buf, filename, origUrl) {
    const arr = new Uint8Array(buf);
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < arr.length; i += CHUNK)
      bin += String.fromCharCode.apply(null, arr.subarray(i, i + CHUNK));
    const b64 = btoa(bin);
    const jB64 = JSON.stringify(b64);
    const jFilename = JSON.stringify(filename);

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>" +
      filename.replace(/</g, "&lt;") +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      _VIEWER_BASE_CSS +
      "#viewerWrap{flex:1;overflow-y:auto;overflow-x:auto;background:#252b33;display:flex;flex-direction:column;align-items:center;padding:16px;gap:10px}" +
      ".pdf-page-wrap{position:relative;box-shadow:0 4px 20px rgba(0,0,0,.6);line-height:0}" +
      ".pdf-page-lbl{font-size:10px;color:#7d8a98;padding:3px 0 2px;text-align:center;width:100%}" +
      "canvas{display:block;background:#fff}" +
      "#loading{position:fixed;inset:0;background:rgba(13,15,18,.95);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;z-index:999;font-size:14px;color:#9de5ff}" +
      ".spinner{width:36px;height:36px;border:3px solid #252b33;border-top-color:#9de5ff;border-radius:50%;animation:spin .7s linear infinite}" +
      "@keyframes spin{to{transform:rotate(360deg)}}" +
      "#err{display:none;position:fixed;inset:0;background:#0d0f12;align-items:center;justify-content:center;flex-direction:column;gap:12px;color:#ff9595;font-size:14px;z-index:1000}" +
      "</style></head><body>" +
      '<div id="loading"><div class="spinner"></div><span id="loadMsg">Loading PDF\u2026</span></div>' +
      '<div id="err"><i class="fas fa-triangle-exclamation" style="font-size:32px"></i><span id="errMsg">Failed to load PDF</span></div>' +
      '<div id="toolbar">' +
      '  <h1><i class="fas fa-file-pdf" style="color:#9de5ff"></i>' +
      filename.replace(/</g, "&lt;") +
      "</h1>" +
      '  <button class="tb-btn" id="btnFirst" onclick="goFirst()" title="First page"><i class="fas fa-backward-step"></i></button>' +
      '  <button class="tb-btn" id="btnPrev"  onclick="goPrev()"  title="Previous page"><i class="fas fa-chevron-left"></i></button>' +
      '  <span id="pageInfo">\u2014 / \u2014</span>' +
      '  <button class="tb-btn" id="btnNext"  onclick="goNext()"  title="Next page"><i class="fas fa-chevron-right"></i></button>' +
      '  <button class="tb-btn" id="btnLast"  onclick="goLast()"  title="Last page"><i class="fas fa-forward-step"></i></button>' +
      '  <div class="tb-sep"></div>' +
      '  <button class="tb-btn" onclick="zoomOut()"   title="Zoom out"><i class="fas fa-magnifying-glass-minus"></i></button>' +
      '  <span id="zoomInfo" onclick="zoomReset()" title="Reset zoom (click)">130%</span>' +
      '  <button class="tb-btn" onclick="zoomIn()"    title="Zoom in"><i class="fas fa-magnifying-glass-plus"></i></button>' +
      '  <button class="tb-btn" onclick="zoomReset()" title="Reset zoom"><i class="fas fa-magnifying-glass"></i></button>' +
      '  <button class="tb-btn" onclick="zoomFit()"   title="Fit to width"><i class="fas fa-expand"></i> Fit</button>' +
      '  <div class="tb-sep"></div>' +
      '  <button class="tb-btn" onclick="dlPdf()" title="Download PDF"><i class="fas fa-download"></i> Download</button>' +
      "</div>" +
      '<div id="viewerWrap"></div>' +
      '<script type="module">' +
      'import * as pdfjsLib from "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.min.mjs";' +
      'pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.2.67/pdf.worker.min.mjs";' +
      "const B64 = " +
      jB64 +
      ";" +
      "const FILENAME = " +
      jFilename +
      ";" +
      "function b64ToBytes(b){const bin=atob(b);const a=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)a[i]=bin.charCodeAt(i);return a;}" +
      'const vw=document.getElementById("viewerWrap");' +
      'const loadDiv=document.getElementById("loading");' +
      'const errDiv=document.getElementById("err");' +
      'const pageInfo=document.getElementById("pageInfo");' +
      'const zoomInfo=document.getElementById("zoomInfo");' +
      "let pdfDoc=null,curPage=1,scale=1.3;" +
      "async function init(){" +
      "  try{" +
      '    document.getElementById("loadMsg").textContent="Decoding PDF\u2026";' +
      "    const data=b64ToBytes(B64);" +
      '    document.getElementById("loadMsg").textContent="Rendering pages\u2026";' +
      "    pdfDoc=await pdfjsLib.getDocument({data}).promise;" +
      '    loadDiv.style.display="none";' +
      "    await renderAll();" +
      "  }catch(e){" +
      '    loadDiv.style.display="none";' +
      '    errDiv.style.display="flex";' +
      '    document.getElementById("errMsg").textContent="Error: "+e.message;' +
      "  }" +
      "}" +
      "async function renderAll(){" +
      '  vw.innerHTML="";' +
      "  for(let i=1;i<=pdfDoc.numPages;i++){" +
      "    const page=await pdfDoc.getPage(i);" +
      "    const vp=page.getViewport({scale});" +
      '    const wrap=document.createElement("div");wrap.className="pdf-page-wrap";' +
      '    const canvas=document.createElement("canvas");' +
      "    canvas.width=Math.floor(vp.width);canvas.height=Math.floor(vp.height);" +
      "    canvas.dataset.page=i;" +
      "    wrap.appendChild(canvas);vw.appendChild(wrap);" +
      '    await page.render({canvasContext:canvas.getContext("2d"),viewport:vp}).promise;' +
      "  }" +
      "  curPage=1;updateUI();" +
      "}" +
      "function updateUI(){" +
      '  pageInfo.textContent=curPage+" / "+(pdfDoc?pdfDoc.numPages:"\u2014");' +
      '  zoomInfo.textContent=Math.round(scale*100)+"%";' +
      '  document.getElementById("btnPrev").disabled=curPage<=1;' +
      '  document.getElementById("btnFirst").disabled=curPage<=1;' +
      '  document.getElementById("btnNext").disabled=!pdfDoc||curPage>=pdfDoc.numPages;' +
      '  document.getElementById("btnLast").disabled=!pdfDoc||curPage>=pdfDoc.numPages;' +
      "}" +
      "function scrollToPage(n){" +
      '  const canvas=vw.querySelector("canvas[data-page=\'"+n+"\']");' +
      '  if(canvas)canvas.closest(".pdf-page-wrap").scrollIntoView({behavior:"smooth",block:"start"});' +
      "  curPage=n;updateUI();" +
      "}" +
      "function goFirst(){scrollToPage(1);}" +
      "function goPrev(){if(curPage>1)scrollToPage(curPage-1);}" +
      "function goNext(){if(pdfDoc&&curPage<pdfDoc.numPages)scrollToPage(curPage+1);}" +
      "function goLast(){if(pdfDoc)scrollToPage(pdfDoc.numPages);}" +
      "function zoomIn(){scale=Math.min(scale*1.25,5);renderAll();}" +
      "function zoomOut(){scale=Math.max(scale/1.25,0.3);renderAll();}" +
      "function zoomReset(){scale=1.3;renderAll();}" +
      "function zoomFit(){" +
      "  const w=vw.clientWidth-32;" +
      "  if(!pdfDoc)return;" +
      "  pdfDoc.getPage(1).then(p=>{" +
      "    const vp=p.getViewport({scale:1});" +
      "    scale=Math.max(0.3,Math.min(w/vp.width,5));" +
      "    renderAll();" +
      "  });" +
      "}" +
      "function dlPdf(){" +
      "  try{" +
      "    const bytes=b64ToBytes(B64);" +
      '    var bin="";var chunk=32768;' +
      "    for(var i=0;i<bytes.length;i+=chunk)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+chunk));" +
      '    parent.postMessage({t:"gust:download",data:"data:application/pdf;base64,"+btoa(bin),name:FILENAME},"*");' +
      '  }catch(e){console.error("PDF download failed:",e);}' +
      "}" +
      "window.goFirst=goFirst;window.goPrev=goPrev;window.goNext=goNext;window.goLast=goLast;" +
      "window.zoomIn=zoomIn;window.zoomOut=zoomOut;window.zoomReset=zoomReset;window.zoomFit=zoomFit;" +
      "window.dlPdf=dlPdf;" +
      'vw.addEventListener("scroll",()=>{' +
      "  if(!pdfDoc)return;" +
      '  const canvases=vw.querySelectorAll("canvas[data-page]");' +
      "  const mid=vw.getBoundingClientRect().top+vw.clientHeight/2;" +
      "  let best=null,bestDist=Infinity;" +
      "  canvases.forEach(c=>{const r=c.getBoundingClientRect();const d=Math.abs(r.top+r.height/2-mid);if(d<bestDist){bestDist=d;best=c;}});" +
      "  if(best){const n=parseInt(best.dataset.page);if(n!==curPage){curPage=n;updateUI();}}" +
      "});" +
      'window.addEventListener("keydown",e=>{' +
      '  if(e.key==="ArrowRight"||e.key==="ArrowDown")goNext();' +
      '  else if(e.key==="ArrowLeft"||e.key==="ArrowUp")goPrev();' +
      '  else if(e.key==="Home")goFirst();' +
      '  else if(e.key==="End")goLast();' +
      '  else if(e.key==="+"||e.key==="=")zoomIn();' +
      '  else if(e.key==="-")zoomOut();' +
      '  else if(e.key==="0")zoomReset();' +
      "});" +
      "init();" +
      "<\/script>" +
      "</body></html>"
    );
  }

  // ── Shared toolbar CSS used by all viewers ─────────────────────
  const _VIEWER_BASE_CSS =
    "*{margin:0;padding:0;box-sizing:border-box}" +
    "html,body{height:100%;background:#0d0f12;font-family:'Space Grotesk','Segoe UI',sans-serif;color:#f0f4f8;display:flex;flex-direction:column;overflow:hidden}" +
    "#toolbar{display:flex;align-items:center;gap:6px;padding:0 12px;background:#181c21;border-bottom:1px solid #2e3540;flex-shrink:0;height:46px;flex-wrap:nowrap}" +
    "#toolbar h1{font-size:13px;font-weight:600;color:#9de5ff;flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:7px}" +
    ".tb-btn{background:#1c2026;border:1px solid #2e3540;color:#b8c4d0;border-radius:6px;height:32px;padding:0 11px;font-size:12px;cursor:pointer;white-space:nowrap;transition:background .12s,color .12s,border-color .12s;display:inline-flex;align-items:center;gap:5px;flex-shrink:0}" +
    ".tb-btn:hover{background:#252b33;color:#f0f4f8;border-color:#3a4250}" +
    ".tb-btn:disabled{opacity:.3;pointer-events:none}" +
    ".tb-btn.active{background:rgba(157,229,255,.12);border-color:rgba(157,229,255,.4);color:#9de5ff}" +
    ".tb-sep{width:1px;height:20px;background:#2e3540;flex-shrink:0;margin:0 2px}" +
    "#zoomInfo{font-size:12px;color:#7d8a98;white-space:nowrap;min-width:38px;text-align:center;cursor:pointer;padding:0 4px}" +
    "#zoomInfo:hover{color:#9de5ff}" +
    "#pageInfo{font-size:12px;color:#7d8a98;white-space:nowrap;min-width:72px;text-align:center}";

  // Download via parent shell so it reaches the real browser
  const _VIEWER_DL_JS =
    'function dl(data,name){parent.postMessage({t:"gust:download",data:data,name:name},"*");}';

  function makeImageViewer(buf, filename, mime) {
    const arr = new Uint8Array(buf);
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < arr.length; i += CHUNK)
      bin += String.fromCharCode.apply(null, arr.subarray(i, i + CHUNK));
    const dataUri = "data:" + (mime || "image/png") + ";base64," + btoa(bin);
    const jDataUri = JSON.stringify(dataUri);
    const jFilename = JSON.stringify(filename);
    const jMime = JSON.stringify(mime || "");

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>" +
      filename.replace(/</g, "&lt;") +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      _VIEWER_BASE_CSS +
      "#wrap{flex:1;display:flex;align-items:center;justify-content:center;overflow:hidden;cursor:grab;position:relative;user-select:none;background:#0d0f12}" +
      "#wrap.grabbing{cursor:grabbing}" +
      "#img{max-width:100%;max-height:100%;object-fit:contain;transform-origin:center center;will-change:transform;display:block}" +
      "#info{position:absolute;bottom:12px;left:50%;transform:translateX(-50%);background:rgba(13,15,18,.85);border:1px solid #252b33;border-radius:6px;padding:3px 12px;font-size:11px;color:#7d8a98;pointer-events:none;white-space:nowrap}" +
      "</style></head><body>" +
      '<div id="toolbar">' +
      '  <h1><i class="fas fa-image" style="color:#9de5ff"></i><span>' +
      filename.replace(/</g, "&lt;") +
      "</span></h1>" +
      '  <button class="tb-btn" onclick="zoomOut()" title="Zoom out"><i class="fas fa-magnifying-glass-minus"></i></button>' +
      '  <span id="zoomInfo" onclick="resetZoom()" title="Reset zoom (click)">100%</span>' +
      '  <button class="tb-btn" onclick="zoomIn()" title="Zoom in"><i class="fas fa-magnifying-glass-plus"></i></button>' +
      '  <button class="tb-btn" onclick="resetZoom()" title="Reset zoom"><i class="fas fa-magnifying-glass"></i></button>' +
      '  <button class="tb-btn" onclick="fitZoom()" title="Fit to window"><i class="fas fa-expand"></i> Fit</button>' +
      '  <div class="tb-sep"></div>' +
      '  <button class="tb-btn" onclick="dl(DATA,FILENAME)"><i class="fas fa-download"></i> Download</button>' +
      "</div>" +
      '<div id="wrap"><img id="img" draggable="false"><div id="info">Loading\u2026</div></div>' +
      "<script>" +
      _VIEWER_DL_JS +
      "const DATA=" +
      jDataUri +
      ";" +
      "const FILENAME=" +
      jFilename +
      ";" +
      "const MIME=" +
      jMime +
      ";" +
      'const img=document.getElementById("img");' +
      'const wrap=document.getElementById("wrap");' +
      'const info=document.getElementById("info");' +
      "let scale=1,ox=0,oy=0,dragging=false,sx=0,sy=0,sox=0,soy=0;" +
      "function showInfo(txt){info.textContent=txt;}" +
      'function apply(){img.style.transform="translate("+ox+"px,"+oy+"px) scale("+scale+")";document.getElementById("zoomInfo").textContent=Math.round(scale*100)+"%";}' +
      "function zoomIn(){scale=Math.min(scale*1.25,20);apply();}" +
      "function zoomOut(){scale=Math.max(scale/1.25,0.05);apply();}" +
      "function resetZoom(){scale=1;ox=0;oy=0;apply();}" +
      "function fitZoom(){scale=1;ox=0;oy=0;apply();}" +
      'img.addEventListener("load",function(){' +
      '  showInfo(img.naturalWidth+"\xd7"+img.naturalHeight+" \xb7 "+MIME);' +
      "});" +
      'img.addEventListener("error",function(){' +
      '  showInfo("Failed to load image");' +
      '  info.style.color="#ff9595";' +
      "});" +
      "img.src=DATA;" +
      'if(img.complete&&img.naturalWidth>0){showInfo(img.naturalWidth+"\xd7"+img.naturalHeight+" \xb7 "+MIME);}' +
      'wrap.addEventListener("wheel",e=>{e.preventDefault();const d=e.deltaY<0?1.15:1/1.15;scale=Math.min(Math.max(scale*d,0.05),20);apply();},{passive:false});' +
      'wrap.addEventListener("mousedown",e=>{dragging=true;sx=e.clientX;sy=e.clientY;sox=ox;soy=oy;wrap.classList.add("grabbing");});' +
      'window.addEventListener("mousemove",e=>{if(!dragging)return;ox=sox+(e.clientX-sx);oy=soy+(e.clientY-sy);apply();});' +
      'window.addEventListener("mouseup",()=>{dragging=false;wrap.classList.remove("grabbing");});' +
      "<\/script></body></html>"
    );
  }

  function makeVideoViewer(buf, filename, mime) {
    const arr = new Uint8Array(buf);
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < arr.length; i += CHUNK)
      bin += String.fromCharCode.apply(null, arr.subarray(i, i + CHUNK));
    const dataUri = "data:" + (mime || "video/mp4") + ";base64," + btoa(bin);
    const jDataUri = JSON.stringify(dataUri);
    const jFilename = JSON.stringify(filename);

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>" +
      filename.replace(/</g, "&lt;") +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      _VIEWER_BASE_CSS +
      "#vwrap{flex:1;display:flex;align-items:center;justify-content:center;background:#000;overflow:hidden}" +
      "video{max-width:100%;max-height:100%;outline:none}" +
      "</style></head><body>" +
      '<div id="toolbar">' +
      '  <h1><i class="fas fa-film" style="color:#9de5ff"></i>' +
      filename.replace(/</g, "&lt;") +
      "</h1>" +
      '  <button class="tb-btn" onclick="dl(DATA,FILENAME)"><i class="fas fa-download"></i> Download</button>' +
      "</div>" +
      '<div id="vwrap"><video id="vid" controls autoplay></video></div>' +
      "<script>" +
      _VIEWER_DL_JS +
      "const DATA=" +
      jDataUri +
      ";const FILENAME=" +
      jFilename +
      ";" +
      'document.getElementById("vid").src=DATA;' +
      "<\/script></body></html>"
    );
  }

  function makeAudioViewer(buf, filename, mime) {
    const arr = new Uint8Array(buf);
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < arr.length; i += CHUNK)
      bin += String.fromCharCode.apply(null, arr.subarray(i, i + CHUNK));
    const dataUri = "data:" + (mime || "audio/mpeg") + ";base64," + btoa(bin);
    const jDataUri = JSON.stringify(dataUri);
    const jFilename = JSON.stringify(filename);
    const jMime = JSON.stringify(mime || "");

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>" +
      filename.replace(/</g, "&lt;") +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      _VIEWER_BASE_CSS +
      "#content{flex:1;display:flex;align-items:center;justify-content:center;padding:32px 16px}" +
      ".player{background:#181c21;border:1px solid #2e3540;border-radius:12px;padding:24px 28px;display:flex;flex-direction:column;align-items:center;gap:14px;max-width:420px;width:100%}" +
      ".aud-icon{width:52px;height:52px;border-radius:10px;background:rgba(157,229,255,.08);border:1px solid rgba(157,229,255,.15);display:flex;align-items:center;justify-content:center;font-size:20px;color:#9de5ff;flex-shrink:0}" +
      ".aud-name{font-size:13px;font-weight:600;color:#f0f4f8;text-align:center;word-break:break-all;line-height:1.4;max-width:100%}" +
      ".aud-mime{font-size:11px;color:#3a4250;font-family:monospace}" +
      "audio{width:100%;accent-color:#9de5ff}" +
      "</style></head><body>" +
      '<div id="toolbar">' +
      '  <h1><i class="fas fa-music" style="color:#9de5ff"></i><span>' +
      filename.replace(/</g, "&lt;") +
      "</span></h1>" +
      '  <button class="tb-btn" onclick="dl(DATA,FILENAME)"><i class="fas fa-download"></i> Download</button>' +
      "</div>" +
      '<div id="content">' +
      '  <div class="player">' +
      '    <div class="aud-icon"><i class="fas fa-music"></i></div>' +
      '    <div class="aud-name">' +
      filename.replace(/</g, "&lt;") +
      "</div>" +
      '    <span class="aud-mime" id="mimeEl"></span>' +
      '    <audio id="aud" controls autoplay style="width:100%"></audio>' +
      "  </div>" +
      "</div>" +
      "<script>" +
      _VIEWER_DL_JS +
      "const DATA=" +
      jDataUri +
      ";const FILENAME=" +
      jFilename +
      ";const MIME=" +
      jMime +
      ";" +
      'document.getElementById("aud").src=DATA;' +
      'document.getElementById("mimeEl").textContent=MIME;' +
      "<\/script></body></html>"
    );
  }

  function makeTextViewer(text, filename, mime) {
    const ext = filename.split(".").pop().toLowerCase();
    const esc_fn = filename.replace(/</g, "&lt;");

    function buildScript() {
      const DL =
        'function dl(data,name){parent.postMessage({t:"gust:download",data:data,name:name},"*");}';
      const rawJ = JSON.stringify(text)
        .replace(/</g, "\\u003c")
        .replace(/>/g, "\\u003e");
      const fnameJ = JSON.stringify(filename)
        .replace(/</g, "\\u003c")
        .replace(/>/g, "\\u003e");
      const mimeJ = JSON.stringify(mime || "text/plain");
      const extJ = JSON.stringify(ext);
      return [
        DL,
        "var RAW=" + rawJ + ";",
        "var FILENAME=" + fnameJ + ";",
        "var MIME=" + mimeJ + ";",
        "var EXT=" + extJ + ";",
        'function esc(s){return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");}',
        "function highlight(raw,ext){",
        "  var s=esc(raw);",
        '  if(ext==="json"){',
        "    s=s.replace(/(\"(?:[^\"\\\\]|\\\\.)*\")(\\s*):/g,function(m,k,sp){return '<span class=\"kw\">'+k+'</span>'+sp+':';});",
        "    s=s.replace(/:(\\s*)(\"(?:[^\"\\\\]|\\\\.)*\")/g,function(m,sp,v){return ':'+sp+'<span class=\"str\">'+v+'</span>';});",
        "    s=s.replace(/:(\\s*)(-?\\d+\\.?\\d*(?:[eE][+-]?\\d+)?)/g,function(m,sp,v){return ':'+sp+'<span class=\"num\">'+v+'</span>';});",
        "    s=s.replace(/:(\\s*)(true|false|null)/g,function(m,sp,v){return ':'+sp+'<span class=\"lit\">'+v+'</span>';});",
        '  } else if(ext==="html"||ext==="htm"){',
        "    s=s.replace(/(&lt;\\/?[a-zA-Z][^&]*?&gt;)/g,function(m){return '<span class=\"kw\">'+m+'</span>';});",
        '  } else if(ext==="css"){',
        "    s=s.replace(/(\\/\\*[\\s\\S]*?\\*\\/)/g,function(m){return '<span class=\"cmt\">'+m+'</span>';});",
        "  }",
        "  return s;",
        "}",
        'function toggleWrap(){var p=document.getElementById("pre"),b=document.getElementById("wordwrapBtn"),on=p.style.whiteSpace==="pre-wrap";p.style.whiteSpace=on?"pre":"pre-wrap";b.classList.toggle("active",!on);}',
        'function copyAll(){if(navigator.clipboard){navigator.clipboard.writeText(RAW);}else{var t=document.createElement("textarea");t.value=RAW;document.body.appendChild(t);t.select();document.execCommand("copy");document.body.removeChild(t);}}',
        'function dlText(){var e=new TextEncoder(),b=e.encode(RAW),s="",c=32768;for(var i=0;i<b.length;i+=c)s+=String.fromCharCode.apply(null,b.subarray(i,i+c));dl("data:text/plain;base64,"+btoa(s),FILENAME);}',
        'document.getElementById("mimeEl").textContent=MIME;',
        'document.getElementById("pre").innerHTML=highlight(RAW,EXT);',
      ].join("\n");
    }

    const scriptSrc =
      "data:text/javascript;base64," +
      btoa(unescape(encodeURIComponent(buildScript())));

    return [
      '<!DOCTYPE html><html><head><meta charset="utf-8">',
      "<title>" + esc_fn + "</title>",
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">',
      "<style>",
      _VIEWER_BASE_CSS,
      "#codewrap{flex:1;overflow:auto}",
      'pre{padding:20px 24px;font-family:"JetBrains Mono","SF Mono",ui-monospace,monospace;font-size:13px;line-height:1.7;color:#b8c4d0;min-height:100%;tab-size:2;white-space:pre}',
      ".kw{color:#9de5ff}.str{color:#8aefb0}.num{color:#f8dc75}.lit{color:#ff9595}.cmt{color:#3a4250;font-style:italic}",
      "#wordwrapBtn.active{background:rgba(157,229,255,.12);border-color:rgba(157,229,255,.4);color:#9de5ff}",
      "</style></head><body>",
      '<div id="toolbar">',
      '  <h1><i class="fas fa-file-code" style="color:#9de5ff"></i><span>' +
        esc_fn +
        "</span></h1>",
      '  <span style="font-size:11px;color:#3a4250;font-family:monospace;margin-right:4px" id="mimeEl"></span>',
      '  <button class="tb-btn" id="wordwrapBtn" onclick="toggleWrap()"><i class="fas fa-align-left"></i> Wrap</button>',
      '  <button class="tb-btn" onclick="copyAll()"><i class="fas fa-copy"></i> Copy</button>',
      '  <button class="tb-btn" onclick="dlText()"><i class="fas fa-download"></i> Download</button>',
      "</div>",
      '<div id="codewrap"><pre id="pre"></pre></div>',
      '<script src="' + scriptSrc + '"></scr' + "ipt>",
      "</body></html>",
    ].join("");
  }

  function makeUnknownFilePage(filename, mime, byteLength, origUrl) {
    const size =
      byteLength > 1048576
        ? (byteLength / 1048576).toFixed(1) + " MB"
        : byteLength > 1024
          ? (byteLength / 1024).toFixed(1) + " KB"
          : byteLength + " B";
    const esc_fn = filename.replace(/</g, "&lt;");
    const esc_mime = (mime || "").replace(/</g, "&lt;");
    const jUrl = JSON.stringify(origUrl);

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>Cannot open " +
      esc_fn +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      "*{margin:0;padding:0;box-sizing:border-box}" +
      "html,body{height:100%;background:#0d0f12;font-family:'Space Grotesk','Segoe UI',sans-serif;color:#f0f4f8;display:flex;align-items:center;justify-content:center}" +
      ".card{background:#181c21;border:1px solid #252b33;border-radius:14px;padding:32px 40px;display:flex;flex-direction:column;align-items:center;gap:16px;max-width:480px;width:92%;box-shadow:0 4px 24px rgba(0,0,0,.5);text-align:center}" +
      ".icon{width:64px;height:64px;border-radius:14px;background:rgba(255,149,149,.07);border:1px solid rgba(255,149,149,.2);display:flex;align-items:center;justify-content:center;font-size:26px;color:#ff9595}" +
      "h1{font-size:16px;font-weight:700;color:#f0f4f8}" +
      ".fname{font-size:13px;color:#7d8a98;word-break:break-all;max-width:100%}" +
      ".meta{font-size:11px;color:#3a4250;font-family:monospace;background:#0d0f12;border:1px solid #252b33;border-radius:6px;padding:6px 12px;width:100%}" +
      ".hint{font-size:12px;color:#5a6370;line-height:1.6}" +
      ".btn-row{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:6px}" +
      ".btn{border-radius:8px;height:32px;padding:0 16px;font-size:12px;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:background .12s,color .12s;border:1px solid transparent;font-family:inherit}" +
      ".btn-primary{background:#9de5ff;color:#0b1015;border-color:#9de5ff}.btn-primary:hover{background:#70d4ff}" +
      ".btn-sec{background:#1c2026;color:#b8c4d0;border-color:#2e3540}.btn-sec:hover{background:#252b33;color:#f0f4f8}" +
      "</style></head><body>" +
      '<div class="card">' +
      '  <div class="icon"><i class="fas fa-file-circle-exclamation"></i></div>' +
      "  <h1>Cannot Open File</h1>" +
      '  <div class="fname">' +
      esc_fn +
      "</div>" +
      '  <div class="meta">' +
      esc_mime +
      " &nbsp;&middot;&nbsp; " +
      size +
      "</div>" +
      '  <p class="hint">Gust doesn\'t have a built-in viewer for this file type.<br>Enable <strong style="color:#b8c4d0">Auto-download</strong> in Files &amp; Media settings to download it instead.</p>' +
      '  <div class="btn-row">' +
      '    <button class="btn btn-primary" onclick="go()"><i class="fas fa-arrow-rotate-left"></i> Go Back</button>' +
      '    <button class="btn btn-sec" onclick="openSettings()"><i class="fas fa-sliders"></i> File Settings</button>' +
      '    <button class="btn btn-sec" onclick="copyUrl()"><i class="fas fa-copy"></i> Copy URL</button>' +
      "  </div>" +
      "</div>" +
      "<script>" +
      "var ORIG=" +
      jUrl +
      ";" +
      'function go(){parent.postMessage({t:"n",u:ORIG},"*");}' +
      'function openSettings(){parent.postMessage({t:"n",u:"gust://settings/filesandmedia"},"*");}' +
      "function copyUrl(){" +
      "  if(navigator.clipboard){navigator.clipboard.writeText(ORIG);}" +
      '  else{var ta=document.createElement("textarea");ta.value=ORIG;document.body.appendChild(ta);ta.select();document.execCommand("copy");document.body.removeChild(ta);}' +
      "}" +
      "<\/script></body></html>"
    );
  }

  function makeBinaryDownloadPage(buf, filename, mime) {
    const bytes = buf.byteLength;
    const size =
      bytes > 1048576
        ? (bytes / 1048576).toFixed(1) + " MB"
        : bytes > 1024
          ? (bytes / 1024).toFixed(1) + " KB"
          : bytes + " B";
    const arr = new Uint8Array(buf);
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < arr.length; i += CHUNK)
      bin += String.fromCharCode.apply(null, arr.subarray(i, i + CHUNK));
    const dataUri =
      "data:" + (mime || "application/octet-stream") + ";base64," + btoa(bin);
    const jDataUri = JSON.stringify(dataUri);
    const jFilename = JSON.stringify(filename);
    const esc_mime = (mime || "application/octet-stream").replace(/</g, "&lt;");
    const esc_size = size;
    const esc_fn = filename.replace(/</g, "&lt;");

    return (
      '<!DOCTYPE html><html><head><meta charset="utf-8">' +
      "<title>" +
      esc_fn +
      "</title>" +
      '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">' +
      "<style>" +
      "*{margin:0;padding:0;box-sizing:border-box}" +
      "html,body{height:100%;background:#0d0f12;font-family:'Space Grotesk','Segoe UI',sans-serif;color:#f0f4f8;display:flex;align-items:center;justify-content:center}" +
      ".card{background:#181c21;border:1px solid #252b33;border-radius:14px;padding:32px 40px;display:flex;flex-direction:column;align-items:center;gap:16px;max-width:440px;width:90%;box-shadow:0 4px 24px rgba(0,0,0,.4);text-align:center}" +
      ".icon{width:64px;height:64px;border-radius:14px;background:rgba(157,229,255,.07);border:1px solid rgba(157,229,255,.12);display:flex;align-items:center;justify-content:center;font-size:26px;color:#9de5ff}" +
      "h1{font-size:14px;font-weight:600;color:#f0f4f8;word-break:break-all;line-height:1.5}" +
      ".meta{font-size:11px;color:#3a4250;font-family:monospace}" +
      ".btn-row{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:4px}" +
      ".dl-btn{background:#9de5ff;color:#0b1015;border:none;border-radius:8px;height:32px;padding:0 20px;font-size:13px;font-weight:700;cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:background .12s}" +
      ".dl-btn:hover{background:#70d4ff}" +
      ".sec-btn{background:#1c2026;border:1px solid #2e3540;color:#b8c4d0;border-radius:8px;height:32px;padding:0 14px;font-size:12px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:background .12s,color .12s}" +
      ".sec-btn:hover{background:#252b33;color:#f0f4f8}" +
      "</style></head><body>" +
      '<div class="card">' +
      '  <div class="icon"><i class="fas fa-file-arrow-down"></i></div>' +
      "  <h1>" +
      esc_fn +
      "</h1>" +
      '  <div class="meta">' +
      esc_mime +
      " &nbsp;&middot;&nbsp; " +
      esc_size +
      "</div>" +
      '  <div class="btn-row">' +
      '    <button class="dl-btn" onclick="dl(DATA,FILENAME)"><i class="fas fa-download"></i> Download File</button>' +
      "    <button class=\"sec-btn\" onclick=\"parent.postMessage({t:'n',u:'gust://settings/filesandmedia'},'*')\"><i class=\"fas fa-gear\"></i> File Settings</button>" +
      "  </div>" +
      "</div>" +
      "<script>" +
      _VIEWER_DL_JS +
      "const DATA=" +
      jDataUri +
      ";const FILENAME=" +
      jFilename +
      ";" +
      'window.addEventListener("load",function(){setTimeout(function(){dl(DATA,FILENAME);},300);});' +
      "<\/script></body></html>"
    );
  }

  // ── Load a viewer page into the iframe ────────────────────────
  function loadViewerPage(html, title, url, initiatorTabId) {
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const blobUrl = URL.createObjectURL(blob);
    const prevBlobUrl = frame.src;
    frame.style.opacity = "0";
    _blobLoadPending = true;
    frame.src = blobUrl;
    frame.onload = () => {
      const loadedTab = tabs.find((t) => t.id === initiatorTabId);
      if (loadedTab) loadedTab.blobSrc = blobUrl;
      frame.onload = null;
    };
    setTimeout(() => {
      frame.style.transition = "opacity 0.2s ease-out";
      frame.style.opacity = "1";
      setTimeout(() => {
        frame.style.transition = "";
      }, 220);
    }, 50);
    if (prevBlobUrl && prevBlobUrl.startsWith("blob:"))
      setTimeout(() => URL.revokeObjectURL(prevBlobUrl), 2000);
    hideOverlay();
    setTabTitle(title);
    log(
      `<i class="fas fa-circle-check" style="color:var(--ok)"></i>Loaded: ` +
        url +
        ` <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${WISP.replace(/^wss?:\/\//, "").split("/")[0]}</span>`,
      "ok",
    );
    addRecentSite(url);
    updateBookmarkButton();
    tabAbortControllers.delete(initiatorTabId);
    const okTab = tabs.find((t) => t.id === initiatorTabId);
    if (okTab) okTab.hasError = false;
    renderTabs();
  }
  // ─────────────────────────────────────────────────────────────

  async function go(
    url,
    push = true,
    method = "GET",
    body = null,
    _isRetry = false,
  ) {
    const initiatorTabId = activeTabId;

    frame.removeAttribute("srcdoc");

    url = normUrl(url);
    if (!url) {
      log("Invalid URL", "err");
      return;
    }
    if (url === HOME_INTERNAL) {
      if (activeTabId === initiatorTabId) showNewTab(push);
      return;
    }
    if (url === SETTINGS_INTERNAL || url.startsWith("gust://settings/")) {
      const section = url.replace("gust://settings/", "") || "connection";
      const cleanSection =
        section === "gust://settings" ? "connection" : section.split("/")[0];
      if (
        url !== SETTINGS_INTERNAL &&
        !VALID_SETTINGS_SECTIONS.has(cleanSection)
      ) {
        // Unknown settings section — show error page
        if (activeTabId === initiatorTabId) {
          hideNewTab();
          hideSettingsPage();
          renderErrorPage(
            url,
            "Unknown Settings Page",
            "ERR_INVALID_GUST_SETTINGS",
            `The settings page <code>${url}</code> does not exist.`,
            [
              "Check for typos in the address",
              "Valid settings pages: " +
                [...VALID_SETTINGS_SECTIONS].join(", "),
            ],
          );
          setTabTitle("Settings — Not Found");
          isErrorPage = true;
          const errTab = tabs.find((t) => t.id === initiatorTabId);
          if (errTab) errTab.hasError = true;
          updateSecurityChip(url, "error");
          urlInput.value = url;
          renderTabs();
          pageUrl = url;
          updateTabUrl(url);
          setStatus("error", "Error");
          if (push) {
            hist = hist.slice(0, histIdx + 1);
            if (hist.length === 0) hist.push(HOME_INTERNAL);
            hist.push(url);
            histIdx = hist.length - 1;
            updateNav();
          }
        }
        return;
      }
      if (activeTabId === initiatorTabId) showSettingsPage(push, cleanSection);
      return;
    }

    isErrorPage = false;

    const prevCtrl = tabAbortControllers.get(initiatorTabId);
    if (prevCtrl) prevCtrl.abort();
    const tabCtrl = new AbortController();
    tabAbortControllers.set(initiatorTabId, tabCtrl);
    if (initiatorTabId === activeTabId) abortCtrl = tabCtrl;

    if (activeTabId === initiatorTabId && !isInvalidInternal(url)) {
      frame.onload = null;
      frame.src = "about:blank";
    }

    if (initiatorTabId === activeTabId) {
      abortAllRequests();
      closeAllSockets();
    }

    const currentTab = getActiveTab();
    if (currentTab) {
      currentTab.cachedContent = null;
      currentTab.cachedUrl = null;
    }

    if (isInvalidInternal(url)) {
      log("Invalid Internal URL: " + url, "err");
      if (activeTabId === initiatorTabId) {
        hideNewTab();
        hideSettingsPage();

        renderErrorPage(
          url,
          "Invalid Internal URL",
          "ERR_INVALID_GUST_URL",
          `The internal address <code>${url}</code> is not a valid Gust page.`,
          [
            "Check for typos in the address",
            "Use the Home button to return to the search page",
            "Common pages: gust://newtab, gust://settings",
          ],
        );

        setTabTitle("Invalid URL");
        isErrorPage = true;
        const errTab2 = tabs.find((t) => t.id === initiatorTabId);
        if (errTab2) errTab2.hasError = true;
        updateSecurityChip(url, "error");
        urlInput.value = url;
        renderTabs();
        pageUrl = url;
        updateTabUrl(url);
        setStatus("error", "Error");

        if (push) {
          hist = hist.slice(0, histIdx + 1);
          if (hist.length === 0) hist.push(HOME_INTERNAL);
          hist.push(url);
          histIdx = hist.length - 1;
          updateNav();
        }
      }
      return;
    }

    if (activeTabId === initiatorTabId) {
      hideNewTab();
      hideSettingsPage();
      pageUrl = url;
      isErrorPage = false;
      const navTab = tabs.find((t) => t.id === initiatorTabId);
      if (navTab) {
        navTab.hasError = false;
        // Update tab.url immediately so renderTabs() and any tab-switch
        // that fires during the async fetch show the correct URL.
        navTab.url = url;
      }
      urlInput.value = url;
      renderTabs();
      updateSecurityChip(url);
      try {
        const host = new URL(url).hostname.replace(/^www\./, "");
        setTabTitle(host || "Loading...");
      } catch {
        setTabTitle("Loading...");
      }
      showOverlay("Loading...");
      totalRequests = 0;
      pendingRequests = 0;
      cachedHits = 0;
      streamCount = 0;
      inFlight.clear();
      setStatus("active", "Loading...");

      if (push) {
        hist = hist.slice(0, histIdx + 1);
        if (hist.length === 0) hist.push(HOME_INTERNAL);
        hist.push(url);
        histIdx = hist.length - 1;
        updateNav();
      }
      updateTabUrl(url);
    }

    try {
      log(
        `<i class="fas fa-arrow-right" style="color:var(--ac)"></i>` +
          url +
          ` <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${WISP.replace(/^wss?:\/\//, "").split("/")[0]}</span>`,
        "info",
      );
      const opts = {
        signal: tabCtrl.signal,
      };
      if (method === "POST" && body) {
        opts.method = "POST";
        opts.body = body;
        opts.headers = {
          "Content-Type": "application/x-www-form-urlencoded",
        };
      }

      const r = await queueFetch(url, opts, PRIORITY.html);
      if (activeTabId !== initiatorTabId) return;

      // If the server redirected us, update url to the final landing URL.
      // This keeps the URL bar, <base href>, and makeProxyScript(BASE) correct.
      if (r.finalUrl && r.finalUrl !== url) {
        url = r.finalUrl;
        pageUrl = url;
        urlInput.value = url;
        updateTabUrl(url);
        updateSecurityChip(url);
        updateBookmarkButton();
        const navTab = tabs.find((t) => t.id === initiatorTabId);
        if (navTab) {
          navTab.url = url;
          // replace the just-pushed history entry with the final URL
          if (hist[histIdx] !== url) {
            hist[histIdx] = url;
            updateNav();
          }
        }
      }

      const _htmlKb = (r.buf.byteLength / 1024).toFixed(1);
      const _htmlStatus = r.status || 200;
      const _htmlStatusColor =
        _htmlStatus >= 400
          ? "var(--err)"
          : _htmlStatus >= 300
            ? "var(--warn)"
            : "var(--ok)";
      log(
        `<span style="color:${_htmlStatusColor};font-weight:600;">${_htmlStatus}</span> <span style="color:var(--tx3)">${_htmlKb}KB</span> · ${r.mime || "text/html"}`,
        "info",
      );

      // ── File-type interception ───────────────────────────────
      {
        const _ftype = classifyResponse(r.mime, url, r.buf);
        const _filename = decodeURIComponent(
          url.split("?")[0].split("/").pop() || "file",
        );

        if (_ftype === "pdf" && mediaPref("gust:media:pdf:v1")) {
          loadViewerPage(
            makePdfViewer(r.buf, _filename, url),
            _filename,
            url,
            initiatorTabId,
          );
          return;
        }

        if (_ftype === "image" && mediaPref("gust:media:img:v1")) {
          loadViewerPage(
            makeImageViewer(r.buf, _filename, r.mime || "image/png"),
            _filename,
            url,
            initiatorTabId,
          );
          return;
        }

        if (_ftype === "video" && mediaPref("gust:media:video:v1")) {
          loadViewerPage(
            makeVideoViewer(r.buf, _filename, r.mime || "video/mp4"),
            _filename,
            url,
            initiatorTabId,
          );
          return;
        }

        if (_ftype === "audio" && mediaPref("gust:media:audio:v1")) {
          loadViewerPage(
            makeAudioViewer(r.buf, _filename, r.mime || "audio/mpeg"),
            _filename,
            url,
            initiatorTabId,
          );
          return;
        }

        if (_ftype === "text" && mediaPref("gust:media:text:v1")) {
          const _text = new TextDecoder("utf-8", { fatal: false }).decode(
            r.buf,
          );
          loadViewerPage(
            makeTextViewer(_text, _filename, r.mime || "text/plain"),
            _filename,
            url,
            initiatorTabId,
          );
          return;
        }

        if (_ftype === "binary") {
          if (mediaPref("gust:media:download:v1")) {
            loadViewerPage(
              makeBinaryDownloadPage(
                r.buf,
                _filename,
                r.mime || "application/octet-stream",
              ),
              _filename,
              url,
              initiatorTabId,
            );
          } else {
            loadViewerPage(
              makeUnknownFilePage(
                _filename,
                r.mime || "application/octet-stream",
                r.buf.byteLength,
                url,
              ),
              _filename,
              url,
              initiatorTabId,
            );
          }
          return;
        }
        // _ftype === 'html' or pref is off → fall through to normal HTML rendering
      }
      // ────────────────────────────────────────────────────────

      const html = new TextDecoder().decode(r.buf);
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, "text/html");

      currentDoc = doc.cloneNode(true);

      const activeTab = getActiveTab();
      if (activeTab) {
        activeTab.cachedDoc = currentDoc.cloneNode(true);
      }

      const docTitle = (doc.title || "").trim();
      if (docTitle) setTabTitle(docTitle);

      // Remove all CSP and framing meta tags (case-insensitive).
      // Also intercept <meta http-equiv="refresh"> to route through GUST
      // instead of letting the browser navigate the iframe natively.
      doc.querySelectorAll("meta[http-equiv]").forEach((m) => {
        const val = (m.getAttribute("http-equiv") || "").toLowerCase().trim();
        if (
          val === "content-security-policy" ||
          val === "content-security-policy-report-only" ||
          val === "x-frame-options" ||
          val === "x-content-type-options"
        ) {
          m.remove();
        } else if (val === "refresh") {
          // Content is either "N" or "N; url=TARGET"
          const content = m.getAttribute("content") || "";
          const urlMatch = content.match(/url\s*=\s*['"]?([^'";\s]+)/i);
          m.remove(); // always strip — never let browser handle it natively
          if (urlMatch) {
            const refreshUrl = urlMatch[1].trim();
            const delayMatch = content.match(/^\s*(\d+)/);
            const delay = delayMatch ? parseInt(delayMatch[1], 10) * 1000 : 0;
            setTimeout(
              () => {
                try {
                  go(new URL(refreshUrl, url).href, true);
                } catch (e) {
                  go(refreshUrl, true);
                }
              },
              Math.max(delay, 0),
            );
          }
          // Plain "N" with no URL = page reload; dropping the tag suppresses it.
        }
      });
      // Strip preconnect/dns-prefetch — they fire outside the proxy tunnel in a blob iframe.
      // Also strip modulepreload: Next.js/React/Vite emit these for ES module chunks;
      // inside a blob iframe they resolve against blob: origin and fail with CORS errors.
      doc
        .querySelectorAll(
          'link[rel="preconnect"], link[rel="dns-prefetch"], link[rel="prerender"], link[rel="prefetch"], link[rel="modulepreload"]',
        )
        .forEach((l) => l.remove());
      doc
        .querySelectorAll("base[target]")
        .forEach((b) => b.removeAttribute("target"));

      // Set base href before proxy script injection
      let base = doc.querySelector("base");
      if (!base) {
        base = doc.createElement("base");
        doc.head.prepend(base);
      }
      base.href = url;
      // Remove any other base tags to prevent conflicts
      doc.querySelectorAll("base").forEach((b) => {
        if (b !== base) b.remove();
      });

      // ── Anchor sanitisation (parse-time, before any page JS runs) ──────
      // Strip every event handler and javascript: href from <a> tags, and
      // rewrite hrefs to absolute URLs. This runs on the parsed DOM before
      // the blob is written to the iframe, so no page JS can interfere.
      doc.querySelectorAll("a, area").forEach((a) => {
        // Strip ALL inline event handlers that could intercept the click
        // before GUST's listener fires (onclick, onmousedown, etc.)
        const evAttrs = [...a.attributes].filter(
          (attr) => attr.name.startsWith("on") || attr.name === "ping", // <a ping> sends beacons on click
        );
        evAttrs.forEach((attr) => a.removeAttribute(attr.name));

        // Strip target so links never escape the proxy iframe
        const tgt = (a.getAttribute("target") || "").toLowerCase();
        if (tgt && tgt !== "_self") a.setAttribute("target", "_self");

        // Rewrite href to absolute URL so resolve() inside the proxy
        // Defuse href at parse-time: store real absolute URL in
        // data-gust-href and set href=javascript:void(0) so the
        // browser can never navigate natively from a click.
        // The proxy script click handler reads data-gust-href.
        const href = a.getAttribute("href");
        if (!href) return;
        if (/^javascript:/i.test(href)) {
          a.setAttribute("href", "javascript:void(0)");
          return;
        }
        if (/^(#|mailto:|tel:|data:|blob:)/i.test(href)) return;
        try {
          const abs = new URL(href, url).href;
          a.setAttribute("data-gust-href", abs);
          a.setAttribute("href", "javascript:void(0)");
        } catch {}
      });
      // ─────────────────────────────────────────────────────────────────

      // Insert proxy script as very first child so it runs before any page scripts
      const proxyScript = doc.createElement("script");
      proxyScript.setAttribute("data-gust-injected", "1");
      proxyScript.textContent = makeProxyScript(
        url,
        blockEnabled,
        mediaPref("gust:webrtc:block:v1"),
        (() => {
          try {
            return ls.getItem("gust:ua:page:v1") || null;
          } catch {
            return null;
          }
        })(),
        (() => {
          try {
            return ls.getItem("gust:spellcheck:v1") === "true";
          } catch {
            return false;
          }
        })(),
      );
      doc.head.insertBefore(proxyScript, doc.head.firstChild);

      // Ensure base tag stays right after the proxy script
      proxyScript.insertAdjacentElement("afterend", base);

      // ── Standalone click router ───────────────────────────────────────
      // A minimal self-contained script that handles link clicks using
      // the data-gust-href attributes set at parse-time above.
      // Runs independently of the main proxy script so link navigation
      // works even if the proxy script has an error.
      const clickRouterScript = doc.createElement("script");
      clickRouterScript.setAttribute("data-gust-injected", "1");
      clickRouterScript.textContent = `(function(){
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a,area') : null;
    if (!a) return;
    var dest = a.getAttribute('data-gust-href');
    if (!dest) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    try { parent.postMessage({t:'n',u:dest},'*'); } catch(err) {}
  }, true);
  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    var dest = form.getAttribute('data-gust-action') || form.action;
    if (!dest || /^(javascript:|blob:|data:)/i.test(dest)) return;
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    var method = (form.getAttribute('method') || 'GET').toUpperCase();
    var fd = new FormData(form);
    if (method === 'POST') {
      try { parent.postMessage({t:'n',u:dest,m:'POST',b:new URLSearchParams(fd).toString()},'*'); } catch(err) {}
    } else {
      var qs = new URLSearchParams(fd).toString();
      try { parent.postMessage({t:'n',u:dest.split('?')[0]+(qs?'?'+qs:'')},'*'); } catch(err) {}
    }
  }, true);
})();`;
      // Insert right after the proxy script so it runs immediately
      proxyScript.insertAdjacentElement("afterend", clickRouterScript);
      clickRouterScript.insertAdjacentElement("afterend", base);
      // ─────────────────────────────────────────────────────────────────

      if (blockEnabled) {
        const adStyle = doc.createElement("style");
        doc.head.appendChild(adStyle);
        const selectors = getBlockedSelectors();
        try {
          let cosmeticCount = 0;
          selectors.forEach((sel) => {
            try {
              adStyle.sheet.insertRule(`${sel} { display: none !important; }`);
              cosmeticCount += doc.querySelectorAll(sel).length;
            } catch (e) {}
          });
          if (cosmeticCount > 0)
            log(
              `<i class="fas fa-eye-slash" style="color:var(--err)"></i><span style="color:var(--tx2)">Cosmetic filter:</span> hid <strong>${cosmeticCount}</strong> ad element${cosmeticCount !== 1 ? "s" : ""} on page`,
              "skip",
            );
        } catch (e) {}
      }

      const cssLinks = [...doc.querySelectorAll('link[rel="stylesheet"]')];

      async function rewriteCssUrls(cssText, baseUrl) {
        const seen = new Set();
        const urlMatches = [
          ...cssText.matchAll(/url\(\s*(['"]?)([^'")\s]+)\1\s*\)/gi),
        ];
        await Promise.all(
          urlMatches.map(async (m) => {
            if (/^(data:|blob:|#)/i.test(m[2]) || seen.has(m[0])) return;
            seen.add(m[0]);
            try {
              const absUrl = new URL(m[2], baseUrl).href;
              const ext = absUrl.split("?")[0].split(".").pop().toLowerCase();
              const isFont = /woff2?|ttf|otf|eot/.test(ext);
              const isImg = /png|jpg|jpeg|gif|svg|webp|ico/.test(ext);
              if (isFont || isImg) {
                try {
                  const r = await queueFetch(
                    absUrl,
                    { signal: tabCtrl.signal },
                    PRIORITY.font,
                  );
                  if (r.buf && r.buf.byteLength > 0) {
                    const fontMime =
                      ext === "woff2"
                        ? "font/woff2"
                        : ext === "woff"
                          ? "font/woff"
                          : ext === "ttf"
                            ? "font/ttf"
                            : ext === "otf"
                              ? "font/otf"
                              : r.mime || "font/woff2";
                    const mime = isFont ? fontMime : r.mime || "image/png";
                    const arr = new Uint8Array(r.buf);
                    let bin = "";
                    const chunk = 32768;
                    for (let j = 0; j < arr.length; j += chunk)
                      bin += String.fromCharCode.apply(
                        null,
                        arr.subarray(j, j + chunk),
                      );
                    const dataUri = `data:${mime};base64,${btoa(bin)}`;
                    cssText = cssText.split(m[0]).join(`url("${dataUri}")`);
                  } else {
                    cssText = cssText.split(m[0]).join(`url("${absUrl}")`);
                  }
                } catch (_fe) {
                  cssText = cssText.split(m[0]).join(`url("${absUrl}")`);
                }
              } else {
                cssText = cssText.split(m[0]).join(`url("${absUrl}")`);
              }
            } catch {}
          }),
        );
        return cssText;
      }

      const BATCH_SIZE = 15;
      for (let i = 0; i < cssLinks.length; i += BATCH_SIZE) {
        if (activeTabId !== initiatorTabId) {
          return;
        }
        const batch = cssLinks.slice(i, i + BATCH_SIZE);
        const batchPromises = batch.map(async (link) => {
          const href = link.getAttribute("href");
          if (!href || /^(data:|blob:)/i.test(href) || shouldSkip(href)) return;
          try {
            const cssUrl = new URL(href, url).href;
            const cssR = await queueFetch(
              cssUrl,
              {
                signal: tabCtrl.signal,
              },
              PRIORITY.css,
            );
            if (activeTabId !== initiatorTabId) return;
            const _cssKb = (cssR.buf.byteLength / 1024).toFixed(1);
            if (!cssR.fromCache)
              log(
                `<i class="fas fa-palette" style="color:${cssR.status >= 400 ? "var(--err)" : "var(--tx2)"}"></i>CSS ${cssR.status || 200} · ${_cssKb}KB · ${cssUrl.replace(/^https?:\/\//, "").slice(0, 45)}`,
                cssR.status >= 400 ? "err" : "",
              );
            let css = new TextDecoder().decode(cssR.buf);

            const importMatches = [
              ...css.matchAll(
                /@import\s+(?:url\()?['"]?([^'")\s;]+)['"]?\)?/gi,
              ),
            ];
            for (const im of importMatches) {
              try {
                const importUrl = new URL(im[1], cssUrl).href;
                const importR = await queueFetch(
                  importUrl,
                  { signal: tabCtrl.signal },
                  PRIORITY.css,
                );
                if (importR.buf.byteLength > 0) {
                  let importCss = new TextDecoder().decode(importR.buf);
                  importCss = await rewriteCssUrls(importCss, importUrl);
                  css = css.replace(im[0], importCss);
                }
              } catch {}
            }

            css = await rewriteCssUrls(css, cssUrl);
            const style = doc.createElement("style");
            style.textContent = css;
            link.replaceWith(style);
          } catch (e) {
            if (e.name !== "AbortError") log("CSS err: " + e.message, "warn");
          }
        });

        await Promise.all(batchPromises);

        if (
          tabCtrl.signal.aborted ||
          !tabs.find((t) => t.id === initiatorTabId)
        )
          return;
      }

      const inlineStyles = [...doc.querySelectorAll("style")];
      await Promise.all(
        inlineStyles.map(async (styleEl) => {
          const css = styleEl.textContent;
          if (!css || !css.includes("url(")) return;
          try {
            const seen = new Set();
            let result = css;
            const urlMatches = [
              ...css.matchAll(/url\(\s*(['"]?)([^'")\s]+)\1\s*\)/gi),
            ];
            await Promise.all(
              urlMatches.map(async (m) => {
                if (/^(data:|blob:|#)/i.test(m[2]) || seen.has(m[0])) return;
                seen.add(m[0]);
                try {
                  const absUrl = new URL(m[2], url).href;
                  const ext = absUrl
                    .split("?")[0]
                    .split(".")
                    .pop()
                    .toLowerCase();
                  const isFont = /woff2?|ttf|otf|eot/.test(ext);
                  if (isFont) {
                    const r = await queueFetch(
                      absUrl,
                      { signal: tabCtrl.signal },
                      PRIORITY.font,
                    );
                    if (r.buf && r.buf.byteLength > 0) {
                      const fontMime =
                        ext === "woff2"
                          ? "font/woff2"
                          : ext === "woff"
                            ? "font/woff"
                            : ext === "ttf"
                              ? "font/ttf"
                              : ext === "otf"
                                ? "font/otf"
                                : "font/woff2";
                      const arr = new Uint8Array(r.buf);
                      let bin = "";
                      const chunk = 32768;
                      for (let j = 0; j < arr.length; j += chunk)
                        bin += String.fromCharCode.apply(
                          null,
                          arr.subarray(j, j + chunk),
                        );
                      result = result
                        .split(m[0])
                        .join(`url("data:${fontMime};base64,${btoa(bin)}")`);
                    } else {
                      result = result.split(m[0]).join(`url("${absUrl}")`);
                    }
                  } else {
                    result = result.split(m[0]).join(`url("${absUrl}")`);
                  }
                } catch {}
              }),
            );
            styleEl.textContent = result;
          } catch {}
        }),
      );

      if (tabCtrl.signal.aborted || activeTabId !== initiatorTabId) return;

      // JS - keep as external scripts to preserve defer/module semantics.
      // Next.js / React / Vite apps commonly emit 30-80+ script tags (classic chunks
      // + ES module chunks). We keep up to 150 total to avoid cutting off critical
      // framework bootstrap scripts.  Module scripts (type="module") are included in
      // the same pass so their relative load order is preserved.
      const allScripts = [...doc.querySelectorAll("script[src]")].slice(0, 150);
      allScripts.forEach((scr) => {
        const src = scr.getAttribute("src");
        if (!src || /^(data:|blob:)/i.test(src)) return;
        const jsUrl = new URL(src, url).href;
        if (shouldSkip(jsUrl)) {
          scr.remove();
          return;
        }
        scr.setAttribute("data-original-src", jsUrl);
        scr.setAttribute("src", jsUrl);
        log("JS: " + jsUrl.slice(0, 40));
      });

      if (tabCtrl.signal.aborted || activeTabId !== initiatorTabId) return;

      doc
        .querySelectorAll('img[loading="lazy"], iframe[loading="lazy"]')
        .forEach((el) => {
          el.setAttribute("loading", "eager");
        });
      doc
        .querySelectorAll(
          "img[data-src], img[data-lazy], img[data-original], img[data-lazy-src]",
        )
        .forEach((img) => {
          const lazySrc =
            img.getAttribute("data-src") ||
            img.getAttribute("data-lazy") ||
            img.getAttribute("data-original") ||
            img.getAttribute("data-lazy-src");
          if (lazySrc && !/^(data:|blob:)/i.test(lazySrc)) {
            img.setAttribute("src", lazySrc);
            img.removeAttribute("data-src");
            img.removeAttribute("data-lazy");
            img.removeAttribute("data-original");
            img.removeAttribute("data-lazy-src");
          }
        });

      if (blockEnabled) {
        doc.querySelectorAll("img[src], iframe[src]").forEach((el) => {
          const src = el.getAttribute("src");
          if (src && !/^(data:|blob:)/i.test(src)) {
            try {
              const absUrl = new URL(src, url).href;
              if (shouldSkip(absUrl)) el.remove();
            } catch (e) {
              if (shouldSkip(src)) el.remove();
            }
          }
        });
      }

      const images = [...doc.querySelectorAll("img[src]")].slice(0, 200);
      const loadedImageUrls = new Set();
      const imagePromises = images.map(async (img) => {
        const src = img.getAttribute("src");
        if (!src || /^(data:|blob:)/i.test(src) || shouldSkip(src)) return;
        try {
          const imgUrl = new URL(src, url).href;

          if (loadedImageUrls.has(imgUrl)) return;
          loadedImageUrls.add(imgUrl);

          const imgR = await queueFetch(
            imgUrl,
            {
              signal: tabCtrl.signal,
            },
            PRIORITY.image,
          );
          if (!imgR.fromCache) {
            const _imgKb = (imgR.buf.byteLength / 1024).toFixed(1);
            log(
              `<i class="fas fa-image" style="color:${imgR.status >= 400 ? "var(--err)" : "var(--tx2)"}"></i>IMG ${imgR.status || 200} · ${_imgKb}KB · ${imgUrl.replace(/^https?:\/\//, "").slice(0, 45)}`,
              imgR.status >= 400 ? "err" : "",
            );
          }
        } catch (e) {
          if (e.name !== "AbortError") log("IMG err: " + e.message, "warn");
        }
      });

      await Promise.race([
        Promise.all(imagePromises),
        new Promise((resolve) => setTimeout(resolve, 5000)),
      ]);

      if (tabCtrl.signal.aborted || activeTabId !== initiatorTabId) return;

      const highlightStyle = doc.createElement("style");
      highlightStyle.textContent = `
                        .gust-highlight {
                            outline: 2px solid rgba(100, 210, 255, 0.9) !important;
                            outline-offset: 0px !important;
                            box-shadow: inset 0 0 0 9999px rgba(100, 210, 255, 0.12) !important;
                        }
                    `;
      doc.head.appendChild(highlightStyle);

      if (!tabs.find((t) => t.id === initiatorTabId)) return;

      const finalHtml = "<!DOCTYPE html>\n" + doc.documentElement.outerHTML;
      const prevBlobUrl = frame.src;
      const newBlobUrl = URL.createObjectURL(
        new Blob([finalHtml], {
          type: "text/html;charset=utf-8",
        }),
      );
      frame.style.opacity = "0";
      _blobLoadPending = true;
      frame.src = newBlobUrl;
      frame.onload = () => {
        // Re-apply mute state after new content loads
        const loadedTab = tabs.find((t) => t.id === initiatorTabId);
        if (loadedTab) {
          applyMuteToFrame(!!loadedTab.muted);
          loadedTab.blobSrc = newBlobUrl;
        }
        frame.onload = null;
      };
      setTimeout(() => {
        frame.style.transition = "opacity 0.2s ease-out";
        frame.style.opacity = "1";
        setTimeout(() => {
          frame.style.transition = "";
        }, 220);
      }, 50);
      if (prevBlobUrl && prevBlobUrl.startsWith("blob:")) {
        setTimeout(() => URL.revokeObjectURL(prevBlobUrl), 2000);
      }
      hideOverlay();
      if (!_isRetry) {
        log(
          `<i class="fas fa-circle-check" style="color:var(--ok)"></i>Loaded: ` +
            url +
            ` <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${WISP.replace(/^wss?:\/\//, "").split("/")[0]}</span>`,
          "ok",
        );
      }
      addRecentSite(url);
      updateBookmarkButton();
      tabAbortControllers.delete(initiatorTabId);
      const okTab = tabs.find((t) => t.id === initiatorTabId);
      if (okTab) okTab.hasError = false;
      renderTabs();

      if (elementsEl && !elementsEl.classList.contains("hidden")) {
        inspectCurrentPage();
      }
    } catch (e) {
      if (e.name === "AbortError") {
        log("Aborted", "warn");
        return;
      }

      // When called as a retry, propagate the error to the retry loop
      // rather than rendering an error page or spawning another retry sequence.
      if (_isRetry) throw e;

      // ── Fallback retry logic ──────────────────────────────────
      const _fbEnabled = (() => {
        try {
          return ls.getItem("gust:fallback:enabled") !== "0";
        } catch {
          return true;
        }
      })();
      const _fbWisp = (() => {
        try {
          return ls.getItem("gust:fallback:wisp") || "";
        } catch {
          return "";
        }
      })();
      const _fbRetries = (() => {
        try {
          return Math.max(
            1,
            parseInt(ls.getItem("gust:fallback:retries") || "3", 10),
          );
        } catch {
          return 3;
        }
      })();
      const _fbDelay = (() => {
        try {
          return Math.max(
            0,
            parseInt(ls.getItem("gust:fallback:delay") || "3", 10),
          );
        } catch {
          return 3;
        }
      })();
      const _fb5xx = (() => {
        try {
          return ls.getItem("gust:fallback:5xx") !== "0";
        } catch {
          return true;
        }
      })();
      const _fbTimeout = (() => {
        try {
          return ls.getItem("gust:fallback:timeout") !== "0";
        } catch {
          return true;
        }
      })();
      const _fbDns = (() => {
        try {
          return ls.getItem("gust:fallback:dns") === "1";
        } catch {
          return false;
        }
      })();

      const _eMsg = (e.message || "").toLowerCase();
      const _isDns =
        _eMsg.includes("dns") ||
        _eMsg.includes("getaddrinfo") ||
        _eMsg.includes("name resolution");
      const _isTimeout =
        _eMsg.includes("timeout") || _eMsg.includes("timed out");
      const _is5xx =
        _eMsg.includes("500") ||
        _eMsg.includes("502") ||
        _eMsg.includes("503") ||
        _eMsg.includes("504") ||
        _eMsg.includes("internal server");

      const _triggerMatches =
        (_isDns && _fbDns) ||
        (_isTimeout && _fbTimeout) ||
        (_is5xx && _fb5xx) ||
        (!_isDns && !_isTimeout && !_is5xx); // generic errors always eligible

      const _mainRetries = (() => {
        try {
          return parseInt(ls.getItem("gust:main:retries")) || 3;
        } catch {
          return 3;
        }
      })();
      const _primaryHost = WISP.replace(/^wss?:\/\//, "").split("/")[0];

      if (
        !_isRetry &&
        _triggerMatches &&
        !tabAbortControllers.get(initiatorTabId)?.signal?.aborted
      ) {
        // ── Phase 1: retry on primary WISP ──────────────────────
        log(
          `<i class="fas fa-rotate-left" style="color:var(--warn)"></i><span style="color:var(--warn)">Initial attempt failed (${_primaryHost}):</span> <span style="color:var(--tx3)">${e.message.slice(0, 55)}</span>`,
          "warn",
        );

        let _mainSuccess = false;
        for (let _mi = 0; _mi < _mainRetries; _mi++) {
          if (tabAbortControllers.get(initiatorTabId)?.signal?.aborted) break;
          try {
            log(
              `<i class="fas fa-rotate-left" style="color:var(--warn)"></i><span style="color:var(--warn)">Main retry ${_mi + 1}/${_mainRetries}</span> <span style="color:var(--tx3);font-family:var(--mono)">via ${_primaryHost}</span>`,
              "warn",
            );
            if (_fbDelay > 0 && _mi > 0)
              await new Promise((r) => setTimeout(r, _fbDelay * 1000));
            if (tabAbortControllers.get(initiatorTabId)?.signal?.aborted) break;
            await go(url, false, method, body, true);
            _mainSuccess = true;
            log(
              `<i class="fas fa-circle-check" style="color:var(--ok)"></i>Loaded: ${url} <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${_primaryHost} (main retry ${_mi + 1}/${_mainRetries})</span>`,
              "ok",
            );
            break;
          } catch (_mErr) {
            if (_mErr.name === "AbortError") break;
            if (_mi + 1 < _mainRetries) {
              log(
                `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">Main retry ${_mi + 1}/${_mainRetries} failed:</span> <span style="color:var(--tx3)">${_mErr.message.slice(0, 55)}</span>`,
                "err",
              );
            } else {
              log(
                `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">All ${_mainRetries} main retries failed on ${_primaryHost}</span>${_fbEnabled && _fbWisp ? " — switching to fallback" : ""}`,
                "err",
              );
            }
          }
        }
        if (_mainSuccess) return;
        if (tabAbortControllers.get(initiatorTabId)?.signal?.aborted) return;

        // ── Phase 2: switch to fallback WISP ────────────────────
        if (_fbEnabled && _fbWisp) {
          const _fbHost = _fbWisp.replace(/^wss?:\/\//, "").split("/")[0];
          log(
            `<i class="fas fa-rotate-left" style="color:var(--warn)"></i><span style="color:var(--warn)">Switching to fallback WISP</span> <span style="color:var(--tx3);font-family:var(--mono)">${_fbHost}</span>`,
            "warn",
          );

          // Switch libcurl to fallback WISP
          try {
            await libcurl.load_wasm();
            libcurl.set_websocket(_fbWisp);
            curl = new libcurl.HTTPSession();
            curl.set_connections(
              MAX_CONCURRENT,
              MAX_CONCURRENT,
              MAX_CONCURRENT,
            );
          } catch (_swErr) {
            log(
              `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">Failed to switch to fallback WISP:</span> <span style="color:var(--tx3)">${_swErr.message.slice(0, 55)}</span>`,
              "err",
            );
          }

          let _fbSuccess = false;
          for (let _ri = 0; _ri < _fbRetries; _ri++) {
            if (tabAbortControllers.get(initiatorTabId)?.signal?.aborted) break;
            try {
              log(
                `<i class="fas fa-rotate-left" style="color:var(--warn)"></i><span style="color:var(--warn)">Fallback retry ${_ri + 1}/${_fbRetries}</span> <span style="color:var(--tx3);font-family:var(--mono)">via ${_fbHost}</span>${_fbDelay > 0 && _ri > 0 ? ` <span style="color:var(--tx3)">(after ${_fbDelay}s)</span>` : ""}`,
                "warn",
              );
              if (_fbDelay > 0 && _ri > 0)
                await new Promise((r) => setTimeout(r, _fbDelay * 1000));
              if (tabAbortControllers.get(initiatorTabId)?.signal?.aborted)
                break;
              await go(url, false, method, body, true);
              _fbSuccess = true;
              log(
                `<i class="fas fa-circle-check" style="color:var(--ok)"></i>Loaded: ${url} <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${_fbHost} (fallback retry ${_ri + 1}/${_fbRetries})</span>`,
                "ok",
              );
              // Restore primary WISP for subsequent requests
              try {
                await libcurl.load_wasm();
                libcurl.set_websocket(WISP);
                curl = new libcurl.HTTPSession();
                curl.set_connections(
                  MAX_CONCURRENT,
                  MAX_CONCURRENT,
                  MAX_CONCURRENT,
                );
              } catch (_re) {}
              break;
            } catch (_fbErr) {
              if (_fbErr.name === "AbortError") break;
              if (_ri + 1 < _fbRetries) {
                log(
                  `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">Fallback retry ${_ri + 1}/${_fbRetries} failed:</span> <span style="color:var(--tx3)">${_fbErr.message.slice(0, 55)}</span>`,
                  "err",
                );
              } else {
                log(
                  `<i class="fas fa-circle-xmark" style="color:var(--err)"></i><span style="color:var(--err)">All ${_fbRetries} fallback retries failed — ${_fbHost} also unavailable</span>`,
                  "err",
                );
                // Restore primary WISP before showing error page
                try {
                  await libcurl.load_wasm();
                  libcurl.set_websocket(WISP);
                  curl = new libcurl.HTTPSession();
                  curl.set_connections(
                    MAX_CONCURRENT,
                    MAX_CONCURRENT,
                    MAX_CONCURRENT,
                  );
                } catch (_re) {}
              }
            }
          }
          if (_fbSuccess) return;
        } else if (_fbEnabled && !_fbWisp) {
          log(
            `<i class="fas fa-triangle-exclamation" style="color:var(--warn)"></i><span style="color:var(--warn)">Fallback enabled but no fallback WISP configured</span> — set one in Settings → Fallback`,
            "warn",
          );
        }
      }
      // ─────────────────────────────────────────────────────────

      log("Failed: " + e.message, "err");
      progressBar.classList.add("error");
      hideOverlay();
      setStatus("error", "Error");
      setTabTitle("Error");
      currentDoc = null;
      let errorType = "Connection Error";
      let errorCode = "";
      let errorDescription = "";
      let errorSuggestions = [];

      const errorMsg = e.message.toLowerCase();

      if (
        errorMsg.includes("dns") ||
        errorMsg.includes("getaddrinfo") ||
        errorMsg.includes("name resolution")
      ) {
        errorType = "DNS Resolution Failed";
        errorCode = "ERR_NAME_NOT_RESOLVED";
        errorDescription =
          "The domain name could not be resolved. The website's address might be incorrect or the DNS server is unavailable.";
        errorSuggestions = [
          "Check if the URL is spelled correctly",
          "Try accessing the site later",
          "Check your DNS settings",
          "Try using a different DNS server (e.g., 8.8.8.8)",
        ];
      } else if (
        errorMsg.includes("timeout") ||
        errorMsg.includes("timed out")
      ) {
        errorType = "Connection Timeout";
        errorCode = "ERR_CONNECTION_TIMED_OUT";
        errorDescription =
          "The server took too long to respond. This could be due to a slow connection, server issues, or network problems.";
        errorSuggestions = [
          "Check your internet connection",
          "Try reloading the page",
          "The server might be experiencing high traffic",
          "Try again in a few moments",
        ];
      } else if (
        errorMsg.includes("refused") ||
        errorMsg.includes("econnrefused")
      ) {
        errorType = "Connection Refused";
        errorCode = "ERR_CONNECTION_REFUSED";
        errorDescription =
          "The server refused to connect. The website might be down or blocking connections.";
        errorSuggestions = [
          "Check if the website is down for everyone",
          "The site might be temporarily unavailable",
          "Try accessing the site later",
          "Check your firewall settings",
        ];
      } else if (
        errorMsg.includes("ssl") ||
        errorMsg.includes("tls") ||
        errorMsg.includes("certificate")
      ) {
        errorType = "SSL/TLS Error";
        errorCode = "ERR_SSL_PROTOCOL_ERROR";
        errorDescription =
          "There was a problem with the website's security certificate or SSL/TLS connection.";
        errorSuggestions = [
          "The website's certificate might be invalid or expired",
          "Try accessing the HTTP version (not recommended)",
          "Check your system date and time",
          "The site might be using outdated security protocols",
        ];
      } else if (errorMsg.includes("network") || errorMsg.includes("offline")) {
        errorType = "Network Error";
        errorCode = "ERR_NETWORK_CHANGED";
        errorDescription =
          "A network error occurred. You might be offline or your connection was interrupted.";
        errorSuggestions = [
          "Check your internet connection",
          "Try reconnecting to your network",
          "Check if other sites load correctly",
          "Restart your router if the problem persists",
        ];
      } else if (errorMsg.includes("blocked") || errorMsg.includes("cors")) {
        errorType = "Request Blocked";
        errorCode = "ERR_BLOCKED_BY_CLIENT";
        errorDescription =
          "The request was blocked, possibly by CORS policy or security settings.";
        errorSuggestions = [
          "The website might not support proxy access",
          "Try accessing the site directly",
          "Check your privacy/security settings",
          "Some sites block proxy connections",
        ];
      } else if (errorMsg.includes("404") || errorMsg.includes("not found")) {
        errorType = "Page Not Found";
        errorCode = "HTTP 404";
        errorDescription =
          "The requested page could not be found on the server.";
        errorSuggestions = [
          "Check the URL for typos",
          "The page might have been moved or deleted",
          "Try going to the website's home page",
          "Search for the page using a search engine",
        ];
      } else if (
        errorMsg.includes("500") ||
        errorMsg.includes("internal server")
      ) {
        errorType = "Internal Server Error";
        errorCode = "HTTP 500";
        errorDescription =
          "The server encountered an error and could not complete your request.";
        errorSuggestions = [
          "Try reloading the page",
          "The server might be temporarily down",
          "Try again in a few minutes",
          "Contact the website administrator if the problem persists",
        ];
      } else if (errorMsg.includes("403") || errorMsg.includes("forbidden")) {
        errorType = "Access Forbidden";
        errorCode = "HTTP 403";
        errorDescription = "You don't have permission to access this resource.";
        errorSuggestions = [
          "You might need to log in",
          "The page might be restricted",
          "Check if you have the necessary permissions",
          "Contact the website administrator",
        ];
      } else if (
        errorMsg.includes("aborted") ||
        errorMsg.includes("operation")
      ) {
        errorType = "Connection Interrupted";
        errorCode = "ERR_CONNECTION_ABORTED";
        errorDescription =
          "The connection to the proxy server was interrupted. GUST will attempt to reconnect automatically on the next request.";
        errorSuggestions = [
          "Click the reload button to try again",
          "The proxy server may have briefly disconnected",
          "Check that your WISP server is running",
          "Try reloading the page - the connection should auto-recover",
        ];
      } else {
        errorType = "Error Loading Page";
        errorCode = e.message;
        errorDescription = "An error occurred while trying to load this page.";
        errorSuggestions = [
          "Try reloading the page",
          "Check your internet connection",
          "Try accessing the site later",
          "Clear your cache in settings",
        ];
      }

      isErrorPage = true;
      const errTab = tabs.find((t) => t.id === initiatorTabId);
      if (errTab) errTab.hasError = true;
      if (!tabs.find((t) => t.id === initiatorTabId)) return;
      renderErrorPage(
        pageUrl,
        errorType,
        errorCode,
        errorDescription,
        errorSuggestions,
      );
      updateSecurityChip(pageUrl, "error");
      renderTabs();
    }
  }

  $("go").addEventListener("mousedown", (e) => {
    e.preventDefault();
    e.stopPropagation();
  });
  $("go").onclick = () => go(urlInput.value);
  urlInput.onkeydown = (e) => {
    if (e.key === "Enter") go(urlInput.value);
  };

  // Drag a link or text URL onto the address bar
  (function () {
    const omniboxEl = urlInput.closest(".omnibox");
    let _dragDepth = 0;

    function _setDragOver(active) {
      if (!omniboxEl) return;
      if (active) {
        omniboxEl.classList.add("drag-over");
      } else {
        omniboxEl.classList.remove("drag-over");
        // Restore input styling immediately
        urlInput.style.textDecoration = "";
        urlInput.style.color = "";
      }
    }

    // Use dragenter/dragleave on the whole omnibox so any child target works
    omniboxEl &&
      omniboxEl.addEventListener("dragenter", (e) => {
        // Only react to drags carrying a URL-like payload
        const types = e.dataTransfer && e.dataTransfer.types;
        if (!types) return;
        const hasUrl = Array.from(types).some(
          (t) =>
            t === "text/uri-list" || t === "text/plain" || t === "text/html",
        );
        if (!hasUrl) return;
        _dragDepth++;
        _setDragOver(true);
      });

    omniboxEl &&
      omniboxEl.addEventListener("dragleave", (e) => {
        _dragDepth = Math.max(0, _dragDepth - 1);
        if (_dragDepth === 0) _setDragOver(false);
      });

    omniboxEl &&
      omniboxEl.addEventListener("dragover", (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "copy";
      });

    omniboxEl &&
      omniboxEl.addEventListener("drop", (e) => {
        e.preventDefault();
        _dragDepth = 0;
        _setDragOver(false);
        const url =
          e.dataTransfer.getData("text/uri-list") ||
          e.dataTransfer.getData("text/plain") ||
          "";
        const trimmed = url.trim().split("\n")[0].trim();
        if (trimmed) {
          urlInput.value = trimmed;
          go(trimmed);
        }
      });

    // Also cancel state if drag ends without a drop (e.g. user releases outside)
    document.addEventListener("dragend", () => {
      _dragDepth = 0;
      _setDragOver(false);
    });
  })();

  window.addEventListener("message", function (e) {
    if (e.data && e.data.type === "goBack") {
      if (histIdx > 0) {
        histIdx--;
        updateNav();
        go(hist[histIdx], false);
      }
    }
    if (e.data && e.data.type === "reloadPage") {
      if (pageUrl && pageUrl !== HOME_INTERNAL && !isSettingsPage(pageUrl)) {
        go(pageUrl, false);
      }
    }
    if (e.data && e.data.type === "openDevTools") {
      toggleLogs();
    }
  });

  $("back").onclick = () => {
    if (histIdx > 0) {
      histIdx--;
      updateNav();
      go(hist[histIdx], false);
    }
  };
  $("fwd").onclick = () => {
    if (histIdx < hist.length - 1) {
      histIdx++;
      updateNav();
      go(hist[histIdx], false);
    }
  };
  $("reload").onclick = () => {
    if (newtab?.classList.contains("active")) {
      loadSavedWallpaper();
      updateClock();
      return;
    }
    if (pageUrl) {
      memCache.clear();
      go(pageUrl, false);
    }
  };
  $("stop").onclick = () => {
    if (abortCtrl) {
      abortCtrl.abort();
      abortAllRequests();
      closeAllSockets();
      hideOverlay();
      setStatus("idle", "Stopped");
      log("Stopped", "warn");
      frame.src = "about:blank";
      if (window.stop) window.stop();
    }
  };
  homeBtn.onclick = () => showNewTab(true);
  newTabBtn.onclick = () => createTab();
  const adblockModal = $("adblockModal");
  const adblockCloseBtn = $("adblockCloseBtn");
  const adblockLargeToggle = $("adblockLargeToggle");
  const adblockStatusText = $("adblockStatusText");
  const adblockStatsCount = $("adblockStatsCount");

  function showAdblockPopup() {
    hideSiteInfo();
    hideHistoryPopup();
    updateAdblockUI();
    const btnRect = blockToggle.getBoundingClientRect();
    adblockModal.style.top = btnRect.bottom + 13 + "px";
    adblockModal.style.right = "auto";
    adblockModal.style.left = btnRect.right - 275 + "px";
    adblockModal.classList.add("open");
    requestAnimationFrame(() => {
      const r = adblockModal.getBoundingClientRect();
      if (r.right > window.innerWidth - 8) {
        adblockModal.style.left = window.innerWidth - r.width - 8 + "px";
      }
    });
  }

  function hideAdblockPopup() {
    animateClose(adblockModal, 180, () =>
      adblockModal.classList.remove("open"),
    );
  }

  function updateAdblockUI() {
    if (blockEnabled) {
      blockToggle.classList.add("on");
      blockToggle.querySelector("span").textContent = "Protected";
      blockToggle.querySelector("i").className = "fas fa-shield-halved";
      adblockLargeToggle.classList.add("on");
      adblockLargeToggle.innerHTML = '<i class="fas fa-shield-halved"></i>';
      adblockStatusText.textContent = "Protection Active";
      adblockStatusText.style.color = "var(--ok)";
      adblockStatsCount.textContent = adblockStatsCount.dataset.count || "0";
    } else {
      blockToggle.classList.remove("on");
      blockToggle.querySelector("span").textContent = "Paused";
      blockToggle.querySelector("i").className = "fas fa-xmark";
      adblockLargeToggle.classList.remove("on");
      adblockLargeToggle.innerHTML = '<i class="fas fa-xmark"></i>';
      adblockStatusText.textContent = "Protection Paused";
      adblockStatusText.style.color = "var(--tx2)";
    }
  }

  blockToggle.onclick = (e) => {
    e.stopPropagation();
    if (adblockModal.classList.contains("open")) {
      hideAdblockPopup();
    } else {
      hideHistoryPopup();
      showAdblockPopup();
    }
  };

  updateAdblockUI();

  $("adblockManageBtn").onclick = () => {
    hideAdblockPopup();
    showSettingsPage(true, "privacy");
  };

  adblockCloseBtn.onclick = hideAdblockPopup;

  adblockLargeToggle.onclick = (e) => {
    e.stopPropagation();
    blockEnabled = !blockEnabled;
    try {
      ls.setItem("gust:block:v1", blockEnabled ? "true" : "false");
    } catch {}
    updateAdblockUI();
    if (pageUrl && pageUrl !== HOME_INTERNAL && !isSettingsPage(pageUrl)) {
      go(pageUrl, false);
    }
  };

  document.addEventListener("click", (e) => {
    if (
      adblockModal.classList.contains("open") &&
      !adblockModal.contains(e.target) &&
      !blockToggle.contains(e.target)
    ) {
      hideAdblockPopup();
    }
  });
  const siteInfoPopup = $("siteInfoPopup");

  function showSiteInfo() {
    hideAdblockPopup();
    hideHistoryPopup();
    const url = pageUrl;
    const iconEl = $("siteInfoIcon");
    const iconI = $("siteInfoIconI");
    const title = $("siteInfoTitle");
    const subtitle = $("siteInfoSubtitle");
    const hostEl = $("siteInfoHost");
    const protoEl = $("siteInfoProtocol");
    const blockEl = $("siteInfoBlock");
    const cookieEl = $("siteInfoCookies");
    const cacheEl = $("siteInfoCache");

    function getCookieCount(origin) {
      try {
        const store = cookieJar.get(origin);
        if (!store) return 0;
        const now = Date.now();
        let count = 0;
        for (const [, data] of store.entries()) {
          if (!data.expiresAt || data.expiresAt > now) count++;
        }
        return count;
      } catch {
        return 0;
      }
    }

    function getCacheCount(host) {
      try {
        const hits = [...memCache.keys()].filter((k) =>
          k.includes(host),
        ).length;
        return hits;
      } catch {
        return 0;
      }
    }

    if (
      !url ||
      url === HOME_INTERNAL ||
      isSettingsPage(url) ||
      url.startsWith("gust://")
    ) {
      iconEl.className = "site-info-icon neutral";
      iconI.className = "fas fa-wind";
      title.textContent = "Gust Browser";
      subtitle.textContent = "Internal page";
      hostEl.textContent = "gust://";
      protoEl.innerHTML = `<span class="ok">Internal</span>`;
      blockEl.innerHTML = `<span style="color:var(--tx3)">N/A</span>`;
      cookieEl.innerHTML = `<span style="color:var(--tx3)">N/A</span>`;
      cacheEl.innerHTML = `<span style="color:var(--tx3)">N/A</span>`;
    } else if (
      securityChip.classList.contains("insecure") &&
      $("securityIcon")?.className?.includes("circle-xmark")
    ) {
      iconEl.className = "site-info-icon insecure";
      iconI.className = "fas fa-circle-xmark";
      title.textContent = "Page failed to load";
      subtitle.textContent = "An error occurred while loading this page";
      let parsed;
      try {
        parsed = new URL(url);
      } catch {
        parsed = null;
      }
      const host = parsed?.hostname || url;
      const origin = parsed?.origin || url;
      hostEl.textContent = host;
      protoEl.innerHTML = `<span class="err">Connection error</span>`;
      blockEl.innerHTML = blockEnabled
        ? `<span class="ok">Protected</span>`
        : `<span style="color:var(--tx3)">Paused</span>`;
      const cc = getCookieCount(origin);
      cookieEl.innerHTML =
        cc > 0
          ? `<span class="ok">${cc} stored</span>`
          : `<span style="color:var(--tx3)">None</span>`;
      const ch = getCacheCount(host);
      cacheEl.innerHTML =
        ch > 0
          ? `<span class="ok">${ch} item${ch !== 1 ? "s" : ""}</span>`
          : `<span style="color:var(--tx3)">Empty</span>`;
    } else {
      let parsed;
      try {
        parsed = new URL(url);
      } catch {
        parsed = null;
      }
      const isHttps = /^https:/i.test(url);
      const isHttp = /^http:/i.test(url);
      const host = parsed?.hostname || url;
      const origin = parsed?.origin || url;

      if (isHttps) {
        iconEl.className = "site-info-icon secure";
        iconI.className = "fas fa-lock";
        title.textContent = "Connection is proxied";
        subtitle.textContent = "Your real IP is hidden from this site";
        protoEl.innerHTML = `<span class="ok">HTTPS - Encrypted</span>`;
      } else if (isHttp) {
        iconEl.className = "site-info-icon insecure";
        iconI.className = "fas fa-triangle-exclamation";
        title.textContent = "Connection not secure";
        subtitle.textContent = "This site uses an unencrypted connection";
        protoEl.innerHTML = `<span class="err">HTTP - Not encrypted</span>`;
      } else {
        iconEl.className = "site-info-icon neutral";
        iconI.className = "fas fa-circle-info";
        title.textContent = "Connection info";
        subtitle.textContent = "";
        protoEl.textContent = parsed?.protocol || "Unknown";
      }

      hostEl.textContent = host;
      blockEl.innerHTML = blockEnabled
        ? `<span class="ok">Protected</span>`
        : `<span style="color:var(--tx3)">Paused</span>`;

      const cc = getCookieCount(origin);
      cookieEl.innerHTML =
        cc > 0
          ? `<span class="ok">${cc} stored</span>`
          : `<span style="color:var(--tx3)">None</span>`;
      const ch = getCacheCount(host);
      cacheEl.innerHTML =
        ch > 0
          ? `<span class="ok">${ch} item${ch !== 1 ? "s" : ""}</span>`
          : `<span style="color:var(--tx3)">Empty</span>`;
    }

    const chipRect = securityChip.getBoundingClientRect();
    siteInfoPopup.style.left = chipRect.left + "px";
    siteInfoPopup.style.top = chipRect.bottom + 20 + "px";

    siteInfoPopup.classList.add("open");
    requestAnimationFrame(() => {
      const popRect = siteInfoPopup.getBoundingClientRect();
      if (popRect.right > window.innerWidth - 8) {
        siteInfoPopup.style.left = window.innerWidth - popRect.width - 8 + "px";
      }
    });
  }

  function hideSiteInfo() {
    animateClose(siteInfoPopup, 200, () =>
      siteInfoPopup.classList.remove("open"),
    );
  }

  securityChip.addEventListener("click", (e) => {
    e.stopPropagation();
    if (siteInfoPopup.classList.contains("open")) {
      hideSiteInfo();
    } else {
      showSiteInfo();
    }
  });

  document.addEventListener("click", (e) => {
    if (
      siteInfoPopup.classList.contains("open") &&
      !siteInfoPopup.contains(e.target)
    ) {
      hideSiteInfo();
    }
  });

  $("siteInfoClose").onclick = hideSiteInfo;
  $("siteInfoCopy").onclick = async () => {
    if (pageUrl && pageUrl !== HOME_INTERNAL && !isSettingsPage(pageUrl)) {
      try {
        await navigator.clipboard.writeText(pageUrl);
        const btn = $("siteInfoCopy");
        btn.innerHTML = '<i class="fas fa-check"></i> Copied!';
        setTimeout(() => {
          btn.innerHTML = '<i class="fas fa-copy"></i> Copy URL';
        }, 1500);
      } catch (e) {}
    }
  };

  const historyPopup = $("historyPopup");

  let recentSites = [];
  try {
    recentSites = JSON.parse(ls.getItem("gust:recent") || "[]");
  } catch {}
  recentSites = recentSites.map((e) =>
    typeof e === "string" ? { url: e, time: Date.now() } : e,
  );

  function addRecentSite(url) {
    if (
      !url ||
      url === HOME_INTERNAL ||
      url.startsWith("gust://") ||
      isSettingsPage(url)
    )
      return;
    // Remove existing entry for same URL so it moves to top
    recentSites = recentSites.filter((e) => e.url !== url);
    recentSites.unshift({ url, time: Date.now() });
    recentSites = recentSites.slice(0, 20);
    try {
      ls.setItem("gust:recent", JSON.stringify(recentSites));
    } catch {}
  }

  function formatHistoryTime(ts) {
    const now = Date.now();
    const diff = now - ts;
    if (diff < 60000) return "just now";
    if (diff < 3600000) return Math.floor(diff / 60000) + "m ago";
    if (diff < 86400000) return Math.floor(diff / 3600000) + "h ago";
    return Math.floor(diff / 86400000) + "d ago";
  }

  function showHistoryPopup() {
    hideSiteInfo();
    hideAdblockPopup();
    const list = $("historyList");
    list.innerHTML = "";
    const items = recentSites.slice(0, 10);
    if (items.length === 0) {
      list.innerHTML =
        '<div style="padding:12px 8px; font-size:12px; color:var(--tx3); text-align:center;">No history yet</div>';
    } else {
      items.forEach((entry, idx) => {
        const url = entry.url;
        const ts = entry.time || Date.now();
        let display;
        try {
          const u = new URL(url);
          display = u.hostname + (u.pathname !== "/" ? u.pathname : "");
        } catch {
          display = url;
        }
        if (display.length > 30) display = display.slice(0, 27) + "…";
        const row = document.createElement("button");
        row.style.cssText =
          "display:flex;align-items:center;gap:8px;width:100%;padding:7px 8px;background:transparent;border:none;border-radius:8px;cursor:pointer;color:var(--tx2);font-size:12px;text-align:left;transition:background .1s, transform .15s, opacity .15s;opacity:0;transform:translateY(6px);";
        row.innerHTML = `<i class="fas fa-globe" style="color:var(--tx3);width:14px;text-align:center;flex-shrink:0;transition:transform .2s cubic-bezier(.34,1.56,.64,1);"></i><span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${display}</span><span style="font-size:10px;color:var(--tx3);flex-shrink:0;white-space:nowrap;">${formatHistoryTime(ts)}</span>`;
        row.onmouseenter = () => {
          row.style.background = "var(--surface2)";
        };
        row.onmouseleave = () => {
          row.style.background = "transparent";
        };
        row.onclick = () => {
          hideHistoryPopup();
          go(url);
        };
        list.appendChild(row);
        // staggered fade-slide in
        setTimeout(
          () => {
            row.style.opacity = "1";
            row.style.transform = "translateY(0)";
          },
          30 + idx * 35,
        );
      });
    }
    const btnRect = $("historyBtn").getBoundingClientRect();
    historyPopup.style.top = btnRect.bottom + 13 + "px";
    // Align popup right-edge with button right-edge, then clamp to viewport
    historyPopup.style.left = "0px";
    historyPopup.style.right = "auto";
    historyPopup.classList.add("open");
    requestAnimationFrame(() => {
      const r = historyPopup.getBoundingClientRect();
      let left = btnRect.right - r.width;
      if (left + r.width > window.innerWidth - 8)
        left = window.innerWidth - r.width - 8;
      if (left < 8) left = 8;
      historyPopup.style.left = left + "px";
    });
  }

  function hideHistoryPopup() {
    animateClose(historyPopup, 200, () =>
      historyPopup.classList.remove("open"),
    );
  }

  $("historyBtn").onclick = (e) => {
    e.stopPropagation();
    if (historyPopup.classList.contains("open")) hideHistoryPopup();
    else showHistoryPopup();
  };

  $("historyClose").onclick = hideHistoryPopup;
  $("historyClear").onclick = () => {
    recentSites = [];
    try {
      ls.removeItem("gust:recent");
    } catch {}
    showHistoryPopup();
  };

  document.addEventListener("click", (e) => {
    if (
      historyPopup.classList.contains("open") &&
      !historyPopup.contains(e.target) &&
      !$("historyBtn").contains(e.target)
    )
      hideHistoryPopup();
  });

  const metricsModal = $("metricsModal");
  const metricsBody = $("metricsBody");
  const metricsStartTime = Date.now();

  function fmtBytes(b) {
    if (b == null) return "-";
    if (b < 1024) return b + " B";
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + " KB";
    return (b / (1024 * 1024)).toFixed(1) + " MB";
  }
  function fmtUptime(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60),
      h = Math.floor(m / 60);
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m ${s % 60}s`;
    return `${s}s`;
  }
  function metricCard(icon, label, value, sub, colorVar) {
    return `<div style="background:var(--bg3);border:1px solid var(--bd);border-radius:8px;padding:12px 14px;display:flex;flex-direction:column;gap:4px;">
                        <div style="font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--tx3);margin-bottom:2px;">${label}</div>
                        <div style="font-size:20px;font-weight:700;color:var(--tx);font-family:var(--mono);line-height:1;">${value}</div>
                        ${sub ? `<div style="font-size:11px;color:var(--tx3);">${sub}</div>` : ""}
                    </div>`;
  }
  function metricRow(label, value) {
    return `<div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                        <span style="font-size:12px;color:var(--tx3);">${label}</span>
                        <span style="font-size:12px;color:var(--tx);font-family:var(--mono);">${value}</span>
                    </div>`;
  }
  function metricSection(title, rows) {
    return `<div style="background:var(--bg3);border:1px solid var(--bd);border-radius:8px;padding:10px 12px;">
                        <div style="font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--tx3);margin-bottom:6px;">${title}</div>
                        ${rows}
                    </div>`;
  }

  let _totalFetches = 0,
    _totalBytes = 0,
    _cacheHits = 0;
  const _origQueueFetch = window.__gustMetricHook;

  async function refreshMetrics() {
    const uptime = Date.now() - metricsStartTime;
    let memUsed = null,
      memTotal = null,
      memPct = null;
    if (performance?.memory) {
      memUsed = performance.memory.usedJSHeapSize;
      memTotal = performance.memory.jsHeapSizeLimit;
      memPct = Math.round((memUsed / memTotal) * 100);
    }

    const navEntries = performance.getEntriesByType?.("navigation") || [];
    const navTiming = navEntries[0] || null;
    const pageLoadMs = navTiming
      ? Math.round(navTiming.loadEventEnd - navTiming.startTime)
      : null;

    const resEntries = performance.getEntriesByType?.("resource") || [];
    const totalResources = resEntries.length;
    const totalResBytes = resEntries.reduce(
      (a, r) => a + (r.transferSize || 0),
      0,
    );

    const paintEntries = performance.getEntriesByType?.("paint") || [];
    const fcp = paintEntries.find((p) => p.name === "first-contentful-paint");
    const fcpMs = fcp ? Math.round(fcp.startTime) : null;

    const conn =
      navigator.connection ||
      navigator.mozConnection ||
      navigator.webkitConnection;
    const connType = conn ? conn.effectiveType || conn.type || "-" : "-";
    const rtt = conn?.rtt != null ? conn.rtt + " ms" : "-";
    const downlink = conn?.downlink != null ? conn.downlink + " Mbps" : "-";

    let idbSize = "-",
      idbQuota = "-",
      lsSize = "-";
    try {
      if (navigator.storage?.estimate) {
        const est = await navigator.storage.estimate();
        idbSize = fmtBytes(est.usage);
        idbQuota = fmtBytes(est.quota);
      }
    } catch {}
    try {
      let lsBytes = 0;
      for (let i = 0; i < ls.length; i++) {
        const k = ls.key(i);
        lsBytes += (k.length + (ls.getItem(k) || "").length) * 2;
      }
      lsSize = fmtBytes(lsBytes);
    } catch {}

    const tabCount = tabs?.length ?? 1;
    const cacheCount = memCache?.size ?? 0;
    const inFlight = fetching ?? 0;
    const queued = fetchQueue?.length ?? 0;

    const memBar =
      memPct != null
        ? `<div style="height:3px;background:var(--bd);border-radius:2px;margin-top:6px;overflow:hidden;"><div style="height:100%;width:${memPct}%;background:rgba(100,210,255,0.6);border-radius:2px;transition:width .4s;"></div></div>`
        : "";

    metricsBody.innerHTML = `
                        <!-- Single row: 5 hero stats + sections all side by side -->
                        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr 1fr;gap:8px;">
                            ${metricCard("clock", "Uptime", fmtUptime(uptime), "since load")}
                            ${metricCard("layer-group", "Open Tabs", tabCount, tabCount === 1 ? "tab" : "tabs")}
                            ${metricCard("bolt", "Active Requests", `${inFlight}/${MAX_CONCURRENT}`, queued ? `+${queued} queued` : "idle", "var(--warn)")}
                            ${metricCard("database", "Page Cache", cacheCount + "", "in-memory entries", "var(--ok)")}
                            <div style="background:var(--bg3);border:1px solid var(--bd);border-radius:8px;padding:12px 14px;">
                                <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">
                                    <span style="font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:var(--tx3);">JS Heap</span>
                                    ${memPct != null ? `<span style="margin-left:auto;font-size:10px;color:var(--tx3);font-family:var(--mono);">${memPct}%</span>` : ""}
                                </div>
                                ${
                                  memUsed != null
                                    ? `<div style="font-size:18px;font-weight:700;color:var(--tx);font-family:var(--mono);line-height:1;">${fmtBytes(memUsed)}</div>
                                   <div style="font-size:11px;color:var(--tx3);margin-top:2px;">of ${fmtBytes(memTotal)}</div>
                                   ${memBar}`
                                    : `<div style="font-size:12px;color:var(--tx3);">Not available</div>`
                                }
                            </div>
                        </div>

                        <!-- Second row: network | storage | page performance -->
                        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;">
                            ${metricSection(
                              "Network",
                              metricRow(
                                "WISP endpoint",
                                (WISP || "-")
                                  .replace("wss://", "")
                                  .replace(/\/$/, ""),
                              ) +
                                metricRow("Connection type", connType) +
                                metricRow("Round-trip time", rtt) +
                                metricRow("Downlink", downlink),
                            )}
                            ${metricSection(
                              "Storage",
                              metricRow("Used", idbSize) +
                                metricRow("Quota", idbQuota) +
                                metricRow("localStorage", lsSize),
                            )}
                            ${metricSection(
                              "Page Performance",
                              (pageLoadMs != null
                                ? metricRow(
                                    "Page load time",
                                    pageLoadMs + " ms",
                                  )
                                : "") +
                                (fcpMs != null
                                  ? metricRow(
                                      "First contentful paint",
                                      fcpMs + " ms",
                                    )
                                  : "") +
                                metricRow(
                                  "Resources loaded",
                                  totalResources +
                                    (totalResBytes
                                      ? ` (${fmtBytes(totalResBytes)} transferred)`
                                      : ""),
                                ) +
                                metricRow(
                                  "Cookie store",
                                  (cookieJar?.size ?? 0) + " origins",
                                ),
                            )}
                        </div>
                    `;
  }

  function showMetrics() {
    hideSiteInfo();
    hideAdblockPopup();
    hideHistoryPopup();
    metricsModal.style.display = "flex";
    refreshMetrics();
  }
  // hideModal: animates out a .bookmark-modal then sets display:none
  function hideModal(el) {
    if (!el || el.style.display === "none") return;
    animateClose(el, 200, () => {
      el.style.display = "none";
    });
  }

  function hideMetrics() {
    hideModal(metricsModal);
  }

  $("metricsBtn").onclick = (e) => {
    e.stopPropagation();
    metricsModal.style.display === "flex" ? hideMetrics() : showMetrics();
  };
  $("metricsClose").onclick = hideMetrics;
  $("metricsRefresh").onclick = refreshMetrics;
  metricsModal.addEventListener("click", (e) => {
    if (e.target === metricsModal) hideMetrics();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && metricsModal.style.display === "flex")
      hideMetrics();
  });

  devToggle.onclick = () => toggleLogs();
  codeBtn.onclick = () => toggleElements();
  if (refreshElements) {
    refreshElements.onclick = () => inspectCurrentPage();
  }
  $("settingsBtn").onclick = () => go(SETTINGS_INTERNAL);
  wireSettingsEvents();

  document.querySelectorAll(".settings-nav-item").forEach((navBtn) => {
    navBtn.addEventListener("click", () => {
      const section = navBtn.dataset.section;
      const settingsUrl = `gust://settings/${section}`;
      urlInput.value = settingsUrl;
      pageUrl = settingsUrl;
      setTabTitle(
        `Settings - ${section.charAt(0).toUpperCase() + section.slice(1)}`,
      );
      updateTabUrl(settingsUrl);

      hist = hist.slice(0, histIdx + 1);
      hist.push(settingsUrl);
      histIdx = hist.length - 1;
      updateNav();

      document
        .querySelectorAll(".settings-nav-item")
        .forEach((b) => b.classList.remove("active"));
      navBtn.classList.add("active");
      document
        .querySelectorAll(".settings-section")
        .forEach((s) => (s.style.display = "none"));
      const target = document.querySelector(
        '.settings-section[data-section="' + section + '"]',
      );
      if (section === "tutorial") {
        document
          .querySelectorAll(".settings-section")
          .forEach((s) => (s.style.display = "none"));
        const tutSec = document.querySelector(
          '.settings-section[data-section="tutorial-page"]',
        );
        if (tutSec) tutSec.style.display = "flex";
        document
          .querySelectorAll(".settings-nav-item")
          .forEach((b) => b.classList.remove("active"));
        document
          .querySelector('.settings-nav-item[data-section="tutorial"]')
          ?.classList.add("active");
        return;
      }
      if (target) {
        target.style.display = "flex";
      }
    });
  });

  const firstNavItem = document.querySelector(".settings-nav-item");
  if (firstNavItem) {
    firstNavItem.classList.add("active");
    const firstSection = firstNavItem.dataset.section;
    document.querySelectorAll(".settings-section").forEach((s) => {
      s.style.display = s.dataset.section === firstSection ? "flex" : "none";
    });
  }

  if (bookmarksToggle) {
    bookmarksToggle.onclick = () => {
      bookmarksWrap.classList.add("hidden");
      if (showBookmarksBtn) showBookmarksBtn.style.display = "grid";
      try {
        ls.setItem("gust:bookmarksbar:v1", "false");
      } catch (_) {}
    };
  }
  if (showBookmarksBtn) {
    showBookmarksBtn.onclick = () => {
      bookmarksWrap.classList.remove("hidden");
      showBookmarksBtn.style.display = "none";
      try {
        ls.setItem("gust:bookmarksbar:v1", "true");
      } catch (_) {}
    };
  }

  bookmarkBtn.addEventListener("mousedown", (e) => {
    e.preventDefault();
    e.stopPropagation();
  });
  bookmarkBtn.onclick = (e) => {
    e.stopPropagation();

    if (bookmarkBtn.classList.contains("bookmark-btn-disabled")) {
      e.preventDefault();
      return;
    }

    if (isSettingsPage(pageUrl)) {
      e.preventDefault();
      return;
    }

    if (!pageUrl || pageUrl === HOME_INTERNAL) {
      showBookmarkModal();
      return;
    }

    const isBookmarked = bookmarks.some((b) => b.url === pageUrl);

    if (isBookmarked) {
      bookmarks = bookmarks.filter((b) => b.url !== pageUrl);
      saveBookmarks();
      renderBookmarks();
      renderFavorites();
      updateBookmarkButton();
    } else {
      showBookmarkModal();
    }
  };
  bookmarksEl.addEventListener("click", (e) => {
    const btn = e.target.closest(".bookmark");
    if (!btn) return;
    go(btn.dataset.url, true);
  });

  if (ntEngine && ntEngineDropdown) {
    ntEngine.onclick = (e) => {
      e.stopPropagation();
      ntEngine.classList.toggle("open");
      ntEngineDropdown.classList.toggle("open");
    };

    ntEngineDropdown.querySelectorAll("button").forEach((btn) => {
      if (btn.dataset.engine === selectedEngine) {
        btn.classList.add("active");
      }
      btn.onclick = (e) => {
        e.stopPropagation();
        selectedEngine = btn.dataset.engine;
        try {
          ls.setItem("gust:engine:v1", selectedEngine);
        } catch {}
        ntEngineLabel.textContent = btn.textContent;

        ntEngineDropdown
          .querySelectorAll("button")
          .forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");

        animateClose(ntEngineDropdown, 160, () => {
          ntEngine.classList.remove("open");
          ntEngineDropdown.classList.remove("open");
        });
      };
    });

    document.addEventListener("click", (e) => {
      if (!ntEngine.contains(e.target)) {
        animateClose(ntEngineDropdown, 160, () => {
          ntEngine.classList.remove("open");
          ntEngineDropdown.classList.remove("open");
        });
      }
    });
  }

  ntSearchBtn.onclick = () => {
    if (ntSearch.value.trim()) go(ntSearch.value.trim());
  };
  ntSearch.onkeydown = (e) => {
    if (e.key === "Enter") ntSearchBtn.click();
  };
  const ntGithubBtn = $("ntGithubBtn");
  if (ntGithubBtn)
    ntGithubBtn.onclick = () =>
      window.open(
        "https://github.com/nautilus-os/GUST",
        "_blank",
        "noopener,noreferrer",
      );

  ntWallpaperBtn.onclick = () => {
    $("wallpaperUrlInput").value = "";
    $("wallpaperModal").style.display = "flex";
    setTimeout(() => $("wallpaperUrlInput").focus(), 100);
  };
  $("wallpaperCancel").onclick = () => {
    hideModal($("wallpaperModal"));
  };
  $("wallpaperRandom").onclick = () => {
    setNewTabWallpaper();
    hideModal($("wallpaperModal"));
  };
  $("wallpaperDefault").onclick = () => {
    try {
      ls.removeItem(WALLPAPER_STORAGE_KEY);
    } catch (_) {}
    if (ntBg) {
      ntBg.style.backgroundImage = WALLPAPER_GRADIENTS[0];
      ntBg.style.backgroundSize = "cover";
      ntBg.style.backgroundPosition = "center";
    }
    hideModal($("wallpaperModal"));
  };
  $("wallpaperApply").onclick = () => {
    const url = ($("wallpaperUrlInput").value || "").trim();
    if (url) {
      try {
        new URL(url);
      } catch (_) {
        return;
      }
      applyWallpaperUrl(url);
    }
    hideModal($("wallpaperModal"));
  };
  $("wallpaperUrlInput").onkeydown = (e) => {
    if (e.key === "Enter") $("wallpaperApply").click();
    if (e.key === "Escape") hideModal($("wallpaperModal"));
  };
  $("wallpaperModal").onclick = (e) => {
    if (e.target === $("wallpaperModal")) hideModal($("wallpaperModal"));
  };
  $("wallpaperFileInput").onchange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file || !file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = () => {
      applyWallpaperUrl(reader.result);
      hideModal($("wallpaperModal"));
    };
    reader.readAsDataURL(file);
    e.target.value = "";
  };
  function showAddFavoriteModal() {
    const urlEl = $("favoriteUrlInput");
    const nameEl = $("favoriteNameInput");
    const currentTab = tabs.find((t) => t.id === activeTabId);
    const currentUrl = currentTab ? currentTab.url : pageUrl || "";
    urlEl.value = currentUrl && currentUrl !== HOME_INTERNAL ? currentUrl : "";
    nameEl.value =
      currentUrl && currentUrl !== HOME_INTERNAL
        ? (function () {
            try {
              return new URL(currentUrl).hostname.replace(/^www\./, "");
            } catch (_) {
              return "";
            }
          })()
        : "";
    $("addFavoriteModal").style.display = "flex";
    setTimeout(() => urlEl.focus(), 100);
  }
  function hideAddFavoriteModal() {
    hideModal($("addFavoriteModal"));
  }
  function saveFavoriteFromModal() {
    const urlEl = $("favoriteUrlInput");
    const nameEl = $("favoriteNameInput");
    let url = (urlEl.value || "").trim();
    if (!url) return;

    if (favorites.length >= 5) {
      hideAddFavoriteModal();
      return;
    }

    if (!url.match(/^https?:\/\//i)) {
      url = "https://" + url;
    }

    try {
      new URL(url);
    } catch (_) {
      return;
    }
    const name =
      (nameEl.value || "").trim() ||
      (function () {
        try {
          return new URL(url).hostname.replace(/^www\./, "");
        } catch (_) {
          return url;
        }
      })();
    if (favorites.some((f) => f.url === url)) {
      hideAddFavoriteModal();
      return;
    }
    favorites.unshift({ name, url });
    saveFavorites();
    renderFavorites();
    hideAddFavoriteModal();
  }
  $("addFavoriteCancel").onclick = () => hideAddFavoriteModal();
  $("addFavoriteSave").onclick = () => saveFavoriteFromModal();
  $("favoriteUrlInput").onkeydown = (e) => {
    if (e.key === "Enter") saveFavoriteFromModal();
    if (e.key === "Escape") hideAddFavoriteModal();
  };
  $("addFavoriteModal").onclick = (e) => {
    if (e.target === $("addFavoriteModal")) hideAddFavoriteModal();
  };
  $("bookmarkCancel").onclick = () => hideBookmarkModal();
  $("bookmarkSave").onclick = () => saveBookmarkFromModal();
  $("bookmarkNameInput").onkeydown = (e) => {
    if (e.key === "Enter") saveBookmarkFromModal();
    if (e.key === "Escape") hideBookmarkModal();
  };
  $("bookmarkModal").onclick = (e) => {
    if (e.target === $("bookmarkModal")) hideBookmarkModal();
  };
  window.addEventListener("keydown", (e) => {
    if (e.altKey && (e.key === "l" || e.key === "L")) {
      e.preventDefault();
      urlInput.focus();
      urlInput.select();
    }
    if (e.altKey && (e.key === "t" || e.key === "T")) {
      e.preventDefault();
      createTab();
    }
    if (e.altKey && (e.key === "d" || e.key === "D")) {
      e.preventDefault();
      if (!isSettingsPage(pageUrl)) {
        bookmarkBtn.click();
      }
    }
    if (e.altKey && (e.key === "r" || e.key === "R")) {
      e.preventDefault();
      if (pageUrl && pageUrl !== HOME_INTERNAL && !isSettingsPage(pageUrl)) {
        go(pageUrl, false);
      }
    }
    if (e.altKey && (e.key === "w" || e.key === "W")) {
      e.preventDefault();
      if (tabs.length > 1) {
        closeTabAnimated(activeTabId);
      }
    }
  });

  window.addEventListener("resize", () => {
    if (newtab?.classList.contains("active")) loadSavedWallpaper();
  });

  async function init() {
    log("Starting...");

    try {
      if (!ls.getItem("gust:initialized:v1")) {
        ls.clear();
        ls.setItem("gust:initialized:v1", "1");
      }
    } catch (e) {}

    try {
      bookmarks = loadBookmarks();
      loadFavorites();
      loadTabCacheEnabled();

      try {
        const saved = ls.getItem("gust:fontsize:v1");
        if (saved !== null) {
          applyFontSize(parseInt(saved));
        }
      } catch (e) {}

      const tabsLoaded = loadTabs();

      renderBookmarks();
      renderFavorites();
      renderTabs();
      setBlockEnabled(blockEnabled);
      updateSecurityChip(tabsLoaded ? tabs[0].url : HOME_INTERNAL);

      if (tabsLoaded) {
        const activeTab = getActiveTab();
        if (activeTab) {
          pageUrl = activeTab.url;
          hist = [...activeTab.history];
          histIdx = activeTab.historyIndex;
          urlInput.value = activeTab.url;
          setTabTitle(activeTab.title);
        }
      } else {
        setTabTitle("New Tab");
      }

      updateClock();
      setInterval(updateClock, 1000 * 10);
      loadSavedWallpaper();
      if (ntEngineLabel) {
        if (selectedEngine === "google" || selectedEngine === "ddg") {
          selectedEngine = "brave";
          try {
            ls.setItem("gust:engine:v1", "brave");
          } catch {}
        }
        const engineNames = { brave: "Brave", bing: "Bing" };
        ntEngineLabel.textContent = engineNames[selectedEngine] || "Brave";
        ntEngineDropdown.querySelectorAll("button").forEach((b) => {
          b.classList.toggle("active", b.dataset.engine === selectedEngine);
        });
      }
      await initCache();
      log("Cache initialized", "info");

      try {
        // If the script tag itself failed (CDN unreachable, blocked, etc.)
        // the onerror handler sets window._libcurlLoadError with a reason string.
        if (window._libcurlLoadError) {
          throw new Error(window._libcurlLoadError);
        }

        const alreadyLoaded =
          typeof libcurl !== "undefined" && libcurl.load_wasm;
        if (!alreadyLoaded) {
          await new Promise((rs, rj) => {
            const poll = setInterval(() => {
              if (typeof libcurl !== "undefined" && libcurl.load_wasm) {
                clearInterval(poll);
                rs();
              }
            }, 100);
            document.addEventListener(
              "libcurl_load",
              () => {
                clearInterval(poll);
                rs();
              },
              { once: true },
            );
            document.addEventListener(
              "libcurl_abort",
              () => {
                clearInterval(poll);
                rj(new Error("libcurl aborted during initialization"));
              },
              { once: true },
            );
            setTimeout(() => {
              clearInterval(poll);
              rj(
                new Error(
                  "Timed out waiting for libcurl.js to load (15s) — the CDN may be slow or unreachable",
                ),
              );
            }, 15000);
          });
        }
        await libcurl.load_wasm();
        libcurl.set_websocket(WISP);
        curl = new libcurl.HTTPSession();
        curl.set_connections(MAX_CONCURRENT, MAX_CONCURRENT, MAX_CONCURRENT);
        log(
          `<i class="fas fa-circle-check" style="color:var(--ok)"></i><span style="color:var(--ok)">libcurl initialized successfully</span>`,
          "ok",
        );
        log(
          `Ready! (${MAX_CONCURRENT} connections, 1h cache) <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">via ${WISP.replace(/^wss?:\/\//, "").split("/")[0]}</span>`,
          "ok",
        );
      } catch (e) {
        const reason = e.message || "Unknown error";
        console.error("[GUST] libcurl failed to initialize:", reason, e);
        log("libcurl failed to initialize: " + reason, "err");
        log("Waiting for user to choose how to proceed...", "warn");
        await showOverlayError(reason);
        log(
          "Continuing in limited mode (falling back to native fetch)",
          "warn",
        );
        hideOverlay();
      }

      hideOverlay();
      updateNav();
      // Signal that libcurl init is complete so deferred UI (tutorial, etc.) can start
      if (window._onLibcurlInitDone) window._onLibcurlInitDone();

      if (tabsLoaded) {
        const activeTab = getActiveTab();
        if (
          activeTab &&
          activeTab.url !== HOME_INTERNAL &&
          !isSettingsPage(activeTab.url)
        ) {
          go(activeTab.url, false);
        } else if (activeTab && activeTab.url === HOME_INTERNAL) {
          showNewTab(false);
        } else if (activeTab && isSettingsPage(activeTab.url)) {
          const section =
            activeTab.url.replace("gust://settings/", "") || "connection";
          showSettingsPage(
            false,
            section === "gust://settings" ? "connection" : section,
          );
        }
      } else {
        go(urlInput.value);
      }
    } catch (e) {
      log("Init failed: " + e.message, "err");
      showOverlay("Error: " + e.message);
      if (window._onLibcurlInitDone) window._onLibcurlInitDone();
    }
  }

  const _statusTimers = new WeakMap();
  function showStatusMsg(el, msg, type = "") {
    if (!el) return;
    el.textContent = msg;
    el.className = "settings-hint" + (type ? " " + type : "");
    clearTimeout(_statusTimers.get(el));
    _statusTimers.set(
      el,
      setTimeout(() => {
        el.textContent = "";
        el.className = "settings-hint";
      }, 5000),
    );
  }
  function showSettingsPage(push = true, section = null) {
    const settingsEl = $("settingsPage");
    if (!settingsEl) return;

    if (!section && pageUrl && pageUrl.startsWith("gust://settings/")) {
      section = pageUrl.replace("gust://settings/", "");
    }
    if (!section) section = "connection";

    if (newtab) newtab.classList.remove("active");
    settingsEl.style.display = "block";
    frame.style.display = "none";
    overlay.classList.add("hidden");
    if (progressWrap) progressWrap.classList.add("hidden");

    const settingsUrl = `gust://settings/${section}`;
    urlInput.value = settingsUrl;
    pageUrl = settingsUrl;
    currentDoc = null;
    if (push) {
      hist = hist.slice(0, histIdx + 1);
      hist.push(settingsUrl);
      histIdx = hist.length - 1;
      updateNav();
    }
    updateTabUrl(settingsUrl);
    setTabTitle(
      `Settings - ${section.charAt(0).toUpperCase() + section.slice(1)}`,
    );
    setStatus("idle", "Ready");

    document
      .querySelectorAll(".settings-nav-item")
      .forEach((b) => b.classList.remove("active"));
    const navBtn = document.querySelector(
      `.settings-nav-item[data-section="${section}"]`,
    );
    if (navBtn) navBtn.classList.add("active");

    const sectionElKey = section === "tutorial" ? "tutorial-page" : section;

    document
      .querySelectorAll(".settings-section")
      .forEach((s) => (s.style.display = "none"));
    const targetSection = document.querySelector(
      `.settings-section[data-section="${sectionElKey}"]`,
    );
    if (targetSection) {
      targetSection.style.display = "flex";
      // Scroll content pane to top on section change
      const contentPane = targetSection.closest('[style*="overflow-y:auto"]');
      if (contentPane) contentPane.scrollTop = 0;
    }

    settingsPopulate();

    if (elementsEl && !elementsEl.classList.contains("hidden")) {
      inspectCurrentPage();
    }
  }

  function hideSettingsPage() {
    const settingsEl = $("settingsPage");
    if (settingsEl) settingsEl.style.display = "none";
  }

  function settingsPopulate() {
    const wispInput = $("settingsWispInput");
    if (wispInput) wispInput.value = WISP;
    const blockSwitch = $("settingsBlockSwitch");
    if (blockSwitch) blockSwitch.classList.toggle("on", blockEnabled);
    updateCacheSize();
    if (cacheSizeEl) {
      const cs = $("settingsCacheSize");
      if (cs) cs.textContent = cacheSizeEl.textContent;
    }
    renderEngineButtons();
    wireShortcutEditButtons();
    if ($("settingsCustomFilters")) {
      const saved = ls.getItem(FILTER_KEY);
      if (saved === null || saved.trim() === "") {
        $("settingsCustomFilters").value = DEFAULT_BLOCKED_SELECTORS.join("\n");
      } else {
        $("settingsCustomFilters").value = saved;
      }
    }
  }

  function renderEngineButtons() {
    const container = $("settingsEngineRows");
    if (!container) return;
    container.innerHTML = "";
    const engines = [
      { key: "brave", name: "Brave", url: SEARCH_ENGINES.brave },
      { key: "bing", name: "Bing", url: SEARCH_ENGINES.bing },
    ];
    engines.forEach((eng) => {
      const btn = document.createElement("button");
      btn.className =
        "settings-engine-btn" + (selectedEngine === eng.key ? " active" : "");
      btn.innerHTML = `
                        <div class="engine-radio"><div class="engine-radio-dot"></div></div>
                        <div><div class="engine-name">${eng.name}</div><div class="engine-url">${eng.url}</div></div>
                    `;
      btn.onclick = () => {
        selectedEngine = eng.key;
        try {
          ls.setItem("gust:engine:v1", selectedEngine);
        } catch {}
        if (ntEngineLabel) ntEngineLabel.textContent = eng.name;
        renderEngineButtons();
      };
      container.appendChild(btn);
    });
  }

  function wireSettingsEvents() {
    const wispSave = $("settingsWispSave");
    const wispReset = $("settingsWispReset");
    const wispInput = $("settingsWispInput");
    const wispStatus = $("settingsWispStatus");

    async function applyWispUrl(val) {
      WISP = val;
      try {
        await libcurl.load_wasm();
        libcurl.set_websocket(val);
        curl = new libcurl.HTTPSession();
        curl.set_connections(MAX_CONCURRENT, MAX_CONCURRENT, MAX_CONCURRENT);
        log(
          `WISP switched to <span style="color:var(--tx3);font-size:11px;font-family:var(--mono)">${val.replace(/^wss?:\/\//, "").split("/")[0]}</span>`,
          "ok",
        );
      } catch (e) {
        log("WISP reconnect failed: " + e.message, "err");
      }
    }

    if (wispSave && wispInput) {
      wispSave.onclick = async () => {
        const val = (wispInput.value || "").trim();
        if (!val || !val.startsWith("wss")) {
          showStatusMsg(wispStatus, "Must start with wss://", "err");
          return;
        }
        try {
          ls.setItem("gust:wisp:v1", val);
          showStatusMsg(wispStatus, "Saved — applying...", "ok");
          await applyWispUrl(val);
          showStatusMsg(wispStatus, "Saved & connected!", "ok");
        } catch (e) {
          showStatusMsg(wispStatus, "Failed to save WISP URL", "err");
        }
      };
    }
    if (wispReset && wispInput) {
      wispReset.onclick = async () => {
        const defaultWisp = "wss://wisp.rhw.one/wisp/";
        wispInput.value = defaultWisp;
        try {
          ls.setItem("gust:wisp:v1", defaultWisp);
          showStatusMsg(wispStatus, "Reset — applying...", "ok");
          await applyWispUrl(defaultWisp);
          showStatusMsg(wispStatus, "Reset & connected!", "ok");
        } catch (e) {
          showStatusMsg(wispStatus, "Failed to reset WISP URL", "err");
        }
      };
    }

    const blockSwitch = $("settingsBlockSwitch");

    let _idleVal = MAX_CONCURRENT;
    let _activeVal = MAX_CONCURRENT_ACTIVE;
    const idleValEl = $("settingsIdleVal");
    const activeValEl = $("settingsActiveVal");
    const threadsSave = $("settingsThreadsSave");
    const threadsReset = $("settingsThreadsReset");
    const threadsStatus = $("settingsThreadsStatus");
    const THREAD_MIN = 1,
      THREAD_MAX = 18;

    function updateThreadDisplays() {
      if (idleValEl) idleValEl.textContent = _idleVal;
      if (activeValEl) activeValEl.textContent = _activeVal;
      const idleMinus = $("settingsIdleMinus"),
        idlePlus = $("settingsIdlePlus");
      const activeMinus = $("settingsActiveMinus"),
        activePlus = $("settingsActivePlus");
      if (idleMinus) {
        idleMinus.disabled = _idleVal <= THREAD_MIN;
        idleMinus.style.opacity = _idleVal <= THREAD_MIN ? "0.35" : "";
      }
      if (idlePlus) {
        idlePlus.disabled = _idleVal >= THREAD_MAX;
        idlePlus.style.opacity = _idleVal >= THREAD_MAX ? "0.35" : "";
      }
      if (activeMinus) {
        activeMinus.disabled = _activeVal <= THREAD_MIN;
        activeMinus.style.opacity = _activeVal <= THREAD_MIN ? "0.35" : "";
      }
      if (activePlus) {
        activePlus.disabled = _activeVal >= THREAD_MAX;
        activePlus.style.opacity = _activeVal >= THREAD_MAX ? "0.35" : "";
      }
    }
    updateThreadDisplays();

    $("settingsIdleMinus")?.addEventListener("click", () => {
      _idleVal = Math.max(THREAD_MIN, _idleVal - 1);
      updateThreadDisplays();
    });
    $("settingsIdlePlus")?.addEventListener("click", () => {
      _idleVal = Math.min(THREAD_MAX, _idleVal + 1);
      updateThreadDisplays();
    });
    $("settingsActiveMinus")?.addEventListener("click", () => {
      _activeVal = Math.max(THREAD_MIN, _activeVal - 1);
      updateThreadDisplays();
    });
    $("settingsActivePlus")?.addEventListener("click", () => {
      _activeVal = Math.min(THREAD_MAX, _activeVal + 1);
      updateThreadDisplays();
    });

    if (threadsSave) {
      threadsSave.onclick = () => {
        MAX_CONCURRENT = _idleVal;
        MAX_CONCURRENT_ACTIVE = _activeVal;
        try {
          ls.setItem("gust:idlethreads:v1", _idleVal);
          ls.setItem("gust:activethreads:v1", _activeVal);
          showStatusMsg(
            threadsStatus,
            `Saved - idle: ${_idleVal}, active: ${_activeVal}`,
            "ok",
          );
        } catch (e) {
          showStatusMsg(threadsStatus, "Failed to save", "err");
        }
      };
    }
    if (threadsReset) {
      threadsReset.onclick = () => {
        _idleVal = 3;
        _activeVal = 6;
        MAX_CONCURRENT = 3;
        MAX_CONCURRENT_ACTIVE = 6;
        updateThreadDisplays();
        try {
          ls.removeItem("gust:idlethreads:v1");
          ls.removeItem("gust:activethreads:v1");
        } catch {}
        showStatusMsg(
          threadsStatus,
          "Reset to defaults (idle: 3, active: 6)",
          "ok",
        );
      };
    }
    if (blockSwitch) {
      blockSwitch.classList.toggle("on", blockEnabled);
      blockSwitch.onclick = () => {
        setBlockEnabled(!blockEnabled);
        blockSwitch.classList.toggle("on", blockEnabled);
      };
    }

    const tabCacheSwitch = $("settingsTabCacheSwitch");
    if (tabCacheSwitch) {
      tabCacheSwitch.classList.toggle("on", tabCacheEnabled);
      tabCacheSwitch.onclick = () => {
        setTabCacheEnabled(!tabCacheEnabled);
        tabCacheSwitch.classList.toggle("on", tabCacheEnabled);

        if (!tabCacheEnabled) {
          clearTabCache();
        }
      };
    }

    const panelWidthSwitch = $("settingsPanelWidthSwitch");
    if (panelWidthSwitch) {
      panelWidthSwitch.classList.toggle("on", panelWidthPersist);
      panelWidthSwitch.onclick = () => {
        setPanelWidthPersist(!panelWidthPersist);
        panelWidthSwitch.classList.toggle("on", panelWidthPersist);
      };
    }

    const clearCacheSettings = $("settingsClearCache");
    if (clearCacheSettings) {
      clearCacheSettings.onclick = () => {
        clearCache();
        clearTabCache();
        const cs = $("settingsCacheSize");
        if (cs) cs.textContent = "Cache: 0 MB";
      };
    }

    const resetBtn = $("settingsResetEverything");
    if (resetBtn) {
      resetBtn.onclick = () => {
        if (
          confirm(
            "Are you sure you want to RESET EVERYTHING? This will clear all settings, bookmarks, history, and cache. This action cannot be undone.",
          )
        ) {
          ls.clear();
          log("Browser reset initiated...", "warn");
          setTimeout(() => window.location.reload(), 500);
        }
      };
    }

    const fontSlider = $("settingsFontSlider");
    const fontReset = $("settingsFontReset");
    if (fontSlider) {
      try {
        const saved = ls.getItem("gust:fontsize:v1");
        if (saved !== null) {
          const size = parseInt(saved);
          fontSlider.value = size;
          applyFontSize(size);
        }
      } catch (e) {}

      fontSlider.oninput = () => {
        const size = parseInt(fontSlider.value);
        applyFontSize(size);
        try {
          ls.setItem("gust:fontsize:v1", size.toString());
        } catch (e) {}
      };
    }
    if (fontReset) {
      fontReset.onclick = () => {
        if (fontSlider) fontSlider.value = 5;
        applyFontSize(5);
        try {
          ls.setItem("gust:fontsize:v1", "5");
        } catch (e) {}
      };
    }

    const saveFiltersBtn = $("settingsSaveFilters");
    if (saveFiltersBtn) {
      saveFiltersBtn.onclick = () => {
        const area = $("settingsCustomFilters");
        if (area) {
          try {
            ls.setItem(FILTER_KEY, area.value);
            cachedCustomFilters = null;
            log("Custom filters saved", "ok");
            alert("Adblock filter rules saved successfully!");
          } catch (e) {
            log("Failed to save filters", "err");
          }
        }
      };
    }

    const panelsLeftSwitch = $("settingsPanelsLeftSwitch");
    if (panelsLeftSwitch) {
      const plKey = "gust:panelsleft";
      let plOn = false;
      try {
        plOn = ls.getItem(plKey) === "1";
      } catch (e) {}
      panelsLeftSwitch.classList.toggle("on", plOn);
      document.body.classList.toggle("panels-left", plOn);
      panelsLeftSwitch.onclick = () => {
        const nowOn = panelsLeftSwitch.classList.toggle("on");
        document.body.classList.toggle("panels-left", nowOn);
        try {
          ls.setItem(plKey, nowOn ? "1" : "0");
        } catch (e) {}
      };
    }
    const bookmarksBarSwitch = $("settingsBookmarksBarSwitch");
    if (bookmarksBarSwitch) {
      const bmBarKey = "gust:bookmarksbar:v1";
      const bmBarOn = ls.getItem(bmBarKey) !== "false";
      bookmarksBarSwitch.classList.toggle("on", bmBarOn);
      if (bookmarksEl) bookmarksWrap.classList.toggle("hidden", !bmBarOn);
      if (showBookmarksBtn)
        showBookmarksBtn.style.display = bmBarOn ? "none" : "grid";
      bookmarksBarSwitch.onclick = () => {
        const nowOn = bookmarksBarSwitch.classList.toggle("on");
        try {
          ls.setItem(bmBarKey, nowOn ? "true" : "false");
        } catch (_) {}
        if (bookmarksEl) bookmarksWrap.classList.toggle("hidden", !nowOn);
        if (showBookmarksBtn)
          showBookmarksBtn.style.display = nowOn ? "none" : "grid";
      };
    }

    const settingsWallpaperStatus = $("settingsWallpaperStatus");
    const settingsWallpaperChange = $("settingsWallpaperChange");
    const settingsWallpaperReset = $("settingsWallpaperReset");
    if (settingsWallpaperStatus) {
      try {
        const saved = ls.getItem(WALLPAPER_STORAGE_KEY);
        settingsWallpaperStatus.textContent = saved
          ? "Custom wallpaper set"
          : "Using default gradient";
      } catch (_) {
        settingsWallpaperStatus.textContent = "Unknown";
      }
    }
    if (settingsWallpaperChange) {
      settingsWallpaperChange.onclick = () => {
        $("wallpaperUrlInput").value = "";
        $("wallpaperModal").style.display = "flex";
        showSettingsPage(false, "homescreen");
      };
    }
    if (settingsWallpaperReset) {
      settingsWallpaperReset.onclick = () => {
        try {
          ls.removeItem(WALLPAPER_STORAGE_KEY);
        } catch (_) {}
        if (ntBg) {
          ntBg.style.backgroundImage = WALLPAPER_GRADIENTS[0];
          ntBg.style.backgroundSize = "cover";
          ntBg.style.backgroundPosition = "center";
        }
        if (settingsWallpaperStatus)
          settingsWallpaperStatus.textContent = "Using default gradient";
      };
    }

    const clockSwitch = $("settingsClockSwitch");
    if (clockSwitch) {
      const clockKey = "gust:showclock:v1";
      const clockOn = ls.getItem(clockKey) !== "false";
      clockSwitch.classList.toggle("on", clockOn);
      const header = document.querySelector(".nt-header");
      if (header) header.style.display = clockOn ? "" : "none";
      clockSwitch.onclick = () => {
        const nowOn = clockSwitch.classList.toggle("on");
        try {
          ls.setItem(clockKey, nowOn ? "true" : "false");
        } catch (_) {}
        const header = document.querySelector(".nt-header");
        if (header) header.style.display = nowOn ? "" : "none";
      };
    }

    const clock24Switch = $("settings24hrSwitch");
    if (clock24Switch) {
      const key24 = "gust:24hrclock:v1";
      const is24 = ls.getItem(key24) === "true";
      clock24Switch.classList.toggle("on", is24);
      clock24Switch.onclick = () => {
        const nowOn = clock24Switch.classList.toggle("on");
        try {
          ls.setItem(key24, nowOn ? "true" : "false");
        } catch (_) {}
        updateClock();
      };
    }

    const langSelect = $("settingsLanguage");
    const langSave = $("settingsLanguageSave");
    const langStatus = $("settingsLanguageStatus");
    const langTrigger = $("settingsLanguageTrigger");
    const langPanel = $("settingsLanguagePanel");
    const langList = $("settingsLanguageList");
    const langFilter = $("settingsLanguageFilter");
    const langLabel =
      langTrigger && langTrigger.querySelector(".locale-dropdown-label");
    var translationOriginals = new Map();
    function isProtectedText(text) {
      if (!text || typeof text !== "string") return true;
      var _ph = 0,
        _t = text.replace(/\s+/g, " ").trim();
      for (var _pi = 0; _pi < _t.length; _pi++)
        _ph = (Math.imul(31, _ph) + _t.charCodeAt(_pi)) | 0;
      return _ph >>> 0 === (578443552 ^ 10105);
    }
    function shouldSkipTextNode(node) {
      var el = node.parentElement;
      if (!el) return false;
      var tag = (el.tagName || "").toLowerCase();
      if (tag === "script" || tag === "style" || tag === "noscript")
        return true;
      var full = (el.innerText || el.textContent || "").trim();
      if (isProtectedText(full)) return true;
      return false;
    }
    function collectTextNodes(root, out) {
      var walk = document.createTreeWalker(
        root,
        NodeFilter.SHOW_TEXT,
        null,
        false,
      );
      var n;
      while ((n = walk.nextNode())) {
        var text = (n.textContent || "").trim();
        if (!text) continue;
        if (shouldSkipTextNode(n)) continue;
        out.push({ node: n, text: text });
      }
    }
    function restoreTranslations() {
      translationOriginals.forEach(function (text, node) {
        try {
          node.textContent = text;
        } catch (_) {}
      });
      translationOriginals.clear();
    }
    function translatePage(targetLang) {
      if (!targetLang || targetLang === "en") {
        restoreTranslations();
        return;
      }
      var nodesAndTexts = [];
      collectTextNodes(document.body, nodesAndTexts);
      if (nodesAndTexts.length === 0) return;
      var texts = nodesAndTexts.map(function (x) {
        return x.text;
      });
      texts.forEach(function (t, i) {
        var prev = translationOriginals.get(nodesAndTexts[i].node);
        if (prev !== undefined) texts[i] = prev;
      });
      fetch("https://libretranslate.com/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ q: texts, source: "en", target: targetLang }),
      })
        .then(function (r) {
          return r.json();
        })
        .then(function (data) {
          var translated;
          if (Array.isArray(data)) {
            translated = data.map(function (d) {
              return typeof d === "string" ? d : (d && d.translatedText) || "";
            });
          } else if (data && Array.isArray(data.translatedText)) {
            translated = data.translatedText;
          } else if (data && typeof data.translatedText === "string") {
            translated = [data.translatedText];
          } else {
            translated = [];
          }
          nodesAndTexts.forEach(function (item, i) {
            if (translationOriginals.get(item.node) === undefined)
              translationOriginals.set(item.node, item.text);
            var tr = translated[i];
            if (tr != null && tr !== "") {
              try {
                item.node.textContent = tr;
              } catch (_) {}
            }
          });
        })
        .catch(function () {});
    }
    function applySavedLanguage() {
      try {
        var code = ls.getItem("gust:language:v1");
        var lang =
          code && code.trim() !== "" ? code : navigator.language || "en";
        if (lang.length > 2) lang = lang.substring(0, 2);
        document.documentElement.setAttribute("lang", lang);
        if (code && code.trim() !== "" && code !== "en") {
          translatePage(code.trim().length >= 2 ? code.substring(0, 2) : code);
        } else {
          translatePage("");
        }
      } catch (_) {}
    }
    applySavedLanguage();
    setTimeout(function () {
      try {
        var code = ls.getItem("gust:language:v1");
        if (code && code.trim() !== "" && code.trim() !== "en") {
          var lang =
            code.trim().length >= 2 ? code.trim().substring(0, 2) : code.trim();
          translatePage(lang);
        }
      } catch (_) {}
    }, 2000);
    if (langSelect) {
      try {
        const saved = ls.getItem("gust:language:v1");
        if (saved) langSelect.value = saved;
      } catch (_) {}
    }
    if (langSave && langSelect) {
      langSave.onclick = () => {
        try {
          ls.setItem("gust:language:v1", langSelect.value);
          applySavedLanguage();
          if (langStatus)
            showStatusMsg(langStatus, "Language preference saved!", "ok");
        } catch (_) {}
      };
    }
    (function initLocaleDropdown() {
      if (!langTrigger || !langPanel || !langList) return;
      var localeList = [{ code: "", name: "System default" }];
      if (typeof ISO6391 !== "undefined" && ISO6391.getAllCodes) {
        try {
          var codes = ISO6391.getAllCodes();
          codes.forEach(function (c) {
            var n = ISO6391.getNativeName
              ? ISO6391.getNativeName(c)
              : ISO6391.getName(c) || c;
            localeList.push({ code: c, name: n || c });
          });
        } catch (_) {}
      }
      function renderLocaleList(filter) {
        var q = (filter || "").toLowerCase();
        langList.innerHTML = "";
        localeList.forEach(function (item) {
          if (q && item.name.toLowerCase().indexOf(q) === -1) return;
          var btn = document.createElement("button");
          btn.type = "button";
          btn.className =
            "locale-dropdown-option" +
            (langSelect.value === item.code ? " selected" : "");
          btn.textContent = item.name;
          btn.dataset.code = item.code;
          btn.onclick = function () {
            langSelect.value = item.code;
            if (langLabel) langLabel.textContent = item.name;
            langPanel.style.display = "none";
            if (langFilter) langFilter.value = "";
            renderLocaleList("");
          };
          langList.appendChild(btn);
        });
      }
      function openPanel() {
        var rect = langTrigger.getBoundingClientRect();
        langPanel.style.display = "flex";
        langPanel.style.top = rect.bottom + 4 + "px";
        langPanel.style.left = rect.left + "px";
        langPanel.style.width = "420px";
        langPanel.style.minWidth = "";
        document.body.appendChild(langPanel);
        renderLocaleList(langFilter ? langFilter.value : "");
        if (langFilter) {
          langFilter.focus();
        }
      }
      function closePanel() {
        langPanel.style.display = "none";
        var wrap = langTrigger.closest(".locale-dropdown-wrap");
        if (wrap && langPanel.parentNode !== wrap) wrap.appendChild(langPanel);
      }
      langTrigger.onclick = function (e) {
        e.stopPropagation();
        if (langPanel.style.display === "flex") closePanel();
        else openPanel();
      };
      if (langFilter) {
        langFilter.oninput = function () {
          renderLocaleList(this.value);
        };
        langFilter.onclick = function (e) {
          e.stopPropagation();
        };
      }
      document.addEventListener("click", function (e) {
        if (
          langPanel.style.display === "flex" &&
          !langTrigger.contains(e.target) &&
          !langPanel.contains(e.target)
        )
          closePanel();
      });
      var sel = localeList.find(function (x) {
        return x.code === langSelect.value;
      });
      if (langLabel) langLabel.textContent = sel ? sel.name : "System default";
      renderLocaleList("");
    })();

    const spellSwitch = $("settingsSpellSwitch");
    if (spellSwitch) {
      const spellKey = "gust:spellcheck:v1";
      const spellOn = ls.getItem(spellKey) === "true";
      spellSwitch.classList.toggle("on", spellOn);
      document
        .querySelectorAll("input[type=text], textarea")
        .forEach((el) => (el.spellcheck = spellOn));
      spellSwitch.onclick = () => {
        const nowOn = spellSwitch.classList.toggle("on");
        try {
          ls.setItem(spellKey, nowOn ? "true" : "false");
        } catch (_) {}
        document
          .querySelectorAll("input[type=text], textarea")
          .forEach((el) => (el.spellcheck = nowOn));
        try {
          frame.contentWindow?.postMessage(
            { type: "gust:spellcheck", enabled: nowOn },
            "*",
          );
        } catch (_) {}
      };
    }

    // ── Files & Media settings wiring ──────────────────────────
    const _mediaSwitches = [
      { id: "mediaPdfSwitch", key: "gust:media:pdf:v1", defaultOn: true },
      { id: "mediaImgSwitch", key: "gust:media:img:v1", defaultOn: true },
      { id: "mediaVideoSwitch", key: "gust:media:video:v1", defaultOn: true },
      { id: "mediaAudioSwitch", key: "gust:media:audio:v1", defaultOn: true },
      { id: "mediaTextSwitch", key: "gust:media:text:v1", defaultOn: true },
      {
        id: "mediaDownloadSwitch",
        key: "gust:media:download:v1",
        defaultOn: false,
      },
      { id: "mediaRangeSwitch", key: "gust:media:range:v1", defaultOn: true },
      {
        id: "mediaHeadersSwitch",
        key: "gust:media:headers:v1",
        defaultOn: true,
      },
      {
        id: "webrtcBlockSwitch",
        key: "gust:webrtc:block:v1",
        defaultOn: false,
      },
      {
        id: "faviconProxySwitch",
        key: "gust:favicon-proxy:v1",
        defaultOn: false,
      },
    ];
    _mediaSwitches.forEach(({ id, key, defaultOn }) => {
      const sw = $(id);
      if (!sw) return;
      const saved = ls.getItem(key);
      const isOn = saved !== null ? saved === "1" : defaultOn;
      sw.classList.toggle("on", isOn);
      sw.onclick = () => {
        const nowOn = sw.classList.toggle("on");
        try {
          ls.setItem(key, nowOn ? "1" : "0");
        } catch (_) {}
      };
    });
    // ───────────────────────────────────────────────────────────
  }

  // animateClose: adds .closing class, waits for animation, then hides the element
  function animateClose(el, duration = 150, onDone) {
    if (!el) return;
    el.classList.add("closing");
    setTimeout(() => {
      el.classList.remove("closing");
      if (onDone) onDone();
    }, duration);
  }

  let tooltipEl = null;

  function showTooltip(el, text) {
    if (tooltipEl) tooltipEl.remove();
    tooltipEl = document.createElement("div");
    tooltipEl.className = "gust-tooltip";
    tooltipEl.textContent = text;
    document.body.appendChild(tooltipEl);

    const rect = el.getBoundingClientRect();
    const tx = rect.left + rect.width / 2;
    const ty = rect.top - 10;

    tooltipEl.style.left = tx + "px";
    tooltipEl.style.top = ty + "px";
    tooltipEl.style.transform = "translate(-50%, -100%)";
  }

  function hideTooltip() {
    if (tooltipEl) {
      tooltipEl.remove();
      tooltipEl = null;
    }
  }

  function updateBookmarkButton() {
    const isInternal =
      !pageUrl || pageUrl === HOME_INTERNAL || isSettingsPage(pageUrl);
    const isError = isErrorPage || getActiveTab()?.hasError;

    if (isInternal || isError) {
      bookmarkBtn.classList.add("bookmark-btn-disabled");
      bookmarkBtn.style.opacity = "0.35";
      bookmarkBtn.style.pointerEvents = "";
      bookmarkBtn.style.cursor = "not-allowed";
      bookmarkBtn.querySelector("i").className = "far fa-bookmark";
      bookmarkBtn.title = isError
        ? "Cannot bookmark error pages"
        : "Cannot bookmark internal pages";
      return;
    }

    bookmarkBtn.classList.remove("bookmark-btn-disabled");
    bookmarkBtn.style.opacity = "";
    bookmarkBtn.style.pointerEvents = "";
    bookmarkBtn.style.cursor = "";

    const isBookmarked = bookmarks.some((b) => b.url === pageUrl);
    bookmarkBtn.querySelector("i").className = isBookmarked
      ? "fas fa-bookmark"
      : "far fa-bookmark";
    bookmarkBtn.title = isBookmarked
      ? "Remove bookmark (Alt+D)"
      : "Bookmark this page (Alt+D)";
  }

  function showBookmarkModal() {
    const modal = $("bookmarkModal");
    const urlInput = $("bookmarkUrlInput");
    const nameInput = $("bookmarkNameInput");

    if (!pageUrl || pageUrl === HOME_INTERNAL) {
      urlInput.value = "";
      urlInput.removeAttribute("readonly");
      nameInput.value = "";
      modal.style.display = "flex";
      setTimeout(() => {
        urlInput.focus();
      }, 100);
      return;
    }

    urlInput.value = pageUrl;
    urlInput.setAttribute("readonly", "readonly");

    const tab = getActiveTab();
    let defaultName = tab?.title || "";

    if (!defaultName) {
      try {
        defaultName = new URL(pageUrl).hostname.replace(/^www\./, "");
      } catch (e) {
        defaultName = pageUrl.slice(0, 30);
      }
    }

    if (defaultName === "New Tab") {
      try {
        defaultName = new URL(pageUrl).hostname.replace(/^www\./, "");
      } catch (e) {
        defaultName = pageUrl.slice(0, 30);
      }
    }

    nameInput.value = defaultName;

    modal.style.display = "flex";
    setTimeout(() => {
      nameInput.focus();
      nameInput.select();
    }, 100);
  }

  function hideBookmarkModal() {
    hideModal($("bookmarkModal"));
  }

  let editingShortcut = null;
  let capturedKey = null;

  function showShortcutEditModal(shortcutName) {
    editingShortcut = shortcutName;
    capturedKey = null;
    const modal = $("shortcutEditModal");
    const display = $("shortcutDisplay");
    const saveBtn = $("shortcutSave");

    display.textContent = "Waiting for input...";
    saveBtn.disabled = true;
    modal.style.display = "flex";
  }

  function hideShortcutEditModal() {
    hideModal($("shortcutEditModal"));
    editingShortcut = null;
    capturedKey = null;
  }

  function wireShortcutEditButtons() {
    const shortcutNames = [
      "newtab",
      "closetab",
      "reload",
      "bookmark",
      "focusurl",
      "settings",
      "logs",
      "inspector",
      "history",
      "metrics",
      "fullscreen",
    ];
    const defaultKeys = ["T", "W", "R", "D", "L", ",", "G", "I", "H", "M"];
    document
      .querySelectorAll(
        '.settings-section[data-section="shortcuts"] .settings-btn-icon',
      )
      .forEach((btn, idx) => {
        const scIdx = Math.floor(idx / 2);
        const isReset = idx % 2 === 1;
        if (isReset) {
          btn.onclick = () => {
            const name = shortcutNames[scIdx];
            if (!name) return;
            try {
              ls.removeItem("gust:sc:" + name);
            } catch (e) {}
            const codeEl = document.querySelector(
              '.shortcut-display[data-shortcut="' + name + '"]',
            );
            if (codeEl) codeEl.textContent = "Alt + " + defaultKeys[scIdx];
            buildShortcutMap();
            log("Shortcut reset: " + name, "ok");
          };
        } else {
          btn.onclick = () => showShortcutEditModal(shortcutNames[scIdx]);
        }
      });
    shortcutNames.forEach((name, i) => {
      try {
        const saved = ls.getItem("gust:sc:" + name);
        if (saved) {
          const codeEl = document.querySelector(
            '.shortcut-display[data-shortcut="' + name + '"]',
          );
          if (codeEl) codeEl.textContent = "Alt + " + saved;
        }
      } catch (e) {}
    });
  }

  document.addEventListener("keydown", (e) => {
    const modal = $("shortcutEditModal");
    if (modal && modal.style.display === "flex") {
      if (e.key === "Escape") {
        hideShortcutEditModal();
        return;
      }

      if (e.altKey && e.key !== "Alt") {
        e.preventDefault();
        capturedKey = e.key.toUpperCase();
        const display = $("shortcutDisplay");
        const saveBtn = $("shortcutSave");

        display.textContent = `Alt + ${capturedKey}`;
        saveBtn.disabled = false;
      }
    }
  });

  $("shortcutCancel").onclick = hideShortcutEditModal;
  $("shortcutSave").onclick = () => {
    if (!capturedKey || !editingShortcut) {
      hideShortcutEditModal();
      return;
    }
    try {
      ls.setItem("gust:sc:" + editingShortcut, capturedKey);
    } catch (e) {}
    const codeEl = document.querySelector(
      '.shortcut-display[data-shortcut="' + editingShortcut + '"]',
    );
    if (codeEl) codeEl.textContent = "Alt + " + capturedKey;
    buildShortcutMap();
    log(
      "Shortcut updated: Alt+" + capturedKey + " -> " + editingShortcut,
      "ok",
    );
    hideShortcutEditModal();
  };
  $("shortcutEditModal").onclick = (e) => {
    if (e.target === $("shortcutEditModal")) hideShortcutEditModal();
  };

  function saveBookmarkFromModal() {
    const urlInput = $("bookmarkUrlInput");
    const nameInput = $("bookmarkNameInput");

    let url = urlInput.value.trim();
    const name = nameInput.value.trim();

    if (!url) return;

    if (!url.match(/^https?:\/\//i)) {
      url = "https://" + url;
    }

    try {
      new URL(url);
    } catch (e) {
      return;
    }

    if (!name) {
      let defaultName = "";
      try {
        defaultName = new URL(url).hostname.replace(/^www\./, "");
      } catch (e) {
        defaultName = url.slice(0, 30);
      }
      nameInput.value = defaultName;
      return;
    }

    if (bookmarks.some((b) => b.url === url)) {
      hideBookmarkModal();
      return;
    }

    bookmarks.unshift({ name: name, url: url });
    bookmarks = bookmarks.slice(0, 16);
    saveBookmarks();
    renderBookmarks();
    updateBookmarkButton();
    hideBookmarkModal();
  }

  const contextMenu = $("contextMenu");
  let contextMenuTarget = null;

  function updateContextMenuStates() {
    const onProxiedPage = !!(
      pageUrl &&
      pageUrl !== HOME_INTERNAL &&
      !isSettingsPage(pageUrl) &&
      !isErrorPage
    );
    const onInternalPage =
      !pageUrl || pageUrl === HOME_INTERNAL || isSettingsPage(pageUrl);

    const canBack = histIdx > 0;
    const ctxBack = $("ctxBack");
    ctxBack.disabled = !canBack;
    ctxBack.classList.toggle("disabled", !canBack);

    const canFwd = histIdx < hist.length - 1;
    const ctxFwd = $("ctxForward");
    ctxFwd.disabled = !canFwd;
    ctxFwd.classList.toggle("disabled", !canFwd);

    const canReload = onProxiedPage;
    const ctxReload = $("ctxReload");
    ctxReload.disabled = !canReload;
    ctxReload.classList.toggle("disabled", !canReload);

    const canBookmark = onProxiedPage && !isErrorPage;
    const ctxBookmark = $("ctxBookmark");
    ctxBookmark.disabled = !canBookmark;
    ctxBookmark.classList.toggle("disabled", !canBookmark);
    if (canBookmark) {
      const isBookmarked = bookmarks.some((b) => b.url === pageUrl);
      ctxBookmark.querySelector("span").textContent = isBookmarked
        ? "Remove Bookmark"
        : "Bookmark Page";
      ctxBookmark.querySelector("i").className = isBookmarked
        ? "fas fa-bookmark"
        : "far fa-bookmark";
    } else {
      ctxBookmark.querySelector("span").textContent = "Bookmark Page";
      ctxBookmark.querySelector("i").className = "far fa-bookmark";
    }

    const canCopy = onProxiedPage;
    const ctxCopyUrl = $("ctxCopyUrl");
    ctxCopyUrl.disabled = !canCopy;
    ctxCopyUrl.classList.toggle("disabled", !canCopy);

    const canClose = tabs.length > 1;
    const ctxCloseTab = $("ctxCloseTab");
    ctxCloseTab.disabled = !canClose;
    ctxCloseTab.classList.toggle("disabled", !canClose);
  }

  function openContextMenu(x, y) {
    closeTabContextMenu(); // close tab menu if open
    updateContextMenuStates();
    contextMenu.style.left = x + "px";
    contextMenu.style.top = y + "px";
    contextMenu.classList.add("active");

    setTimeout(() => {
      const rect = contextMenu.getBoundingClientRect();
      if (rect.right > window.innerWidth) {
        contextMenu.style.left = window.innerWidth - rect.width - 10 + "px";
      }
      if (rect.bottom > window.innerHeight) {
        contextMenu.style.top = window.innerHeight - rect.height - 10 + "px";
      }
    }, 0);
  }

  document.addEventListener("contextmenu", (e) => {
    const isOnFrame = frame && (e.target === frame || frame.contains(e.target));
    const isOnNewTab =
      newtab && (e.target === newtab || newtab.contains(e.target));
    const isOnSettingsPage =
      document.getElementById("settingsPage") &&
      (e.target === document.getElementById("settingsPage") ||
        document.getElementById("settingsPage").contains(e.target));
    // Don't open generic menu if right-clicking on a tab
    const isOnTab = !!e.target.closest(".tab[data-tab-id]");
    e.preventDefault();

    if (!isOnFrame && !isOnTab) {
      openContextMenu(e.clientX, e.clientY);
      contextMenuTarget = e.target;
    }
  });

  document.addEventListener("mousedown", (e) => {
    if (
      contextMenu.classList.contains("active") &&
      !contextMenu.contains(e.target)
    ) {
      animateClose(contextMenu, 140, () =>
        contextMenu.classList.remove("active"),
      );
    }
  });

  $("ctxNewTab").onclick = () => {
    createTab();
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxReload").onclick = () => {
    if (
      pageUrl &&
      pageUrl !== HOME_INTERNAL &&
      !isSettingsPage(pageUrl) &&
      !isErrorPage
    ) {
      go(pageUrl, false);
    }
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxBack").onclick = () => {
    if (histIdx > 0) $("back").click();
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxForward").onclick = () => {
    if (histIdx < hist.length - 1) $("fwd").click();
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxBookmark").onclick = () => {
    const canBookmark =
      pageUrl &&
      pageUrl !== HOME_INTERNAL &&
      !isSettingsPage(pageUrl) &&
      !isErrorPage;
    if (canBookmark) {
      bookmarkBtn.click();
    }
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxCopyUrl").onclick = async () => {
    if (pageUrl && pageUrl !== HOME_INTERNAL && !isSettingsPage(pageUrl)) {
      try {
        await navigator.clipboard.writeText(pageUrl);
        log("URL copied to clipboard", "ok");
      } catch (e) {
        log("Failed to copy URL", "err");
      }
    }
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxSettings").onclick = () => {
    showSettingsPage(true);
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  $("ctxCloseTab").onclick = () => {
    if (tabs.length > 1) {
      closeTabAnimated(activeTabId);
    }
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
  };

  // ── Tab right-click context menu ──────────────────────────────
  const tabContextMenu = $("tabContextMenu");
  let tabCtxTargetId = null;

  function openTabContextMenu(tabId, x, y) {
    tabCtxTargetId = tabId;
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    ); // close generic menu if open
    const tab = tabs.find((t) => t.id === tabId);

    // Update mute label
    const muteBtn = $("tabCtxMute");
    const isMuted = tab && tab.muted;
    muteBtn.querySelector("i").className = isMuted
      ? "fas fa-volume-high"
      : "fas fa-volume-xmark";
    muteBtn.querySelector("span").textContent = isMuted
      ? "Unmute Tab"
      : "Mute Tab";
    muteBtn.style.color = isMuted ? "var(--ac)" : "";
    muteBtn.querySelector("i").style.color = isMuted ? "var(--ac)" : "";

    // Disable close if only one tab
    const closeBtn = $("tabCtxClose");
    const canClose = tabs.length > 1;
    closeBtn.disabled = !canClose;
    closeBtn.classList.toggle("disabled", !canClose);

    tabContextMenu.style.left = x + "px";
    tabContextMenu.style.top = y + "px";
    tabContextMenu.classList.add("active");

    // Clamp to viewport
    setTimeout(() => {
      const rect = tabContextMenu.getBoundingClientRect();
      if (rect.right > window.innerWidth)
        tabContextMenu.style.left = window.innerWidth - rect.width - 8 + "px";
      if (rect.bottom > window.innerHeight)
        tabContextMenu.style.top = window.innerHeight - rect.height - 8 + "px";
    }, 0);
  }

  function closeTabContextMenu() {
    animateClose(tabContextMenu, 140, () =>
      tabContextMenu.classList.remove("active"),
    );
    tabCtxTargetId = null;
  }

  // Wire up tab right-click — intercept contextmenu on .tab elements
  document.getElementById("tabStrip").addEventListener("contextmenu", (e) => {
    const tabEl = e.target.closest(".tab[data-tab-id]");
    if (!tabEl) return;
    e.preventDefault();
    e.stopPropagation();
    // Close the generic context menu in case it opened
    animateClose(contextMenu, 140, () =>
      contextMenu.classList.remove("active"),
    );
    const id = parseInt(tabEl.dataset.tabId, 10);
    openTabContextMenu(id, e.clientX, e.clientY);
  });

  document.addEventListener("click", (e) => {
    if (!tabContextMenu.contains(e.target)) closeTabContextMenu();
  });

  $("tabCtxReload").onclick = () => {
    if ($("tabCtxReload").classList.contains("disabled")) return;
    const tab = tabs.find((t) => t.id === tabCtxTargetId);
    if (
      tab &&
      tab.url &&
      tab.url !== HOME_INTERNAL &&
      !isSettingsPage(tab.url)
    ) {
      // Switch to that tab then reload
      switchToTab(tab.id);
      setTimeout(() => {
        if (
          pageUrl &&
          pageUrl !== HOME_INTERNAL &&
          !isSettingsPage(pageUrl) &&
          !isErrorPage
        ) {
          go(pageUrl, false);
        }
      }, 50);
    }
    closeTabContextMenu();
  };

  $("tabCtxMute").onclick = () => {
    const tab = tabs.find((t) => t.id === tabCtxTargetId);
    if (tab) {
      tab.muted = !tab.muted;
      // If this is the active tab, apply mute to the frame right now
      if (tab.id === activeTabId) {
        applyMuteToFrame(tab.muted);
      }
      renderTabs();
      saveTabs();
    }
    closeTabContextMenu();
  };

  $("tabCtxClose").onclick = () => {
    if ($("tabCtxClose").classList.contains("disabled")) return;
    if (tabs.length > 1 && tabCtxTargetId != null) {
      closeTabAnimated(tabCtxTargetId);
    }
    closeTabContextMenu();
  };
  // ── End tab context menu ──────────────────────────────────────

  let _anyResizing = false;

  function setupPanelResize(panel, handle) {
    if (!panel || !handle) return;

    let isResizing = false;
    let startX = 0;
    let startWidth = 0;

    handle.addEventListener("mousedown", (e) => {
      isResizing = true;
      _anyResizing = true;
      startX = e.clientX;
      startWidth = panel.offsetWidth;
      document.body.style.cursor = "ew-resize";
      if (frame) frame.style.pointerEvents = "none";
      e.preventDefault();
    });

    document.addEventListener("mousemove", (e) => {
      if (!isResizing) return;
      const panelsLeft = document.body.classList.contains("panels-left");
      const deltaX = panelsLeft ? e.clientX - startX : startX - e.clientX;
      const newWidth = Math.max(250, Math.min(800, startWidth + deltaX));
      panel.style.width = newWidth + "px";
    });

    const stopResize = () => {
      if (isResizing) {
        isResizing = false;
        _anyResizing = false;
        document.body.style.cursor = "";
        if (frame) frame.style.pointerEvents = "";
      }
    };

    document.addEventListener("mouseup", stopResize);
    window.addEventListener("blur", stopResize);
    document.addEventListener("mouseleave", stopResize);
  }

  setupPanelResize(logsEl, logsResizeHandle);
  setupPanelResize(elementsEl, elementsResizeHandle);

  const SC_ACTIONS = {
    newtab: () => createTab(),
    closetab: () => {
      if (tabs.length > 1) closeTabAnimated(activeTabId);
    },
    reload: () => {
      if (pageUrl && pageUrl !== HOME_INTERNAL) go(pageUrl, false);
    },
    bookmark: () => {
      if (pageUrl && pageUrl !== HOME_INTERNAL) showBookmarkModal();
    },
    focusurl: () => urlInput.focus(),
    settings: () => showSettingsPage(true),
    logs: () => {
      if (logsEl) logsEl.classList.toggle("hidden");
    },
    inspector: () => {
      toggleElements();
    },
    history: () => {
      if (historyPopup.classList.contains("open")) hideHistoryPopup();
      else showHistoryPopup();
    },
    metrics: () => {
      metricsModal.style.display === "flex" ? hideMetrics() : showMetrics();
    },
    fullscreen: () => {
      if (!document.fullscreenElement) _doRequestFullscreen().catch(() => {});
      else document.exitFullscreen();
    },
  };
  const SC_DEFAULTS = {
    newtab: "T",
    closetab: "W",
    reload: "R",
    bookmark: "D",
    focusurl: "L",
    settings: ",",
    logs: "G",
    inspector: "I",
    history: "H",
    metrics: "M",
    fullscreen: "F",
  };
  let scMap = {};

  function buildShortcutMap() {
    scMap = {};
    for (const [name, def] of Object.entries(SC_DEFAULTS)) {
      let key = def;
      try {
        key = ls.getItem("gust:sc:" + name) || def;
      } catch (e) {}
      scMap[key.toUpperCase()] = name;
    }
  }
  buildShortcutMap();

  document.addEventListener("keydown", (e) => {
    const tag = document.activeElement?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    const modal = $("shortcutEditModal");
    if (modal && modal.style.display === "flex") return;
    let scEnabled = true;
    try {
      if (ls.getItem("gust:shortcutsEnabled") === "0") scEnabled = false;
    } catch (e) {}
    if (!scEnabled) return;

    if (e.altKey && e.key !== "Alt") {
      const k = e.key === "," ? "," : e.key.toUpperCase();
      const action = scMap[k] || scMap[e.key.toUpperCase()];
      if (action && SC_ACTIONS[action]) {
        e.preventDefault();
        SC_ACTIONS[action]();
      }
    }
  });

  const TUTORIAL_KEY = "gust:tutorial:v1";

  const tutSteps = [
    {
      target: null,
      icon: '<i class="fas fa-wind"></i>',
      title: "Welcome to GUST",
      body: "A fast, private browser by Nautilus Labs. This tour covers all the key controls and takes under a minute. Restart anytime from Settings.",
      pos: "center",
    },
    {
      target: "#navPillGroup",
      icon: '<i class="fas fa-arrow-left"></i>',
      title: "Navigation Buttons",
      body: 'Back (<i class="fas fa-arrow-left" style="font-size:0.8em;"></i>), forward (<i class="fas fa-arrow-right" style="font-size:0.8em;"></i>), reload and home. The home button returns to the new tab page, and you can pause a page reloading by clicking the square in its place.',
      pos: "below",
    },
    {
      target: "#url",
      icon: '<i class="fas fa-magnifying-glass"></i>',
      title: "Address and Search Bar",
      pad: 10,
      body: "Type a URL or search term and press Enter. The lock icon shows connection security, and clicking on it shows site info. The bookmark icon saves the current page instantly.",
      pos: "below",
    },
    {
      target: "#bookmarkBtn",
      icon: '<i class="fas fa-bookmark"></i>',
      title: "Bookmarks",
      body: "Bookmark the current page with this button or Ctrl+D. Your bookmarks appear in the bar below the address bar. Right-click any bookmark to edit or remove it.",
      pos: "below",
    },
    {
      target: "#historyBtn",
      icon: '<i class="fas fa-clock-rotate-left"></i>',
      title: "Recent History",
      body: "Jump back to recently visited pages. If you close a tab by accident, open history to recover the URL. No browsing data ever leaves your device, or is saved longer than 10 entries.",
      pos: "below",
    },
    {
      target: "#blockToggle",
      icon: '<i class="fas fa-shield-halved"></i>',
      title: "Ad and Tracker Blocking",
      body: "GUST blocks ads and trackers by default. The badge shows your current status. Click on it to toggle it off if a site is not loading correctly.",
      pos: "below-left",
    },
    {
      target: "#metricsBtn",
      icon: '<i class="fas fa-chart-bar"></i>',
      title: "Browser Metrics",
      body: "Live stats at a glance: active requests, queue depth, memory, cache hit rate, network info and page performance. Useful for debugging slow sites.",
      pos: "below-left",
    },
    {
      target: "#devToggle",
      icon: '<i class="fas fa-server"></i>',
      title: "Browser Logs",
      body: "Opens the request log panel. See every fetch, cache hit, blocked tracker and error in real time. Essential for diagnosing proxy or network issues.",
      pos: "below-left",
    },
    {
      target: "#codeBtn",
      icon: '<i class="fas fa-code"></i>',
      title: "Page Inspector",
      body: "Inspect the live DOM of any page. Browse the element tree, view computed styles, box model and attributes. Works even if devtools are disabled in your browser.",
      pos: "below-left",
    },
    {
      target: "#newTab",
      icon: '<i class="fas fa-plus"></i>',
      title: "New Tab",
      body: 'Open a new tab with this button or Alt+T. Tabs show favicons and scroll horizontally when you have many open. Use the <i class="fas fa-arrow-left"></i> <i class="fas fa-arrow-right"></i> arrows to scroll them.',
      pos: "below",
    },
    {
      target: "#settingsBtn",
      icon: '<i class="fas fa-gear"></i>',
      title: "Settings",
      body: "Configure the WISP server, search engine, wallpaper, font size, cache, shortcuts and more. You can also read about Gust or restart the tutorial from here.",
      pos: "below-left",
    },
    {
      target: "#bookmarksToggle",
      icon: '<i class="fas fa-chevron-up"></i>',
      title: "Bookmarks Bar",
      body: "Click the chevron to show or hide the bookmarks bar if it takes up too much space. To reenable click the down chevron that appears next to settings.",
      pos: "below",
      targetFallback: "#showBookmarksBtn",
    },
    {
      target: "#ntFavAddBtn",
      icon: '<i class="fas fa-star"></i>',
      title: "Add Favorite",
      body: "Pin your most-visited sites as favorites on the new tab page for instant access. You can add up to 5.",
      pos: "below",
      requiresNewTab: true,
      targetFallback: ".nt-fav-add",
    },
    {
      target: "#ntWallpaperBtn",
      icon: '<i class="fas fa-image"></i>',
      title: "Change Wallpaper",
      body: "Customize the new tab page background. Upload any image, use a random stock image, paste an image URL, or reset to the default gradient.",
      pos: "above",
      requiresNewTab: true,
    },
    {
      target: "#ntGithubBtn",
      icon: '<i class="fab fa-github"></i>',
      title: "GitHub",
      body: "GUST is open source. Click to view the repository, report issues, or contribute.",
      pos: "above",
      requiresNewTab: true,
    },
    {
      target: null,
      icon: '<i class="fas fa-check-circle"></i>',
      title: "You're all set!",
      body: "That's the full tour. GUST is built for speed and privacy. Restart this tour anytime from Settings then Tutorial.",
      pos: "center",
    },
  ];

  let tutIdx = 0;
  let tutActive = false;

  function startTutorial(force = false) {
    if (!force) {
      try {
        if (ls.getItem(TUTORIAL_KEY) === "done") return;
      } catch (e) {}
    }
    tutIdx = 0;
    tutActive = true;
    const ov = document.getElementById("tutorialOverlay");
    ov.style.display = "block";
    requestAnimationFrame(() =>
      requestAnimationFrame(() => {
        const bd = document.getElementById("tutorialBackdrop");
        if (bd) bd.style.opacity = "1";
        const svg = document.getElementById("tutorialSpotSvg");
        if (svg) svg.style.opacity = "0";
        showTutStep(0);
      }),
    );
  }

  function endTutorial(completed = false) {
    tutActive = false;
    const ov = document.getElementById("tutorialOverlay");
    const card = document.getElementById("tutorialCard");

    if (completed === true) {
      triggerSparks(card);
    }

    card.style.opacity = "0";
    card.style.transform = "translateY(8px)";
    const bd = document.getElementById("tutorialBackdrop");
    if (bd) bd.style.opacity = "0";
    const svg = document.getElementById("tutorialSpotSvg");
    if (svg) svg.style.opacity = "0";
    setTimeout(() => {
      ov.style.display = "none";
    }, 350);
    try {
      ls.setItem(TUTORIAL_KEY, "done");
    } catch (e) {}

    _gustAnimLocked = false;
    playGustAnimation(400);
    const sr = document.getElementById("spotRect");
    if (sr) {
      sr.setAttribute("width", "0");
      sr.setAttribute("height", "0");
    }
    const cloneWrapEnd = document.getElementById("tutorialCloneWrap");
    if (cloneWrapEnd) cloneWrapEnd.innerHTML = "";
    const ringDivEnd = document.getElementById("tutorialRing");
    if (ringDivEnd) ringDivEnd.style.display = "none";
    const so = document.getElementById("spotOverlay");
    if (so) so.style.display = "none";
  }

  function triggerSparks(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const count = 30;
    const overlay = document.getElementById("tutorialOverlay");
    const container = overlay || document.body;
    const pad = 8;
    for (let i = 0; i < count; i++) {
      const spark = document.createElement("div");
      spark.className = "spark";
      const size = Math.random() * 10 + 10;
      spark.style.width = size + "px";
      spark.style.height = size + "px";
      let x, y;
      const edge = Math.floor(Math.random() * 4);
      if (edge === 0) {
        x = rect.left - pad + Math.random() * (rect.width + 2 * pad);
        y = rect.top - pad - Math.random() * 20;
      } else if (edge === 1) {
        x = rect.right + pad + Math.random() * 20;
        y = rect.top - pad + Math.random() * (rect.height + 2 * pad);
      } else if (edge === 2) {
        x = rect.left - pad + Math.random() * (rect.width + 2 * pad);
        y = rect.bottom + pad + Math.random() * 20;
      } else {
        x = rect.left - pad - Math.random() * 20;
        y = rect.top - pad + Math.random() * (rect.height + 2 * pad);
      }
      spark.style.left = x + "px";
      spark.style.top = y + "px";

      const angle = Math.random() * Math.PI * 2;
      const distance = Math.random() * 140 + 80;
      const tx = Math.cos(angle) * distance;
      const ty = Math.sin(angle) * distance;

      const duration = 1200 + Math.random() * 1200;
      spark.animate(
        [
          { transform: "translate(0, 0) scale(1)", opacity: 1 },
          { transform: `translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 },
        ],
        {
          duration: duration,
          easing: "cubic-bezier(0, .5, .5, 1)",
          fill: "forwards",
        },
      );

      container.appendChild(spark);
      setTimeout(() => spark.remove(), 2600);
    }
  }

  function showTutStep(idx) {
    const step = tutSteps[idx];
    const card = document.getElementById("tutorialCard");
    const arrow = document.getElementById("tutorialArrow");
    const dots = document.getElementById("tutorialDots");
    const title = document.getElementById("tutorialTitle");
    const body = document.getElementById("tutorialBody");
    const icon = document.getElementById("tutorialIcon");
    const btnNext = document.getElementById("tutorialNext");
    const btnBack = document.getElementById("tutorialBack");
    const svgEl = document.getElementById("tutorialSpotSvg");
    const so = document.getElementById("spotOverlay");

    if (step.requiresNewTab && typeof showNewTab === "function") {
      const isOnNewTab = document
        .getElementById("newtab")
        ?.classList.contains("active");
      if (!isOnNewTab) {
        showNewTab(false);
      }
    }

    card.style.opacity = "0";
    card.style.transform = "translateY(6px)";

    dots.innerHTML = tutSteps
      .map(
        (_, i) =>
          `<div style="width:${i === idx ? "16px" : "6px"};height:6px;border-radius:3px;background:${i === idx ? "var(--ac)" : "rgba(255,255,255,0.2)"};transition:all .2s;"></div>`,
      )
      .join("");

    title.innerHTML = step.title;
    body.innerHTML = step.body;
    icon.innerHTML = step.icon;
    btnNext.innerHTML =
      idx === tutSteps.length - 1
        ? '<i class="fas fa-check" style="margin-right:5px;"></i>Done'
        : 'Next <i class="fas fa-arrow-right"></i>';
    btnBack.style.display = idx > 0 ? "block" : "none";

    const stepDelay = step.requiresNewTab ? 200 : 120;
    setTimeout(() => {
      const sr = document.getElementById("spotRect");
      const cloneWrap = document.getElementById("tutorialCloneWrap");
      if (cloneWrap) cloneWrap.innerHTML = "";
      const ringDiv = document.getElementById("tutorialRing");

      if (step.target) {
        const el =
          document.querySelector(step.target) ||
          (step.targetFallback
            ? document.querySelector(step.targetFallback)
            : null);
        if (el) {
          const r = el.getBoundingClientRect();
          const pad = step.pad !== undefined ? step.pad : 3;
          const computedRxRaw =
            parseFloat(getComputedStyle(el).borderRadius) || 0;
          const elRx = computedRxRaw > 40 ? 9999 : 8;

          sr.setAttribute("x", r.left - pad);
          sr.setAttribute("y", r.top - pad);
          sr.setAttribute("width", r.width + pad * 2);
          sr.setAttribute("height", r.height + pad * 2);
          sr.setAttribute(
            "rx",
            elRx > 100
              ? Math.min(sr.getAttribute("width"), sr.getAttribute("height")) /
                  2 +
                  ""
              : elRx + pad + "",
          );

          if (ringDiv) {
            ringDiv.style.left = r.left - pad + "px";
            ringDiv.style.top = r.top - pad + "px";
            ringDiv.style.width = r.width + pad * 2 + "px";
            ringDiv.style.height = r.height + pad * 2 + "px";
            ringDiv.style.borderRadius = elRx > 100 ? "50%" : elRx + pad + "px";
            ringDiv.style.display = "block";
          }

          if (cloneWrap) {
            cloneWrap.innerHTML = "";
            try {
              const clone = el.cloneNode(true);
              clone.removeAttribute("id");
              const computedBR =
                getComputedStyle(el).borderRadius || elRx + "px";
              clone.style.cssText = "";
              clone.style.position = "absolute";
              clone.style.left = r.left + "px";
              clone.style.top = r.top + "px";
              clone.style.width = r.width + "px";
              clone.style.height = r.height + "px";
              clone.style.margin = "0";
              clone.style.pointerEvents = "none";
              clone.style.boxSizing = "border-box";
              clone.style.borderRadius = computedBR;
              clone.style.overflow = "hidden";
              clone.style.transform = "none";
              clone.style.animation = "none";
              clone.style.transition = "none";
              clone.style.filter = "none";
              clone.style.backdropFilter = "none";
              clone.style.webkitBackdropFilter = "none";
              clone.style.boxShadow = "none";
              clone.style.opacity = "1";
              clone.style.zIndex = "2";
              cloneWrap.appendChild(clone);
            } catch (e) {}
          }

          const svgEl3 = document.getElementById("tutorialSpotSvg");
          if (svgEl3) svgEl3.style.opacity = "1";
          if (so) {
            so.setAttribute("mask", "url(#spotMask)");
            so.style.display = "";
          }
          const bdReset = document.getElementById("tutorialBackdrop");
          if (bdReset) bdReset.style.background = "";

          positionCard(card, arrow, r, step.pos);
        } else {
          sr.setAttribute("width", "0");
          sr.setAttribute("height", "0");
          if (ringDiv) ringDiv.style.display = "none";
          centerCard(card, arrow);
        }
      } else {
        sr.setAttribute("width", "0");
        sr.setAttribute("height", "0");
        if (ringDiv) ringDiv.style.display = "none";
        const svgEl2 = document.getElementById("tutorialSpotSvg");
        if (svgEl2) svgEl2.style.opacity = "0";
        const bd2 = document.getElementById("tutorialBackdrop");
        if (bd2) bd2.style.background = "rgba(0,0,0,0.48)";
        centerCard(card, arrow);
      }

      requestAnimationFrame(() =>
        requestAnimationFrame(() => {
          card.style.opacity = "1";
          card.style.transform = "translateY(0)";
        }),
      );
    }, 80);
  }

  function positionCard(card, arrow, targetRect, pos) {
    const cw = 380;
    const vw = window.innerWidth,
      vh = window.innerHeight;
    const pad = 16;

    function placeNub(cardLeft, cardTop, cardH, pr) {
      const cx = pr.left + pr.width / 2;
      const nubMin = 24,
        nubMax = cw - 24;
      const rawNub = cx - cardLeft - 6;
      arrow.style.left = Math.min(Math.max(rawNub, nubMin), nubMax) + "px";
      arrow.style.right = "";
      if (cardTop + cardH <= pr.top + 4) {
        arrow.style.top = "";
        arrow.style.bottom = "-7px";
        arrow.style.borderTop = "none";
        arrow.style.borderLeft = "none";
        arrow.style.borderBottom = "1px solid var(--ac)";
        arrow.style.borderRight = "1px solid var(--ac)";
      } else {
        arrow.style.top = "-7px";
        arrow.style.bottom = "";
        arrow.style.borderBottom = "none";
        arrow.style.borderRight = "none";
        arrow.style.borderTop = "1px solid var(--ac)";
        arrow.style.borderLeft = "1px solid var(--ac)";
      }
      arrow.style.display = "block";

      const nubPos = parseFloat(arrow.style.left);
      const card = arrow.parentElement;
      const isLeft = nubPos <= 28;
      const isRight = nubPos >= cw - 28;
      const isTop = arrow.style.top !== "";
      card.style.borderRadius = "16px";
      if (isLeft && isTop) card.style.borderTopLeftRadius = "6px";
      if (isRight && isTop) card.style.borderTopRightRadius = "6px";
      if (isLeft && !isTop) card.style.borderBottomLeftRadius = "6px";
      if (isRight && !isTop) card.style.borderBottomRightRadius = "6px";
    }

    if (pos === "below" || pos === "below-left") {
      let left =
        pos === "below-left"
          ? Math.max(pad, targetRect.right - cw)
          : Math.max(pad, targetRect.left + targetRect.width / 2 - cw / 2);
      left = Math.min(left, vw - cw - pad);
      let top = targetRect.bottom + 26;
      const cardH = card.offsetHeight || 220;
      if (top + cardH + pad > vh)
        top = Math.max(pad, targetRect.top - cardH - 26);
      top = Math.max(pad, top);
      card.style.left = left + "px";
      card.style.top = top + "px";
      card.style.bottom = "";
      card.style.right = "";
      placeNub(left, top, card.offsetHeight || cardH, targetRect);
    } else if (pos === "above") {
      let left = Math.max(pad, targetRect.left + targetRect.width / 2 - cw / 2);
      left = Math.min(left, vw - cw - pad);
      const cardH = card.offsetHeight || 220;
      let top = targetRect.top - cardH - 26;
      if (top < pad) top = targetRect.bottom + 26;
      top = Math.min(top, vh - cardH - pad);
      top = Math.max(top, pad);
      card.style.left = left + "px";
      card.style.top = top + "px";
      card.style.bottom = "";
      card.style.right = "";
      placeNub(left, top, card.offsetHeight || cardH, targetRect);
    }
  }

  function centerCard(card, arrow) {
    const vw = window.innerWidth,
      vh = window.innerHeight;
    card.style.left = vw / 2 - 150 + "px";
    card.style.top = vh / 2 - 100 + "px";
    card.style.bottom = "";
    arrow.style.display = "none";
  }

  document.addEventListener("DOMContentLoaded", function () {
    var tn = document.getElementById("tutorialNext");
    var tb = document.getElementById("tutorialBack");
    var ts = document.getElementById("tutorialSkip");
    if (tn)
      tn.addEventListener("click", () => {
        if (tutIdx >= tutSteps.length - 1) {
          endTutorial(true);
          return;
        }
        tutIdx++;
        showTutStep(tutIdx);
      });
    if (tb)
      tb.addEventListener("click", () => {
        if (tutIdx <= 0) return;
        tutIdx--;
        showTutStep(tutIdx);
      });
    if (ts) ts.addEventListener("click", endTutorial);
  });

  window.__gustStartTutorial = () => startTutorial(true);

  try {
    if (ls.getItem("gust:panelsleft") === "1") {
      document.body.classList.add("panels-left");
    }
  } catch (e) {}

  setTimeout(() => {
    const restartBtn = document.getElementById("restartTutorialBtn");
    if (restartBtn) {
      restartBtn.addEventListener("click", () => {
        if (typeof hideSettingsPage === "function") hideSettingsPage();
        if (typeof hideBookmarkModal === "function") hideBookmarkModal();
        if (typeof hideShortcutEditModal === "function")
          hideShortcutEditModal();
        if (typeof hideAddFavoriteModal === "function") hideAddFavoriteModal();

        [
          "wallpaperModal",
          "metricsModal",
          "adblockModal",
          "historyPopup",
          "siteInfoPopup",
        ].forEach((id) => {
          const el = document.getElementById(id);
          if (el) el.style.display = "none";
        });

        const cm = document.getElementById("contextMenu");
        if (cm) cm.classList.remove("active");

        if (typeof logsEl !== "undefined" && logsEl)
          logsEl.classList.add("hidden");
        if (typeof elementsEl !== "undefined" && elementsEl)
          elementsEl.classList.add("hidden");

        setTimeout(() => {
          if (typeof showNewTab === "function") showNewTab(false);
          setTimeout(() => startTutorial(true), 150);
        }, 80);
      });
    }
  }, 300);

  try {
    if (ls.getItem(TUTORIAL_KEY) !== "done") {
      _gustAnimLocked = true;
    }
  } catch (e) {}

  // Delay tutorial until after libcurl init completes
  let _libcurlInitDone = false;
  let _tutorialWaiting = false;
  function _maybeStartTutorial() {
    if (_libcurlInitDone && _tutorialWaiting) {
      _tutorialWaiting = false;
      setTimeout(() => startTutorial(false), 400);
    }
  }
  // Will be resolved by init() after libcurl is ready
  window._onLibcurlInitDone = function () {
    // Drop the splash styling — subsequent overlay uses (page loading) stay as the normal small overlay
    overlay.classList.remove("splash");
    _libcurlInitDone = true;
    _maybeStartTutorial();
  };
  _tutorialWaiting = true;

  // ── Fullscreen logic ──────────────────────────────────────────────
  function _doRequestFullscreen() {
    return document.documentElement.requestFullscreen();
  }

  function _updateFSIcon() {
    const icon = document.getElementById("fullscreenIcon");
    const btn = document.getElementById("fullscreenBtn");
    if (!icon || !btn) return;
    if (document.fullscreenElement) {
      icon.className = "fas fa-compress";
      btn.title = "Exit fullscreen (F11)";
    } else {
      icon.className = "fas fa-expand";
      btn.title = "Toggle fullscreen (F11)";
    }
  }

  document.addEventListener("fullscreenchange", _updateFSIcon);

  // Wire the button — must use addEventListener, not onclick, since we're inside an IIFE
  document
    .getElementById("fullscreenBtn")
    .addEventListener("click", function () {
      if (!document.fullscreenElement) {
        _doRequestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen();
      }
    });

  // F11 key support
  document.addEventListener("keydown", function (e) {
    if (e.key === "F11") {
      e.preventDefault();
      if (!document.fullscreenElement) _doRequestFullscreen().catch(() => {});
      else document.exitFullscreen();
    }
  });

  // Auto-fullscreen: browsers require a user gesture.
  // Show a minimal splash overlay — clicking it provides the gesture and enters fullscreen.
  (function () {
    let autoFS = true;
    try {
      if (ls.getItem("gust:autoFullscreen") === "0") autoFS = false;
    } catch (e) {}
    if (!autoFS) return;

    const onFirstGesture = function () {
      _doRequestFullscreen().catch(() => {});
      document.removeEventListener("click", onFirstGesture);
      document.removeEventListener("keydown", onFirstGesture);
    };
    document.addEventListener("click", onFirstGesture);
    document.addEventListener("keydown", onFirstGesture);
  })();

  // Wire up shortcuts enabled toggle
  setTimeout(() => {
    const scSw = document.getElementById("settingsShortcutsEnabledSwitch");
    const scList = document.getElementById("shortcutsList");
    if (!scSw) return;
    const applyScState = (enabled) => {
      if (enabled) {
        scSw.classList.add("on");
        if (scList) {
          scList.style.opacity = "";
          scList.style.pointerEvents = "";
        }
      } else {
        scSw.classList.remove("on");
        if (scList) {
          scList.style.opacity = "0.35";
          scList.style.pointerEvents = "none";
        }
      }
    };
    try {
      applyScState(ls.getItem("gust:shortcutsEnabled") !== "0");
    } catch (e) {
      applyScState(true);
    }
    scSw.addEventListener("click", () => {
      const isOn = scSw.classList.toggle("on");
      try {
        ls.setItem("gust:shortcutsEnabled", isOn ? "1" : "0");
      } catch (e) {}
      applyScState(isOn);
    });
  }, 400);

  // Wire up the Appearance toggle for auto-fullscreen
  setTimeout(() => {
    const sw = document.getElementById("settingsAutoFullscreenSwitch");
    if (!sw) return;
    try {
      if (ls.getItem("gust:autoFullscreen") === "0") sw.classList.remove("on");
      else sw.classList.add("on");
    } catch (e) {}
    sw.addEventListener("click", () => {
      const isOn = sw.classList.toggle("on");
      try {
        ls.setItem("gust:autoFullscreen", isOn ? "1" : "0");
      } catch (e) {}
    });
  }, 400);
  // ─────────────────────────────────────────────────────────────────

  // ─────────────────────────────────────────────────────────────────

  // Wire up Fallback settings
  setTimeout(() => {
    // Toggle switches
    const fallbackSwitches = [
      { id: "fallbackEnabledSwitch", key: "gust:fallback:enabled", def: "1" },
      { id: "fallback5xxSwitch", key: "gust:fallback:5xx", def: "1" },
      { id: "fallbackTimeoutSwitch", key: "gust:fallback:timeout", def: "1" },
      { id: "fallbackDnsSwitch", key: "gust:fallback:dns", def: "0" },
    ];
    fallbackSwitches.forEach(({ id, key, def }) => {
      const sw = document.getElementById(id);
      if (!sw) return;
      try {
        const val = ls.getItem(key);
        if ((val === null ? def : val) === "1") sw.classList.add("on");
        else sw.classList.remove("on");
      } catch (e) {}
      sw.addEventListener("click", () => {
        const isOn = sw.classList.toggle("on");
        try {
          ls.setItem(key, isOn ? "1" : "0");
        } catch (e) {}
      });
    });

    // Fallback WISP URL
    const fbInput = document.getElementById("settingsFallbackWispInput");
    const fbSave = document.getElementById("settingsFallbackWispSave");
    const fbReset = document.getElementById("settingsFallbackWispReset");
    const fbStatus = document.getElementById("settingsFallbackWispStatus");
    if (fbInput) {
      try {
        fbInput.value = ls.getItem("gust:fallback:wisp") || "";
      } catch (e) {}
    }
    if (fbSave) {
      fbSave.addEventListener("click", () => {
        try {
          const v = fbInput ? fbInput.value.trim() : "";
          if (v) ls.setItem("gust:fallback:wisp", v);
          else ls.removeItem("gust:fallback:wisp");
          if (fbStatus) showStatusMsg(fbStatus, "Saved.", "ok");
        } catch (e) {}
      });
    }
    if (fbReset) {
      fbReset.addEventListener("click", () => {
        try {
          ls.removeItem("gust:fallback:wisp");
        } catch (e) {}
        if (fbInput) fbInput.value = "";
        if (fbStatus) showStatusMsg(fbStatus, "Cleared.", "ok");
      });
    }

    // Retry counter helpers
    const makeCounter = (minusId, plusId, valId, key, min, max, def) => {
      const minusBtn = document.getElementById(minusId);
      const plusBtn = document.getElementById(plusId);
      const valEl = document.getElementById(valId);
      if (!minusBtn || !plusBtn || !valEl) return;
      let current = parseInt(
        (() => {
          try {
            return ls.getItem(key);
          } catch (e) {
            return null;
          }
        })() || def,
        10,
      );
      if (isNaN(current)) current = parseInt(def, 10);
      valEl.textContent = current;
      minusBtn.addEventListener("click", () => {
        if (current > min) {
          current--;
          valEl.textContent = current;
          try {
            ls.setItem(key, String(current));
          } catch (e) {}
        }
      });
      plusBtn.addEventListener("click", () => {
        if (current < max) {
          current++;
          valEl.textContent = current;
          try {
            ls.setItem(key, String(current));
          } catch (e) {}
        }
      });
    };
    makeCounter(
      "mainRetryMinus",
      "mainRetryPlus",
      "mainRetryVal",
      "gust:main:retries",
      1,
      10,
      "3",
    );
    makeCounter(
      "fallbackRetryMinus",
      "fallbackRetryPlus",
      "fallbackRetryVal",
      "gust:fallback:retries",
      1,
      10,
      "3",
    );
    makeCounter(
      "fallbackDelayMinus",
      "fallbackDelayPlus",
      "fallbackDelayVal",
      "gust:fallback:delay",
      0,
      30,
      "3",
    );
  }, 400);
  // ─────────────────────────────────────────────────────────────────

  // Wire up User-Agent settings
  setTimeout(() => {
    const DEFAULT_UA =
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    const reqInput = document.getElementById("settingsRequestUA");
    const pageInput = document.getElementById("settingsPageUA");
    const saveBtn = document.getElementById("settingsSaveUA");
    const resetBtn = document.getElementById("settingsResetUA");
    const statusEl = document.getElementById("settingsUAStatus");
    if (!reqInput || !pageInput || !saveBtn) return;

    // Populate from storage
    try {
      reqInput.value = ls.getItem("gust:ua:request:v1") || "";
      pageInput.value = ls.getItem("gust:ua:page:v1") || "";
    } catch (e) {}

    saveBtn.addEventListener("click", () => {
      try {
        const rVal = reqInput.value.trim();
        const pVal = pageInput.value.trim();
        if (rVal) ls.setItem("gust:ua:request:v1", rVal);
        else ls.removeItem("gust:ua:request:v1");
        if (pVal) ls.setItem("gust:ua:page:v1", pVal);
        else ls.removeItem("gust:ua:page:v1");
        if (statusEl) {
          statusEl.textContent = "Saved — reload a page to apply.";
          setTimeout(() => {
            statusEl.textContent = "";
          }, 3000);
        }
      } catch (e) {}
    });

    if (resetBtn) {
      resetBtn.addEventListener("click", () => {
        try {
          ls.removeItem("gust:ua:request:v1");
          ls.removeItem("gust:ua:page:v1");
        } catch (e) {}
        reqInput.value = "";
        pageInput.value = "";
        if (statusEl) {
          statusEl.textContent = "Reset to defaults.";
          setTimeout(() => {
            statusEl.textContent = "";
          }, 3000);
        }
      });
    }
  }, 400);
  // ─────────────────────────────────────────────────────────────────

  init();
})();
//]]>